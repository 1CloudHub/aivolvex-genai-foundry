import React, { useState, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, User, Building, Mail, Phone, Calendar, Users } from 'lucide-react';
import { useNotification } from '../../hooks/useNotification';
import EmailConfirmation from '../../components/ui/EmailConfirmation';
import type { Customer } from '../../CustomerTypes';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbSeparator,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbHome,
} from '../../components/ui/breadcrumb';
import styles from './CustomerRegistration.module.css';

export default function CustomerRegistration() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const mockEvents = [
    { id: '1', name: 'GenAI for Banking Summit', date: '2025-02-15' },
    { id: '2', name: 'Insurance AI Workshop', date: '2025-01-28' }
  ];
  const eventIdFromQuery = searchParams.get('eventId') || mockEvents[0].id;
  const { showNotification } = useNotification();
  const [showEmailConfirmation, setShowEmailConfirmation] = useState(false);
  const [formData, setFormData] = useState({
    // Event Selection
    eventId: eventIdFromQuery,

    // Customer Information
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    jobTitle: '',
    company: '',
    industry: '',
    companySize: '',

    // Additional Info
    interests: [] as string[],
    specialRequests: '',
    howDidYouHear: ''
  });

  const industries = [
    'Banking & Finance', 'Insurance', 'Retail & E-commerce', 'Healthcare',
    'Manufacturing', 'Logistics & Supply Chain', 'Media & Entertainment', 'Government'
  ];

  const companySizes = [
    '1-10 employees', '11-50 employees', '51-200 employees',
    '201-1000 employees', '1000+ employees'
  ];

  const sandboxModules = [
    'PolicyPal Assistant', 'FreightLens', 'Product Vision Search',
    'BankAssist Suite', 'VideoInsight Studio'
  ];

  // Refs for scroll-to-error
  const firstNameRef = useRef<HTMLInputElement>(null);
  const lastNameRef = useRef<HTMLInputElement>(null);
  const emailRef = useRef<HTMLInputElement>(null);
  const phoneRef = useRef<HTMLInputElement>(null);
  const jobTitleRef = useRef<HTMLInputElement>(null);
  const companyRef = useRef<HTMLInputElement>(null);
  const industryRef = useRef<HTMLSelectElement>(null);

  const [errors, setErrors] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    jobTitle: '',
    company: '',
    industry: ''
  });

  const [submitAttempted, setSubmitAttempted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitAttempted(true);
    const newErrors = {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      jobTitle: '',
      company: '',
      industry: ''
    };
    let hasError = false;
    if (!formData.firstName) {
      newErrors.firstName = 'First name is required.';
      hasError = true;
    }
    if (!formData.lastName) {
      newErrors.lastName = 'Last name is required.';
      hasError = true;
    }
    if (!formData.email) {
      newErrors.email = 'Email is required.';
      hasError = true;
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Enter a valid email address (e.g., user@example.com)';
      hasError = true;
    }
    if (!formData.phone) {
      newErrors.phone = 'Phone number is required';
      hasError = true;
    } else if (!/^\d{10}$/.test(formData.phone)) {
      newErrors.phone = 'Enter a valid 10-digit mobile number';
      hasError = true;
    }
    if (!formData.jobTitle) {
      newErrors.jobTitle = 'Job title is required.';
      hasError = true;
    }
    if (!formData.company) {
      newErrors.company = 'Company name is required.';
      hasError = true;
    }
    if (!formData.industry) {
      newErrors.industry = 'Industry is required.';
      hasError = true;
    }
    setErrors(newErrors);
    if (hasError) {
      // Scroll to first error field
      const errorOrder = [
        { key: 'firstName', ref: firstNameRef },
        { key: 'lastName', ref: lastNameRef },
        { key: 'email', ref: emailRef },
        { key: 'phone', ref: phoneRef },
        { key: 'jobTitle', ref: jobTitleRef },
        { key: 'company', ref: companyRef },
        { key: 'industry', ref: industryRef },
      ];
      for (const { key, ref } of errorOrder) {
        if (newErrors[key as keyof typeof newErrors] && ref.current) {
          ref.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
          ref.current.focus();
          break;
        }
      }
      return;
    }
    // Success logic
    setSubmitAttempted(false);
    setErrors({} as any);
    showNotification('success', 'Customer registered successfully!');
    navigate('/reports/customers');
  };

  const handleInterestChange = (module: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(module)
        ? prev.interests.filter(i => i !== module)
        : [...prev.interests, module]
    }));
  };

  const selectedEvent = mockEvents.find(event => event.id === formData.eventId);
  const customerData = {
    name: `${formData.firstName} ${formData.lastName}`,
    email: formData.email,
    company: formData.company,
    eventName: selectedEvent?.name || '',
    eventDate: selectedEvent?.date || ''
  };

  // Field change handlers with live error update after submitAttempted
  const handleFirstNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, firstName: value }));
    if (submitAttempted) {
      setErrors(prev => ({ ...prev, firstName: value ? '' : 'First name is required.' }));
    }
  };
  const handleLastNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, lastName: value }));
    if (submitAttempted) {
      setErrors(prev => ({ ...prev, lastName: value ? '' : 'Last name is required.' }));
    }
  };
  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, email: value }));
    if (submitAttempted) {
      let msg = '';
      if (!value) msg = 'Email is required.';
      else if (!/^\S+@\S+\.\S+$/.test(value)) msg = 'Enter a valid email address (e.g., user@example.com)';
      setErrors(prev => {
        const updated = { ...prev, email: msg };
        console.log('Email error state:', updated); // debug
        return updated;
      });
    }
  };
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, phone: value }));
    if (submitAttempted) {
      let msg = '';
      if (!value) msg = 'Phone number is required';
      else if (!/^\d{10}$/.test(value)) msg = 'Enter a valid 10-digit mobile number';
      setErrors(prev => ({ ...prev, phone: msg }));
    }
  };
  const handleJobTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, jobTitle: value }));
    if (submitAttempted) {
      setErrors(prev => ({ ...prev, jobTitle: value ? '' : 'Job title is required.' }));
    }
  };
  const handleCompanyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, company: value }));
    if (submitAttempted) {
      setErrors(prev => ({ ...prev, company: value ? '' : 'Company name is required.' }));
    }
  };
  const handleIndustryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, industry: value }));
    if (submitAttempted) {
      setErrors(prev => ({ ...prev, industry: value ? '' : 'Industry is required.' }));
    }
  };

  return (
    <div className={styles['space-y-8']}>
      <div className={styles['mb-2']}>
        <Breadcrumb>
          <BreadcrumbList className={`${styles['flex']} ${styles['items-center']} ${styles['text-base']} ${styles['font-semibold']} gap-0`}>
            <BreadcrumbItem>
              <BreadcrumbLink to="/">
                <BreadcrumbHome />
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <span className={`${styles['mx-0.5']} ${styles['text-gray-400']} ${styles['text-lg']} ${styles['font-bold']}`}>/</span>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink to="/events" className={`${styles['text-gray-700']} ${styles['hover:text-orange-600']} ${styles['font-semibold']}`}>Events</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <span className={`${styles['mx-0.5']} ${styles['text-gray-400']} ${styles['text-lg']} ${styles['font-bold']}`}>/</span>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink to="/reports/customers" className={`${styles['text-gray-700']} ${styles['hover:text-orange-600']} ${styles['font-semibold']}`}>Customer Reports</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <span className={`${styles['mx-0.5']} ${styles['text-gray-400']} ${styles['text-lg']} ${styles['font-bold']}`}>/</span>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage className={`${styles['text-orange-600']} ${styles['font-semibold']}`}>Customer Registration</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <h1 className={`${styles['text-3xl']} ${styles['font-medium']} ${styles['text-gray-900']} ${styles['mb-4']}`}>Customer Registration</h1>
      </div>

      <form onSubmit={handleSubmit} className={styles['space-y-8']}>
        {/* Event Selection (hardcoded) */}
        <div className={`${styles['bg-white']} ${styles['rounded-lg']} ${styles['shadow-sm']} ${styles['border']} ${styles['p-6']}`}>
          <h2 className={`${styles['text-xl']} ${styles['font-medium']} ${styles['text-gray-900']} ${styles['mb-6']}`}>
            <Calendar className="h-5 w-5 inline mr-2" />
            Event Selection
          </h2>
          <div>
            <label className={`${styles['block']} ${styles['text-sm']} ${styles['font-medium']} ${styles['text-gray-700']} ${styles['mb-2']}`}>
              Event
            </label>
            <input
              type="text"
              value="GenAI for Banking Summit"
              readOnly
              className={`${styles['w-full']} ${styles['px-3']} ${styles['py-2']} ${styles['border']} ${styles['border-gray-300']} ${styles['rounded-md']} ${styles['bg-gray-100']} ${styles['text-gray-900']} ${styles['cursor-not-allowed']} ${styles['focus:outline-none']}`}
            />
          </div>
        </div>

        {/* Personal Information */}
        <div className={`${styles['bg-white']} ${styles['rounded-lg']} ${styles['shadow-sm']} ${styles['border']} ${styles['p-6']}`}>
          <h2 className={`${styles['text-xl']} ${styles['font-medium']} ${styles['text-gray-900']} ${styles['mb-6']}`}>
            <User className="h-5 w-5 inline mr-2" />
            Personal Information
          </h2>
          <div className={`${styles['grid']} ${styles['grid-cols-1']} ${styles['md:grid-cols-2']} ${styles['gap-6']} ${styles['mt-4']}`}>
            <div>
              <label htmlFor="firstName" className={`${styles['form-label']}`}>First Name *</label>
              <input
                type="text"
                id="firstName"
                ref={firstNameRef}
                className={`${styles['form-control']} ${submitAttempted && errors.firstName ? styles['input-error'] : ''}`}
                value={formData.firstName}
                onChange={handleFirstNameChange}
              />
              {submitAttempted && errors.firstName && <div className={styles['form-error']}>{errors.firstName}</div>}
            </div>

            <div>
              <label htmlFor="lastName" className={`${styles['form-label']}`}>Last Name *</label>
              <input
                type="text"
                id="lastName"
                ref={lastNameRef}
                className={`${styles['form-control']} ${submitAttempted && errors.lastName ? styles['input-error'] : ''}`}
                value={formData.lastName}
                onChange={handleLastNameChange}
              />
              {submitAttempted && errors.lastName && <div className={styles['form-error']}>{errors.lastName}</div>}
            </div>

            <div>
              <label htmlFor="email" className={`${styles['form-label']}`}>Email Address *</label>
              <input
                type="email"
                id="email"
                ref={emailRef}
                className={`${styles['form-control']} ${submitAttempted && errors.email ? styles['input-error'] : ''}`}
                value={formData.email}
                onChange={handleEmailChange}
              />
              {submitAttempted && errors.email && <div className={styles['form-error']}>{errors.email}</div>}
            </div>

            <div>
              <label htmlFor="phone" className={`${styles['form-label']}`}>Phone Number *</label>
              <input
                type="tel"
                id="phone"
                ref={phoneRef}
                className={`${styles['form-control']} ${submitAttempted && errors.phone ? styles['input-error'] : ''}`}
                value={formData.phone}
                onChange={handlePhoneChange}
              />
              {submitAttempted && errors.phone && <div className={styles['form-error']}>{errors.phone}</div>}
            </div>

            <div>
              <label htmlFor="jobTitle" className={`${styles['form-label']}`}>Job Title *</label>
              <input
                type="text"
                id="jobTitle"
                ref={jobTitleRef}
                className={`${styles['form-control']} ${submitAttempted && errors.jobTitle ? styles['input-error'] : ''}`}
                value={formData.jobTitle}
                onChange={handleJobTitleChange}
                placeholder="e.g., VP of Technology"
              />
              {submitAttempted && errors.jobTitle && <div className={styles['form-error']}>{errors.jobTitle}</div>}
            </div>
          </div>
        </div>

        {/* Company Information */}
        <div className={`${styles['bg-white']} ${styles['rounded-lg']} ${styles['shadow-sm']} ${styles['border']} ${styles['p-6']}`}>
          <h2 className={`${styles['text-xl']} ${styles['font-medium']} ${styles['text-gray-900']} ${styles['mb-6']}`}>
            <Building className="h-5 w-5 inline mr-2" />
            Company Information
          </h2>
          <div className={`${styles['grid']} ${styles['grid-cols-1']} ${styles['md:grid-cols-2']} ${styles['gap-6']} ${styles['mt-4']}`}>
            <div>
              <label htmlFor="company" className={`${styles['form-label']}`}>Company Name *</label>
              <input
                type="text"
                id="company"
                ref={companyRef}
                className={`${styles['form-control']} ${submitAttempted && errors.company ? styles['input-error'] : ''}`}
                value={formData.company}
                onChange={handleCompanyChange}
              />
              {submitAttempted && errors.company && <div className={styles['form-error']}>{errors.company}</div>}
            </div>

            <div>
              <label htmlFor="industry" className={`${styles['form-label']}`}>Industry *</label>
              <select
                id="industry"
                ref={industryRef}
                className={`${styles['form-select']} ${submitAttempted && errors.industry ? styles['input-error'] : ''}`}
                value={formData.industry}
                onChange={handleIndustryChange}
              >
                <option value="">Select industry...</option>
                {industries.map((industry) => (
                  <option key={industry} value={industry}>{industry}</option>
                ))}
              </select>
              {submitAttempted && errors.industry && <div className={styles['form-error']}>{errors.industry}</div>}
            </div>

            <div>
              <label htmlFor="companySize" className={`${styles['form-label']}`}>Company Size</label>
              <select
                id="companySize"
                className={styles['form-select']}
                value={formData.companySize}
                onChange={(e) => setFormData(prev => ({ ...prev, companySize: e.target.value }))}
              >
                <option value="">Select size...</option>
                {companySizes.map((size) => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Interests & Preferences */}
        <div className={`${styles['bg-white']} ${styles['rounded-lg']} ${styles['shadow-sm']} ${styles['border']} ${styles['p-6']}`}>
          <h2 className={`${styles['text-xl']} ${styles['font-medium']} ${styles['text-gray-900']} ${styles['mb-6']}`}>Interests & Preferences</h2>
          <div className={`${styles['space-y-6']} ${styles['mt-4']}`}>
            <div>
              <label className={`${styles['form-label']}`}>Sandbox Modules of Interest</label>
              <div className={`${styles['grid']} ${styles['grid-cols-1']} ${styles['md:grid-cols-2']} ${styles['gap-3']}`}>
                {sandboxModules.map((module) => (
                  <label key={module} className={`${styles['flex']} ${styles['items-center']}`}>
                    <input
                      type="checkbox"
                      checked={formData.interests.includes(module)}
                      onChange={() => handleInterestChange(module)}
                      className={`${styles['h-4']} ${styles['w-4']} ${styles['text-orange-500']} ${styles['focus:ring-orange-500']} ${styles['border-gray-300']} ${styles['rounded']}`}
                    />
                    <span className={`${styles['ml-2']} ${styles['text-sm']} ${styles['text-gray-700']}`}>{module}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="howDidYouHear" className={`${styles['form-label']}`}>How did you hear about us?</label>
              <select
                id="howDidYouHear"
                className={styles['form-select']}
                value={formData.howDidYouHear}
                onChange={(e) => setFormData(prev => ({ ...prev, howDidYouHear: e.target.value }))}
              >
                <option value="">Select source...</option>
                <option value="website">Website</option>
                <option value="linkedin">LinkedIn</option>
                <option value="referral">Referral</option>
                <option value="event">Industry Event</option>
                <option value="email">Email Campaign</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label htmlFor="specialRequests" className={`${styles['form-label']}`}>Special Requests or Notes</label>
              <textarea
                id="specialRequests"
                rows={3}
                className={styles['form-control']}
                value={formData.specialRequests}
                onChange={(e) => setFormData(prev => ({ ...prev, specialRequests: e.target.value }))}
                placeholder="Any specific requirements or questions..."
              />
            </div>
          </div>
        </div>

        <div className={`${styles['flex']} ${styles['justify-end']} ${styles['space-x-4']}`}>
          <button
            type="button"
            onClick={() => navigate(-1)}
            className={`${styles['btn-cancel']} ${styles['w-auto']}`}
          >
            Cancel
          </button>
          <button
            type="submit"
            className={`${styles['btn-orange']} ${styles['w-auto']}`}
          >
            Register
          </button>
        </div>
      </form>

      {/* Email Confirmation Modal */}
      {showEmailConfirmation && (
        <EmailConfirmation
          customerData={customerData}
          onClose={() => {
            setShowEmailConfirmation(false);
            navigate('/events');
          }}
        />
      )}
    </div>
  );
}