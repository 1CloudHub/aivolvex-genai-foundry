import React, { useState, useEffect } from 'react';
import { Upload, Button, Card, Image as AntImage, Spin, Typography, Divider, List, message, Row, Col, Breadcrumb, Tag, Tabs } from 'antd';
import { UploadOutlined, SearchOutlined, ShoppingCartOutlined, StarFilled, ThunderboltFilled, HomeOutlined } from '@ant-design/icons';
import { Camera, Headphones, Image, Sparkles, ChevronRight, Footprints, Home } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../../components/layout/LoginNavbar';
import Footer from './RetailFooter';

// Import bucket name from environment
const BUCKET_NAME = import.meta.env.VITE_S3_BUCKET_NAME;

const BotTypingLoader: React.FC = () => (
  <span className="streaming-cursor" style={{
    display: 'inline-block',
    width: '2px',
    height: '1.2em',
    backgroundColor: '#1C6E8C',
    marginLeft: '2px',
    animation: 'cursor-blink 1s infinite'
  }}>
    <style>{`
      @keyframes cursor-blink {
        0%, 50% { opacity: 1; }
        51%, 100% { opacity: 0; }
      }
    `}</style>
  </span>
);

const { Title, Text } = Typography;

const RetailProductSearch = () => {
    const [loading, setLoading] = useState(false);
    const [loadingType, setLoadingType] = useState<'text' | 'image' | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredResults, setFilteredResults] = useState<any[]>([]);
    const [showUploadGallery, setShowUploadGallery] = useState(false);
    const [selectedSampleImage, setSelectedSampleImage] = useState<string | null>(null);
    const [uploadedImagePreview, setUploadedImagePreview] = useState<string | null>(null);
    const [showImageModal, setShowImageModal] = useState(false);
    const navigate = useNavigate();

    const allProducts = [
                {
                    id: 1,
                    name: "HyperX Cloud Stinger 2 Core Gaming Headset",
                    price: 29.22,
                    rating: 4.5,
                    image: "/VisualProductSearch/headphone1.jpg",
                    matches: 100,
            description: "40mm sound drivers with powerful bass and wide frequency response.",
            category: "headphone",
            color: "black"
                },
                {
                    id: 2,
                    name: "Sennheiser HD 599 Special Edition",
                    price: 105.13,
                    rating: 4.2,
                    image: "/VisualProductSearch/headphone2.jpg",
                    matches: 87,
            description: "Premium open-back headphones with outstanding natural spatial performance.",
            category: "headphone",
            color: "black"
                },
                {
                    id: 3,
                    name: "Razer Blackshark V2 X Gaming Headset",
                    price: 37.02,
                    rating: 4.7,
                    image: "/VisualProductSearch/headphone3.jpg",
                    matches: 85,
            description: "7.1 Surround Sound with custom-tuned 50mm drivers.",
            category: "headphone",
            color: "black"
        },
                {
                    id: 4,
                    name: "Skechers Women's Hands Free Slip-ins Glide- Step - Excite Sneaker",
                    price: 63.00,
                    rating: 4.8,
                    image: "/VisualProductSearch/shoe1.jpg",
                    matches: 95,
            description: "Hands Free Slip-In Technology,Breathable leather lining,Flexible outsole",
            category: "shoe",
            color: "blue"
                },
                {
                    id: 5,
                    name: "Glolily Elle Slip-On Women's Comfort Sneakers",
                    price: 39.99,
                    rating: 4.6,
                    image: "/VisualProductSearch/shoe2.jpg",
                    matches: 90,
            description: "Orthotic Lightweight & Flexible Walking Shoes with Arch Support, Comfortable Casual Fashion Shoes for Women.",
            category: "shoe",
            color: "blue"
                },
                {
                    id: 6,
                    name: "Feethit Womens Slip On Walking Shoes ",
                    price: 36.99,
                    rating: 4.4,
                    image: "/VisualProductSearch/shoe3.jpg",
                    matches: 88,
            description: "Non Slip Running Shoes Breathable Workout Shoes Lightweight Gym Sneakers.",
            category: "shoe",
            color: "blue"
        },
                {
                    id: 7,
                    name: "Canon EOS Rebel T7 DSLR Camera with 18-55mm Lens | Built-in Wi-Fi | 24.1 MP CMOS Sensor",
                    price: 350.00,
                    rating: 4.7,
                    image: "/VisualProductSearch/camera1.jpg",
                    matches: 93,
            description: " 24.1 MP CMOS Sensor | DIGIC 4+ Image Processor and Full HD Videos",
            category: "camera",
            color: "black"
                },
                {
                    id: 8,
                    name: "NIkon COOLPIX P950 Superzoom Digital Camera ",
                    price: 479.00,
                    rating: 4.5,
                    image: "/VisualProductSearch/camera2.jpg",
                    matches: 91,
            description: "83x Optical Zoom with Image Stabilization 16 MP 4K Ultra HD Video Wi-Fi Connectivity RAW Format and Rotating LCD Screen (Black)",
            category: "camera",
            color: "black"
                },
                {
                    id: 9,
                    name: "Sony Alpha 7 IV Full-frame Mirrorless Interchangeable Lens Camera",
                    price: 556.95,
                    rating: 4.6,
                    image: "/VisualProductSearch/camera3.jpg",
                    matches: 89,
            description: "33MP full-frame Exmor R back-illuminated CMOS sensor.",
            category: "camera",
            color: "black"
        }
    ];

    const sampleImages = [
        {
            id: 'headphone1',
            image: "/VisualProductSearch/headphone1.jpg",
            category: "Headphones",
            name: "Gaming Headset"
        },
        {
            id: 'headphone2',
            image: "/VisualProductSearch/headphone2.jpg",
            category: "Headphones",
            name: "Premium Headphones"
        },
        {
            id: 'headphone3',
            image: "/VisualProductSearch/headphone3.jpg",
            category: "Headphones",
            name: "Gaming Headset Pro"
        },
        {
            id: 'shoe1',
            image: "/VisualProductSearch/shoe1.jpg",
            category: "Shoes",
            name: "Comfort Sneakers"
        },
        {
            id: 'shoe2',
            image: "/VisualProductSearch/shoe2.jpg",
            category: "Shoes",
            name: "Slip-on Shoes"
        },
        {
            id: 'shoe3',
            image: "/VisualProductSearch/shoe3.jpg",
            category: "Shoes",
            name: "Running Shoes"
        },
        {
            id: 'camera1',
            image: "/VisualProductSearch/camera1.jpg",
            category: "Cameras",
            name: "DSLR Camera"
        },
        {
            id: 'camera2',
            image: "/VisualProductSearch/camera2.jpg",
            category: "Cameras",
            name: "Digital Camera"
        },
        {
            id: 'camera3',
            image: "/VisualProductSearch/camera3.jpg",
            category: "Cameras",
            name: "Mirrorless Camera"
        }
    ];

    useEffect(() => {
        // Initialize with all products
        setFilteredResults(allProducts);
    }, []);

    const handleSearch = async (query: string) => {
        console.log('handleSearch called with query:', query);
        if (!query.trim()) {
            console.log('Query is empty, returning');
            return;
        }
        
        setSearchQuery(query);
        setLoading(true);
        setLoadingType('text');
        
        // Clear previous results when starting new search
        setFilteredResults([]);
        
        try {
            const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    event_type: "visual_product_search",
                    search_type: "text",
                    search_query: query
                })
            });

            if (!response.ok) {
                throw new Error('API request failed');
            }

            const data = await response.json();
            const apiResults = JSON.parse(data.body);
            
            // Dynamic S3 URI to local image path mapping
            const getLocalImagePath = (s3Uri: string): string => {
                // Extract filename from S3 URI (e.g., "headphone1.jpg" from "s3://bucket/visualproductsearch/headphone1.jpg")
                const filename = s3Uri.split('/').pop() || '';
                return `/VisualProductSearch/${filename}`;
            };

            // Transform API results to match our product format and limit to 3 results
            const transformedResults = apiResults.results.slice(0, 3).map((result: any, index: number) => {
                const localImagePath = getLocalImagePath(result.s3_uri);
                const category = result.s3_uri.includes('headphone') ? 'headphone' : 
                               result.s3_uri.includes('shoe') ? 'shoe' : 
                               result.s3_uri.includes('camera') ? 'camera' : 'other';
                
                // Find matching product from allProducts based on image path
                const matchingProduct = allProducts.find(product => product.image === localImagePath);
                
                // Convert score to percentage - scores are already in decimal format (0-1)
                let matchPercentage = Math.round(result.score * 100);
                
                return {
                    id: index + 1,
                    name: matchingProduct?.name || 'Product',
                    price: matchingProduct?.price || Math.floor(Math.random() * 200) + 20,
                    rating: matchingProduct?.rating || (Math.random() * 2 + 3).toFixed(1),
                    image: localImagePath || '/VisualProductSearch/headphone1.jpg',
                    matches: matchPercentage,
                    description: matchingProduct?.description || 'Product description',
                    category: matchingProduct?.category || category,
                    color: matchingProduct?.color || (category === 'headphone' ? 'black' : category === 'shoe' ? 'blue' : 'black')
                };
            });
            
            setFilteredResults(transformedResults);
        } catch (error) {
            console.error('Search API error:', error);
            // Fallback to local search if API fails
            const filtered = allProducts.filter(product => {
                const searchTerm = query.toLowerCase();
                const productText = `${product.color} ${product.category}`.toLowerCase();
                const productName = product.name.toLowerCase();
                
                return productText.includes(searchTerm) || 
                       productName.includes(searchTerm) ||
                       searchTerm.includes(product.color) ||
                       searchTerm.includes(product.category);
            });
            setFilteredResults(filtered);
        } finally {
            setLoading(false);
            setLoadingType(null);
        }
    };

    const handleImageUpload = (sampleImage: any) => {
        setSelectedSampleImage(sampleImage.id);
        setUploadedImagePreview(sampleImage.image);
        setShowUploadGallery(false);
        // Clear results when image is selected
        setFilteredResults([]);
    };

    const handlePromptChipClick = (text: string) => {
        setSearchQuery(text);
        // Focus the input field after setting the query
        setTimeout(() => {
            const inputElement = document.querySelector('input[type="text"]') as HTMLInputElement;
            if (inputElement) {
                inputElement.focus();
            }
        }, 100);
    };

    const handleImageSearch = async () => {
        if (!uploadedImagePreview) return;
        
        setLoading(true);
        setLoadingType('image');
        
        // Clear previous results when starting new search
        setFilteredResults([]);
        
        try {
            // Get the selected sample image
            const selectedSample = sampleImages.find(img => img.id === selectedSampleImage);
            
            if (!selectedSample) {
                throw new Error('No image selected');
            }
            
            // Map local image path to S3 URI
            const localToS3Map: { [key: string]: string } = {
                '/VisualProductSearch/headphone1.jpg': `s3://${BUCKET_NAME}/visualproductsearch/headphone1.jpg`,
                '/VisualProductSearch/headphone2.jpg': `s3://${BUCKET_NAME}/visualproductsearch/headphone2.jpg`,
                '/VisualProductSearch/headphone3.jpg': `s3://${BUCKET_NAME}/visualproductsearch/headphone3.jpg`,
                '/VisualProductSearch/shoe1.jpg': `s3://${BUCKET_NAME}/visualproductsearch/shoe1.jpg`,
                '/VisualProductSearch/shoe2.jpg': `s3://${BUCKET_NAME}/visualproductsearch/shoe2.jpg`,
                '/VisualProductSearch/shoe3.jpg': `s3://${BUCKET_NAME}/visualproductsearch/shoe3.jpg`,
                '/VisualProductSearch/camera1.jpg': `s3://${BUCKET_NAME}/visualproductsearch/camera1.jpg`,
                '/VisualProductSearch/camera2.jpg': `s3://${BUCKET_NAME}/visualproductsearch/camera2.jpg`,
                '/VisualProductSearch/camera3.jpg': `s3://${BUCKET_NAME}/visualproductsearch/camera3.jpg`
            };
            
            const imageS3Uri = localToS3Map[selectedSample.image];
            
            if (!imageS3Uri) {
                throw new Error('Image S3 URI not found');
            }
            
            const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    event_type: "visual_product_search",
                    search_type: "image",
                    image_s3_uri: imageS3Uri
                })
            });

            if (!response.ok) {
                throw new Error('API request failed');
            }

            const data = await response.json();
            const apiResults = JSON.parse(data.body);
            
            // Dynamic S3 URI to local image path mapping
            const getLocalImagePath = (s3Uri: string): string => {
                // Extract filename from S3 URI (e.g., "headphone1.jpg" from "s3://bucket/visualproductsearch/headphone1.jpg")
                const filename = s3Uri.split('/').pop() || '';
                return `/VisualProductSearch/${filename}`;
            };

            // Transform API results to match our product format and limit to 3 results
            const transformedResults = apiResults.results.slice(0, 3).map((result: any, index: number) => {
                const localImagePath = getLocalImagePath(result.s3_uri);
                const category = result.s3_uri.includes('headphone') ? 'headphone' : 
                               result.s3_uri.includes('shoe') ? 'shoe' : 
                               result.s3_uri.includes('camera') ? 'camera' : 'other';
                
                // Find matching product from allProducts based on image path
                const matchingProduct = allProducts.find(product => product.image === localImagePath);
                
                // Convert score to percentage - scores are already in decimal format (0-1)
                let matchPercentage = Math.round(result.score * 100);
                
                return {
                    id: index + 1,
                    name: matchingProduct?.name || 'Product',
                    price: matchingProduct?.price || Math.floor(Math.random() * 200) + 20,
                    rating: matchingProduct?.rating || (Math.random() * 2 + 3).toFixed(1),
                    image: localImagePath || '/VisualProductSearch/headphone1.jpg',
                    matches: matchPercentage,
                    description: matchingProduct?.description || 'Product description',
                    category: matchingProduct?.category || category,
                    color: matchingProduct?.color || (category === 'headphone' ? 'black' : category === 'shoe' ? 'blue' : 'black')
                };
            });
            
            setFilteredResults(transformedResults);
        } catch (error) {
            console.error('Image search API error:', error);
            // Fallback to local search if API fails
            const categoryMapping: { [key: string]: string } = {
                'Headphones': 'headphone',
                'Shoes': 'shoe',
                'Cameras': 'camera',
                'Electronics': 'camera',
                'Accessories': 'shoe'
            };
            
            const selectedSample = sampleImages.find(img => img.id === selectedSampleImage);
            if (selectedSample) {
                const targetCategory = categoryMapping[selectedSample.category];
                const filtered = allProducts.filter(product => 
                    product.category === targetCategory
                );
                setFilteredResults(filtered);
            }
        } finally {
            setLoading(false);
            setLoadingType(null);
        }
    };

    const renderRating = (rating: number) => {
        return (
            <div className="flex items-center bg-blue-50 px-2 py-1 rounded">
                <StarFilled className="text-yellow-400 mr-1" />
                <Text className="text-sm font-medium">{rating}</Text>
            </div>
        );
    };

    const renderMatchPercentage = (percentage: number) => {
        let color = '';
        if (percentage >= 90) color = 'green';
        else if (percentage >= 80) color = 'blue';
        else color = 'orange';
        
        return (
            <Tag color={color} className="text-xs font-medium">
                {percentage}% match
            </Tag>
        );
    };

    return (
        <>
        <Navbar/>
        
        <style>
            {`
                .custom-tabs .ant-tabs-tab.ant-tabs-tab-active .ant-tabs-tab-btn {
                    color: rgb(232 119 34) !important;
                }
                .custom-tabs .ant-tabs-ink-bar {
                    background: rgb(232 119 34) !important;
                }
                .custom-tabs .ant-tabs-tab:hover .ant-tabs-tab-btn {
                    color: rgb(232 119 34) !important;
                }
            `}
        </style>
        
        <div className="min-h-screen bg-gray-50">
            
            <main className="flex-grow">
                <div className="max-w-6xl mx-auto px-6 py-8">
                 

                    <nav className="flex text-sm text-gray-500 mb-2 -ml-5" aria-label="Breadcrumb">
                      <ol className="inline-flex items-center space-x-1">
                        <li>
                          <button 
                            type="button" 
                            onClick={() => navigate('/customer/sandbox/retailhome')} 
                            className="flex items-center text-gray-500 hover:text-gray-700"
                            style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
                          >
                            <Home size={16} className="mr-1" />
                            Home
                          </button>
                        </li>
                        <li>
                          <span className="mx-2">/</span>
                          <span className="text-orange-600 font-medium">Visual Product Search</span>
                        </li>
                      </ol>
                    </nav>
                    <div className="flex items-center gap-6 mb-8">
                        <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
                            <Image className="h-8 w-8 text-primary" />
                        </div>
                        <div style={{marginTop: '2rem'}}>
                            <h1 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
                                Visual Product Search
                            </h1>
                            <p className="text-base text-gray-600">
                                Find similar products using visual search technology that analyzes features and matches against similar products
                            </p>
                        </div>
                    </div>

                    {/* Search Bar */}
                    <div className="mb-8">
                        <div className="relative max-w-6xl mx-auto">
                            <div className="relative bg-white rounded-xl p-4" style={{boxShadow: '0 0 3px 0 rgba(0, 0, 0, 0.1)'}}>
                                <div className="flex items-center gap-4">
                                    {/* Search Input */}
                                    <div className="flex-1 relative">
                                        <input
                                            type="text"
                                            placeholder={uploadedImagePreview ? "Press Enter or click search to find similar products" : "Ask anything"}
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            onKeyPress={(e) => {
                                                if (e.key === 'Enter') {
                                                    console.log('Enter pressed, searchQuery:', searchQuery);
                                                    if (uploadedImagePreview) {
                                                        handleImageSearch();
                                                    } else {
                                                        handleSearch(searchQuery);
                                                    }
                                                }
                                            }}
                                            disabled={!!uploadedImagePreview || loading}
                                            className={`w-full bg-gray-100 rounded-lg px-4 py-3 text-lg border-0 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors pr-20 ${
                                                uploadedImagePreview || loading ? 'opacity-50 cursor-not-allowed' : ''
                                            }`}
                                        />
                                        {uploadedImagePreview && (
                                            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center gap-2">
                                                <button
                                                    onClick={() => setShowImageModal(true)}
                                                    className="w-8 h-8 rounded overflow-hidden hover:opacity-80 transition-opacity flex-shrink-0 bg-gray-100 border border-gray-200"
                                                >
                                                    <AntImage
                                                        src={uploadedImagePreview}
                                                        alt="Uploaded image"
                                                        className="w-full h-full object-contain"
                                                        preview={false}
                                                    />
                                                </button>
                                                <button
                                                    onClick={() => {
                                                        setSearchQuery('');
                                                        setSelectedSampleImage(null);
                                                        setUploadedImagePreview(null);
                                                        setFilteredResults([]);
                                                    }}
                                                    className="text-gray-400 hover:text-gray-600 transition-colors"
                                                >
                                                    <span className="text-xl">×</span>
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                    
                                    {/* Right Side Icons */}
                                    <div className="flex items-center gap-3">
                                        {/* Plus Icon */}
                                        <button
                                            onClick={() => setShowUploadGallery(true)}
                                            disabled={!!searchQuery.trim() || loading}
                                            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                                                searchQuery.trim() || loading
                                                    ? 'bg-gray-400 cursor-not-allowed' 
                                                    : 'bg-orange-500 hover:bg-orange-600'
                                            }`}
                                        >
                                            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                            </svg>
                                        </button>
                                        
                                        {/* Search Button (Up Arrow) */}
                                        <div className="relative">
                                            <button
                                                onClick={() => {
                                                    if (uploadedImagePreview) {
                                                        handleImageSearch();
                                                    } else if (searchQuery.trim()) {
                                                        handleSearch(searchQuery);
                                                    }
                                                }}
                                                disabled={(!searchQuery.trim() && !uploadedImagePreview) || loading}
                                                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                                                    (!searchQuery.trim() && !uploadedImagePreview) || loading
                                                        ? 'bg-gray-400 cursor-not-allowed' 
                                                        : uploadedImagePreview
                                                        ? 'bg-orange-500 hover:bg-orange-600 animate-pulse'
                                                        : 'bg-orange-500 hover:bg-orange-600'
                                                }`}
                                            >
                                                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                                                </svg>
                                            </button>
                                            
                                            {/* Popup Message */}
                                            {uploadedImagePreview && !loading && (
                                                <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-white text-orange-500 text-xs px-3 py-2 rounded-lg whitespace-nowrap z-10 shadow-lg border border-orange-200">
                                                    Click to search the image
                                                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-white"></div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                                
                                {/* Quick Reply Suggestions - Now inside the card */}
                                <div className="mt-4 pt-4 border-t border-gray-100">
                                    <div
                                        style={{
                                            display: 'flex',
                                            gap: '8px',
                                            overflowX: 'auto',
                                            paddingBottom: '8px',
                                            WebkitOverflowScrolling: 'touch'
                                        }}
                                        className="faq-scroll"
                                    >
                                        {[
                                            "Black headsets",
                                            "Blue shoes",
                                            "Green gaming headset",
                                            "Beige Colored shoes",
                                            "DSLR camera",
                                            "Mirrorless camera",
                                            "Wireless headphones",
                                            "Running shoes"
                                        ].map((prompt, idx) => (
                                            <button
                                                key={idx}
                                                className="btn btn-outline-secondary"
                                                disabled={loading}
                                                style={{
                                                    borderRadius: '8px',
                                                    fontSize: '13px',
                                                    fontWeight: '500',
                                                    padding: '8px 16px',
                                                    whiteSpace: 'nowrap',
                                                    border: '1px solid #e9ecef',
                                                    color: loading ? '#ccc' : '#e87722',
                                                    backgroundColor: 'white',
                                                    minWidth: 'fit-content',
                                                    opacity: loading ? 0.5 : 1,
                                                    cursor: loading ? 'not-allowed' : 'pointer'
                                                }}
                                                onClick={() => !loading && handlePromptChipClick(prompt)}
                                                onMouseEnter={(e) => {
                                                    if (!loading) {
                                                        e.currentTarget.style.backgroundColor = '#f8f9fa';
                                                        e.currentTarget.style.borderColor = '#e87722';
                                                        e.currentTarget.style.color = '#e87722';
                                                    }
                                                }}
                                                onMouseLeave={(e) => {
                                                    if (!loading) {
                                                        e.currentTarget.style.backgroundColor = 'white';
                                                        e.currentTarget.style.borderColor = '#e9ecef';
                                                        e.currentTarget.style.color = '#e87722';
                                                    }
                                                }}
                                            >
                                                {prompt}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Upload Gallery Modal */}
                    {showUploadGallery && (
                        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                            <div className="bg-white rounded-lg max-w-4xl w-full max-h-[80vh] overflow-y-auto">
                                <div className="p-6 border-b border-gray-200">
                                    <div className="flex items-center justify-between">
                                        <h3 className="text-xl font-semibold text-gray-800">Select Sample Image</h3>
                                        <button
                                            onClick={() => setShowUploadGallery(false)}
                                            className="text-gray-400 hover:text-gray-600"
                                        >
                                            <span className="text-2xl">×</span>
                                        </button>
                                    </div>
                                    <p className="text-gray-600 mt-2">Choose a sample image to find similar products</p>
                                </div>
                                <div className="p-6">
                                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                                        {sampleImages.map((sample) => (
                                <Card
                                                key={sample.id}
                                    hoverable
                                                className={`transition-all duration-200 cursor-pointer ${
                                                    selectedSampleImage === sample.id 
                                                        ? 'border-2 border-orange-500' 
                                                        : 'border border-gray-200'
                                                }`}
                                                onClick={() => handleImageUpload(sample)}
                                >
                                    <div className="flex flex-col items-center text-center">
                                                    <div className="w-full h-32 mb-3 flex items-center justify-center bg-gray-50 rounded-lg overflow-hidden">
                                                        <AntImage
                                                            src={sample.image}
                                                            alt={sample.name}
                                                            className="max-w-full max-h-full object-contain"
                                                            preview={false}
                                                        />
                                        </div>
                                                    <h4 className="font-medium text-gray-800 text-sm mb-1">{sample.name}</h4>
                                                    <p className="text-xs text-gray-500">{sample.category}</p>
                                    </div>
                                </Card>
                            ))}
                        </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Image Preview Modal */}
                    {showImageModal && uploadedImagePreview && (
                        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
                                <div className="p-6 border-b border-gray-200">
                                    <div className="flex items-center justify-between">
                                        <h3 className="text-xl font-semibold text-gray-800">Uploaded Image</h3>
                                        <button
                                            onClick={() => setShowImageModal(false)}
                                            className="text-gray-400 hover:text-gray-600"
                                        >
                                            <span className="text-2xl">×</span>
                                        </button>
                                    </div>
                                </div>
                                <div className="p-6">
                                    <div className="flex justify-center">
                                        <div className="max-w-full rounded-lg">
                                            <AntImage
                                                src={uploadedImagePreview}
                                                alt="Uploaded image"
                                                className="max-w-full object-contain"
                                                preview={false}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                                    </div>
                                )}



                    {/* Two Column Layout */}
                    <Row gutter={[24, 24]}>
                        {/* Search Results - Left 70% */}
                        <Col xs={24} lg={17}>
                            <Card className="border-0 shadow-sm" style={{ height: '500px' }}>
                                <div className="flex items-center justify-between mb-4">
                                    <div className="flex items-center">
                                        <SearchOutlined className="!text-[#e87722] mr-2" style={{marginTop: '-5px'}}/>
                                        <h2 className="text-lg font-semibold text-gray-800">Search Results</h2>
                                    </div>
                                    {filteredResults.length > 0 && filteredResults.length < allProducts.length && (
                                        <button
                                            onClick={() => {
                                                setSearchQuery('');
                                                setSelectedSampleImage(null);
                                                setUploadedImagePreview(null);
                                                setFilteredResults(allProducts);
                                            }}
                                            className="btn btn-outline-primary btn-sm px-3 py-1"
                                            style={{ 
                                                borderRadius: '8px',
                                                fontSize: '11px',
                                                fontWeight: '500',
                                                borderColor: '#e87722',
                                                color: '#e87722',
                                                backgroundColor: 'transparent'
                                            }}
                                        >
                                            Clear Results
                                        </button>
                                    )}
                                </div>
                                {loading ? (
                                    <div className="flex items-center justify-center" style={{ height: '430px' }}>
                                        <div className="text-center">
                                            <div className="mb-4">
                                                <div className="spinner-border me-1" role="status" style={{ width: '32px', height: '32px', color: '#e87722' }}></div>
                                            </div>
                                            <div className="text-sm text-gray-500">
                                                {loadingType === 'image' ? "Analyzing image and finding similar products..." : "Searching products..."}
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="h-[400px] overflow-y-auto pr-2">
                                        {filteredResults.length > 0 ? (
                                        <List
                                            itemLayout="vertical"
                                                dataSource={filteredResults}
                                            renderItem={(product) => (
                                                <List.Item className="!py-4 !px-0">
                                                    <Card hoverable className="border border-gray-100 shadow-xs">
                                                        <div className="flex flex-col sm:flex-row gap-4">
                                                            <div className="w-full sm:w-1/3">
                                                                <div className="relative">
                                                                        <AntImage
                                                                        src={product.image}
                                                                        alt={product.name}
                                                                        className="rounded-lg w-full"
                                                                        preview={false}
                                                                    />
                                                                    <div className="absolute top-2 right-2">
                                                                        {renderMatchPercentage(product.matches)}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="w-full sm:w-2/3">
                                                                    <h3 className="font-medium text-gray-800 mb-2" style={{fontSize: 'medium'}}>{product.name}</h3>
                                                                <p className="text-gray-600 text-sm mb-3">{product.description}</p>
                                                                <div className="flex justify-between items-center">
                                                                    <p className="text-lg font-bold text-blue-600">${product.price}</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </Card>
                                                </List.Item>
                                            )}
                                        />
                                        ) : (
                                            <div className="flex items-center justify-center h-full">
                                                <div className="text-center">
                                                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                                        <SearchOutlined className="text-2xl text-gray-400" />
                                                    </div>
                                                    <h3 className="text-lg font-medium text-gray-500 mb-2">No products found</h3>
                                                    <p className="text-sm text-gray-400">
                                                        Try searching for "black headphones", "blue shoes", or "black camera"
                                                    </p>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </Card>
                        </Col>

                        {/* Feature Card - Right 30% */}
                        <Col xs={24} lg={7}>
                            <Card className="border-0 shadow-sm bg-gradient-to-br from-orange-50 to-orange-100" style={{ height: '500px' }}>
                                <div className="text-center mb-4">
                                    <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                                        <Image className="w-6 h-6 text-white" />
                                    </div>
                                    <h3 className="text-lg font-bold text-gray-800 mb-1">Product Vision Search</h3>
                                    <p className="text-gray-600 text-xs">Advanced visual search capabilities</p>
                                </div>
                                
                                <div className="space-y-3">
                                    <div className="flex items-start space-x-3">
                                        <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                            <span className="text-white text-xs">✓</span>
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-gray-800 text-sm">Color-Based Search</h4>
                                            <p className="text-gray-600 text-xs">Find products by specific colors</p>
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-start space-x-3">
                                        <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                            <span className="text-white text-xs">✓</span>
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-gray-800 text-sm">Category Filtering</h4>
                                            <p className="text-gray-600 text-xs">Filter by product categories</p>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    <div className="flex items-start space-x-3">
                                        <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                            <span className="text-white text-xs">✓</span>
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-gray-800 text-sm">Real-time Results</h4>
                                            <p className="text-gray-600 text-xs">Instant product matching</p>
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-start space-x-3">
                                        <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                            <span className="text-white text-xs">✓</span>
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-gray-800 text-sm">Match Percentage</h4>
                                            <p className="text-gray-600 text-xs">See how well products match</p>
                                        </div>
                                    </div>
                                </div>
                            </Card>
                        </Col>
                    </Row>
                </div>
            </main>

            <Footer/>
        </div>
        </>
    );
};

export default RetailProductSearch;