export interface PromptChip {
  text: string;
  category: string;
}

export interface AnalyticsData {
  totalConversations: number;
  averageResponseTime: number;
  customerSatisfaction: number;
  topQueries: string[];
}

export const promptChips: PromptChip[] = [
  { text: "What products do you have?", category: "products" },
  { text: "Can you help me find a specific item?", category: "search" },
  { text: "What are your return policies?", category: "policies" },
  { text: "Do you have any ongoing promotions?", category: "promotions" },
  { text: "How can I track my order?", category: "orders" },
  { text: "What payment methods do you accept?", category: "payment" }
];

export const sampleConversation = [
  {
    id: 1,
    sender: 'user',
    message: "Hi, I'm looking for a new smartphone. Can you help me?"
  },
  {
    id: 2,
    sender: 'bot',
    message: "Hello! I'd be happy to help you find the perfect smartphone. What's your budget range and what features are most important to you?"
  },
  {
    id: 3,
    sender: 'user',
    message: "I'm looking for something under $500 with a good camera."
  },
  {
    id: 4,
    sender: 'bot',
    message: "Great! I have several options for you under $500 with excellent cameras. Here are our top recommendations:\n\n1. **Samsung Galaxy A54** - $449\n   - 50MP main camera\n   - 6.4\" AMOLED display\n   - 128GB storage\n\n2. **Google Pixel 6a** - $399\n   - 12.2MP dual camera\n   - Google's AI photography\n   - 6.1\" OLED display\n\n3. **OnePlus Nord N30** - $299\n   - 108MP main camera\n   - 6.7\" LCD display\n   - 128GB storage\n\nWould you like me to show you more details about any of these models?"
  }
];

export const whatsAppPreview = {
  title: "Retail Assistant Summary",
  content: "Your shopping session summary:\n\n• Products viewed: 3 smartphones\n• Price range: $299-$449\n• Recommendations provided: Samsung Galaxy A54, Google Pixel 6a, OnePlus Nord N30\n• Next steps: Detailed comparison or purchase assistance"
};

export const analyticsData: AnalyticsData = {
  totalConversations: 1247,
  averageResponseTime: 2.3,
  customerSatisfaction: 4.8,
  topQueries: [
    "Product recommendations",
    "Price comparisons", 
    "Return policies",
    "Order tracking",
    "Payment options"
  ]
}; 