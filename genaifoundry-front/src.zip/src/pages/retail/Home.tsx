import React, { useState } from 'react';
import { Row, Col } from 'antd';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, FileText, Image, Sparkles, ShoppingBag } from 'lucide-react';
import LoginNavbar from '../../components/layout/LoginNavbar';
import RetailFooter from './RetailFooter';
import HomeCard from '../../components/ui/HomeCard';

const GenAISandboxHome = () => {
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');

const solutions = [
  {
    title: 'Customer Service Assistant',
    area: 'Retail',
    icon: <MessageSquare size={24} />,
    description: 'AI-powered chatbot for retail customers that handles product FAQs, shipping policies, returns, and order tracking using intelligent knowledge base integration.',
    buttonText: 'Try Now',
    tags: ['Customer Service', 'Order Tracking'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '💬',
      heading: 'Customer Service Assistant',
      subheading: 'AI Chatbot for Retail Services',
      points: [
        'Track order status and delivery updates',
        'Process return requests and cancellations',
        'Check product availability and pricing',
      ]
    }
  },
  {
    title: 'Intelligent Document Processing',
    area: 'Operations',
    icon: <FileText size={24} />,
    description: 'Automated document processing that extracts key data from invoices and performs three-way matching (PO, GRN, Invoice) to flag discrepancies automatically.',
    buttonText: 'Try Now',
    tags: ['Automation', 'Invoices', 'Matching'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📄',
      heading: 'Intelligent Document Processing',
      subheading: 'Automated Invoice & Document Analysis',
      points: [
        'Extract key data from invoices automatically',
        'Perform three-way matching (PO, GRN, Invoice)',
        'Flag discrepancies and mismatches',
      ]
    }
  },
  {
    title: 'Visual Product Search',
    area: 'Customer Experience',
    icon: <Image size={24} />,
    description: 'Multimodal search that allows customers to find products using text, images, or both. Combines semantic search with visual matching for accurate product discovery.',
    buttonText: 'Explore',
    tags: ['Search', 'Multimodal'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🔍',
      heading: 'Visual Product Search',
      subheading: 'Multimodal Product Discovery',
      points: [
        'Search products using text or images',
        'Semantic matching for better results',
        'Combine visual and text search',
        'Find similar products instantly'
      ]
    }
  },
  {
    title: 'Product Optimization Assistant',
    area: 'Marketing',
    icon: <Sparkles size={24} />,
    description: 'AI-powered tool that generates optimized product listings from images and analyzes customer reviews to extract sentiment, pros/cons, and improvement insights for better SEO and product development.',
    buttonText: 'Try Now',
    tags: ['Optimization', 'SEO', 'Reviews'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '✨',
      heading: 'Product Optimization Assistant',
      subheading: 'AI-Powered Product Enhancement',
      points: [
        'Generate optimized product listings',
        'Analyze customer reviews and sentiment',
        'Extract product improvement insights',
        'Enhance SEO and discoverability'
      ]
    }
  },
  {
    title: 'Visual Content & Virtual Try-On',
    area: 'Customer Experience',
    icon: <ShoppingBag size={24} />,
    description: 'AI-powered content generation that transforms product photos into lifestyle imagery and promotional videos, plus virtual try-on technology for garments using uploaded body images.',
    buttonText: 'Try Now',
    tags: ['Content', 'Try-On'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '👕',
      heading: 'Visual Content & Virtual Try-On',
      subheading: 'AI-Generated Content & Virtual Fitting',
      points: [
        'Generate lifestyle product imagery',
        'Create promotional videos automatically',
        'Virtual try-on for clothing items',
        'Enhance product visualization'
      ]
    }
  },

];

    // Navigation handler for Retail solutions
    const handleRetailNavigation = (solution: any) => {
      switch (solution.title) {
        case "Customer Service Assistant":
          navigate('/customer/sandbox/retailhome/retail-assistant');
          break;
        case "Intelligent Document Processing":
          navigate('/customer/sandbox/retailhome/document-processing');
          break;
        case "Visual Product Search":
          navigate('/customer/sandbox/retailhome/visual-product-search');
          break;
        case "Product Optimization Assistant":
          navigate('/customer/sandbox/retailhome/product-optimization');
          break;
        case "Visual Content & Virtual Try-On":
          navigate('/customer/sandbox/retailhome/visual-content-virtual-tryon');
          break;
        default:
          // Handle default case or external links
          break;
      }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {/* Login Navbar */}
            <LoginNavbar />
            {/* Spacing below navbar */}
            <div className="flex-grow px-15 mx-auto py-3">
                {/* Header Section - Matching the image */}
                <div className="text-center">
                    <div className="flex flex-col items-center justify-center mt-8 mb-2">
                        <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                            <span style={{ color: '#e87722' }}>GenAI</span>
                            <span style={{ color: '#181f5a' }}> Sandbox</span>
                        </h1>
                    </div>
                    <div className="mb-8">
                        <span className="text-lg text-gray-700">
                            Explore AI-powered tools designed to transform business unit operations across industries.
                        </span>
                    </div>
                </div>

                {/* Solution Cards Section */}
                <div className="max-w-7xl mx-auto px-4">
                    <Row
                        gutter={[16, 16]}
                        justify="center"
                        className="p-4"
                        style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                    >
                        {solutions.map((solution, index) => (
                            <Col 
                                key={index} 
                                xs={24}
                                sm={24}
                                md={8}
                                lg={8}
                                xl={8}
                                style={{ 
                                    marginBottom: "16px"
                                }}
                            >
                                <HomeCard
                                    solution={solution}
                                    cardHeight="h-[370px]"
                                    buttonHeight="36px"
                                    onNavigate={handleRetailNavigation}
                                />
                            </Col>
                        ))}
                    </Row>
                </div>
            </div>
            <RetailFooter />

        </div>

    );
};

export default GenAISandboxHome; 