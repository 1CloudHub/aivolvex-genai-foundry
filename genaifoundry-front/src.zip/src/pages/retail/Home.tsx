import React, { useState } from 'react';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import {
    Mic ,
    Edit3 ,
    BarChart2 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    FileText,
    Home,
    ClipboardCheck,
    PieChart,
    Image,
    ShoppingBag,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import RetailFooter from './RetailFooter';

const GenAISandboxHome = () => {
    const { Title, Text } = Typography;
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');

const solutions = [
  {
    title: 'Customer Service Assistant',
    area: 'Retail',
    icon: <MessageSquare size={24} />,
    description: 'GenAI-powered chatbot for retail customers that answers product-related FAQs, shipping policies, return instructions, and store information using a knowledge base. Supports tool-calling to track order delivery by retrieving status using the provided order ID.',
    buttonText: 'Try Now',
    tags: ['Customer Service', 'Order Tracking'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '💬',
      heading: 'Customer Service Assistant',
      subheading: 'AI Chatbot for Retail Services',
      points: [
        'Track order status and delivery updates',
        'Process return requests and cancellations',
        'Check product availability and pricing',
      ]
    }
  },
  {
    title: 'Intelligent Document Processing',
    area: 'Operations',
    icon: <FileText size={24} />,
    description: 'A GenAI agent that automates:\n• Invoice Processing – Extracts fields like invoice number, vendor, total, and due date from supplier invoices for downstream systems.\n• Three-Way Matching – Compares Purchase Orders, GRNs, and Invoices across item, quantity, and price fields to flag mismatches automatically.',
    buttonText: 'Try Now',
    tags: ['Automation', 'Invoices', 'Matching'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📄',
      heading: 'Intelligent Document Processing',
      subheading: 'Automated Invoice & Document Analysis',
      points: [
        'Extract key data from invoices automatically',
        'Perform three-way matching (PO, GRN, Invoice)',
        'Flag discrepancies and mismatches',
      ]
    }
  },
  {
    title: 'Visual Product Search',
    area: 'Customer Experience',
    icon: <Image size={24} />,
    description: 'Customers can input text, image, or both to search the catalog semantically. Combines keyword and multimodal search to retrieve the closest matching products from the knowledge base using product image embeddings and metadata.',
    buttonText: 'Explore',
    tags: ['Search', 'Multimodal'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🔍',
      heading: 'Visual Product Search',
      subheading: 'Multimodal Product Discovery',
      points: [
        'Search products using text or images',
        'Semantic matching for better results',
        'Combine visual and text search',
        'Find similar products instantly'
      ]
    }
  },
  {
    title: 'Product Optimization Assistant',
    area: 'Marketing',
    icon: <Sparkles size={24} />,
    description: 'A. AI-powered Product Listing Generator: Sellers upload a product image; GenAI generates optimized titles, descriptions, and attribute tags (color, category, material, etc.) for better discoverability and SEO.\nB. Product Review Analyzer: Processes product reviews to generate overall sentiment distribution, top pros and cons, and extracts feature requests and usage scenarios for product improvement.',
    buttonText: 'Try Now',
    tags: ['Optimization', 'SEO', 'Reviews'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '✨',
      heading: 'Product Optimization Assistant',
      subheading: 'AI-Powered Product Enhancement',
      points: [
        'Generate optimized product listings',
        'Analyze customer reviews and sentiment',
        'Extract product improvement insights',
        'Enhance SEO and discoverability'
      ]
    }
  },
  {
    title: 'Visual Content & Virtual Try-On',
    area: 'Customer Experience',
    icon: <ShoppingBag size={24} />,
    description: 'A. Product Image/Video Generator – Transforms raw product photos into lifestyle imagery or short promotional videos using GenAI.\nB. Virtual Try-On – Allows users to upload a full-body image and try on garments virtually for visual fit and style.',
    buttonText: 'Try Now',
    tags: ['Content', 'Try-On'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '👕',
      heading: 'Visual Content & Virtual Try-On',
      subheading: 'AI-Generated Content & Virtual Fitting',
      points: [
        'Generate lifestyle product imagery',
        'Create promotional videos automatically',
        'Virtual try-on for clothing items',
        'Enhance product visualization'
      ]
    }
  },

];

    // const handleSolutionClick = (solution) => {
    //     if (solution.type === 'external') {
    //         window.open(solution.redirect, '_blank');
    //     } else if (solution.type === 'component') {
    //         navigate(`/industryusecases/${solution.redirect}`);
    //     } else {
    //         navigate(`/industryusecases/${solution.redirect}`);
    //     }
    // };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {/* Login Navbar */}
            <LoginNavbar />
            {/* Spacing below navbar */}
            <div className="flex-grow px-4 md:px-8 lg:px-16 mx-auto py-4 max-w-7xl">
                {/* Header Section - Matching the image */}
                <div className="text-center">
                    <div className="flex flex-col items-center justify-center mt-4 mb-2">
                        <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                            <span style={{ color: '#e87722' }}>GenAI</span>
                            <span style={{ color: '#181f5a' }}> Sandbox</span>
                        </h1>
                    </div>
                    <div className="mb-8">
                        <span className="text-lg text-gray-700">
                            Explore AI-powered tools designed to transform business unit operations across industries.
                        </span>
                    </div>
                </div>

                {/* Solution Cards Section */}
                <Row
                        gutter={[24, 24]}
                        justify="center"
                        className="p-4 md:p-6 lg:p-8"
                        style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                    >
                        {solutions.map((solution, index) => (
                      
                            <Col key={index} xs={24} sm={12} lg={8} xl={8}>
    <Card
        className="relative w-full h-[340px] border-2 border-transparent rounded-lg shadow-md
            hover:shadow-lg transition-all duration-300 ease-in-out
            hover:!border-[#e87822] flex flex-col"
        bodyStyle={{
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            padding: '1rem',
        }}
    >


        <div className="absolute top-2 right-2 z-10">
            
    
<Tooltip
  placement="topRight"
  color="white" 
  overlayInnerStyle={{
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    borderRadius: '10px',
    padding: '0', 
    maxWidth: '250px',
  }}
  title={
    <div className="p-[1px]">
  
      <div className="flex bg-[#f9fafb] rounded-md border-l-[4px] border-[#e87722] p-4">
        <div className="flex flex-col">
          <div className="font-bold text-[#181f5a] text-sm mb-1">
            {solution.tooltip.icon} {solution.tooltip.heading}
          </div>
          <div className="text-black text-xs font-semibold mb-2">
            {solution.tooltip.subheading}
          </div>
          <ul className="list-disc pl-5 space-y-1 text-xs text-gray-700">
            {solution.tooltip.points.map((point, idx) => (
              <li key={idx}>{point}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  }
>
  <Info className="text-[#e87722] hover:cursor-pointer" size={16} />
</Tooltip>


        </div>

        <div className="flex flex-col h-full">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-[#e8782222] mb-3">
                {React.cloneElement(solution.icon, {
                    size: 24,
                    className: "text-[#e87722]",
                })}
            </div>

            <div className="mb-2 min-h-[24px] flex gap-2 flex-wrap">
                {solution.tags?.map((tag, index) => (
                    <span key={index} className="inline-block bg-[#e8782222] text-[#e87722] text-xs font-medium px-2.5 py-0.5 rounded-md">
                        {tag}
                    </span>
                ))}
            </div>

            {/* Title */}
            <Title level={5} className="!text-xl !font-bold !mb-2 !text-gray-900" style={{ height: '48px', lineHeight: '1.2' }}>
                {solution.title}
            </Title>

            {/* Description */}
            <div 
                className="flex-grow mb-4 min-h-[72px] max-h-[72px] overflow-y-auto thin-scrollbar"
                style={{
                    scrollbarWidth: 'thin',
                    scrollbarColor: '#e5e7eb #f9fafb'
                }}
            >
                <Text className="text-gray-600 !text-xs leading-relaxed">
                    {solution.description}
                </Text>
            </div>

            {/* Button - Always at bottom */}
            <div className="mt-auto">
            {solution.title === "Customer Service Assistant" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/retailhome/retail-assistant')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                    style={{ height: '36px', textDecoration: 'none' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Intelligent Document Processing" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/retailhome/document-processing')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                    style={{ height: '36px', textDecoration: 'none' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Visual Product Search" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/retailhome/visual-product-search')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                    style={{ height: '36px', textDecoration: 'none' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Product Optimization Assistant" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/retailhome/product-optimization')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                    style={{ height: '36px', textDecoration: 'none' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Visual Content & Virtual Try-On" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/retailhome/visual-content-virtual-tryon')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                    style={{ height: '36px', textDecoration: 'none' }}
                >
                    {solution.buttonText}
                </button>
            ) : (
                <Link
                    to={`/industryusecases/${solution.redirect}`}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                    style={{ height: '36px', textDecoration: 'none' }}
                >
                    {solution.buttonText}
                </Link>
            )}
            </div>
        </div>
    </Card>
</Col>
))}
                    </Row>
                </div>
                <RetailFooter />

            </div>

    );
};

export default GenAISandboxHome; 