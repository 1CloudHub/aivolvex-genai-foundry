import React, { useState, useEffect, useCallback } from 'react';
import { Card, Button, Input, Select, message, Modal, Tooltip } from 'antd';
import { 
  ChevronDown, 
  ChevronRight, 
  Sparkles, 
  Book, 
  Info, 
  Edit3, 
  Upload, 
  X, 
  Plus,
  Eye,
  Download,
  Save,
  RefreshCw,
  Undo2,
  Lock,
  Eraser
} from 'lucide-react';

const { TextArea } = Input;
const { Option } = Select;

interface CollapsibleSectionProps {
  title: string;
  isOpen: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  badge?: string;
  action?: React.ReactNode;
  isDemo?: boolean;
}

function CollapsibleSection({ title, isOpen, onToggle, children, badge, action, isDemo }: CollapsibleSectionProps) {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm">
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <h3 className="text-sm font-semibold text-[#1A0040] flex items-center">
              {title}
              {isDemo && (
                <div className="relative group ml-1 z-[60]">
                  <button className="p-1 text-gray-400 hover:text-orange-500 transition-colors" tabIndex={-1} type="button" onClick={e => e.stopPropagation()}>
                    <Info className="w-3 h-3" />
                  </button>
                  <div className="absolute top-full left-0 mt-2 w-72 min-w-[16rem] px-3 py-2 bg-gray-900 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none group-hover:pointer-events-auto z-[999] shadow-xl border border-gray-800">
                    <div>
                      <p className="text-gray-300 leading-relaxed">
                        Choose each category to see how different filters and options affect the generated image.
                      </p>
                    </div>
                    <div className="absolute -top-2 left-4 border-4 border-transparent border-b-gray-900"></div>
                  </div>
                </div>
              )}
            </h3>
            {badge && (
              <span className="px-2 py-1 bg-orange-100 text-orange-600 text-xs font-medium rounded-full">
                {badge}
              </span>
            )}
          </div>
        </div>
        {action && <div className="ml-auto">{action}</div>}
      </div>
      <div className="px-3 pb-3 border-t border-gray-100">
        {children}
      </div>
    </div>
  );
}

const ImageGeneration: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [libraryVisible, setLibraryVisible] = useState(false);
  const [enhancingPrompt, setEnhancingPrompt] = useState(false);
  const [hasEnhancedPrompt, setHasEnhancedPrompt] = useState(false);
  const [enhancedPromptText, setEnhancedPromptText] = useState('');
  const [previousPrompt, setPreviousPrompt] = useState('');
  
  // Form state
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedRatio, setSelectedRatio] = useState('16:9');
  const [formData, setFormData] = useState({
    product: '',
    action: '',
    background: '',
    style: '',
    lighting: '',
    mood: '',
    setting: ''
  });
  const [advancedSettings, setAdvancedSettings] = useState({
    variations: 1,
    quality: 'standard',
    height: 720,
    width: 1280
  });

  // Section collapse states
  const [sectionStates, setSectionStates] = useState({
    category: true,
    sceneDetails: true,
    styleSettings: true,
    advancedSettings: true
  });

  const categories = [
    { id: 'product-showcase', name: 'Product Photography' },
    { id: 'lifestyle', name: 'Lifestyle Marketing' },
    { id: 'ecommerce', name: 'E-commerce Listing' },
    { id: 'fashion', name: 'Fashion Retail' },
    { id: 'electronics', name: 'Tech Retail' },
    { id: 'home-decor', name: 'Home & Garden' },
  ];

  const aspectRatios = [
    { id: '1:1', name: 'Square (1:1)', width: 1024, height: 1024 },
    { id: '1:1-hd', name: 'Square HD (1:1)', width: 1536, height: 1536 },
    { id: '16:9', name: 'Landscape (16:9)', width: 1280, height: 720 },
    { id: '3:2', name: 'Landscape (3:2)', width: 1536, height: 1024 },
    { id: '9:16', name: 'Portrait (9:16)', width: 720, height: 1280 },
    { id: '2:3', name: 'Portrait (2:3)', width: 1024, height: 1536 },
  ];

  const toggleSection = (section: keyof typeof sectionStates) => {
    setSectionStates(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    
    // Set default values based on selected category
    const defaultValues = getDefaultValuesForCategory(categoryId);
    setFormData(prev => ({
      ...prev,
      ...defaultValues
    }));
  };

  const getDefaultValuesForCategory = (categoryId: string) => {
    const defaults: { [key: string]: any } = {
      'product-showcase': {
        product: 'Professional Product',
        action: 'On display',
        background: 'studio',
        style: 'studio',
        lighting: 'softbox',
        mood: 'professional',
        setting: 'home-office'
      },
      'lifestyle': {
        product: 'Lifestyle Product',
        action: 'Being used',
        background: 'modern-home',
        style: 'lifestyle',
        lighting: 'natural',
        mood: 'casual',
        setting: 'living-room'
      },
      'ecommerce': {
        product: 'E-commerce Product',
        action: 'Featured prominently',
        background: 'white',
        style: 'minimalist',
        lighting: 'softbox',
        mood: 'modern',
        setting: 'home-office'
      },
      'fashion': {
        product: 'Fashion Item',
        action: 'Being worn',
        background: 'modern-home',
        style: 'editorial',
        lighting: 'golden',
        mood: 'trendy',
        setting: 'bedroom'
      },
      'electronics': {
        product: 'Tech Device',
        action: 'In use',
        background: 'modern-home',
        style: 'minimalist',
        lighting: 'dramatic',
        mood: 'professional',
        setting: 'home-office'
      },
      'home-decor': {
        product: 'Home Decor Item',
        action: 'Displayed beautifully',
        background: 'modern-home',
        style: 'lifestyle',
        lighting: 'natural',
        mood: 'casual',
        setting: 'living-room'
      }
    };
    
    return defaults[categoryId] || {};
  };

  // Dynamic Prompt Generator Function
  const generatePrompt = (inputs: {
    category?: string | null;
    product?: string;
    action?: string;
    ratio?: string;
    background?: string;
    style?: string;
    lighting?: string;
    mood?: string;
    setting?: string;
  }): string => {
    const {
      category,
      product,
      action,
      ratio,
      background,
      style,
      lighting,
      mood,
      setting
    } = inputs;

    const capitalize = (str: string): string => {
      return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
    };

    const getCategoryBase = (cat: string): string => {
      const categoryBases: { [key: string]: string } = {
        'product-showcase': 'Professional retail product photography with clean composition and commercial lighting',
        'lifestyle': 'Lifestyle-oriented retail scene in a modern, aspirational setting',
        'ecommerce': 'E-commerce focused product presentation with clean, conversion-optimized styling',
        'fashion': 'Fashion-forward retail photography with trendy, editorial styling',
        'electronics': 'Modern tech retail showcase with sleek, minimalist composition',
        'home-decor': 'Home and garden retail photography with warm, inviting atmosphere'
      };
      return categoryBases[cat] || 'Professional retail product photography with balanced composition';
    };

    const parts: string[] = [];

    if (category) {
      parts.push(getCategoryBase(category));
    } else {
      parts.push('Professional photography');
    }

    if (product?.trim()) {
      parts.push(`featuring ${product.trim()}`);
    }

    if (action?.trim()) {
      parts.push(`with ${action.trim().toLowerCase()}`);
    }

    if (style?.trim()) {
      const styleMap: { [key: string]: string } = {
        'flat-lay': 'in flat lay composition',
        'lifestyle': 'in lifestyle setting',
        'studio': 'in studio setup',
        'artistic': 'with artistic composition',
        'minimalist': 'with minimalist composition',
        'editorial': 'with editorial styling'
      };
      parts.push(styleMap[style] || `in ${style} style`);
    }

    if (background?.trim()) {
      const backgroundMap: { [key: string]: string } = {
        'studio': 'against clean studio background',
        'modern-home': 'against modern home interior',
        'office': 'against contemporary office setting',
        'outdoor': 'against outdoor urban setting',
        'white': 'against clean white background',
        'gradient': 'against gradient background'
      };
      parts.push(backgroundMap[background] || `against ${background} background`);
    }

    if (lighting?.trim()) {
      const lightingMap: { [key: string]: string } = {
        'natural': 'with natural lighting',
        'softbox': 'with softbox lighting',
        'spotlight': 'with spotlight illumination',
        'golden': 'with golden hour lighting',
        'dramatic': 'with dramatic lighting',
        'soft': 'with soft, diffused lighting'
      };
      parts.push(lightingMap[lighting] || `with ${lighting} lighting`);
    }

    if (mood?.trim()) {
      const moodMap: { [key: string]: string } = {
        'modern': 'creating modern and sophisticated atmosphere',
        'luxurious': 'creating luxurious and premium atmosphere',
        'casual': 'creating casual and approachable atmosphere',
        'professional': 'creating professional and trustworthy atmosphere',
        'trendy': 'creating trendy and fashionable atmosphere',
        'minimalist': 'creating clean and minimalist atmosphere'
      };
      parts.push(moodMap[mood] || `creating ${mood} atmosphere`);
    }

    if (setting?.trim()) {
      const settingMap: { [key: string]: string } = {
        'home-office': 'in home office environment',
        'living-room': 'in modern living room',
        'bedroom': 'in contemporary bedroom',
        'kitchen': 'in modern kitchen',
        'outdoor': 'in outdoor setting',
        'urban': 'in urban environment'
      };
      parts.push(settingMap[setting] || `in ${setting} setting`);
    }

    if (ratio) {
      const ratioMap: { [key: string]: string } = {
        '1:1': 'square format',
        '16:9': 'landscape format',
        '9:16': 'portrait format',
        '4:5': 'portrait format',
        '3:2': 'photo format',
        '21:9': 'ultra-wide format'
      };
      parts.push(`in ${ratioMap[ratio] || ratio} `);
    }

    let finalPrompt = parts.join(', ');
    finalPrompt = capitalize(finalPrompt);
    
    if (!finalPrompt.endsWith('.')) {
      finalPrompt += '.';
    }

    if (finalPrompt === 'Professional photography.') {
      finalPrompt = 'Professional retail product photography with clean background and optimal lighting.';
    }

    return finalPrompt;
  };

  const handleGeneratePrompt = () => {
    const hasInput = !!(
      selectedCategory ||
      formData.product ||
      formData.action ||
      formData.background ||
      formData.style ||
      formData.lighting ||
      formData.mood ||
      formData.setting
    );
    
    if (hasInput) {
      const newPrompt = generatePrompt({
        category: selectedCategory,
        product: formData.product,
        action: formData.action,
        ratio: selectedRatio,
        background: formData.background,
        style: formData.style,
        lighting: formData.lighting,
        mood: formData.mood,
        setting: formData.setting
      });
      setPrompt(newPrompt);
    }
  };

  // Auto-generate prompt when form data changes
  useEffect(() => {
    const hasInput = !!(
      selectedCategory ||
      formData.product ||
      formData.action ||
      formData.background ||
      formData.style ||
      formData.lighting ||
      formData.mood ||
      formData.setting
    );
    
    if (hasInput) {
      const newPrompt = generatePrompt({
        category: selectedCategory,
        product: formData.product,
        action: formData.action,
        ratio: selectedRatio,
        background: formData.background,
        style: formData.style,
        lighting: formData.lighting,
        mood: formData.mood,
        setting: formData.setting
      });
      setPrompt(newPrompt);
    }
  }, [selectedCategory, formData, selectedRatio]);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      message.error('Please enter a prompt');
      return;
    }

    setLoading(true);
    try {
      let finalPrompt = prompt;
      
      if (hasEnhancedPrompt && enhancedPromptText) {
        console.log('Using stored enhanced prompt...');
        finalPrompt = enhancedPromptText;
        console.log('Enhanced Prompt:', finalPrompt);
      } else {
        console.log('Using direct prompt approach...');
      }

      const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_type: "generate_image",
          text: finalPrompt,
          numberOfImages: advancedSettings.variations,
          height: advancedSettings.height,
          width: advancedSettings.width,
          quality: advancedSettings.quality
        })
      });

      if (!response.ok) {
        throw new Error('Generate image API request failed');
      }

      const generateData = await response.json();
      console.log('Generate API Response:', generateData);

      if (generateData.statusCode === 500) {
        throw new Error(generateData.message || 'Failed to generate image');
      }

      // Handle both single image and multiple images response
      let images: string[] = [];
      
      if (generateData.images && Array.isArray(generateData.images)) {
        // Multiple images response
        images = generateData.images.map((img: any) => {
          if (img.image_base64) {
            return `data:image/png;base64,${img.image_base64}`;
          }
          return null;
        }).filter(Boolean);
      } else if (generateData.image_base64) {
        // Single image response (backward compatibility)
        images = [`data:image/png;base64,${generateData.image_base64}`];
      }

      if (images.length > 0) {
        // Validate all images
        const validatedImages: string[] = [];
        let validatedCount = 0;
        
        images.forEach((imageUrl, index) => {
          const testImg = new window.Image();
          testImg.onload = () => {
            validatedImages[index] = imageUrl;
            validatedCount++;
            
            if (validatedCount === images.length) {
              setGeneratedImages(validatedImages);
              setCurrentImageIndex(0);
              setPrompt(''); // Clear the prompt after successful generation
              setHasEnhancedPrompt(false); // Reset enhanced prompt flag
              setEnhancedPromptText(''); // Clear stored enhanced prompt
              message.success(`${validatedImages.length} image${validatedImages.length > 1 ? 's' : ''} generated successfully!`);
            }
          };
          testImg.onerror = () => {
            console.error(`Invalid image data for image ${index}`);
            validatedCount++;
            
            if (validatedCount === images.length) {
              if (validatedImages.length > 0) {
                setGeneratedImages(validatedImages);
                setCurrentImageIndex(0);
                setPrompt('');
                setHasEnhancedPrompt(false);
                setEnhancedPromptText('');
                message.success(`${validatedImages.length} image${validatedImages.length > 1 ? 's' : ''} generated successfully!`);
              } else {
                throw new Error('No valid images received');
              }
            }
          };
          testImg.src = imageUrl;
        });
      } else {
        throw new Error('No image data received');
      }
    } catch (error) {
      console.error('Generate image error:', error);
      message.error(error instanceof Error ? error.message : 'Failed to generate image');
    } finally {
      setLoading(false);
    }
  };

  const handleEnhancePrompt = async () => {
    if (!prompt.trim()) {
      message.error('Please enter a prompt to enhance');
      return;
    }

    setPreviousPrompt(prompt);
    setEnhancingPrompt(true);
    try {
      const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_type: "enhance_prompt",
          prompt: prompt
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Enhance prompt API request failed: ${errorText}`);
      }

      const data = await response.json();
      console.log('Enhance API Response:', data);

      if (data.statusCode === 500) {
        throw new Error(data.message || 'Failed to enhance prompt');
      }

      let enhancedPrompt = '';
      if (data.enhanced_prompt?.text) {
        enhancedPrompt = data.enhanced_prompt.text;
      } else if (data.body?.enhanced_prompt?.text) {
        enhancedPrompt = data.body.enhanced_prompt.text;
      } else if (typeof data === 'string') {
        enhancedPrompt = data;
      } else {
        throw new Error('Invalid enhance prompt response format');
      }

      console.log('Enhanced Prompt:', enhancedPrompt);
      setPrompt(enhancedPrompt);
      setEnhancedPromptText(enhancedPrompt);
      setHasEnhancedPrompt(true);
      message.success('Prompt enhanced successfully!');
    } catch (error) {
      console.error('Enhance prompt error:', error);
      message.error(error instanceof Error ? error.message : 'Failed to enhance prompt');
    } finally {
      setEnhancingPrompt(false);
    }
  };

  const handlePreview = () => {
    setPreviewVisible(true);
  };

  const handleDownload = () => {
    if (generatedImages.length > 0 && generatedImages[currentImageIndex]) {
      const link = document.createElement('a');
      link.href = generatedImages[currentImageIndex];
      link.download = `generated-image-${currentImageIndex + 1}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleNextImage = () => {
    if (currentImageIndex < generatedImages.length - 1) {
      setCurrentImageIndex(currentImageIndex + 1);
    }
  };

  const handlePrevImage = () => {
    if (currentImageIndex > 0) {
      setCurrentImageIndex(currentImageIndex - 1);
    }
  };

  const handleLibraryClick = () => {
    setLibraryVisible(true);
  };

  const handlePromptSelect = (selectedPrompt: string) => {
    setPrompt(selectedPrompt);
    setLibraryVisible(false);
  };

  // Memoized clear function
  const handleClearAllResults = useCallback(() => {
    setSelectedCategory(null);
    setGeneratedImages([]);
    setCurrentImageIndex(0);
    setPrompt('');
    setHasEnhancedPrompt(false);
    setEnhancedPromptText('');
    setFormData({
      product: '',
      action: '',
      background: '',
      style: '',
      lighting: '',
      mood: '',
      setting: ''
    });
    setAdvancedSettings({
      variations: 1,
      quality: 'standard',
      height: 720,
      width: 1280
    });
  }, []);

  // Memoized action component
  const clearAction = useCallback(() => {
    const hasData = selectedCategory || generatedImages.length > 0 || formData.product || formData.action || formData.background || formData.style || formData.lighting || formData.mood || formData.setting;
    
    if (!hasData) return null;
    
    return (
      <button
        onClick={handleClearAllResults}
        className="btn btn-outline-primary btn-sm px-3 py-1"
        style={{
          borderRadius: '8px',
          fontSize: '11px',
          fontWeight: '500',
          borderColor: '#e87722',
          color: '#e87722',
          backgroundColor: 'transparent'
        }}
      >
        Clear All Results
      </button>
    );
  }, [selectedCategory, generatedImages.length, formData, handleClearAllResults]);



  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Left Column - Form Sections */}
          <div>
            <Card className="shadow-sm border-0">
              <div className="flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Configuration Settings</h3>
                  {clearAction()}
                </div>
                
                <div className="max-h-[645px] overflow-y-auto space-y-6 pr-2">
                  {/* Choose Category Section */}
                  <CollapsibleSection
                    title="Choose Category"
                    isOpen={sectionStates.category}
                    onToggle={() => toggleSection('category')}
                    isDemo={true}
                  >
                    <div className="pt-3 space-y-3">
                      <div className="grid grid-cols-3 gap-2">
                        {categories.map((category) => (
                          <button
                            key={category.id}
                            onClick={() => handleCategorySelect(category.id)}
                            className={`p-2 rounded-lg border-2 transition-all duration-200 text-center ${
                              selectedCategory === category.id
                                ? 'bg-orange-100 border-orange-500 shadow-md'
                                : 'bg-gray-50 border-gray-200 hover:bg-gray-100 hover:border-gray-300'
                            }`}
                          >
                            <span className="text-xs font-medium text-[#1A0040]">{category.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </CollapsibleSection>

                  {/* Scene Details Section */}
                  <CollapsibleSection
                    title="Scene Details"
                    isOpen={sectionStates.sceneDetails}
                    onToggle={() => toggleSection('sceneDetails')}
                  >
                    <div className="pt-3 space-y-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Product Name</label>
                        <Input 
                          value={formData.product}
                          onChange={(e) => setFormData({...formData, product: e.target.value})}
                          className="!rounded-lg"
                          placeholder="e.g., Nike Running Shoes, Apple iPhone, Levi's Jeans"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Action / CTA</label>
                        <Input 
                          value={formData.action}
                          onChange={(e) => setFormData({...formData, action: e.target.value})}
                          className="!rounded-lg"
                          placeholder="e.g., Being worn, On display, In use, Close-up detail"
                        />
                      </div>
                    </div>
                  </CollapsibleSection>

                  {/* Style Settings Section */}
                  <CollapsibleSection
                    title="Style Settings"
                    isOpen={sectionStates.styleSettings}
                    onToggle={() => toggleSection('styleSettings')}
                  >
                    <div className="pt-3 grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Background</label>
                        <Select
                          value={formData.background || undefined}
                          onChange={(value) => setFormData({...formData, background: value})}
                          className="w-full !rounded-lg"
                          placeholder="Select background"
                          allowClear
                        >
                          <Option value="studio">Studio Setup</Option>
                          <Option value="modern-home">Modern Home</Option>
                          <Option value="office">Office Setting</Option>
                          <Option value="outdoor">Outdoor Urban</Option>
                          <Option value="white">Clean White</Option>
                          <Option value="gradient">Gradient Background</Option>
                        </Select>
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Style</label>
                        <Select
                          value={formData.style || undefined}
                          onChange={(value) => setFormData({...formData, style: value})}
                          className="w-full !rounded-lg"
                          placeholder="Select style"
                          allowClear
                        >
                          <Option value="flat-lay">Flat Lay</Option>
                          <Option value="lifestyle">Lifestyle</Option>
                          <Option value="studio">Studio</Option>
                          <Option value="artistic">Artistic</Option>
                          <Option value="minimalist">Minimalist</Option>
                          <Option value="editorial">Editorial</Option>
                        </Select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Lighting</label>
                        <Select
                          value={formData.lighting || undefined}
                          onChange={(value) => setFormData({...formData, lighting: value})}
                          className="w-full !rounded-lg"
                          placeholder="Select lighting"
                          allowClear
                        >
                          <Option value="natural">Natural Light</Option>
                          <Option value="softbox">Softbox</Option>
                          <Option value="spotlight">Spotlight</Option>
                          <Option value="golden">Golden Hour</Option>
                          <Option value="dramatic">Dramatic</Option>
                          <Option value="soft">Soft & Diffused</Option>
                        </Select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Mood</label>
                        <Select
                          value={formData.mood || undefined}
                          onChange={(value) => setFormData({...formData, mood: value})}
                          className="w-full !rounded-lg"
                          placeholder="Select mood"
                          allowClear
                        >
                          <Option value="modern">Modern & Sophisticated</Option>
                          <Option value="luxurious">Luxurious & Premium</Option>
                          <Option value="casual">Casual & Approachable</Option>
                          <Option value="professional">Professional & Trustworthy</Option>
                          <Option value="trendy">Trendy & Fashionable</Option>
                          <Option value="minimalist">Clean & Minimalist</Option>
                        </Select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Setting</label>
                        <Select
                          value={formData.setting || undefined}
                          onChange={(value) => setFormData({...formData, setting: value})}
                          className="w-full !rounded-lg"
                          placeholder="Select setting"
                          allowClear
                        >
                          <Option value="home-office">Home Office</Option>
                          <Option value="living-room">Living Room</Option>
                          <Option value="bedroom">Bedroom</Option>
                          <Option value="kitchen">Kitchen</Option>
                          <Option value="outdoor">Outdoor</Option>
                          <Option value="urban">Urban Environment</Option>
                        </Select>
                      </div>
                    </div>
                  </CollapsibleSection>

                  {/* Advanced Settings Section */}
                  <CollapsibleSection
                    title="Advanced Settings"
                    isOpen={sectionStates.advancedSettings}
                    onToggle={() => toggleSection('advancedSettings')}
                  >
                    <div className="pt-3 space-y-3">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">
                          Output Variations <span className="text-gray-500">(Max: 3)</span>
                        </label>
                        <Input
                          type="number"
                          min="1"
                          max="3"
                          value={advancedSettings.variations}
                          onChange={(e) => {
                            const value = parseInt(e.target.value) || 1;
                            const clampedValue = Math.min(3, Math.max(1, value));
                            setAdvancedSettings({...advancedSettings, variations: clampedValue});
                          }}
                          className="!rounded-lg"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Image Ratio</label>
                        <Select
                          value={selectedRatio}
                          onChange={(value) => {
                            setSelectedRatio(value);
                            const selectedRatioData = aspectRatios.find(ratio => ratio.id === value);
                            if (selectedRatioData) {
                              setAdvancedSettings({
                                ...advancedSettings,
                                width: selectedRatioData.width,
                                height: selectedRatioData.height
                              });
                            }
                          }}
                          className="w-full !rounded-lg"
                        >
                          {aspectRatios.map((ratio) => (
                            <Option key={ratio.id} value={ratio.id}>
                              {ratio.name} - {ratio.width}×{ratio.height}
                            </Option>
                          ))}
                        </Select>
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 mb-1">Image Quality</label>
                        <Select
                          value={advancedSettings.quality}
                          onChange={(value) => setAdvancedSettings({...advancedSettings, quality: value})}
                          className="w-full !rounded-lg"
                        >
                          <Option value="standard">Standard</Option>
                          <Option value="premium">Premium</Option>
                        </Select>
                      </div>
                    </div>
                  </CollapsibleSection>
                </div>
              </div>
            </Card>
          </div>

          {/* Right Column - Generated Images and Prompt Preview */}
          <div className="space-y-6">
            
            {/* Generated Images Section */}
            <Card className="shadow-sm border-0">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Generated Images</h3>
                {generatedImages.length > 0 && (
                  <button
                    onClick={() => {
                      setGeneratedImages([]);
                      setCurrentImageIndex(0);
                      setPrompt('');
                      setHasEnhancedPrompt(false);
                      setEnhancedPromptText('');
                    }}
                    className="btn btn-outline-primary btn-sm px-3 py-1"
                    style={{
                      borderRadius: '8px',
                      fontSize: '11px',
                      fontWeight: '500',
                      borderColor: '#e87722',
                      color: '#e87722',
                      backgroundColor: 'transparent'
                    }}
                  >
                    Clear Results
                  </button>
                )}
              </div>
              
                             <div className="min-h-[300px] flex items-center justify-center">
                 {loading ? (
                   <div className="text-center">
                     <div className="flex justify-center mb-4">
                       <div className="relative">
                         <div className="w-16 h-16 border-4 border-gray-200 border-t-[#e87722] rounded-full animate-spin"></div>
                         <div className="absolute inset-0 flex items-center justify-center">
                           <Sparkles className="w-6 h-6 text-[#e87722]" />
                         </div>
                       </div>
                     </div>
                     <div className="text-lg font-medium text-gray-700 mb-2">Generating Images...</div>
                     <div className="text-sm text-gray-500">Please wait while your images are being generated</div>
                     <div className="mt-4 text-xs text-gray-400">This may take a few moments</div>
                   </div>
                 ) : generatedImages.length > 0 ? (
                   <div className="w-full">
                     <div className="relative">
                       <img 
                         src={generatedImages[currentImageIndex]} 
                         alt={`Generated ${currentImageIndex + 1}`}
                         className="w-full h-[250px] object-contain rounded-lg shadow-sm"
                         onError={(e) => {
                           console.error('Image failed to load');
                           e.currentTarget.style.display = 'none';
                         }}
                         onLoad={() => console.log('Image loaded successfully')}
                       />
                      
                      {/* Navigation arrows for multiple images */}
                      {generatedImages.length > 1 && (
                        <>
                          <button
                            onClick={handlePrevImage}
                            disabled={currentImageIndex === 0}
                            className={`absolute left-2 top-1/2 transform -translate-y-1/2 w-8 h-8 rounded-full bg-white shadow-md flex items-center justify-center transition-all ${
                              currentImageIndex === 0 
                                ? 'opacity-50 cursor-not-allowed' 
                                : 'hover:bg-gray-50 hover:shadow-lg'
                            }`}
                          >
                            <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                            </svg>
                          </button>
                          
                          <button
                            onClick={handleNextImage}
                            disabled={currentImageIndex === generatedImages.length - 1}
                            className={`absolute right-2 top-1/2 transform -translate-y-1/2 w-8 h-8 rounded-full bg-white shadow-md flex items-center justify-center transition-all ${
                              currentImageIndex === generatedImages.length - 1 
                                ? 'opacity-50 cursor-not-allowed' 
                                : 'hover:bg-gray-50 hover:shadow-lg'
                            }`}
                          >
                            <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </button>
                        </>
                      )}
                    </div>
                    
                    {/* Image counter */}
                    {generatedImages.length > 1 && (
                      <div className="flex justify-center mt-2 mb-4">
                        <span className="text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
                          {currentImageIndex + 1} of {generatedImages.length}
                        </span>
                      </div>
                    )}
                    
                    <div className="flex gap-2 mt-4">
                      <Button 
                        onClick={handlePreview}
                        className="!bg-white !text-gray-700 !border-gray-300 hover:!bg-gray-50 hover:!text-gray-900 shadow-sm"
                      >
                        Preview
                      </Button>
                      <Button 
                        onClick={handleDownload}
                        className="!bg-orange-500 hover:!bg-orange-600 !border-orange-500 text-white shadow-sm"
                      >
                        Download
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    <Sparkles size={48} className="mx-auto mb-4 text-gray-300" />
                    <p className="text-lg font-medium mb-2">No assets generated yet.</p>
                    <p className="text-sm">Configure your settings and hit generate</p>
                  </div>
                )}
              </div>
            </Card>

            {/* Prompt Preview Section */}
            <Card className="shadow-sm border-0">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold text-gray-900">Prompt Preview</h3>
                  {prompt.trim() && (
                    <Button 
                      onClick={() => {
                        setPrompt('');
                        setHasEnhancedPrompt(false);
                        setEnhancedPromptText('');
                        setPreviousPrompt('');
                      }}
                      className="!bg-gradient-to-r !from-orange-500 !to-orange-600 !text-white !font-medium !rounded-lg hover:!shadow-lg transition-all duration-200 !text-xs"
                      icon={<Eraser size={14} />}
                      style={{marginLeft: '4.5rem'}}
                    >
                      
                    </Button>
                  )}
                </div>
                <div className="flex gap-2 items-center">
                                                         <Button 
                      type="primary"
                      icon={<Sparkles size={16} />}
                      onClick={handleEnhancePrompt}
                      loading={enhancingPrompt}
                      disabled={!prompt.trim() || enhancingPrompt}
                      className="!bg-orange-500 hover:!bg-orange-600 !border-orange-500 !text-white relative"
                    >
                      <span className="flex items-center gap-2">
                        {enhancingPrompt ? 'Enhancing...' : 'Enhance Prompt'}
                        <Tooltip
                          placement="topRight"
                          color="white"
                          overlayInnerStyle={{
                            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
                            borderRadius: '10px',
                            padding: '0',
                            maxWidth: '250px',
                          }}
                          title={
                            <div className="p-[1px]">
                              <div className="flex bg-[#f9fafb] rounded-md border-l-[4px] border-[#e87722] p-4">
                                <div className="flex flex-col">
                                  <div className="font-bold text-[#181f5a] text-sm mb-1">
                                    ℹ️ Enhance Prompt
                                  </div>
                                  <div className="text-black text-xs font-semibold mb-2">
                                    AI-Powered Prompt Enhancement
                                  </div>
                                  <ul className="list-disc pl-5 space-y-1 text-xs text-gray-700">
                                    <li>Improves your description for better results</li>
                                    <li>Adds relevant details and context</li>
                                    <li>Optimizes for image generation quality</li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          }
                        >
                          <Info className="w-3 h-3 text-white/80 hover:text-white transition-colors cursor-help" />
                        </Tooltip>
                      </span>
                    </Button>
                  <Button 
                    icon={<Book size={16} />}
                    onClick={handleLibraryClick}
                    className="!bg-white !text-gray-700 !border-gray-300 hover:!bg-gray-50"
                  >
                    Library
                  </Button>

                </div>
              </div>
              
              <TextArea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={6}
                className="!rounded-lg mb-4"
                placeholder="Your AI prompt will appear here as you configure settings..."
                disabled={true}
                style={{
                  backgroundColor: '#f5f5f5',
                  color: '#6b7280',
                  cursor: 'not-allowed'
                }}
              />
              
              <Button 
                type="primary"
                size="large"
                icon={<Sparkles size={20} />}
                onClick={handleGenerate}
                loading={loading}
                disabled={!prompt.trim() || loading}
                className="w-full !h-12 !text-lg !bg-orange-500 hover:!bg-orange-600 !border-orange-500 !text-white"
              >
                Generate Image
              </Button>
            </Card>
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      <Modal
        title="Image Preview"
        open={previewVisible}
        onCancel={() => setPreviewVisible(false)}
        footer={null}
        width={800}
      >
        {generatedImages.length > 0 && generatedImages[currentImageIndex] && (
          <img 
            src={generatedImages[currentImageIndex]} 
            alt="Preview" 
            className="w-full h-auto"
          />
        )}
      </Modal>

      {/* Library Modal */}
      <Modal
        title="Sample Prompts Library"
        open={libraryVisible}
        onCancel={() => setLibraryVisible(false)}
        footer={null}
        width={600}
      >
        <div className="space-y-4">
          <p className="text-gray-600 text-sm mb-4">
            Choose from these sample prompts to get started with your retail image generation:
          </p>
          
                     <div className="space-y-3">
             <div 
               className="p-4 border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 cursor-pointer transition-all duration-200"
               onClick={() => handlePromptSelect("Professional retail product photography featuring running shoes being worn in modern home office environment with natural lighting, creating modern and sophisticated atmosphere.")}
             >
               <h4 className="font-medium text-gray-900 mb-2">Running Shoes</h4>
               <p className="text-sm text-gray-600">Professional retail product photography featuring running shoes being worn in modern home office environment with natural lighting, creating modern and sophisticated atmosphere.</p>
             </div>

             <div 
               className="p-4 border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 cursor-pointer transition-all duration-200"
               onClick={() => handlePromptSelect("E-commerce focused retail presentation featuring smartphone displayed elegantly against clean white background with softbox lighting, creating luxurious and premium atmosphere.")}
             >
               <h4 className="font-medium text-gray-900 mb-2">Smartphone</h4>
               <p className="text-sm text-gray-600">E-commerce focused retail presentation featuring smartphone displayed elegantly against clean white background with softbox lighting, creating luxurious and premium atmosphere.</p>
             </div>

             <div 
               className="p-4 border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 cursor-pointer transition-all duration-200"
               onClick={() => handlePromptSelect("Fashion-forward retail photography featuring jeans in lifestyle setting against modern home interior with golden hour lighting, creating trendy and fashionable atmosphere.")}
             >
               <h4 className="font-medium text-gray-900 mb-2">Denim Jeans</h4>
               <p className="text-sm text-gray-600">Fashion-forward retail photography featuring jeans in lifestyle setting against modern home interior with golden hour lighting, creating trendy and fashionable atmosphere.</p>
             </div>

             <div 
               className="p-4 border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 cursor-pointer transition-all duration-200"
               onClick={() => handlePromptSelect("Modern tech retail showcase featuring laptop in contemporary bedroom with dramatic lighting, creating professional and trustworthy atmosphere.")}
             >
               <h4 className="font-medium text-gray-900 mb-2">Laptop</h4>
               <p className="text-sm text-gray-600">Modern tech retail showcase featuring laptop in contemporary bedroom with dramatic lighting, creating professional and trustworthy atmosphere.</p>
             </div>
           </div>
        </div>
      </Modal>
    </div>
  );
};

export default ImageGeneration; 