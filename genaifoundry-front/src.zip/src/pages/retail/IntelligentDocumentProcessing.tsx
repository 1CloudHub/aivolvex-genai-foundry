import React, { useState } from 'react';
import { Card } from 'antd';
import { FileText, Home, Lock, Unlock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import RetailFooter from './RetailFooter';
import DocumentWorkflow from '../../components/ui/DocumentWorkflow';

// API Types for retail document processing
interface RetailDocumentResponse {
  extracted_fields: {
    invoice_number?: string;
    vendor_name?: string;
    invoice_date?: string;
    due_date?: string;
    total_amount?: string;
    tax_amount?: string;
    status?: string;
    po_number?: string;
    payment_terms?: string;
    line_item_count?: string;
    early_payment_discount?: string;
  };
  confidence_score: number;
  processing_status: 'completed' | 'failed';
  error_message?: string;
}

const explicitFields = [
  { field: 'Invoice Number', value: 'INV-2024-001' },
  { field: 'Vendor Name', value: 'Acme Supplies Ltd.' },
  { field: 'Invoice Date', value: '2024-05-01' },
  { field: 'Due Date', value: '2024-05-31' },
  { field: 'Total Amount', value: '$2,450.00' },
  { field: 'Tax Amount', value: '$150.00' },
  { field: 'Status', value: 'Pending' },
];

const inferredFields = [
  { field: 'PO Number', value: 'PO-2024-007' },
  { field: 'Payment Terms', value: 'Net 30' },
  { field: 'Line Item Count', value: '5' },
  { field: 'Early Payment Discount', value: 'Available (2%)' },
];

const IntelligentDocumentProcessing: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'invoice' | 'threeway'>('invoice');
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractedData, setExtractedData] = useState<{
    invoice: RetailDocumentResponse | null;
    threeway: RetailDocumentResponse | null;
  }>({
    invoice: null,
    threeway: null
  });
  const [showResults, setShowResults] = useState<{
    invoice: boolean;
    threeway: boolean;
  }>({
    invoice: false,
    threeway: false
  });
  const [activeInfoTab, setActiveInfoTab] = useState<'extracted' | 'workflow'>('extracted');
  const navigate = useNavigate();

  // API call function for retail document processing - exact same as Document Processing Assistant
  const makeDummyApiCall = (documentType: 'invoice' | 'threeway') => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    // Default applicant data for MediPlus assessment - exact same as Document Processing Assistant
    const applicantData = {
      full_name: 'Tan Wei Ming',
      age: 42,
      gender: 'Male',
      occupation: 'Logistics Supervisor',
      annual_income: 72000,
      smoker_status: 'Smoker',
      pre_existing_conditions: ['Hypertension', 'Type 2 Diabetes (on oral meds)'],
      ongoing_medications: ['Amlodipine', 'Metformin'],
      height_cm: 170,
      weight_kg: 92,
      alcohol_consumption: 'Occasionally',
      selected_plan: 'Standard',
      agent_comments: 'Applicant reports well-controlled BP and sugar levels, no recent hospitalisations.'
    };

    const requestData = {
      event_type: 'mediplus_assess',
      applicant_data: applicantData
    };
    
    // Non-blocking API call - exact same as Document Processing Assistant
    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestData)
    }).catch(error => {
      console.log('MediPlus Risk Assess API call made:', requestData);
    });
  };

  // Handle extract button click - exact same as Document Processing Assistant
  const handleExtract = (documentType: 'invoice' | 'threeway') => {
    setIsExtracting(true);
    setShowResults(prev => ({ ...prev, [documentType]: false }));
    
    // Make dummy API call - exact same as Document Processing Assistant
    makeDummyApiCall(documentType);
    
    // Show extracted info after 5-6 seconds - exact same as Document Processing Assistant
    setTimeout(() => {
      setExtractedData(prev => ({ ...prev, [documentType]: true }));
      setShowResults(prev => ({ ...prev, [documentType]: true }));
      setIsExtracting(false);
    }, 5500); // 5.5 seconds - exact same as Document Processing Assistant
  };

  // Helper function to render extracted fields
  const renderExtractedFields = (data: RetailDocumentResponse | null, isLocked: boolean) => {
    if (isLocked) {
      return (
        <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
          style={{
            minHeight: 600,
            height: 600,
            color: '#b0b0b0',
            fontSize: '0.9rem',
            fontWeight: 400,
            letterSpacing: '0.01em',
            textAlign: 'center',
            background: 'inherit',
            fontFamily: 'Inter, sans-serif'
          }}
        >
          <span>
            Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
          </span>
          <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
            to begin document processing!
          </span>
        </div>
      );
    }

    // Show static data when unlocked with actual AnyRetail Store invoice data
    return (
      <>
        <h3 className="text-lg font-bold mb-4">Explicit Extraction</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500">
              <th className="py-2 text-left">Field</th>
              <th className="py-2 text-right">Extracted Value</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Invoice Number</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">AR-INV-20250724</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Invoice Date</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">2025-07-20</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Due Date</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">2025-08-04</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Vendor Name</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">FastSupply Co.</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Vendor UEN</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">201912345N</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">GST Registration</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">M90345678A</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Customer Name</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Mr. Aaron Tan</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Currency</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Total Amount</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD 1,295.00</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Amount in Words</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">One Thousand Two Hundred Ninety-Five Only</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Reverse Charge</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">No</td>
            </tr>
          </tbody>
        </table>
        
        <h3 className="text-lg font-bold mb-4 mt-6">Inferred Fields</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500">
              <th className="py-2 text-left">Field</th>
              <th className="py-2 text-right">Inferred Value</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Document Type</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Tax Invoice / Bill of Supply</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Payment Terms</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Net 15 days</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Line Item Count</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">2</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Product Category</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Electronics</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Shipping Included</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Yes</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Tax Status</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">GST Registered</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Country</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Singapore</td>
            </tr>
          </tbody>
        </table>
        
        <div className="mt-4 p-3 bg-green-50 rounded-lg">
          <p className="text-sm text-green-700">
            <span className="font-medium">Confidence Score:</span> 98.5%
          </p>
        </div>
      </>
    );
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <LoginNavbar />
      <div className="container py-6">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-2 -ml-5" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button 
                type="button" 
                onClick={() => navigate('/customer/sandbox/retailhome')} 
                className="flex items-center text-orange-600 hover:underline"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <Home size={16} className="mr-1" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-gray-500">Intelligent Document Processing</span>
            </li>
          </ol>
        </nav>
        {/* Page Title and Subtitle */}
        <div className="flex items-center gap-6 mb-8">
          <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
            <FileText className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
              Intelligent Document Processing
            </h1>
            <p className="text-base text-gray-600">
              Extract and analyze retail invoices with AI-powered field extraction and validation.
            </p>
          </div>
        </div>
        {/* Card Style Tab Selector - Centered */}
        <div className="flex justify-center mb-10">
          <div className="grid grid-cols-2 gap-6 w-full">
            <Card
              className={`cursor-pointer transition-all duration-200 p-6 rounded-lg shadow-md bg-white ${
                activeTab === 'invoice' ? 'ring-2 ring-orange-500' : ''
              }`}
              onClick={() => setActiveTab('invoice')}
            >
              <div className="flex items-center justify-center gap-6">
                <div className="w-16 h-16 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
                    <path d="M14 2v6h6"/>
                    <path d="M16 13H8"/>
                    <path d="M16 17H8"/>
                    <path d="M10 9H8"/>
                  </svg>
                </div>
                <div className="flex-1 text-center">
                  <h3 className="font-semibold text-xl text-gray-800 mb-2">Invoice Extraction</h3>
                  <p className="text-base text-gray-500">Extract and analyze invoice data</p>
                </div>
              </div>
            </Card>
            <Card
              className={`cursor-pointer transition-all duration-200 p-6 rounded-lg shadow-md bg-white ${
                activeTab === 'threeway' ? 'ring-2 ring-orange-500' : ''
              }`}
              onClick={() => setActiveTab('threeway')}
            >
              <div className="flex items-center justify-center gap-6">
                <div className="w-16 h-16 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
                    <path d="M14 2v6h6"/>
                    <path d="M16 13H8"/>
                    <path d="M16 17H8"/>
                    <path d="M10 9H8"/>
                  </svg>
                </div>
                <div className="flex-1 text-center">
                  <h3 className="font-semibold text-xl text-gray-800 mb-2">Three-Way Comparison</h3>
                  <p className="text-base text-gray-500">Compare PO, invoice, and receipt</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
        {/* Tab Content */}
        {activeTab === 'invoice' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left: PDF Placeholder */}
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Invoice PDF</h2>
              <div className="w-full h-[700px] rounded-lg overflow-hidden bg-white flex flex-col" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                <div className="flex-1 flex items-center justify-center" style={{ minHeight: 0 }}>
                  <iframe
                    src="/retail/AnyRetail_Invoice_With_Fields.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                    title="Invoice PDF"
                    width="100%"
                    height="100%"
                    style={{ border: 'none' }}
                    allowFullScreen
                  />
                </div>
                {/* Extract Button */}
                <div className="p-4 border-t border-gray-200 bg-white" style={{ flexShrink: 0 }}>
                  <button
                    onClick={() => handleExtract('invoice')}
                    disabled={isExtracting}
                    className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                      isExtracting
                        ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                        : 'bg-orange-500 text-white hover:bg-orange-600'
                    }`}
                  >
                    {isExtracting ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                        Extracting...
                      </div>
                    ) : (
                      'Extract'
                    )}
                  </button>
                </div>
              </div>
            </div>
                         {/* Right: Tabbed Interface */}
             <div>
               <h2 className="text-xl font-semibold text-gray-800 mb-4">Document Analysis</h2>
               <div className="w-full rounded-lg bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                 {/* Tab Navigation */}
                 <div className="d-flex border-bottom" style={{ backgroundColor: '#f8f9fa' }}>
                   <button
                     className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeInfoTab === 'extracted' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                     style={{ 
                       fontSize: '14px',
                       fontFamily: 'Inter, sans-serif',
                       borderBottom: activeInfoTab === 'extracted' ? '2px solid #e87722' : 'none',
                       transition: 'all 0.2s ease'
                     }}
                     onClick={() => setActiveInfoTab('extracted')}
                   >
                     Extracted Information
                   </button>
                   <button
                     className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeInfoTab === 'workflow' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                     style={{ 
                       fontSize: '14px',
                       fontFamily: 'Inter, sans-serif',
                       borderBottom: activeInfoTab === 'workflow' ? '2px solid #e87722' : 'none',
                       transition: 'all 0.2s ease'
                     }}
                     onClick={() => setActiveInfoTab('workflow')}
                   >
                     Processing Workflow
                   </button>
                 </div>
                 
                 {/* Tab Content */}
                 <div className="card_body_custom" style={{ position: 'relative', minHeight: 600, height: 600, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: '#f8f9fa' }}>
                   <div style={{ minHeight: 600, height: 600, maxHeight: 600, overflowY: 'auto' }}>
                     {activeInfoTab === 'extracted' && (
                       <div className="p-6">
                         {renderExtractedFields(extractedData.invoice, !showResults.invoice)}
                       </div>
                     )}
                     
                                           {activeInfoTab === 'workflow' && (
                        <div className="p-6">
                          <DocumentWorkflow 
                            isVisible={showResults.invoice}
                            documentType="Invoice"
                          />
                        </div>
                      )}
                   </div>  
                 </div>
               </div>
             </div>
          </div>
        ) : (
          <div className="flex flex-col gap-10">
            {/* Top: Three PDF Placeholders (now real PDFs) */}
            <div className="w-full flex flex-col items-center">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                {/* Purchase Order */}
                <div className="flex flex-col items-center w-full">
                  <div className="text-xl font-semibold mb-2" style={{letterSpacing:0.5}}>Purchase Order</div>
                  <div className="w-full h-[420px] rounded-lg bg-white flex items-center justify-center" style={{minWidth:'260px', maxWidth:'420px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none'}}>
                    <iframe
                      src="/retail/AnyRetail_PO_Sample.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                      title="Purchase Order PDF"
                      width="100%"
                      height="100%"
                      style={{ border: 'none' }}
                      allowFullScreen
                    />
                  </div>
                </div>
                {/* Sales Invoice */}
                <div className="flex flex-col items-center w-full">
                  <div className="text-xl font-semibold mb-2" style={{letterSpacing:0.5}}>Sales Invoice</div>
                  <div className="w-full h-[420px] rounded-lg bg-white flex items-center justify-center" style={{minWidth:'260px', maxWidth:'420px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none'}}>
                    <iframe
                      src="/retail/AnyRetail_Invoice_Sample.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                      title="Sales Invoice PDF"
                      width="100%"
                      height="100%"
                      style={{ border: 'none' }}
                      allowFullScreen
                    />
                  </div>
                </div>
                {/* Delivery Receipt (GRN) */}
                <div className="flex flex-col items-center w-full">
                  <div className="text-xl font-semibold mb-2" style={{letterSpacing:0.5}}>Delivery Receipt</div>
                  <div className="w-full h-[420px] rounded-lg bg-white flex items-center justify-center" style={{minWidth:'260px', maxWidth:'420px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none'}}>
                    <iframe
                      src="/retail/AnyRetail_GRN_Sample.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                      title="Delivery Receipt PDF"
                      width="100%"
                      height="100%"
                      style={{ border: 'none' }}
                      allowFullScreen
                    />
                  </div>
                </div>
              </div>
              {/* Extract Button for Three-Way Comparison */}
              <div className="mt-6 w-full max-w-md">
                <button
                  onClick={() => handleExtract('threeway')}
                  disabled={isExtracting}
                  className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                    isExtracting
                      ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                      : 'bg-orange-500 text-white hover:bg-orange-600'
                  }`}
                >
                  {isExtracting ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                      Processing Three-Way Comparison...
                    </div>
                  ) : (
                    'Extract & Compare'
                  )}
                </button>
              </div>
            </div>
                         {/* Bottom: Tabbed Interface for Three-Way Comparison */}
             <div className="w-full">
               <h2 className="text-xl font-semibold text-gray-800 mb-4">Document Analysis</h2>
               <div className="w-full rounded-lg bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                 {/* Tab Navigation */}
                 <div className="d-flex border-bottom" style={{ backgroundColor: '#f8f9fa' }}>
                   <button
                     className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeInfoTab === 'extracted' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                     style={{ 
                       fontSize: '14px',
                       fontFamily: 'Inter, sans-serif',
                       borderBottom: activeInfoTab === 'extracted' ? '2px solid #e87722' : 'none',
                       transition: 'all 0.2s ease'
                     }}
                     onClick={() => setActiveInfoTab('extracted')}
                   >
                     Field Extraction & Validation
                   </button>
                   <button
                     className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeInfoTab === 'workflow' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                     style={{ 
                       fontSize: '14px',
                       fontFamily: 'Inter, sans-serif',
                       borderBottom: activeInfoTab === 'workflow' ? '2px solid #e87722' : 'none',
                       transition: 'all 0.2s ease'
                     }}
                     onClick={() => setActiveInfoTab('workflow')}
                   >
                     Processing Workflow
                   </button>
                 </div>
                 
                 {/* Tab Content */}
                 <div className="card_body_custom" style={{ position: 'relative', minHeight: 600, height: 600, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: '#f8f9fa' }}>
                   <div style={{ minHeight: 600, height: 600, maxHeight: 600, overflowY: 'auto' }}>
                     {activeInfoTab === 'extracted' && (
                       <div className="p-6">
                         {!showResults.threeway ? (
                           <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                             style={{
                               minHeight: 500,
                               height: 500,
                               color: '#b0b0b0',
                               fontSize: '0.9rem',
                               fontWeight: 400,
                               letterSpacing: '0.01em',
                               textAlign: 'center',
                               background: 'inherit',
                               fontFamily: 'Inter, sans-serif'
                             }}
                           >
                             <span>
                               Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract & Compare'</span>
                             </span>
                             <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                               to begin document processing!
                             </span>
                           </div>
                         ) : (
                           <>
                             {/* Discrepancy Alert */}
                             <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-6 flex items-start gap-3">
                               <span className="text-yellow-600 text-xl mt-1">&#9888;</span>
                               <div>
                                 <div className="font-semibold text-yellow-800 mb-1">Discrepancies Detected</div>
                                 <div className="text-yellow-800 text-sm">4 discrepancies found in USB Cable quantity, price, and totals. Manual review required before approval.</div>
                               </div>
                             </div>
                             <div className="overflow-x-auto">
                               <table className="w-full text-sm bg-white rounded-lg" style={{ border: '1px solid #e5e7eb', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)' }}>
                                 <thead>
                                   <tr>
                                     <th className="text-left font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Field</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Purchase Order</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Sales Invoice</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Delivery Receipt</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Status</th>
                                   </tr>
                                 </thead>
                                 <tbody>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Document Number</td>
                                     <td className="text-center py-3 px-4">PO-2025072401</td>
                                     <td className="text-center py-3 px-4">INV-2025072401</td>
                                     <td className="text-center py-3 px-4">GRN-2025072401</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Vendor</td>
                                     <td className="text-center py-3 px-4">FastSupply Co.</td>
                                     <td className="text-center py-3 px-4">FastSupply Co.</td>
                                     <td className="text-center py-3 px-4">FastSupply Co.</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Wireless Speaker Qty</td>
                                     <td className="text-center py-3 px-4">10</td>
                                     <td className="text-center py-3 px-4">10</td>
                                     <td className="text-center py-3 px-4">10</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Wireless Speaker Price</td>
                                     <td className="text-center py-3 px-4">S$1,250.00</td>
                                     <td className="text-center py-3 px-4">S$1,250.00</td>
                                     <td className="text-center py-3 px-4">S$1,250.00</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">USB Cable Qty</td>
                                     <td className="text-center py-3 px-4">50</td>
                                     <td className="text-center py-3 px-4">50</td>
                                     <td className="text-center py-3 px-4">48</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">USB Cable Price</td>
                                     <td className="text-center py-3 px-4">S$45.00</td>
                                     <td className="text-center py-3 px-4">S$47.00</td>
                                     <td className="text-center py-3 px-4">S$45.00</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">USB Cable Total</td>
                                     <td className="text-center py-3 px-4">S$2,250.00</td>
                                     <td className="text-center py-3 px-4">S$2,350.00</td>
                                     <td className="text-center py-3 px-4">S$2,160.00</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Grand Total</td>
                                     <td className="text-center py-3 px-4">S$14,750.00</td>
                                     <td className="text-center py-3 px-4">S$14,850.00</td>
                                     <td className="text-center py-3 px-4">S$14,660.00</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                 </tbody>
                               </table>
                             </div>
                           </>
                         )}
                       </div>
                     )}
                     
                     {activeInfoTab === 'workflow' && (
                       <div className="p-6">
                         <DocumentWorkflow 
                           isVisible={showResults.threeway}
                           documentType="Three-Way Comparison"
                         />
                       </div>
                     )}
                   </div>  
                 </div>
               </div>
             </div>
          </div>
        )}
      </div>
      <RetailFooter />
    </div>
  );
};

export default IntelligentDocumentProcessing;
 