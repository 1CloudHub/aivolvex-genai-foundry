import React, { useState, useEffect } from 'react';
import { Card } from 'antd';
import { FileText, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import RetailFooter from './RetailFooter';
import DocumentWorkflow from '../../components/ui/DocumentWorkflow';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { setExtractedData, clearExtractedData } from '../../store/slices/extractedDataSlice';

// API Types for retail document processing
interface RetailDocumentResponse {
  extracted_fields: {
    invoice_number?: string;
    vendor_name?: string;
    invoice_date?: string;
    due_date?: string;
    total_amount?: string;
    tax_amount?: string;
    status?: string;
    po_number?: string;
    payment_terms?: string;
    line_item_count?: string;
    early_payment_discount?: string;
  };
  confidence_score: number;
  processing_status: 'completed' | 'failed';
  error_message?: string;
}


const IntelligentDocumentProcessing: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'invoice' | 'threeway'>('invoice');
  const [isExtracting, setIsExtracting] = useState(false);
  const [showResults, setShowResults] = useState<{
    invoice: boolean;
    threeway: boolean;
  }>({
    invoice: false,
    threeway: false
  });
  const [isProcessing, setIsProcessing] = useState<{
    invoice: boolean;
    threeway: boolean;
  }>({
    invoice: false,
    threeway: false
  });
  const [activeInfoTab, setActiveInfoTab] = useState<'extracted' | 'workflow'>('workflow');
  const [extractionCount, setExtractionCount] = useState<{
    invoice: number;
    threeway: number;
  }>({
    invoice: 0,
    threeway: 0
  });
  const [workflowCompleted, setWorkflowCompleted] = useState<{
    invoice: boolean;
    threeway: boolean;
  }>({
    invoice: false,
    threeway: false
  });
  const [isWorkflowAnimating, setIsWorkflowAnimating] = useState<{
    invoice: boolean;
    threeway: boolean;
  }>({
    invoice: false,
    threeway: false
  });
  const navigate = useNavigate();

  // Redux state management
  const dispatch = useAppDispatch();
  const extractedData = useAppSelector((state) => state.extractedData);

  // API call for Invoice extraction
  const makeInvoiceApiCall = async (documentType: 'invoice' | 'threeway') => {
    if (documentType === 'invoice') {
      const API_URL = import.meta.env.VITE_API_BASE_URL;
      
      const documentData = `Invoice Extracted information 
Explicit Extraction
Field	Extracted Value
Invoice Number	AR-INV-20250724
Invoice Date	2025-07-20
Due Date	2025-08-04
Vendor Name	FastSupply Co.
Vendor UEN	201912345N
GST Registration	M90345678A
Customer Name	Mr. Aaron Tan
Currency	SGD
Subtotal	SGD 1,250.00
Discount	SGD 0.00
Tax Rate	3.6%
Total Tax	SGD 45.00
Shipping/Handling	SGD 0.00
Total Amount	SGD 1,295.00
Amount in Words	One Thousand Two Hundred Ninety-Five Only
Reverse Charge	No
Payment Terms	Net 15 days
Inferred Fields
Field	Inferred Value
Document Type	Tax Invoice / Bill of Supply
Line Item Count	2
Product Category	Electronics
Shipping Included	Yes
Tax Status	GST Registered
Country	Singapore`;

      const requestData = {
        event_type: "kyc_extraction",
        document_data: documentData
      };
      
      try {
        console.log('Making Invoice API call with data:', requestData);
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
          const result = await response.json();
          console.log('Invoice API response received:', result);
          // Store the API response for display in workflow
          dispatch(setExtractedData({ docId: documentType, data: result }));
          console.log('Updated extractedData state:', { ...extractedData, [documentType]: result });
        } else {
          console.error('Invoice API call failed:', response.status);
          // Set a default response for demo purposes matching the actual API structure
          dispatch(setExtractedData({ 
            docId: documentType, 
            data: { 
              statusCode: 200,
              session_id: 'demo-session-' + Date.now(),
              response_data: {
                extracted_kyc_data: `Invoice Extracted information 

Explicit Extraction
Field	Extracted Value
Invoice Number	AR-INV-20250724
Invoice Date	2025-07-20
Due Date	2025-08-04
Vendor Name	FastSupply Co.
Vendor UEN	201912345N
GST Registration	M90345678A
Customer Name	Mr. Aaron Tan
Currency	SGD
Subtotal	SGD 1,250.00
Discount	SGD 0.00
Tax Rate	3.6%
Total Tax	SGD 45.00
Shipping/Handling	SGD 0.00
Total Amount	SGD 1,295.00
Amount in Words	One Thousand Two Hundred Ninety-Five Only
Reverse Charge	No
Payment Terms	Net 15 days
Inferred Fields
Field	Inferred Value
Document Type	Tax Invoice / Bill of Supply
Line Item Count	2
Product Category	Electronics
Shipping Included	Yes
Tax Status	GST Registered
Country	Singapore`,
                timestamp: new Date().toISOString(),
                session_id: 'demo-session-' + Date.now()
              }
            }
          }));
        }
      } catch (error) {
        console.error('Invoice API call error:', error);
        // Set a default response for demo purposes matching the actual API structure
        dispatch(setExtractedData({ 
          docId: documentType, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: `Invoice Extracted information 

Explicit Extraction
Field	Extracted Value
Invoice Number	AR-INV-20250724
Invoice Date	2025-07-20
Due Date	2025-08-04
Vendor Name	FastSupply Co.
Vendor UEN	201912345N
GST Registration	M90345678A
Customer Name	Mr. Aaron Tan
Currency	SGD
Subtotal	SGD 1,250.00
Discount	SGD 0.00
Tax Rate	3.6%
Total Tax	SGD 45.00
Shipping/Handling	SGD 0.00
Total Amount	SGD 1,295.00
Amount in Words	One Thousand Two Hundred Ninety-Five Only
Reverse Charge	No
Payment Terms	Net 15 days
Inferred Fields
Field	Inferred Value
Document Type	Tax Invoice / Bill of Supply
Line Item Count	2
Product Category	Electronics
Shipping Included	Yes
Tax Status	GST Registered
Country	Singapore`,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    }
  };

  // API call function for three-way comparison
  const makeThreeWayApiCall = async (documentType: 'invoice' | 'threeway') => {
    if (documentType === 'threeway') {
      const API_URL = import.meta.env.VITE_API_BASE_URL;
      
      const documentData = `Three-Way Comparison Extracted information 
Purchase Order, Sales Invoice, and Delivery Receipt
Field	Purchase Order	Sales Invoice	Delivery Receipt	Status
Document Number	PO-2025072401	INV-2025072401	GRN-2025072401	Match
Vendor	FastSupply Co.	FastSupply Co.	FastSupply Co.	Match
Wireless Speaker Qty	10	10	10	Match
Wireless Speaker Price	S$1,250.00	S$1,250.00	S$1,250.00	Match
USB Cable Qty	50	50	48	Discrepancy
USB Cable Price	S$45.00	S$47.00	S$45.00	Discrepancy
USB Cable Total	S$2,250.00	S$2,350.00	S$2,160.00	Discrepancy
Grand Total	S$14,750.00	S$14,850.00	S$14,660.00	Discrepancy`;

      const requestData = {
        event_type: "kyc_extraction",
        document_data: documentData
      };
      
      try {
        console.log('Making Three-Way Comparison API call with data:', requestData);
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
          const result = await response.json();
          console.log('Three-Way Comparison API response received:', result);
          // Store the API response for display in workflow
          dispatch(setExtractedData({ docId: documentType, data: result }));
          console.log('Updated extractedData state:', { ...extractedData, [documentType]: result });
        } else {
          console.error('Three-Way Comparison API call failed:', response.status);
          // Set a default response for demo purposes matching the actual API structure
          dispatch(setExtractedData({ 
            docId: documentType, 
            data: { 
              statusCode: 200,
              session_id: 'demo-session-' + Date.now(),
              response_data: {
                extracted_kyc_data: `Three-Way Comparison Extracted information 

Purchase Order, Sales Invoice, and Delivery Receipt
Field	Purchase Order	Sales Invoice	Delivery Receipt	Status
Document Number	PO-2025072401	INV-2025072401	GRN-2025072401	Match
Vendor	FastSupply Co.	FastSupply Co.	FastSupply Co.	Match
Wireless Speaker Qty	10	10	10	Match
Wireless Speaker Price	S$1,250.00	S$1,250.00	S$1,250.00	Match
USB Cable Qty	50	50	48	Discrepancy
USB Cable Price	S$45.00	S$47.00	S$45.00	Discrepancy
USB Cable Total	S$2,250.00	S$2,350.00	S$2,160.00	Discrepancy
Grand Total	S$14,750.00	S$14,850.00	S$14,660.00	Discrepancy`,
                timestamp: new Date().toISOString(),
                session_id: 'demo-session-' + Date.now()
              }
            }
          }));
        }
      } catch (error) {
        console.error('Three-Way Comparison API call error:', error);
        // Set a default response for demo purposes matching the actual API structure
        dispatch(setExtractedData({ 
          docId: documentType, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: `Three-Way Comparison Extracted information 

Purchase Order, Sales Invoice, and Delivery Receipt
Field	Purchase Order	Sales Invoice	Delivery Receipt	Status
Document Number	PO-2025072401	INV-2025072401	GRN-2025072401	Match
Vendor	FastSupply Co.	FastSupply Co.	FastSupply Co.	Match
Wireless Speaker Qty	10	10	10	Match
Wireless Speaker Price	S$1,250.00	S$1,250.00	S$1,250.00	Match
USB Cable Qty	50	50	48	Discrepancy
USB Cable Price	S$45.00	S$47.00	S$45.00	Discrepancy
USB Cable Total	S$2,250.00	S$2,350.00	S$2,160.00	Discrepancy
Grand Total	S$14,750.00	S$14,850.00	S$14,660.00	Discrepancy`,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    }
  };

  // Handle extract button click
  const handleExtract = async (documentType: 'invoice' | 'threeway') => {
    setIsExtracting(true);
    setIsProcessing(prev => ({ ...prev, [documentType]: true }));
    
    // Reset workflow completion state for new extraction
    setWorkflowCompleted(prev => ({ ...prev, [documentType]: false }));
    
    // Increment extraction count to force workflow re-render
    setExtractionCount(prev => ({ ...prev, [documentType]: (prev[documentType] || 0) + 1 }));
    
    // Trigger workflow animation
    setIsWorkflowAnimating(prev => ({ ...prev, [documentType]: true }));
    
    // Clear Redux state for fresh extraction
    dispatch(clearExtractedData(documentType));
    
    // Automatically switch to workflow tab when starting new extraction
    setActiveInfoTab('workflow');
    
    // Make appropriate API call based on document type
    if (documentType === 'invoice') {
      console.log('Starting Invoice extraction...');
      await makeInvoiceApiCall(documentType);
      console.log('Invoice extraction completed, extractedData state:', extractedData);
      
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else if (documentType === 'threeway') {
      // Make three-way comparison API call
      console.log('Starting Three-Way Comparison extraction...');
      await makeThreeWayApiCall(documentType);
      console.log('Three-Way Comparison extraction completed, extractedData state:', extractedData);
      
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    }
    
    // The workflow completion will be handled by the DocumentWorkflow component callback
  };

  // Prevent access to extracted tab if not available
  const handleTabChange = (tab: 'extracted' | 'workflow') => {
    if (tab === 'extracted' && !showResults.invoice && !showResults.threeway) {
      return; // Block access to extracted tab
    }
    setActiveInfoTab(tab);
  };

  // Handle workflow completion
  const handleWorkflowComplete = (documentType: 'invoice' | 'threeway') => {
    setShowResults(prev => ({ ...prev, [documentType]: true }));
    setIsProcessing(prev => ({ ...prev, [documentType]: false }));
    setIsWorkflowAnimating(prev => ({ ...prev, [documentType]: false }));
    setWorkflowCompleted(prev => ({ ...prev, [documentType]: true }));
    setIsExtracting(false); // Reset the extracting state to stop the loading button
    setActiveInfoTab('extracted');
  };

  // Auto-redirect to workflow tab if extracted tab is accessed before completion
  useEffect(() => {
    if (activeInfoTab === 'extracted' && !showResults.invoice && !showResults.threeway) {
      setActiveInfoTab('workflow');
    }
  }, [activeInfoTab, showResults.invoice, showResults.threeway]);

  // Monitor extractedData changes for debugging
  useEffect(() => {
    if (activeTab === 'invoice' && extractedData.invoice) {
      console.log('IntelligentDocumentProcessing - extractedData updated:', extractedData.invoice);
      console.log('Invoice data available:', extractedData.invoice?.response_data?.extracted_kyc_data);
    }
  }, [extractedData, activeTab]);


  // Helper function to render extracted fields
  const renderExtractedFields = (_data: RetailDocumentResponse | null, isLocked: boolean) => {
    if (isLocked) {
      return (
        <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
          style={{
            minHeight: 600,
            height: 600,
            color: '#b0b0b0',
            fontSize: '0.9rem',
            fontWeight: 400,
            letterSpacing: '0.01em',
            textAlign: 'center',
            background: 'inherit',
            fontFamily: 'Inter, sans-serif'
          }}
        >
          <span>
            Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
          </span>
          <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
            to begin document processing!
          </span>
        </div>
      );
    }

    // Show static data when unlocked with actual AnyRetail Store invoice data
    return (
      <>
        <h3 className="text-lg font-bold mb-4">Explicit Extraction</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500">
              <th className="py-2 text-left">Field</th>
              <th className="py-2 text-right">Extracted Value</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Invoice Number</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">AR-INV-20250724</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Invoice Date</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">2025-07-20</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Due Date</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">2025-08-04</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Vendor Name</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">FastSupply Co.</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Vendor UEN</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">201912345N</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">GST Registration</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">M90345678A</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Customer Name</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Mr. Aaron Tan</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Currency</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Subtotal</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD 1,250.00</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Discount</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD 0.00</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Tax Rate</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">3.6%</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Total Tax</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD 45.00</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Shipping/Handling</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD 0.00</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Total Amount</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">SGD 1,295.00</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Amount in Words</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">One Thousand Two Hundred Ninety-Five Only</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Reverse Charge</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">No</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Payment Terms</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Net 15 days</td>
            </tr>
          </tbody>
        </table>
        
        <h3 className="text-lg font-bold mb-4 mt-6">Inferred Fields</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-500">
              <th className="py-2 text-left">Field</th>
              <th className="py-2 text-right">Inferred Value</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Document Type</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Tax Invoice / Bill of Supply</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Line Item Count</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">2</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Product Category</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Electronics</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Shipping Included</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Yes</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Tax Status</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">GST Registered</td>
            </tr>
            <tr className="border-b last:border-b-0">
              <td className="py-2 text-gray-700 text-left align-middle">Country</td>
              <td className="py-2 font-medium text-gray-900 text-right align-middle">Singapore</td>
            </tr>
          </tbody>
        </table>
        
        <div className="mt-4 p-3 bg-green-50 rounded-lg">
          <p className="text-sm text-green-700">
            <span className="font-medium">Confidence Score:</span> 98.5%
          </p>
        </div>
      </>
    );
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <LoginNavbar />
      <div className="container py-6">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-2 -ml-5" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button 
                type="button" 
                onClick={() => navigate('/customer/sandbox/retailhome')} 
                className="flex items-center text-gray-500 hover:text-gray-700"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <Home size={16} className="mr-1" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
                <span className="text-orange-600 font-medium">Intelligent Document Processing</span>
            </li>
          </ol>
        </nav>
        {/* Page Title and Subtitle */}
        <div className="flex items-center gap-6 mb-8">
          <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
            <FileText className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
              Intelligent Document Processing
            </h1>
            <p className="text-base text-gray-600">
              Extract and analyze retail invoices with AI-powered field extraction and validation.
            </p>
          </div>
        </div>
        {/* Card Style Tab Selector - Centered */}
        <div className="flex justify-center mb-10">
          <div className="grid grid-cols-2 gap-6 w-full">
            <Card
              className={`cursor-pointer transition-all duration-200 p-6 rounded-lg shadow-md bg-white ${
                activeTab === 'invoice' ? 'ring-2 ring-orange-500' : ''
              }`}
                              onClick={() => {
                  setActiveTab('invoice');
                  // Reset workflow states for invoice
                  setWorkflowCompleted(prev => ({ ...prev, invoice: false }));
                  setShowResults(prev => ({ ...prev, invoice: false }));
                  dispatch(clearExtractedData('invoice'));
                  setIsWorkflowAnimating(prev => ({ ...prev, invoice: false }));
                  setActiveInfoTab('workflow');
                }}
            >
              <div className="flex items-center justify-center gap-6">
                <div className="w-16 h-16 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
                    <path d="M14 2v6h6"/>
                    <path d="M16 13H8"/>
                    <path d="M16 17H8"/>
                    <path d="M10 9H8"/>
                  </svg>
                </div>
                <div className="flex-1 text-center">
                  <h3 className="font-semibold text-xl text-gray-800 mb-2">Invoice Extraction</h3>
                  <p className="text-base text-gray-500">Extract and analyze invoice data</p>
                </div>
              </div>
            </Card>
            <Card
              className={`cursor-pointer transition-all duration-200 p-6 rounded-lg shadow-md bg-white ${
                activeTab === 'threeway' ? 'ring-2 ring-orange-500' : ''
              }`}
                              onClick={() => {
                  setActiveTab('threeway');
                  // Reset workflow states for three-way comparison
                  setWorkflowCompleted(prev => ({ ...prev, threeway: false }));
                  setShowResults(prev => ({ ...prev, threeway: false }));
                  dispatch(clearExtractedData('threeway'));
                  setIsWorkflowAnimating(prev => ({ ...prev, threeway: false }));
                  setActiveInfoTab('workflow');
                }}
            >
              <div className="flex items-center justify-center gap-6">
                <div className="w-16 h-16 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
                    <path d="M14 2v6h6"/>
                    <path d="M16 13H8"/>
                    <path d="M16 17H8"/>
                    <path d="M10 9H8"/>
                  </svg>
                </div>
                <div className="flex-1 text-center">
                  <h3 className="font-semibold text-xl text-gray-800 mb-2">Three-Way Comparison</h3>
                  <p className="text-base text-gray-500">Compare PO, invoice, and receipt</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
        {/* Tab Content */}
        {activeTab === 'invoice' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left: PDF Placeholder */}
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Invoice PDF</h2>
              <div className="w-full h-[700px] rounded-md overflow-hidden bg-white flex flex-col" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                <div className="flex-1 flex items-center justify-center" style={{ minHeight: 0 }}>
                  <iframe
                    src="/retail/AnyRetail_Invoice_With_Fields.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                    title="Invoice PDF"
                    width="100%"
                    height="100%"
                    style={{ border: 'none' }}
                    allowFullScreen
                  />
                </div>
                {/* Extract Button */}
                <div className="p-4 border-t border-gray-200 bg-white" style={{ flexShrink: 0 }}>
                  <button
                    onClick={() => handleExtract('invoice')}
                    disabled={isExtracting}
                    className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                      isExtracting
                        ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                        : 'bg-orange-500 text-white hover:bg-orange-600'
                    }`}
                  >
                    {isExtracting ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                        Extracting...
                      </div>
                    ) : (
                      'Extract'
                    )}
                  </button>
                </div>
              </div>
            </div>
                         {/* Right: Tabbed Interface */}
             <div>
               <h2 className="text-xl font-semibold text-gray-800 mb-4">Document Analysis</h2>
               <div className="w-full rounded-md bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                 {/* Tab Navigation */}
                 <div className="flex border-b border-gray-200 bg-gray-50">
                   <button
                     className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                       activeInfoTab === 'workflow'
                         ? 'bg-white text-orange-600 border-b-2 border-orange-500'
                         : 'bg-transparent text-gray-500 hover:text-gray-700'
                     }`}
                     onClick={() => handleTabChange('workflow')}
                   >
                     Processing Workflow
                   </button>
                   <button
                     className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                       activeInfoTab === 'extracted'
                         ? 'bg-white text-orange-600 border-b-2 border-orange-500'
                         : 'bg-transparent text-gray-500 hover:text-gray-700'
                     } ${!showResults.invoice && !showResults.threeway ? 'opacity-50 cursor-not-allowed' : ''}`}
                     onClick={() => handleTabChange('extracted')}
                     disabled={!showResults.invoice && !showResults.threeway}
                   >
                     Extracted Information
                   </button>
                 </div>
                 
                 {/* Tab Content */}
                 <div className="card_body_custom" style={{ position: 'relative', minHeight: 650, height: 650, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: 'white' }}>
                   <div style={{ minHeight: 650, height: 650, maxHeight: 650, overflowY: 'auto' }}>
                     {activeInfoTab === 'extracted' && (
                       <div className="p-6">
                         {!showResults.invoice ? (
                           // Force redirect to workflow tab if extracted info is not available
                           <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                             style={{
                               minHeight: 650,
                               height: 650,
                               color: '#b0b0b0',
                               fontSize: '0.9rem',
                               fontWeight: 400,
                               letterSpacing: '0.01em',
                               textAlign: 'center',
                               background: 'inherit',
                               fontFamily: 'Inter, sans-serif'
                             }}
                           >
                             <span>
                               Processing not completed yet.
                             </span>
                             <span style={{ lineHeight: '1.2', marginTop: '10px' }}>
                               Please complete the workflow first.
                             </span>
                             <button
                               onClick={() => setActiveInfoTab('workflow')}
                               className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                             >
                               Go to Workflow
                             </button>
                           </div>
                         ) : (
                           renderExtractedFields(null, !showResults.invoice)
                         )}
                       </div>
                     )}
                     
                                           {activeInfoTab === 'workflow' && (
                        <div className="p-6">
                           {!isProcessing.invoice && !showResults.invoice ? (
                             // Show initial message when workflow hasn't started
                             <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                               style={{
                                 minHeight: 650,
                                 height: 650,
                                 color: '#b0b0b0',
                                 fontSize: '0.9rem',
                                 fontWeight: 400,
                                 letterSpacing: '0.01em',
                                 textAlign: 'center',
                                 background: 'inherit',
                                 fontFamily: 'Inter, sans-serif'
                               }}
                             >
                              <span>
                                Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
                              </span>
                              <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                                to begin document processing!
                              </span>
                            </div>
                          ) : (
                            <DocumentWorkflow 
                              key={`invoice-${extractionCount.invoice || 0}`}
                              isVisible={isProcessing.invoice || showResults.invoice}
                              isAnimating={isWorkflowAnimating.invoice}
                              isCompleted={workflowCompleted.invoice}
                              documentType="Invoice"
                              onProcessingComplete={() => handleWorkflowComplete('invoice')}
                              resetKey="invoice"
                              extractedData={extractedData.invoice}
                            />
                          )}
                        </div>
                      )}
                   </div>  
                 </div>
               </div>
             </div>
          </div>
        ) : (
          <div className="flex flex-col gap-10">
            {/* Top: Three PDF Placeholders (now real PDFs) */}
            <div className="w-full flex flex-col items-center">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                {/* Purchase Order */}
                <div className="flex flex-col items-center w-full">
                  <div className="text-xl font-semibold mb-2" style={{letterSpacing:0.5}}>Purchase Order</div>
                  <div className="w-full h-[420px] rounded-md bg-white flex items-center justify-center" style={{minWidth:'260px', maxWidth:'420px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none'}}>
                    <iframe
                      src="/retail/AnyRetail_PO_Sample.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                      title="Purchase Order PDF"
                      width="100%"
                      height="100%"
                      style={{ border: 'none' }}
                      allowFullScreen
                    />
                  </div>
                </div>
                {/* Sales Invoice */}
                <div className="flex flex-col items-center w-full">
                  <div className="text-xl font-semibold mb-2" style={{letterSpacing:0.5}}>Sales Invoice</div>
                  <div className="w-full h-[420px] rounded-md bg-white flex items-center justify-center" style={{minWidth:'260px', maxWidth:'420px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none'}}>
                    <iframe
                      src="/retail/AnyRetail_Invoice_Sample.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                      title="Sales Invoice PDF"
                      width="100%"
                      height="100%"
                      style={{ border: 'none' }}
                      allowFullScreen
                    />
                  </div>
                </div>
                {/* Delivery Receipt (GRN) */}
                <div className="flex flex-col items-center w-full">
                  <div className="text-xl font-semibold mb-2" style={{letterSpacing:0.5}}>Delivery Receipt</div>
                  <div className="w-full h-[420px] rounded-md bg-white flex items-center justify-center" style={{minWidth:'260px', maxWidth:'420px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none'}}>
                    <iframe
                      src="/retail/AnyRetail_GRN_Sample.pdf#toolbar=0&navpanes=0&scrollbar=0&view=FitH"
                      title="Delivery Receipt PDF"
                      width="100%"
                      height="100%"
                      style={{ border: 'none' }}
                      allowFullScreen
                    />
                  </div>
                </div>
              </div>
              {/* Extract Button for Three-Way Comparison */}
              <div className="mt-6 w-full max-w-md">
                <button
                  onClick={() => handleExtract('threeway')}
                  disabled={isExtracting}
                  className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                    isExtracting
                      ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                      : 'bg-orange-500 text-white hover:bg-orange-600'
                  }`}
                >
                  {isExtracting ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                      Processing Three-Way Comparison...
                    </div>
                  ) : (
                    'Extract & Compare'
                  )}
                </button>
              </div>
            </div>
                         {/* Bottom: Tabbed Interface for Three-Way Comparison */}
             <div className="w-full">
               <h2 className="text-xl font-semibold text-gray-800 mb-4">Document Analysis</h2>
               <div className="w-full rounded-md bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                 {/* Tab Navigation */}
                 <div className="flex border-b border-gray-200 bg-gray-50">
                   <button
                     className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                       activeInfoTab === 'workflow'
                         ? 'bg-white text-orange-600 border-b-2 border-orange-500'
                         : 'bg-transparent text-gray-500 hover:text-gray-700'
                     }`}
                     onClick={() => handleTabChange('workflow')}
                   >
                     Processing Workflow
                   </button>
                   <button
                     className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                       activeInfoTab === 'extracted'
                         ? 'bg-white text-orange-600 border-b-2 border-orange-500'
                         : 'bg-transparent text-gray-500 hover:text-gray-700'
                     } ${!showResults.threeway ? 'opacity-50 cursor-not-allowed' : ''}`}
                     onClick={() => handleTabChange('extracted')}
                     disabled={!showResults.threeway}
                   >
                     Field Extraction & Validation
                   </button>
                 </div>
                 
                 {/* Tab Content */}
                 <div className="card_body_custom" style={{ position: 'relative', minHeight: 650, height: 650, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: 'white' }}>
                   <div style={{ minHeight: 650, height: 650, maxHeight: 650, overflowY: 'auto' }}>
                     {activeInfoTab === 'extracted' && (
                       <div className="p-6">
                         {!showResults.threeway ? (
                           // Force redirect to workflow tab if extracted info is not available
                           <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                             style={{
                               minHeight: 650,
                               height: 650,
                               color: '#b0b0b0',
                               fontSize: '0.9rem',
                               fontWeight: 400,
                               letterSpacing: '0.01em',
                               textAlign: 'center',
                               background: 'inherit',
                               fontFamily: 'Inter, sans-serif'
                             }}
                           >
                             <span>
                               Processing not completed yet.
                             </span>
                             <span style={{ lineHeight: '1.2', marginTop: '10px' }}>
                               Please complete the workflow first.
                             </span>
                             <button
                               onClick={() => setActiveInfoTab('workflow')}
                               className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                             >
                               Go to Workflow
                             </button>
                           </div>
                         ) : (
                           <>
                             {/* Discrepancy Alert */}
                             <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-6 flex items-start gap-3">
                               <span className="text-yellow-600 text-xl mt-1">&#9888;</span>
                               <div>
                                 <div className="font-semibold text-yellow-800 mb-1">Discrepancies Detected</div>
                                 <div className="text-yellow-800 text-sm">4 discrepancies found in USB Cable quantity, price, and totals. Manual review required before approval.</div>
                               </div>
                             </div>
                             <div className="overflow-x-auto">
                               <table className="w-full text-sm bg-white rounded-lg" style={{ border: '1px solid #e5e7eb', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)' }}>
                                 <thead>
                                   <tr>
                                     <th className="text-left font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Field</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Purchase Order</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Sales Invoice</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Delivery Receipt</th>
                                     <th className="text-center font-bold text-gray-700 py-3 px-4 border-b border-gray-200">Status</th>
                                   </tr>
                                 </thead>
                                 <tbody>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Document Number</td>
                                     <td className="text-center py-3 px-4">PO-2025072401</td>
                                     <td className="text-center py-3 px-4">INV-2025072401</td>
                                     <td className="text-center py-3 px-4">GRN-2025072401</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Vendor</td>
                                     <td className="text-center py-3 px-4">FastSupply Co.</td>
                                     <td className="text-center py-3 px-4">FastSupply Co.</td>
                                     <td className="text-center py-3 px-4">FastSupply Co.</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Wireless Speaker Qty</td>
                                     <td className="text-center py-3 px-4">10</td>
                                     <td className="text-center py-3 px-4">10</td>
                                     <td className="text-center py-3 px-4">10</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Wireless Speaker Price</td>
                                     <td className="text-center py-3 px-4">S$1,250.00</td>
                                     <td className="text-center py-3 px-4">S$1,250.00</td>
                                     <td className="text-center py-3 px-4">S$1,250.00</td>
                                     <td className="text-center text-green-600 font-semibold py-3 px-4">Match</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">USB Cable Qty</td>
                                     <td className="text-center py-3 px-4">50</td>
                                     <td className="text-center py-3 px-4">50</td>
                                     <td className="text-center py-3 px-4">48</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">USB Cable Price</td>
                                     <td className="text-center py-3 px-4">S$45.00</td>
                                     <td className="text-center py-3 px-4">S$47.00</td>
                                     <td className="text-center py-3 px-4">S$45.00</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">USB Cable Total</td>
                                     <td className="text-center py-3 px-4">S$2,250.00</td>
                                     <td className="text-center py-3 px-4">S$2,350.00</td>
                                     <td className="text-center py-3 px-4">S$2,160.00</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                   <tr className="border-b border-gray-200 hover:bg-gray-50 transition">
                                     <td className="font-medium text-gray-700 py-3 px-4">Grand Total</td>
                                     <td className="text-center py-3 px-4">S$14,750.00</td>
                                     <td className="text-center py-3 px-4">S$14,850.00</td>
                                     <td className="text-center py-3 px-4">S$14,660.00</td>
                                     <td className="text-center text-red-500 font-semibold py-3 px-4">Discrepancy</td>
                                   </tr>
                                 </tbody>
                               </table>
                             </div>
                           </>
                         )}
                       </div>
                     )}
                     
                                           {activeInfoTab === 'workflow' && (
                        <div className="p-6">
                           {!isProcessing.threeway && !showResults.threeway ? (
                             // Show initial message when workflow hasn't started
                             <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                               style={{
                                 minHeight: 650,
                                 height: 650,
                                 color: '#b0b0b0',
                                 fontSize: '0.9rem',
                                 fontWeight: 400,
                                 letterSpacing: '0.01em',
                                 textAlign: 'center',
                                 background: 'inherit',
                                 fontFamily: 'Inter, sans-serif'
                               }}
                             >
                              <span>
                                Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract & Compare'</span>
                              </span>
                              <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                                to begin document processing!
                              </span>
                            </div>
                          ) : (
                            <DocumentWorkflow 
                              key={`threeway-${extractionCount.threeway || 0}`}
                              isVisible={isProcessing.threeway || showResults.threeway}
                              isAnimating={isWorkflowAnimating.threeway}
                              isCompleted={workflowCompleted.threeway}
                              documentType="Three-Way Comparison"
                              onProcessingComplete={() => handleWorkflowComplete('threeway')}
                              resetKey="threeway"
                              extractedData={extractedData.threeway}
                            />
                          )}
                        </div>
                      )}
                   </div>  
                 </div>
               </div>
             </div>
          </div>
        )}
      </div>
      <RetailFooter />
    </div>
  );
};

export default IntelligentDocumentProcessing;
 