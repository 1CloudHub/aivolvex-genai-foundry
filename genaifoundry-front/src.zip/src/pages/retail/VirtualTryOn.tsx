import React, { useState } from 'react';
import { Card, Typography, Button } from 'antd';
import { Sparkles, Upload, Image, User } from 'lucide-react';

const { Text } = Typography;

// Import bucket name from environment
const BUCKET_NAME = import.meta.env.VITE_S3_BUCKET_NAME || 'genaifoundryxzh4bmyd';

// Sample person images for virtual try-on with S3 URIs
const SAMPLE_PERSON_IMAGES = [
  { name: 'Person 1', url: '/VirtualTryOn/person4.jpg', s3Uri: `s3://${BUCKET_NAME}/virtualtryon/person4.jpg`, category: 'Full Body' },
  { name: 'Person 2', url: '/VirtualTryOn/person2.jpg', s3Uri: `s3://${BUCKET_NAME}/virtualtryon/person2.jpg`, category: 'Full Body' },
  { name: 'Person 3', url: '/VirtualTryOn/person3.jpg', s3Uri: `s3://${BUCKET_NAME}/virtualtryon/person3.jpg`, category: 'Full Body' }
];

// Sample garment images for virtual try-on with S3 URIs
const SAMPLE_GARMENT_IMAGES = [
  { name: 'Olive Corduroy Shirt', url: '/VirtualTryOn/style2.png', s3Uri: `s3://${BUCKET_NAME}/virtualtryon/style2.png`, category: 'Shirts' },
  { name: 'Grey Henley Shirt', url: '/VirtualTryOn/style3.png', s3Uri: `s3://${BUCKET_NAME}/virtualtryon/style3.png`, category: 'Shirts' },
  { name: 'Plaid Button-Down Shirt', url: '/VirtualTryOn/style4.jpg', s3Uri: `s3://${BUCKET_NAME}/virtualtryon/style4.jpg`, category: 'Shirts' }
];

const VirtualTryOn: React.FC = () => {
  // Add CSS to hide scrollbar
  React.useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .hide-scrollbar::-webkit-scrollbar {
        display: none;
      }
    `;
    document.head.appendChild(style);
    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);
  const [selectedPersonImage, setSelectedPersonImage] = useState<string | null>(null);
  const [selectedPersonS3Uri, setSelectedPersonS3Uri] = useState<string | null>(null);
  const [selectedGarmentImage, setSelectedGarmentImage] = useState<string | null>(null);
  const [selectedGarmentS3Uri, setSelectedGarmentS3Uri] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [tryOnContentGenerated, setTryOnContentGenerated] = useState(false);
  const [generatedTryOnImage, setGeneratedTryOnImage] = useState<string | null>(null);
  const [isPersonImageModalVisible, setIsPersonImageModalVisible] = useState(false);
  const [isGarmentImageModalVisible, setIsGarmentImageModalVisible] = useState(false);

  const handlePersonImageSelect = (image: { url: string; s3Uri: string }) => {
    setSelectedPersonImage(image.url);
    setSelectedPersonS3Uri(image.s3Uri);
    setIsPersonImageModalVisible(false);
  };

  const handleGarmentImageSelect = (image: { url: string; s3Uri: string }) => {
    setSelectedGarmentImage(image.url);
    setSelectedGarmentS3Uri(image.s3Uri);
    setIsGarmentImageModalVisible(false);
  };

  const handleVirtualTryOn = async () => {
    if (selectedPersonS3Uri && selectedGarmentS3Uri && !isGenerating) {
      setIsGenerating(true);
      
      try {
        const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            event_type: "virtual_tryon",
            person_s3_uri: selectedPersonS3Uri,
            style_s3_uri: selectedGarmentS3Uri
          })
        });

        if (!response.ok) {
          throw new Error('Virtual try-on API request failed');
        }

        const data = await response.json();
        console.log('Virtual Try-On API Response:', data);

        if (data.statusCode === 200 && data.image_base64) {
          const imageUrl = `data:image/png;base64,${data.image_base64}`;
          setGeneratedTryOnImage(imageUrl);
          setTryOnContentGenerated(true);
        } else {
          throw new Error(data.message || 'Failed to generate virtual try-on');
        }
      } catch (error) {
        console.error('Virtual try-on error:', error);
        // Fallback to simulated result for demo
        setTryOnContentGenerated(true);
      } finally {
        setIsGenerating(false);
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Left: Person and Garment Selection */}
      <div className="rounded-lg bg-white h-[520px]" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'hidden' }}>
        <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
          <div className="flex items-center">
            <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
              <User size={16} className="text-white" />
            </div>
            <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Person & Garment Selection</h5>
          </div>
          {(selectedPersonImage || selectedGarmentImage) && (
            <button
              onClick={() => {
                setSelectedPersonImage(null);
                setSelectedPersonS3Uri(null);
                setSelectedGarmentImage(null);
                setSelectedGarmentS3Uri(null);
                setTryOnContentGenerated(false);
                setGeneratedTryOnImage(null);
              }}
              className="btn btn-outline-primary btn-sm px-3 py-1"
              style={{
                borderRadius: '8px',
                fontSize: '11px',
                fontWeight: '500',
                borderColor: '#e87722',
                color: '#e87722',
                backgroundColor: 'transparent'
              }}
            >
              Clear Selection
            </button>
          )}
        </div>
        <div className="p-6 flex flex-col h-full">
          {/* Split Image Display */}
          <div className="mb-4 flex-shrink-0">
            <div className="grid grid-cols-2 gap-4 h-56">
              {/* Person Selection */}
              <div className="flex flex-col">
                <Text className="!text-sm !font-medium !text-gray-700 mb-2">Select Person</Text>
                {selectedPersonImage ? (
                  <div className="flex-1 bg-white rounded-lg overflow-hidden flex items-center justify-center border border-gray-200">
                    <img 
                      src={selectedPersonImage} 
                      alt="Selected Person"
                      className="w-full h-full object-contain"
                      style={{ maxHeight: '8rem', maxWidth: '100%' }}
                    />
                  </div>
                                 ) : (
                   <div className="flex-1 bg-transparent rounded-lg flex items-center justify-center border-2 border-dashed border-orange-300">
                     <div className="text-center p-4">
                       <div className="w-12 h-12 bg-orange-200 rounded-full flex items-center justify-center mx-auto mb-3">
                         <User size={24} className="text-orange-600" />
                       </div>
                       <Text className="!text-sm font-medium text-orange-700 mb-1">No person selected</Text>
                       <br />
                       <Text className="!text-xs text-orange-600">Click to choose a person</Text>
                     </div>
                   </div>
                )}
                                 <Button 
                   type="primary"
                   className={`w-full mt-2 transition-colors ${
                     isGenerating 
                       ? '!bg-[#e87722]/60 !border-[#e87722]/60 cursor-not-allowed' 
                       : '!bg-[#e87722] !border-[#e87722] hover:!bg-[#d0691d] hover:!border-[#d0691d]'
                   }`}
                   icon={<Upload size={14} />}
                   disabled={isGenerating}
                   onClick={() => !isGenerating && setIsPersonImageModalVisible(true)}
                   size="small"
                 >
                   Select Person
                 </Button>
              </div>

              {/* Garment Selection */}
              <div className="flex flex-col">
                <Text className="!text-sm !font-medium !text-gray-700 mb-2">Select Garment</Text>
                {selectedGarmentImage ? (
                  <div className="flex-1 bg-white rounded-lg overflow-hidden flex items-center justify-center border border-gray-200">
                    <img 
                      src={selectedGarmentImage} 
                      alt="Selected Garment"
                      className="w-full h-full object-contain"
                      style={{
                        maxHeight: selectedGarmentImage.includes('style4.jpg') ? '13rem' : '8rem',
                        maxWidth: '100%'
                      }}
                    />
                  </div>
                                 ) : (
                   <div className="flex-1 bg-transparent rounded-lg flex items-center justify-center border-2 border-dashed border-orange-300">
                     <div className="text-center p-4">
                       <div className="w-12 h-12 bg-orange-200 rounded-full flex items-center justify-center mx-auto mb-3">
                         <Image size={24} className="text-orange-600" />
                       </div>
                       <Text className="!text-sm font-medium text-orange-700 mb-1">No garment selected</Text>
                       <br />
                       <Text className="!text-xs text-orange-600">Click to choose a garment</Text>
                     </div>
                   </div>
                )}
                                 <Button 
                   type="primary"
                   className={`w-full mt-2 transition-colors ${
                     isGenerating 
                       ? '!bg-[#e87722]/60 !border-[#e87722]/60 cursor-not-allowed' 
                       : '!bg-[#e87722] !border-[#e87722] hover:!bg-[#d0691d] hover:!border-[#d0691d]'
                   }`}
                   icon={<Upload size={14} />}
                   disabled={isGenerating}
                   onClick={() => !isGenerating && setIsGarmentImageModalVisible(true)}
                   size="small"
                 >
                   Select Garment
                 </Button>
              </div>
            </div>
          </div>

          {/* Progress Steps - Horizontal */}
          <div className="mt-6 mb-4">
            <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-4 border border-orange-200">
              <div className="flex items-center justify-center space-x-6">
                <div className="flex items-center space-x-2">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                    selectedPersonImage 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-300 text-gray-600'
                  }`}>
                    {selectedPersonImage ? '✓' : '1'}
                  </div>
                  <div className="text-center">
                    <div className={`text-xs font-medium ${
                      selectedPersonImage ? 'text-green-700' : 'text-gray-600'
                    }`}>
                      Select Person
                    </div>
                    {selectedPersonImage && (
                      <div className="text-xs text-green-600 font-medium">✓ Done</div>
                    )}
                  </div>
                </div>

                <div className="w-8 h-px bg-gray-300"></div>

                <div className="flex items-center space-x-2">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                    selectedGarmentImage 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-300 text-gray-600'
                  }`}>
                    {selectedGarmentImage ? '✓' : '2'}
                  </div>
                  <div className="text-center">
                    <div className={`text-xs font-medium ${
                      selectedGarmentImage ? 'text-green-700' : 'text-gray-600'
                    }`}>
                      Select Garment
                    </div>
                    {selectedGarmentImage && (
                      <div className="text-xs text-green-600 font-medium">✓ Done</div>
                    )}
                  </div>
                </div>

                <div className="w-8 h-px bg-gray-300"></div>

                <div className="flex items-center space-x-2">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                    tryOnContentGenerated 
                      ? 'bg-green-500 text-white' 
                      : selectedPersonImage && selectedGarmentImage 
                        ? 'bg-orange-500 text-white' 
                        : 'bg-gray-300 text-gray-600'
                  }`}>
                    {tryOnContentGenerated ? '✓' : '3'}
                  </div>
                  <div className="text-center">
                    <div className={`text-xs font-medium ${
                      tryOnContentGenerated 
                        ? 'text-green-700' 
                        : selectedPersonImage && selectedGarmentImage 
                          ? 'text-orange-700' 
                          : 'text-gray-600'
                    }`}>
                      Generate Result
                    </div>
                    {tryOnContentGenerated ? (
                      <div className="text-xs text-green-600 font-medium">✓ Done</div>
                    ) : selectedPersonImage && selectedGarmentImage && (
                      <div className="text-xs text-orange-600 font-medium">Ready</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Try-On Button */}
          <div >
            <Button 
              type="primary" 
              className={`w-full flex-shrink-0 ${isGenerating ? '!bg-[#e87722]/60 !border-[#e87722]/60 cursor-not-allowed' : '!bg-[#e87722] !border-[#e87722] hover:!bg-[#d0691d] hover:!border-[#d0691d]'}`}
              icon={isGenerating ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div> : <User size={16} />}
              disabled={isGenerating || !selectedPersonImage || !selectedGarmentImage}
              onClick={handleVirtualTryOn}
              
            >
              {isGenerating ? 'Processing...' : 'Try On Garments'}
            </Button>
          </div>
        </div>
      </div>

      {/* Right: Virtual Try-On Results */}
      <div className="rounded-lg bg-white flex flex-col h-[520px]" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'auto' }}>
        <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between flex-shrink-0" style={{ padding: '1rem 1.5rem' }}>
          <div className="flex items-center">
            <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
              <User size={16} className="text-white" />
            </div>
            <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Virtual Try-On Results</h5>
          </div>
          {tryOnContentGenerated && (
            <button
              onClick={() => {
                setTryOnContentGenerated(false);
                setGeneratedTryOnImage(null);
              }}
              className="btn btn-outline-primary btn-sm px-3 py-1"
              style={{
                borderRadius: '8px',
                fontSize: '11px',
                fontWeight: '500',
                borderColor: '#e87722',
                color: '#e87722',
                backgroundColor: 'transparent'
              }}
            >
              Clear Results
            </button>
          )}
        </div>
        <div 
          className={`p-6 flex-1 hide-scrollbar${!tryOnContentGenerated ? ' flex items-center justify-center' : ''}`} 
          style={{ 
            scrollbarWidth: 'none', 
            msOverflowStyle: 'none',
            overflowY: 'auto'
          }}
        >
          {isGenerating ? (
            <div className="text-center">
              <div className="flex justify-center mb-4">
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-gray-200 border-t-[#e87722] rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <User className="w-6 h-6 text-[#e87722]" />
                  </div>
                </div>
              </div>
              <div className="text-lg font-medium text-gray-700 mb-2">Processing Virtual Try-On...</div>
              <div className="text-sm text-gray-500">Please wait while your virtual try-on is being generated</div>
              <div className="mt-4 text-xs text-gray-400">This may take a few moments</div>
            </div>
          ) : !tryOnContentGenerated ? (
            <div className="text-center text-gray-500">
              <Sparkles size={48} className="mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">No assets generated yet.</p>
              <p className="text-sm">Configure your settings and hit generate</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <Text className="!text-sm !font-medium !text-gray-700">Try-On Results :</Text>
                <div className="mt-2">
                  {generatedTryOnImage ? (
                    <div className="bg-white rounded-lg p-4 border border-gray-200">
                      <img 
                        src={generatedTryOnImage} 
                        alt="Virtual Try-On Result"
                        className="w-full h-auto rounded-lg"
                        onError={(e) => {
                          console.error('Generated image failed to load');
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                      
                      {/* Preview and Download Buttons */}
                      <div className="flex gap-2 mt-4">
                        <Button 
                          onClick={() => {
                            // Create a modal for preview
                            const modal = document.createElement('div');
                            modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
                            modal.onclick = () => document.body.removeChild(modal);
                            
                            const img = document.createElement('img');
                            img.src = generatedTryOnImage;
                            img.className = 'max-w-4xl max-h-4xl object-contain';
                            img.onclick = (e) => e.stopPropagation();
                            
                            modal.appendChild(img);
                            document.body.appendChild(modal);
                          }}
                          className="!bg-white !text-gray-700 !border-gray-300 hover:!bg-gray-50 hover:!text-gray-900 shadow-sm"
                        >
                          Preview
                        </Button>
                        <Button 
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = generatedTryOnImage;
                            link.download = 'virtual-tryon-result.png';
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                          }}
                          className="!bg-orange-500 hover:!bg-orange-600 !border-orange-500 text-white shadow-sm"
                        >
                          Download
                        </Button>
                      </div>
                    </div>
                                     ) : (
                     <div className="flex items-center justify-center h-full">
                       <div className="text-center text-gray-500">
                         <Sparkles size={48} className="mx-auto mb-4 text-gray-300" />
                         <p className="text-lg font-medium mb-2">Sorry, couldn't process the request.</p>
                         <p className="text-sm">Please try again after some time.</p>
                       </div>
                     </div>
                   )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Person Image Selection Modal */}
      {isPersonImageModalVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Select Person</h3>
                <p className="text-sm text-gray-500">Choose a person for virtual try-on</p>
              </div>
              <button
                onClick={() => setIsPersonImageModalVisible(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              {SAMPLE_PERSON_IMAGES.map((image: { name: string; url: string; s3Uri: string; category: string }) => (
                <div
                  key={image.url}
                  className="border border-gray-200 rounded-lg p-4 cursor-pointer hover:border-[#e87722] transition-colors"
                  onClick={() => handlePersonImageSelect(image)}
                >
                  <div className="w-full h-32 bg-gray-100 rounded mb-3 flex items-center justify-center overflow-hidden">
                    <img 
                      src={image.url} 
                      alt={image.name}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-gray-800 text-sm">{image.name}</div>
                    <div className="text-xs text-gray-500">{image.category}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Garment Image Selection Modal */}
      {isGarmentImageModalVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Select Garment</h3>
                <p className="text-sm text-gray-500">Choose a garment for virtual try-on</p>
              </div>
              <button
                onClick={() => setIsGarmentImageModalVisible(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              {SAMPLE_GARMENT_IMAGES.map((image: { name: string; url: string; s3Uri: string; category: string }) => (
                <div
                  key={image.url}
                  className="border border-gray-200 rounded-lg p-4 cursor-pointer hover:border-[#e87722] transition-colors"
                  onClick={() => handleGarmentImageSelect(image)}
                >
                  <div className="w-full h-32 bg-gray-100 rounded mb-3 flex items-center justify-center overflow-hidden">
                    <img 
                      src={image.url} 
                      alt={image.name}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-gray-800 text-sm">{image.name}</div>
                    <div className="text-xs text-gray-500">{image.category}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VirtualTryOn; 