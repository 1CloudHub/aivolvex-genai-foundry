import React, { useState } from 'react';
import { Card, Typography } from 'antd';
import { Home, Image, User, Video, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import RetailFooter from './RetailFooter';
import VideoGeneration from './VideoGeneration';
import VirtualTryOn from './VirtualTryOn';
import ImageGeneration from './ImageGeneration';

const { Title, Text } = Typography;

const VisualContentVirtualTryOn: React.FC = () => {
  const [activeTab, setActiveTab] = useState('image-generator');
  const [subTab, setSubTab] = useState<string>('image-generation'); // Default to image generation
  const navigate = useNavigate();

  const tabs = [
    {
      key: 'image-generator',
      title: 'Product Image/Video Generator',
      icon: <Image size={20} />,
      description: 'Transform raw product photos into lifestyle imagery or short promotional videos'
    },
    {
      key: 'virtual-tryon',
      title: 'Virtual Try-On',
      icon: <User size={20} />,
      description: 'Upload a full-body image and try on garments virtually for visual fit and style'
    }
  ];

  const subTabs = [
    {
      key: 'image-generation',
      title: 'Image Generation',
      icon: <Sparkles size={20} />,
      description: 'Create stunning lifestyle imagery from product photos'
    },
    {
      key: 'video-generation',
      title: 'Video Generation',
      icon: <Video size={20} />,
      description: 'Generate short promotional videos from product images'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <LoginNavbar />
      
      {/* Main Content */}
      <div className="px-4 md:px-8 lg:px-16 mx-auto py-6 max-w-7xl">
        {/* Breadcrumb */}
        <nav className="mb-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <button
              onClick={() => navigate('/customer/sandbox/retailhome')}
              className="flex items-center gap-2 text-[#e87722] hover:text-[#d0691d] no-underline"
            >
              <Home size={16} className="relative top-[-1px]" />
              <span>Home</span>
            </button>
            <span>/</span>
            <span className="text-gray-900">Visual Content & Virtual Try-On</span>
          </div>
        </nav>

        {/* Page Header */}
        <div className="mb-8">
          <Title level={1} className="!text-3xl !font-bold !mb-2 !text-gray-900">
            Visual Content & Virtual Try-On
          </Title>
          <Text className="text-gray-600 !text-base">
            Transform raw product photos into lifestyle imagery and create virtual try-on experiences
          </Text>
        </div>

        {/* Tab Selectors */}
        <div className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
            {tabs.map((tab) => (
              <div
                key={tab.key}
                onClick={() => {
                  setActiveTab(tab.key);
                  if (tab.key === 'image-generator') {
                    setSubTab('image-generation'); // Default to image generation when switching to image-generator
                  }
                }}
                className={`cursor-pointer rounded-lg p-6 transition-all duration-200 ${
                  activeTab === tab.key
                    ? 'bg-white border-2 border-[#e87722]'
                    : 'bg-white hover:bg-gray-50'
                }`}
                style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)' }}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="w-11 h-11 rounded-lg flex items-center justify-center mb-3 bg-[#e87722]">
                    {tab.key === 'image-generator' ? (
                      <Image size={28} className="text-white" />
                    ) : tab.key === 'virtual-tryon' ? (
                      <User size={28} className="text-white" />
                    ) : (
                      React.cloneElement(tab.icon, {
                        size: 24,
                        className: 'text-white',
                      })
                    )}
                  </div>
                  <Title level={4} className="!text-lg !font-semibold !mb-2 !text-gray-900">
                    {tab.title}
                  </Title>
                  <Text className="text-gray-600 !text-sm leading-relaxed">
                    {tab.description}
                  </Text>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sub-Tab Selectors for Image/Video Generator */}
        {activeTab === 'image-generator' && (
          <div className="mb-8">
            <div className="flex justify-center">
              <div className="inline-flex bg-white rounded-xl p-1 shadow-sm border border-gray-100">
                {subTabs.map((subTabItem) => (
                  <button
                    key={subTabItem.key}
                    onClick={() => setSubTab(subTabItem.key)}
                    className={`flex items-center gap-3 px-6 py-3 rounded-lg font-medium text-sm transition-all duration-200 ${
                      subTab === subTabItem.key
                        ? 'bg-orange-500 text-white shadow-sm'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    {subTabItem.key === 'image-generation' ? (
                      <Sparkles size={18} />
                    ) : subTabItem.key === 'video-generation' ? (
                      <Video size={18} />
                    ) : (
                      React.cloneElement(subTabItem.icon, { size: 18 })
                    )}
                    {subTabItem.title}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab Content */}
        <div className="mt-8">
          {activeTab === 'image-generator' && subTab === 'image-generation' && <ImageGeneration />}
          {activeTab === 'image-generator' && subTab === 'video-generation' && <VideoGeneration />}
          {activeTab === 'virtual-tryon' && <VirtualTryOn />}
        </div>
      </div>
      


      <RetailFooter />
    </div>
  );
};

export default VisualContentVirtualTryOn; 