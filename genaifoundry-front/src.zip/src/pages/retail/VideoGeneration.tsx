import React, { useState } from 'react';
import { Card, Typography, Button } from 'antd';
import { Sparkles, Upload, Image, Video, Type } from 'lucide-react';

const { Text } = Typography;

// Sample images for the popups
const SAMPLE_PRODUCT_IMAGES = [
  { name: 'Woman Handbag', url: '/retail/woman_handbag.jpg', category: 'Accessories' },
  { name: 'Man Suit', url: '/retail/man_suit.jpg', category: 'Clothing' },
  { name: 'Man Gaming', url: '/retail/man_gaming.jpg', category: 'Electronics' }
];

// Text-to-Video prompts for specific product showcases
const TEXT_TO_VIDEO_PROMPTS = [
  {
    name: 'Premium Shoes',
    prompt: 'Elegant close-up shots of premium leather shoes, detailed craftsmanship, smooth camera movements highlighting texture and quality, professional studio lighting, luxury product presentation, ultra realistic, 4K quality'
  },
  {
    name: 'Designer Suit',
    prompt: 'Professional businessman wearing designer suit, confident posture, urban cityscape background, dynamic camera movements, natural daylight, sophisticated lifestyle presentation, ultra realistic, 4K quality'
  },
  {
    name: 'Gaming Headset',
    prompt: 'Gamer wearing high-end gaming headset, intense gaming session, RGB lighting effects, dynamic camera movements around gaming setup, dramatic lighting, immersive gaming environment, ultra realistic, 4K quality'
  },
  {
    name: 'Luxury Handbag',
    prompt: 'Elegant woman carrying luxury designer handbag, upscale shopping district, golden hour lighting, smooth cinematic camera movements, shallow depth of field, professional fashion photography, ultra realistic, 4K quality'
  },
  {
    name: 'Smart Watch',
    prompt: 'Active lifestyle shots featuring premium smartwatch, outdoor activities, natural lighting, smooth camera transitions, modern tech-focused presentation, ultra realistic, 4K quality'
  },
  {
    name: 'Wireless Earbuds',
    prompt: 'Young professional using wireless earbuds, urban lifestyle scenes, natural lighting, cinematic camera movements, modern tech advertising style, ultra realistic, 4K quality'
  }
];

const VideoGeneration: React.FC = () => {
  const [activeTab, setActiveTab] = useState('image-text');
  const [selectedProductImage, setSelectedProductImage] = useState<string | null>(null);
  const [selectedProductName, setSelectedProductName] = useState<string | null>(null);
  const [selectedPrompt, setSelectedPrompt] = useState<string | null>(null);
  const [selectedTextPrompt, setSelectedTextPrompt] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [imageContentGenerated, setImageContentGenerated] = useState(false);
  const [isProductImageModalVisible, setIsProductImageModalVisible] = useState(false);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [isPolling, setIsPolling] = useState(false);
  const [generationPhase, setGenerationPhase] = useState<'idle' | 'uploading' | 'processing' | 'generating' | 'complete' | 'error'>('idle');

  // Prompt chips for video generation
  const promptChips = [
    'Lifestyle Video',
    'Product Showcase'
  ];

  // Specific prompts for each image and video style combination
  const getPromptForImageAndStyle = (imageName: string, style: string): string => {
    const prompts = {
      'Woman Handbag': {
        'Lifestyle Video': 'Elegant woman walking through upscale shopping district with designer handbag, natural golden hour lighting, smooth cinematic camera movements, shallow depth of field, professional fashion photography style,ultra realistic',
        'Product Showcase': 'Close-up detailed shots of handbag craftsmanship, leather texture, hardware details, professional studio lighting, premium product photography presentation , ultra realistic'
      },
      'Man Suit': {
        'Lifestyle Video': 'Professional businessman in urban environment, confident posture and stride, walking through city streets, dynamic camera movements with smooth transitions, natural daylight, sophisticated lifestyle presentation , ultra realistic',
        'Product Showcase': 'Detailed macro shots of suit fabric texture, stitching quality,  smooth camera transitions between angles, premium studio lighting setup, high-end fashion photography style,ultra realistic'
      },
      'Man Gaming': {
        'Lifestyle Video': 'Gamer in intense gaming session, focused expression and concentration, dynamic camera movements around gaming setup, dramatic lighting with RGB accents, immersive gaming environment presentation, ultra realistic',
        'Product Showcase': 'Close-up detailed shots of gaming headset features, microphone quality, ear cushion texture, rotating camera angles highlighting technical specifications, professional product photography with tech focus, ultra realistic'
      }
    };
    
    return prompts[imageName as keyof typeof prompts]?.[style as keyof typeof prompts[keyof typeof prompts]] || '';
  };

  const handleProductImageSelect = (imageUrl: string, imageName: string) => {
    setSelectedProductImage(imageUrl);
    setSelectedProductName(imageName);
    setIsProductImageModalVisible(false);
  };

  const handlePromptChipClick = (prompt: string) => {
    setSelectedPrompt(selectedPrompt === prompt ? null : prompt);
  };

  const handleTextPromptClick = (prompt: string) => {
    setSelectedTextPrompt(selectedTextPrompt === prompt ? null : prompt);
  };

  // Generate session ID from current timestamp
  const generateSessionId = (): string => {
    const now = new Date();
    return now.getTime().toString();
  };

  // Function to get the correct image URL based on selected image and video style
  const getImageUrlForStyle = (selectedImageName: string, videoStyle: string): string => {
    if (videoStyle === 'Product Showcase') {
      // Map to product-focused images for Product Showcase
      switch (selectedImageName) {
        case 'Man Gaming':
          return '/retail/headphone_gaming.jpg';
        case 'Man Suit':
          return '/retail/suit.jpg';
        case 'Woman Handbag':
          return '/retail/handbag.jpg';
        default:
          return selectedProductImage || '';
      }
    } else {
      // Use original images for Lifestyle Video
      return selectedProductImage || '';
    }
  };

  // Convert image to base64
  const convertImageToBase64 = async (imageUrl: string): Promise<string> => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const base64 = reader.result as string;
          // Remove the data:image/jpeg;base64, prefix
          const base64Data = base64.split(',')[1];
          resolve(base64Data);
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error('Error converting image to base64:', error);
      throw error;
    }
  };

  // Poll for video generation status
  const pollVideoStatus = async (sessionId: string): Promise<string> => {
    const maxAttempts = 30; // 180 seconds / 10 seconds = 18 attempts
    let attempts = 0;

    return new Promise((resolve, reject) => {
      const poll = async () => {
        try {
          console.log(`Polling attempt ${attempts + 1}/${maxAttempts} for session: ${sessionId}`);
          
          const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              event_type: "check_vid_gen_status",
              session_id: sessionId
            }),
          });

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const result = await response.json();
          console.log('Poll response:', result);

          if (result.status === 'found' && result.video_url) {
            console.log('Video found! URL:', result.video_url);
            resolve(result.video_url);
          } else if (attempts >= maxAttempts) {
            reject(new Error('Video generation timed out after 3 minutes'));
          } else {
            attempts++;
            console.log(`Video not ready yet. Retrying in 10 seconds... (${attempts}/${maxAttempts})`);
            setTimeout(poll, 10000); // Poll every 10 seconds
          }
        } catch (error) {
          console.error('Polling error:', error);
          if (attempts >= maxAttempts) {
            reject(error);
          } else {
            attempts++;
            console.log(`Polling error, retrying in 10 seconds... (${attempts}/${maxAttempts})`);
            setTimeout(poll, 10000);
          }
        }
      };

      poll();
    });
  };

  const handleGenerateContent = async () => {
    if (!isGenerating) {
      
      setIsGenerating(true);
      setApiError(null);
      setGeneratedVideoUrl(null);
      setGenerationPhase('uploading');
      
      try {
        // Generate session ID
        const newSessionId = generateSessionId();
        setSessionId(newSessionId);
        
        let triggerRequestBody;
        
        if (activeTab === 'image-text') {
          // Image-to-Video logic
          // Get the specific prompt for the selected image and style
          const specificPrompt = getPromptForImageAndStyle(selectedProductName!, selectedPrompt!);
          
          // Get the correct image URL based on video style
          const imageUrlForStyle = getImageUrlForStyle(selectedProductName!, selectedPrompt!);
      
          // Convert image to base64
          const imageBase64 = await convertImageToBase64(imageUrlForStyle);
          
          triggerRequestBody = {
            event_type: "vid_generation",
            image_base64: imageBase64,
            prompt: specificPrompt,
            session_id: newSessionId
          };
        } else {
          // Text-to-Video logic
          const selectedPromptText = TEXT_TO_VIDEO_PROMPTS.find(p => p.name === selectedTextPrompt)?.prompt;
          
          triggerRequestBody = {
            event_type: "vid_generation_text",
            prompt: selectedPromptText,
            session_id: newSessionId
          };
        }

        console.log('Triggering video generation:', triggerRequestBody);

        // Step 1: Trigger video generation (expect timeout)
        try {
          const triggerResponse = await fetch(import.meta.env.VITE_API_BASE_URL, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(triggerRequestBody),
          });

          console.log('Trigger response status:', triggerResponse.status);
          
          // Even if we get a timeout error, we continue with polling
          if (triggerResponse.ok) {
            const triggerResult = await triggerResponse.text();
            console.log('Trigger response:', triggerResult);
          }
        } catch (error) {
          console.log('Expected timeout from trigger API:', error);
          // Continue with polling even if trigger times out
        }

        console.log('Video generation triggered, starting polling...');
        setGenerationPhase('processing');
        
        // Step 2: Start pollings for video completion
        setIsPolling(true);
        setGenerationPhase('generating');
        const videoUrl = await pollVideoStatus(newSessionId);
        
        console.log('Video generation completed:', videoUrl);
        setGeneratedVideoUrl(videoUrl);
        setImageContentGenerated(true);
        setGenerationPhase('complete');
        
      } catch (error) {
        console.error('Error generating video:', error);
        setApiError(error instanceof Error ? error.message : 'Failed to generate video');
        setGenerationPhase('error');
      } finally {
        setIsGenerating(false);
        setIsPolling(false);
        if (generationPhase !== 'error') {
          setGenerationPhase('idle');
        }
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Left: Product Image Display and Selection */}
      <div className="rounded-lg bg-white h-[750px]" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'hidden' }}>
        <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
          <div className="flex items-center">
            <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
              {activeTab === 'image-text' ? <Image size={16} className="text-white" /> : <Type size={16} className="text-white" />}
            </div>
            <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>
              {activeTab === 'image-text' ? 'Product Images' : 'Video Prompts'}
            </h5>
          </div>
        </div>
        
        {/* Tab Selectors */}
        <div className="px-6 pt-4 pb-2">
          <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setActiveTab('image-text')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all duration-200 ${
                activeTab === 'image-text'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                <Image size={14} />
                <span>Image to Video</span>
              </div>
            </button>
            <button
              onClick={() => setActiveTab('text-only')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all duration-200 ${
                activeTab === 'text-only'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                <Type size={14} />
                <span>Text to Video</span>
              </div>
            </button>
          </div>
        </div>

        <div className="p-6 flex flex-col h-full">
          {activeTab === 'image-text' ? (
            <>
              {/* Large Image Display */}
              <div className="mb-4 flex-shrink-0">
                {selectedProductImage ? (
                  <div className="w-full h-56 bg-white rounded-lg overflow-hidden flex items-center justify-center">
                    <img 
                      src={selectedProductImage} 
                      alt="Selected Product"
                      className="w-full h-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-full h-56 bg-white rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                    <div className="text-center text-gray-500">
                      <Image size={48} className="mx-auto mb-4 text-gray-400" />
                      <Text className="!text-lg !font-medium">No product image selected</Text>
                      <Text className="!text-sm !text-gray-500 block mt-2">Click the button below to select a product image</Text>
                    </div>
                  </div>
                )}
              </div>

              {/* Upload Button */}
              <Button 
                type="default"
                className={`w-full mb-6 border-2 border-dashed transition-colors flex-shrink-0 ${
                  isGenerating 
                    ? 'border-gray-200 bg-gray-50 text-gray-400 cursor-not-allowed' 
                    : 'border-gray-300 hover:border-[#e87722]'
                }`}
                icon={<Upload size={16} />}
                disabled={isGenerating}
                onClick={() => !isGenerating && setIsProductImageModalVisible(true)}
              >
                Select Product Image
              </Button>

              {/* Prompt Selection */}
              <div className="mb-4 flex-shrink-0">
                <Text className="!text-sm !font-medium !text-gray-700">Select Video Style :</Text>
                <div style={{ height: '10px' }}></div>
                <div className="flex flex-wrap gap-2">
                  {promptChips.map((prompt) => (
                    <button
                      key={prompt}
                      onClick={() => !isGenerating && handlePromptChipClick(prompt)}
                      disabled={isGenerating}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                        isGenerating
                          ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                          : selectedPrompt === prompt
                          ? 'bg-[#e87722] text-white'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
                
                {/* Prompt Display Window */}
                <div className="mt-4 flex-shrink-0">
                  <Text className="!text-sm !font-medium !text-gray-700 mb-2">Selected Prompt :</Text>
                  <div 
                    className="w-full h-24 bg-gray-50 border border-gray-200 rounded-lg p-3 overflow-y-auto"
                    style={{ 
                      fontFamily: 'Inter, sans-serif',
                      fontSize: '0.75rem',
                      lineHeight: '1.4',
                      color: '#374151'
                    }}
                  >
                    {selectedPrompt && selectedProductName 
                      ? getPromptForImageAndStyle(selectedProductName, selectedPrompt)
                      : 'No prompt selected. Please select a product image and video style to see the detailed prompt.'
                    }
                  </div>
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Text-to-Video Prompts */}
              <div className="mb-4 flex-shrink-0">
                <Text className="!text-sm !font-medium !text-gray-700 mb-3">Select Video Prompt :</Text>
                <div className="grid grid-cols-2 gap-3">
                  {TEXT_TO_VIDEO_PROMPTS.map((prompt) => (
                    <button
                      key={prompt.name}
                      onClick={() => !isGenerating && handleTextPromptClick(prompt.name)}
                      disabled={isGenerating}
                      className={`p-3 rounded-lg border-2 transition-all duration-200 text-left ${
                        isGenerating
                          ? 'border-gray-200 bg-gray-50 text-gray-400 cursor-not-allowed'
                          : selectedTextPrompt === prompt.name
                          ? 'border-[#e87722] bg-[#e87722] text-white'
                          : 'border-gray-200 bg-white text-gray-700 hover:border-[#e87722] hover:bg-gray-50'
                      }`}
                    >
                      <div className="font-medium text-sm mb-1">{prompt.name}</div>
                      <div className="text-xs opacity-75 line-clamp-2">{prompt.prompt.substring(0, 80)}...</div>
                    </button>
                  ))}
                </div>
                
                                 {/* Selected Prompt Display */}
                 <div className="mt-4 mb-8 flex-shrink-0">
                   <Text className="!text-sm !font-medium !text-gray-700 mb-2">Selected Prompt :</Text>
                   <div 
                     className="w-full h-24 bg-gray-50 border border-gray-200 rounded-lg p-3 overflow-y-auto"
                     style={{ 
                       fontFamily: 'Inter, sans-serif',
                       fontSize: '0.75rem',
                       lineHeight: '1.4',
                       color: '#374151'
                     }}
                   >
                     {selectedTextPrompt 
                       ? TEXT_TO_VIDEO_PROMPTS.find(p => p.name === selectedTextPrompt)?.prompt || 'No prompt selected.'
                       : 'No prompt selected. Please select a video prompt to see the detailed prompt.'
                     }
                   </div>
                 </div>
              </div>
            </>
          )}

          {/* Error Display */}
          {apiError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <Text className="!text-sm !text-red-600">
                Error: {apiError}
              </Text>
            </div>
          )}

          {/* Generate Button */}
          <Button 
            type="primary" 
            className={`w-full flex-shrink-0 ${isGenerating ? '!bg-[#e87722]/60 !border-[#e87722]/60 cursor-not-allowed' : '!bg-[#e87722] !border-[#e87722] hover:!bg-[#d0691d] hover:!border-[#d0691d]'}`}
            icon={isGenerating ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div> : <Sparkles size={16} />}
            disabled={
              isGenerating || 
              (activeTab === 'image-text' && (!selectedProductImage || !selectedPrompt)) ||
              (activeTab === 'text-only' && !selectedTextPrompt)
            }
            onClick={handleGenerateContent}
          >
            {isGenerating ? (isPolling ? 'Generating Video...' : 'Starting Generation...') : 'Generate Video'}
          </Button>
        </div>
      </div>

      {/* Right: Generated Content */}
      <div className="rounded-lg bg-white flex flex-col h-[750px]" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'hidden' }}>
        <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between flex-shrink-0" style={{ padding: '1rem 1.5rem' }}>
          <div className="flex items-center">
            <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
              <Video size={16} className="text-white" />
            </div>
            <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Generated Content</h5>
          </div>
        </div>
        <div className={`p-6 flex-1 overflow-y-auto${!imageContentGenerated ? ' flex items-center justify-center' : ''}`}>
          {!imageContentGenerated ? (
            <div className="h-full flex items-center justify-center">
              {generationPhase === 'idle' ? (
                <div
                  style={{
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    fontFamily: 'Inter, sans-serif',
                    width: '100%'
                  }}
                >
                  <div>
                    Click <span className="font-bold" style={{ color: '#b0b0b0', fontWeight: 700, fontFamily: 'Inter, sans-serif' }}>'Generate Content'</span>
                  </div>
                  <div style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your generated lifestyle imagery and videos!
                  </div>
                </div>
              ) : generationPhase === 'uploading' ? (
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e87722]"></div>
                  </div>
                  <div className="text-lg font-medium text-gray-700 mb-2">Uploading...</div>
                  <div className="text-sm text-gray-500">Preparing your image for video generation</div>
                </div>
              ) : generationPhase === 'processing' ? (
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="flex space-x-1">
                      <div className="w-3 h-3 bg-[#e87722] rounded-full animate-bounce"></div>
                      <div className="w-3 h-3 bg-[#e87722] rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-3 h-3 bg-[#e87722] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                  <div className="text-lg font-medium text-gray-700 mb-2">Processing...</div>
                  <div className="text-sm text-gray-500">Upload completed. Processing video generation...</div>
                </div>
              ) : generationPhase === 'generating' ? (
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="relative">
                      <div className="w-16 h-16 border-4 border-gray-200 border-t-[#e87722] rounded-full animate-spin"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Video className="w-6 h-6 text-[#e87722]" />
                      </div>
                    </div>
                  </div>
                  <div className="text-lg font-medium text-gray-700 mb-2">Generating Video...</div>
                  <div className="text-sm text-gray-500">Please wait while your video is being generated</div>
                  <div className="mt-4 text-xs text-gray-400">This may take a few minutes</div>
                </div>
              ) : generationPhase === 'error' ? (
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                      <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </div>
                  </div>
                  <div className="text-lg font-medium text-red-600 mb-2">Generation Failed</div>
                  <div className="text-sm text-gray-500">Please try again</div>
                </div>
              ) : (
                <div
                  style={{
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    fontFamily: 'Inter, sans-serif',
                    width: '100%'
                  }}
                >
                  <div>
                    Click <span className="font-bold" style={{ color: '#b0b0b0', fontWeight: 700, fontFamily: 'Inter, sans-serif' }}>'Generate Content'</span>
                  </div>
                  <div style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your generated lifestyle imagery and videos!
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="h-full flex items-center justify-center">
              {generatedVideoUrl ? (
                <div className="w-full bg-black rounded-lg overflow-hidden">
                  <video 
                    controls 
                    className="w-full h-auto"
                    style={{ maxHeight: '420px' }}
                  >
                    <source src={generatedVideoUrl} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                </div>
              ) : (
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="relative">
                      <div className="w-16 h-16 border-4 border-gray-200 border-t-[#e87722] rounded-full animate-spin"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Video className="w-6 h-6 text-[#e87722]" />
                      </div>
                    </div>
                  </div>
                  <div className="text-lg font-medium text-gray-700 mb-2">Generating Video...</div>
                  <div className="text-sm text-gray-500">Please wait while your video is being generated</div>
                  <div className="mt-4 text-xs text-gray-400">This may take a few minutes</div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Product Image Selection Modal */}
      {isProductImageModalVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Select Product Image</h3>
                <p className="text-sm text-gray-500">Choose a product image to generate lifestyle content</p>
              </div>
              <button
                onClick={() => setIsProductImageModalVisible(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              {SAMPLE_PRODUCT_IMAGES.map((image: { name: string; url: string; category: string }) => (
                <div
                  key={image.url}
                  className="border border-gray-200 rounded-lg p-4 cursor-pointer hover:border-[#e87722] transition-colors"
                  onClick={() => handleProductImageSelect(image.url, image.name)}
                >
                  <div className="w-full h-32 bg-white rounded mb-3 flex items-center justify-center overflow-hidden">
                    <img 
                      src={image.url} 
                      alt={image.name}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-gray-800 text-sm">{image.name}</div>
                    <div className="text-xs text-gray-500">{image.category}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoGeneration; 