import React, { useState } from 'react';
import { Card, Typography, Row, Col, Button, Tooltip } from 'antd';
import { Sparkles, MessageSquare, ArrowLeft, Upload, FileText, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import RetailFooter from './RetailFooter';
import * as XLSX from 'xlsx';
import { Pie, PieChart, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';

const { Title, Text } = Typography;

// Product review files with enhanced data structure
const PRODUCT_REVIEW_FILES: ProductReviewFile[] = [
  { 
    name: 'Camera Product Reviews.xlsx', 
    url: '/retail/camera_product_reviews.xlsx', 
    description: 'Camera product reviews dataset',
    data: [
      { username: 'John Smith', email: 'john.smith@email.com', phone: '+1-555-0123', review: 'Excellent camera quality and features', rating: 5 },
      { username: 'Sarah Johnson', email: 'sarah.j@email.com', phone: '+1-555-0124', review: 'Great performance but expensive', rating: 4 },
      { username: 'Mike Davis', email: 'mike.davis@email.com', phone: '+1-555-0125', review: 'Amazing image clarity and zoom', rating: 5 },
      { username: 'Emily Wilson', email: 'emily.w@email.com', phone: '+1-555-0126', review: 'Good camera but battery life could be better', rating: 3 },
      { username: 'David Brown', email: 'david.brown@email.com', phone: '+1-555-0127', review: 'Perfect for professional photography', rating: 5 },
      { username: 'Lisa Anderson', email: 'lisa.a@email.com', phone: '+1-555-0128', review: 'Compact design with great features', rating: 4 },
      { username: 'Robert Taylor', email: 'robert.t@email.com', phone: '+1-555-0129', review: 'Excellent low-light performance', rating: 5 },
      { username: 'Jennifer Lee', email: 'jennifer.lee@email.com', phone: '+1-555-0130', review: 'Good value for money', rating: 4 },
      { username: 'Michael White', email: 'michael.w@email.com', phone: '+1-555-0131', review: 'Fast autofocus and great build quality', rating: 5 },
      { username: 'Amanda Garcia', email: 'amanda.g@email.com', phone: '+1-555-0132', review: 'Beautiful photos but complex menu system', rating: 3 }
    ]
  },
  { 
    name: 'Shoe Product Reviews.xlsx', 
    url: '/retail/shoe_product_reviews.xlsx', 
    description: 'Shoe product reviews dataset',
    data: [
      { username: 'Alex Thompson', email: 'alex.t@email.com', phone: '+1-555-0201', review: 'Very comfortable and stylish', rating: 5 },
      { username: 'Rachel Green', email: 'rachel.g@email.com', phone: '+1-555-0202', review: 'Great for running and daily wear', rating: 4 },
      { username: 'Chris Martin', email: 'chris.m@email.com', phone: '+1-555-0203', review: 'Excellent cushioning and support', rating: 5 },
      { username: 'Jessica Kim', email: 'jessica.k@email.com', phone: '+1-555-0204', review: 'Good quality but runs small', rating: 3 },
      { username: 'Daniel Rodriguez', email: 'daniel.r@email.com', phone: '+1-555-0205', review: 'Perfect fit and great durability', rating: 5 },
      { username: 'Maria Gonzalez', email: 'maria.g@email.com', phone: '+1-555-0206', review: 'Lightweight and breathable', rating: 4 },
      { username: 'Kevin Chen', email: 'kevin.c@email.com', phone: '+1-555-0207', review: 'Excellent traction on various surfaces', rating: 5 },
      { username: 'Nicole Adams', email: 'nicole.a@email.com', phone: '+1-555-0208', review: 'Good arch support for long walks', rating: 4 },
      { username: 'Steven Miller', email: 'steven.m@email.com', phone: '+1-555-0209', review: 'Durable construction and great comfort', rating: 5 },
      { username: 'Hannah Clark', email: 'hannah.c@email.com', phone: '+1-555-0210', review: 'Stylish design with good functionality', rating: 4 }
    ]
  }
];

// Sample images for the popup
const SAMPLE_IMAGES = [
  { name: 'Kitchen Knife Set', url: '/retail/knife_set.jpg', category: 'Kitchen' },
  { name: 'Running Shoes', url: '/retail/shoe.jpg', category: 'Footwear' },
  { name: 'Premium Headphones', url: '/retail/headphone.jpg', category: 'Electronics' },
  { name: 'Digital Camera', url: '/retail/camera1.jpg', category: 'Electronics' },
  { name: 'Stylish Sunglasses', url: '/retail/sunglasses.jpg', category: 'Accessories' },
  { name: 'Premium Watch', url: '/retail/watch.jpg', category: 'Accessories' }
];

// Interface for API response
interface GeneratedContent {
  title: string;
  description: string;
  tags: string[];
  category: string;
  subcategory: string;
  color: string[] | string;
  target_audience: string;
  use_case: string[] | string;
}

// Interface for enhanced product review file
interface ProductReviewFile {
  name: string;
  url: string;
  description: string;
  data: {
    username: string;
    email: string;
    phone: string;
    review: string;
    rating: number;
  }[];
}

// Interface for review analysis response
interface ReviewAnalysis {
  sentiment_distribution: {
    positive: string;
    neutral: string;
    negative: string;
  };
  top_pros: string[];
  top_cons: string[];
  feature_requests: string[];
  customer_insights: {
    average_rating: string;
    total_reviews: number;
    recommendation_rate: string;
  };
}

const ProductOptimizationAssistant = () => {
  // State management for UI components and data
  const [activeTab, setActiveTab] = useState('listing-generator');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [listingContentGenerated, setListingContentGenerated] = useState(false);
  const [reviewContentGenerated, setReviewContentGenerated] = useState(false);
  const [selectedReviewFile, setSelectedReviewFile] = useState<string | null>(null);
  const [sheetPreview, setSheetPreview] = useState<any[]>([]);
  const [isSheetLoading, setIsSheetLoading] = useState(false);
  
  // Navigation and modal state
  const navigate = useNavigate();
  const [isImageModalVisible, setIsImageModalVisible] = useState(false);
  const [isFileModalVisible, setIsFileModalVisible] = useState(false);
  
  // API response data and error states
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const [reviewAnalysis, setReviewAnalysis] = useState<ReviewAnalysis | null>(null);

  // Tab configuration for the main interface
  const tabs = [
    {
      key: 'listing-generator',
      title: 'AI-powered Product Listing Generator',
      icon: <Sparkles size={20} />,
      description: 'Generate optimized titles, descriptions, and attribute tags from product images'
    },
    {
      key: 'review-analyzer',
      title: 'Product Review Analyzer',
      icon: <MessageSquare size={20} />,
      description: 'Analyze product reviews for sentiment, pros/cons, and feature requests'
    }
  ];

  /**
   * Converts an image URL to Base64 string for API transmission
   * @param imageUrl - The URL of the image to convert
   * @returns Promise<string> - Base64 encoded string without data URL prefix
   */
  const convertImageToBase64 = async (imageUrl: string): Promise<string> => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = reader.result as string;
          // Remove the data URL prefix to get just the base64 string
          const base64 = base64String.split(',')[1];
          resolve(base64);
        };
        reader.onerror = (error) => {
          console.error('FileReader error:', error);
          reject(error);
        };
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error('Error converting image to Base64:', error);
      throw error;
    }
  };

  /**
   * Makes API call to generate product listing content from image
   * @param imageBase64 - Base64 encoded image string
   * @returns Promise<GeneratedContent> - Generated product listing data
   */
  const generateProductListing = async (imageBase64: string): Promise<GeneratedContent> => {
    try {
      // Use environment variable for API endpoint
      const apiEndpoint = import.meta.env.VITE_API_BASE_URL;
      
      const response = await fetch(apiEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_type: 'genai_product_desc',
          image_base64: imageBase64
        })
      });

      if (!response.ok) {
        throw new Error(`API call failed with status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error calling API:', error);
      // Return mock data for demo purposes when API is not available
      return {
        title: 'Sony Alpha 7 Full-Frame Mirrorless Camera',
        description: 'The Sony Alpha 7 is a high-performance full-frame mirrorless camera that delivers exceptional image quality and advanced features in a compact, lightweight body. With its cutting-edge imaging sensor, advanced autofocus, and intuitive controls, this camera is a versatile choice for photography enthusiasts and professionals alike.',
        tags: ['full-frame', 'mirrorless', 'Sony', 'high-performance', 'advanced', 'compact', 'versatile'],
        category: 'Electronics',
        subcategory: 'Cameras',
        color: ['black'],
        target_audience: 'Photography enthusiasts, professionals',
        use_case: ['landscape', 'portraiture', 'action', 'low-light']
      };
    }
  };

  /**
   * Helper function to parse percentage string to number
   * @param percentageStr - Percentage string like "65%"
   * @returns number - Parsed percentage as number
   */
  const parsePercentage = (percentageStr: string): number => {
    if (!percentageStr) return 0;
    return parseInt(percentageStr.replace('%', '')) || 0;
  };

  /**
   * Converts Excel data to the required JSON format for review analysis
   * @param excelData - Raw Excel data from XLSX
   * @returns Array of review objects with review and rating
   */
  const convertExcelToReviewFormat = (excelData: any[]): { review: string; rating: number }[] => {
    if (!excelData || excelData.length < 2) return [];
    
    // Skip header row and convert data
    // For enhanced data structure, review is at index 3 and rating at index 4
    const reviews = [];
    for (let i = 1; i < excelData.length; i++) {
      const row = excelData[i];
      if (row && row.length >= 5) {
        const review = row[3] || ''; // Review column (index 3)
        const rating = parseInt(row[4]) || 0; // Rating column (index 4)
        if (review && rating > 0) {
          reviews.push({ review, rating });
        }
      }
    }
    return reviews;
  };

  /**
   * Makes API call to analyze product reviews
   * @param spreadsheetJson - Array of review objects
   * @returns Promise<ReviewAnalysis> - Review analysis data
   */
  const analyzeProductReviews = async (spreadsheetJson: { review: string; rating: number }[]): Promise<ReviewAnalysis> => {
    try {
      // Use environment variable for API endpoint
      const apiEndpoint = import.meta.env.VITE_API_BASE_URL;
      
      const response = await fetch(apiEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event_type: 'product_review_analyzer',
          spreadsheet_json: spreadsheetJson
        })
      });

      if (!response.ok) {
        throw new Error(`API call failed with status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error calling review analysis API:', error);
      // Return mock data for demo purposes when API is not available
      return {
        sentiment_distribution: {
          positive: "65%",
          neutral: "20%",
          negative: "15%"
        },
        top_pros: [
          "Excellent sound quality",
          "Comfortable fit",
          "Good battery life"
        ],
        top_cons: [
          "Expensive price",
          "Limited color options"
        ],
        feature_requests: [
          "More color options requested by 23% of customers",
          "Wireless charging case suggested by 18% of customers",
          "Better noise cancellation for calls mentioned by 15% of customers"
        ],
        customer_insights: {
          average_rating: "4.2/5",
          total_reviews: 1247,
          recommendation_rate: "87%"
        }
      };
    }
  };

  // DonutChart component for sentiment using recharts
  const DonutChart = ({ positive, neutral, negative }: { positive: number; neutral: number; negative: number }) => {
    const data = [
      { name: 'Positive', value: positive, color: '#22c55e' },
      { name: 'Neutral', value: neutral, color: '#facc15' },
      { name: 'Negative', value: negative, color: '#ef4444' }
    ];

    const CustomTooltip = ({ active, payload }: any) => {
      if (active && payload && payload.length) {
        return (
          <div className="bg-black text-white text-xs px-2 py-1 rounded shadow-lg">
            <p>{`${payload[0].name}: ${payload[0].value}%`}</p>
          </div>
        );
      }
      return null;
    };

    return (
      <div className="flex flex-col items-center justify-center">
        <div className="w-32 h-32">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={30}
                outerRadius={50}
                paddingAngle={2}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <RechartsTooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex justify-center gap-6 mt-3">
          <div className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded-full bg-[#22c55e]"></span><span className="text-xs text-gray-700">Positive</span></div>
          <div className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded-full bg-[#facc15]"></span><span className="text-xs text-gray-700">Neutral</span></div>
          <div className="flex items-center gap-1"><span className="inline-block w-3 h-3 rounded-full bg-[#ef4444]"></span><span className="text-xs text-gray-700">Negative</span></div>
        </div>
      </div>
    );
  };

  // Helper to fetch and parse Excel file
  const handleSheetSelect = async (fileUrl: string) => {
    setIsSheetLoading(true);
    setSheetPreview([]);
    setSelectedReviewFile(fileUrl);
    try {
      // Find the selected file data
      const selectedFile = PRODUCT_REVIEW_FILES.find(file => file.url === fileUrl);
      if (selectedFile && selectedFile.data) {
        // Create Excel data structure with headers
        const headers = ['Username', 'Email ID', 'Phone Number', 'Review', 'Rating'];
        const excelData = [headers];
        
        // Add data rows
        selectedFile.data.forEach(row => {
          excelData.push([
            row.username,
            row.email,
            row.phone,
            row.review,
            row.rating.toString()
          ]);
        });
        
        setSheetPreview(excelData);
      } else {
        // Fallback to original file parsing if data not found
        const response = await fetch(fileUrl);
        const arrayBuffer = await response.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        setSheetPreview(data);
      }
    } catch (e) {
      setSheetPreview([]);
    }
    setIsSheetLoading(false);
  };

  const handleImageSelect = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setIsImageModalVisible(false);
  };

  const handleFileSelect = (fileUrl: string) => {
    setSelectedReviewFile(fileUrl);
    setIsFileModalVisible(false);
    // Reset review analysis when selecting a new file
    setReviewAnalysis(null);
    setReviewContentGenerated(false);
    handleSheetSelect(fileUrl);
  };

  /**
   * Handles the image analysis process including Base64 conversion and API call
   */
  const handleAnalyzeImage = async () => {
    if (selectedImage && !isAnalyzing) {
      setIsAnalyzing(true);
      setApiError(null);
      try {
        // Convert image to Base64 for API transmission
        const imageBase64 = await convertImageToBase64(selectedImage);
        
        // Call API to generate product listing content
        const generatedData = await generateProductListing(imageBase64);
        
        // Update state with generated content
        setGeneratedContent(generatedData);
        setListingContentGenerated(true);
      } catch (error) {
        console.error('Error analyzing image:', error);
        setApiError('Failed to analyze image. Please try again.');
        setListingContentGenerated(false);
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <LoginNavbar />
      
      {/* Main Content */}
      <div className="px-4 md:px-8 lg:px-16 mx-auto py-6 max-w-7xl">
        {/* Breadcrumb */}
        <nav className="mb-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <button
              onClick={() => navigate('/customer/sandbox/retailhome')}
              className="flex items-center gap-2 text-[#e87722] hover:text-[#d0691d] no-underline"
            >
              <Home size={16} className="relative top-[-1px]" />
              <span>Home</span>
            </button>
            <span>/</span>
            <span className="text-gray-900">Product Optimization Assistant</span>
          </div>
        </nav>

        {/* Page Header */}
        <div className="mb-8">
          <Title level={1} className="!text-3xl !font-bold !mb-2 !text-gray-900">
            Product Optimization Assistant
          </Title>
          <Text className="text-gray-600 !text-base">
            Optimize your product listings and analyze customer reviews with AI-powered tools
          </Text>
        </div>

        {/* Tab Selectors */}
        <div className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
            {tabs.map((tab) => (
              <div
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`cursor-pointer rounded-lg p-6 transition-all duration-200 ${
                  activeTab === tab.key
                    ? 'bg-white border-2 border-[#e87722]'
                    : 'bg-white hover:bg-gray-50'
                }`}
                style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)' }}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="w-11 h-11 rounded-lg flex items-center justify-center mb-3 bg-[#e87722]">
                    {tab.key === 'listing-generator' ? (
                      <Sparkles size={28} className="text-white" />
                    ) : tab.key === 'review-analyzer' ? (
                      <MessageSquare size={28} className="text-white" />
                    ) : (
                      React.cloneElement(tab.icon, {
                        size: 24,
                        className: 'text-white',
                      })
                    )}
                  </div>
                  <Title level={4} className="!text-lg !font-semibold !mb-2 !text-gray-900">
                    {tab.title}
                  </Title>
                  <Text className="text-gray-600 !text-sm leading-relaxed">
                    {tab.description}
                  </Text>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="mt-8">
          {activeTab === 'listing-generator' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left: Image Display and Selection */}
              <div className="rounded-lg bg-white h-[500px]" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'hidden' }}>
                <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                      <Sparkles size={16} className="text-white" />
                    </div>
                    <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Product Images</h5>
                  </div>
                </div>
                <div className="p-6 flex flex-col h-full">
                  {/* Large Image Display */}
                  <div className="mb-6 flex-shrink-0">
                    {selectedImage ? (
                      <div className="w-full h-64 bg-white rounded-lg overflow-hidden flex items-center justify-center border border-gray-200">
                        <img 
                          src={selectedImage} 
                          alt="Selected Product"
                          className="w-full h-full object-contain"
                        />
                      </div>
                    ) : (
                      <div className="w-full h-64 bg-white rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                        <div className="text-center text-gray-500">
                          <Sparkles size={48} className="mx-auto mb-4 text-gray-400" />
                          <Text className="!text-lg !font-medium">No image selected</Text>
                          <Text className="!text-sm !text-gray-500 block mt-2">Click the button below to select an image</Text>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Upload Button */}
                  <Button 
                    type="default"
                    className={`w-full mb-6 border-2 border-dashed transition-colors flex-shrink-0 ${
                      isAnalyzing 
                        ? 'border-gray-200 bg-gray-50 text-gray-400 cursor-not-allowed' 
                        : 'border-gray-300 hover:border-[#e87722]'
                    }`}
                    icon={<Upload size={16} />}
                    disabled={isAnalyzing}
                    onClick={() => !isAnalyzing && setIsImageModalVisible(true)}
                  >
                    Upload Images
                  </Button>

                  {/* Analyze Button */}
                  <Button 
                    type="primary" 
                    className={`w-full flex-shrink-0 ${isAnalyzing ? '!bg-[#e87722]/60 !border-[#e87722]/60 cursor-not-allowed' : '!bg-[#e87722] !border-[#e87722] hover:!bg-[#d0691d] hover:!border-[#d0691d]'}`}
                    icon={isAnalyzing ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div> : <Sparkles size={16} />}
                    disabled={isAnalyzing || !selectedImage}
                    onClick={handleAnalyzeImage}
                  >
                    {isAnalyzing ? 'Analyzing...' : 'Analyze Image'}
                  </Button>
                </div>
              </div>

              {/* Right: Generated Content */}
              <div className="rounded-lg bg-white flex flex-col h-[500px]" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'hidden' }}>
                <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between flex-shrink-0" style={{ padding: '1rem 1.5rem' }}>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                      <Sparkles size={16} className="text-white" />
                    </div>
                    <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Generated Content</h5>
                  </div>
                </div>
                <div className={`p-6 flex-1 overflow-y-auto${!listingContentGenerated ? ' flex items-center justify-center' : ''}`}>
                  {apiError ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <div className="text-red-500 mb-2">
                          <svg className="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <Text className="!text-red-500 !font-medium">{apiError}</Text>
                        <Button 
                          type="primary" 
                          size="small" 
                          className="mt-3 !bg-[#e87722] !border-[#e87722]"
                          onClick={() => {
                            setApiError(null);
                            setListingContentGenerated(false);
                          }}
                        >
                          Try Again
                        </Button>
                      </div>
                    </div>
                  ) : !listingContentGenerated ? (
                    <div
                      style={{
                        color: '#b0b0b0',
                        fontSize: '0.9rem',
                        fontWeight: 400,
                        letterSpacing: '0.01em',
                        textAlign: 'center',
                        fontFamily: 'Inter, sans-serif',
                        width: '100%'
                      }}
                    >
                      <div>
                        Click <span className="font-bold" style={{ color: '#b0b0b0', fontWeight: 700, fontFamily: 'Inter, sans-serif' }}>'Analyze Image'</span>
                      </div>
                      <div style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                        to unlock your generated content!
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div>
                        <Text className="!text-sm !font-medium !text-gray-700">Optimized Title :</Text>
                        <div className="mt-2">
                          <Text className="!text-sm">{generatedContent?.title}</Text>
                        </div>
                      </div>
                      <div>
                        <Text className="!text-sm !font-medium !text-gray-700">Product Description :</Text>
                        <div className="mt-2">
                          <Text className="!text-sm">{generatedContent?.description}</Text>
                        </div>
                      </div>
                      <div>
                        <Text className="!text-sm !font-medium !text-gray-700">Attribute Tags :</Text>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {generatedContent?.tags.map((tag, index) => (
                            <span key={index} className="inline-block bg-[#e8782222] text-[#e87722] text-xs font-medium px-2.5 py-1 rounded-md">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Category :</Text>
                          <div className="mt-2">
                            <Text className="!text-sm">{generatedContent?.category}</Text>
                          </div>
                        </div>
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Subcategory :</Text>
                          <div className="mt-2">
                            <Text className="!text-sm">{generatedContent?.subcategory}</Text>
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Color :</Text>
                          <div className="mt-2">
                            <Text className="!text-sm">
                              {Array.isArray(generatedContent?.color) 
                                ? generatedContent?.color.join(', ') 
                                : generatedContent?.color}
                            </Text>
                          </div>
                        </div>
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Target Audience :</Text>
                          <div className="mt-2">
                            <Text className="!text-sm">{generatedContent?.target_audience}</Text>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Text className="!text-sm !font-medium !text-gray-700">Use Case :</Text>
                        <div className="mt-2">
                          <Text className="!text-sm">
                            {Array.isArray(generatedContent?.use_case) 
                              ? generatedContent?.use_case.join(', ') 
                              : generatedContent?.use_case}
                          </Text>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'review-analyzer' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left: Review Input Area */}
              <div className="rounded-lg bg-white h-[480px]" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'hidden' }}>
                <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                      <MessageSquare size={16} className="text-white" />
                    </div>
                    <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Product Reviews</h5>
                  </div>
                </div>
                <div className="p-6 pb-0 flex-1 min-h-0 flex flex-col" style={{ height: 'calc(450px - 80px)' }}>
                  <div className="mb-6 flex-shrink-0">
                    {selectedReviewFile ? (
                      <div className="w-full h-64 bg-white rounded-lg overflow-hidden flex items-center justify-center border-2 border-[#e87722]">
                        <div className="text-center">
                          <svg className="w-16 h-16 mx-auto mb-4 text-[#e87722]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          <Text className="!text-lg !font-medium">{PRODUCT_REVIEW_FILES.find(f => f.url === selectedReviewFile)?.name}</Text>
                          <Text className="!text-sm !text-gray-500 block mt-2">{PRODUCT_REVIEW_FILES.find(f => f.url === selectedReviewFile)?.description}</Text>
                        </div>
                      </div>
                    ) : (
                      <div className="w-full h-64 bg-white rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
                        <div className="text-center text-gray-500">
                          <MessageSquare size={48} className="mx-auto mb-4 text-gray-400" />
                          <Text className="!text-lg !font-medium">No file selected</Text>
                          <Text className="!text-sm !text-gray-500 block mt-2">Click the button below to select a file</Text>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Upload Button */}
                  <Button 
                    type="default"
                    className={`w-full mb-6 border-2 border-dashed transition-colors flex-shrink-0 ${
                      isAnalyzing 
                        ? 'border-gray-200 bg-gray-50 text-gray-400 cursor-not-allowed' 
                        : 'border-gray-300 hover:border-[#e87722]'
                    }`}
                    icon={<Upload size={16} />}
                    disabled={isAnalyzing}
                    onClick={() => !isAnalyzing && setIsFileModalVisible(true)}
                  >
                    Upload Files
                  </Button>
                  <div className="mt-auto">
                    <Button
                      type="primary"
                      className={`w-full ${isAnalyzing ? '!bg-[#e87722]/60 !border-[#e87722]/60 cursor-not-allowed' : '!bg-[#e87722] !border-[#e87722] hover:!bg-[#d0691d] hover:!border-[#d0691d]'}`}
                      icon={isAnalyzing ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div> : <MessageSquare size={16} />}
                      disabled={isAnalyzing || !selectedReviewFile}
                      onClick={async () => {
                        if (selectedReviewFile && !isAnalyzing) {
                          setIsAnalyzing(true);
                          setApiError(null);
                          try {
                            // Convert Excel data to required format
                            const reviews = convertExcelToReviewFormat(sheetPreview);
                            
                            // Call API to analyze reviews
                            const analysisData = await analyzeProductReviews(reviews);
                            
                            // Update state with analysis results
                            setReviewAnalysis(analysisData);
                            setReviewContentGenerated(true);
                          } catch (error) {
                            console.error('Error analyzing reviews:', error);
                            setApiError('Failed to analyze reviews. Please try again.');
                            setReviewContentGenerated(false);
                          } finally {
                            setIsAnalyzing(false);
                          }
                        }
                      }}
                    >
                      {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                    </Button>
                  </div>
                </div>
              </div>

              {/* Right: Analysis Results */}
              <div className="rounded-lg bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none', overflow: 'hidden' }}>
                <div className="card-header with-separator bg-white fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
                  <div className="flex items-center">
                    <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                      <MessageSquare size={16} className="text-white" />
                    </div>
                    <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Analysis Results</h5>
                  </div>
                </div>
                <div className="p-6 h-[400px] overflow-y-auto">
                  <div className="space-y-4 h-full">
                    {!reviewContentGenerated ? (
                      <div className="flex items-center justify-center h-full">
                        <div
                          style={{
                            color: '#b0b0b0',
                            fontSize: '0.9rem',
                            fontWeight: 400,
                            letterSpacing: '0.01em',
                            textAlign: 'center',
                            fontFamily: 'Inter, sans-serif',
                            width: '100%'
                          }}
                        >
                          <div>
                            Click <span className="font-bold" style={{ color: '#b0b0b0', fontWeight: 700, fontFamily: 'Inter, sans-serif' }}>'Analyze'</span>
                          </div>
                          <div style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                            to unlock your analysis results!
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="h-full space-y-6">
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Sentiment Distribution :</Text>
                          <div className="mt-2 flex flex-col items-center">
                            <DonutChart 
                              positive={parsePercentage(reviewAnalysis?.sentiment_distribution.positive || '0')} 
                              neutral={parsePercentage(reviewAnalysis?.sentiment_distribution.neutral || '0')} 
                              negative={parsePercentage(reviewAnalysis?.sentiment_distribution.negative || '0')} 
                            />

                          </div>
                        </div>
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Top Pros :</Text>
                          <div className="mt-2">
                            {reviewAnalysis?.top_pros && reviewAnalysis.top_pros.length > 0 ? (
                              <div className="space-y-1">
                                {reviewAnalysis.top_pros.map((pro, index) => (
                                  <div key={index} className="flex items-center gap-2">
                                    <span className="text-green-500">✓</span>
                                    <Text className="!text-sm">{pro}</Text>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <Text className="!text-sm text-gray-500">Nil</Text>
                            )}
                          </div>
                        </div>
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Top Cons :</Text>
                          <div className="mt-2">
                            {reviewAnalysis?.top_cons && reviewAnalysis.top_cons.length > 0 ? (
                              <div className="space-y-1">
                                {reviewAnalysis.top_cons.map((con, index) => (
                                  <div key={index} className="flex items-center gap-2">
                                    <span className="text-red-500">✗</span>
                                    <Text className="!text-sm">{con}</Text>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <Text className="!text-sm text-gray-500">Nil</Text>
                            )}
                          </div>
                        </div>
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Feature Requests :</Text>
                          <div className="mt-2">
                            {reviewAnalysis?.feature_requests && reviewAnalysis.feature_requests.length > 0 ? (
                              <ul className="list-disc pl-5 space-y-1">
                                {reviewAnalysis.feature_requests.map((request, index) => (
                                  <li key={index} className="!text-sm">{request}</li>
                                ))}
                              </ul>
                            ) : (
                              <Text className="!text-sm text-gray-500">Nil</Text>
                            )}
                          </div>
                        </div>
                        <div>
                          <Text className="!text-sm !font-medium !text-gray-700">Customer Insights :</Text>
                          <div className="mt-2">
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm text-gray-600">Average Rating:</span>
                                <span className="text-sm font-medium">{reviewAnalysis?.customer_insights.average_rating || 'Nil'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-sm text-gray-600">Total Reviews:</span>
                                <span className="text-sm font-medium">{reviewAnalysis?.customer_insights.total_reviews ? reviewAnalysis.customer_insights.total_reviews.toLocaleString() : 'Nil'}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-sm text-gray-600">Recommendation Rate:</span>
                                <span className="text-sm font-medium">{reviewAnalysis?.customer_insights.recommendation_rate || 'Nil'}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Image Selection Modal */}
      {isImageModalVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Select Sample Image</h3>
                <p className="text-sm text-gray-500">Choose a sample image to analyze and generate content</p>
              </div>
              <button
                onClick={() => setIsImageModalVisible(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              {SAMPLE_IMAGES.map((image: { name: string; url: string; category: string }) => (
                <div
                  key={image.url}
                  className="border border-gray-200 rounded-lg p-4 cursor-pointer hover:border-[#e87722] transition-colors"
                  onClick={() => handleImageSelect(image.url)}
                >
                  <div className="w-full h-32 bg-white rounded mb-3 flex items-center justify-center overflow-hidden">
                    <img 
                      src={image.url} 
                      alt={image.name}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-gray-800 text-sm">{image.name}</div>
                    <div className="text-xs text-gray-500">{image.category}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* File Selection Modal */}
      {isFileModalVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Select Review File</h3>
                <p className="text-sm text-gray-500">Choose a review dataset to analyze</p>
              </div>
              <button
                onClick={() => setIsFileModalVisible(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {PRODUCT_REVIEW_FILES.map((file) => (
                <div
                  key={file.url}
                  className={`p-4 rounded-lg border-2 transition-colors cursor-pointer ${
                    selectedReviewFile === file.url 
                      ? 'border-[#e87722] bg-[#e87722] text-white' 
                      : 'border-gray-200 bg-white text-gray-800 hover:border-[#e87722]'
                  }`}
                  onClick={() => handleFileSelect(file.url)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 flex-1">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      <div>
                        <div className="font-semibold">{file.name}</div>
                        <div className="text-sm opacity-70">{file.description}</div>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        // Create enhanced Excel data with headers
                        const headers = ['Username', 'Email ID', 'Phone Number', 'Review', 'Rating'];
                        const excelData = [headers];
                        
                        // Add data rows with enhanced user information
                        if (file.data && file.data.length > 0) {
                          file.data.forEach(row => {
                            excelData.push([
                              row.username,
                              row.email,
                              row.phone,
                              row.review,
                              row.rating.toString()
                            ]);
                          });
                        } else {
                          // Fallback: show error if no data available
                          console.warn('No enhanced data available for file:', file.name);
                          return;
                        }
                        
                        try {
                          // Create workbook and worksheet
                          const workbook = XLSX.utils.book_new();
                          const worksheet = XLSX.utils.aoa_to_sheet(excelData);
                          
                          // Add worksheet to workbook
                          XLSX.utils.book_append_sheet(workbook, worksheet, 'Product Reviews');
                          
                          // Generate Excel file and download
                          const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
                          const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                          const url = window.URL.createObjectURL(blob);
                          
                          const link = document.createElement('a');
                          link.href = url;
                          link.download = file.name;
                          document.body.appendChild(link);
                          link.click();
                          document.body.removeChild(link);
                          
                          // Clean up URL object
                          window.URL.revokeObjectURL(url);
                        } catch (error) {
                          console.error('Error generating Excel file:', error);
                          alert('Failed to generate Excel file. Please try again.');
                        }
                      }}
                      className={`p-2 rounded-md transition-colors ${
                        selectedReviewFile === file.url 
                          ? 'text-white hover:bg-white/20' 
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                      title="Download enhanced file with user details"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <RetailFooter />
    </div>
  );
};

export default ProductOptimizationAssistant; 