import React from 'react';
import { MessageSquare, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import RetailAssistantTool from './RetailAssistantTool';
import LoginNavbar from '../../components/layout/LoginNavbar';
import RetailFooter from './RetailFooter';

const RetailAssistantPage: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <LoginNavbar />
      <div className="flex-grow container mx-auto px-4 py-4">
        <div className="mx-auto w-full max-w-10xl mt-8">
          <div className="mb-4">
            <div className="w-full">
              <nav className="flex text-sm text-gray-500 mb-2 -mt-6 -ml-5" aria-label="Breadcrumb">
                <ol className="inline-flex items-center space-x-1">
                  <li>
                    <button 
                      type="button" 
                      onClick={() => navigate('/customer/sandbox/retailhome')} 
                      className="flex items-center text-orange-600 hover:underline"
                      style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
                    >
                      <Home size={16} className="mr-1" />
                      Home
                    </button>
                  </li>
                  <li>
                    <span className="mx-2">/</span>
                    <span className="text-gray-500">Customer Service Assistant</span>
                  </li>
                </ol>
              </nav>
              <div className="flex items-center mb-2">
                <div className="ub-feature-icon mr-3">
                  <MessageSquare size={30} />
                </div>
                <div>
                  <h2 className="mb-0 text-3xl font-bold">Customer Service Assistant</h2>
                  <p className="text-gray-500">AI-powered chatbot helping customers discover products, compare prices, and get shopping assistance using advanced RAG technology</p>
                </div>
              </div>
            </div>
          </div>
          
          <RetailAssistantTool />
        </div>
      </div>
      <RetailFooter />
    </div>
  );
};

export default RetailAssistantPage;