import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, User, Building, Mail, Phone, Calendar, Users } from 'lucide-react';


const mockEvents = [
    { id: '1', name: 'GenAI for Banking Summit', date: '2025-02-15' },
    { id: '2', name: 'Insurance AI Workshop', date: '2025-01-28' },
    { id: '3', name: 'Retail AI Innovation Conference', date: '2025-01-20' }
];

const industries = [
    'Banking & Finance', 'Insurance', 'Retail & E-commerce', 'Healthcare',
    'Manufacturing', 'Logistics & Supply Chain', 'Media & Entertainment', 'Government'
];

const companySizes = [
    '1-10 employees', '11-50 employees', '51-200 employees',
    '201-1000 employees', '1000+ employees'
];

const sandboxModules = [
    'PolicyPal Assistant', 'FreightLens', 'Product Vision Search',
    'BankAssist Suite', 'VideoInsight Studio'
];

export default function PublicRegistration() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const eventIdFromUrl = searchParams.get('event') || '';
    const [formData, setFormData] = useState({
        eventId: eventIdFromUrl,
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        jobTitle: '',
        company: '',
        industry: '',
        companySize: '',
        interests: [] as string[],
        specialRequests: '',
        howDidYouHear: ''
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Basic validation
        if (!formData.eventId || !formData.firstName || !formData.lastName || !formData.email || !formData.company) {
            alert('Please fill in all required fields.');
            return;
        }
        // Simulate registration
        console.log('Registering customer:', formData);
        alert('Thank you for registering! Your registration has been received.');
        navigate('/');
    };

    const handleInterestChange = (module: string) => {
        setFormData(prev => ({
            ...prev,
            interests: prev.interests.includes(module)
                ? prev.interests.filter(i => i !== module)
                : [...prev.interests, module]
        }));
    };

    const selectedEvent = mockEvents.find(event => event.id === formData.eventId);
    const customerData = {
        name: `${formData.firstName} ${formData.lastName}`,
        email: formData.email,
        company: formData.company,
        eventName: selectedEvent?.name || '',
        eventDate: selectedEvent?.date || ''
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col items-center py-8 px-2">
            <div className="w-full max-w-2xl space-y-8">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Event Registration</h1>
                    <p className="text-gray-600 mt-2">Register to attend a GenAI Sandbox event</p>
                </div>

                {/* Show event info if pre-selected via URL param */}
                {eventIdFromUrl && selectedEvent && (
                    <div className="bg-gradient-to-r from-orange-50 to-white border-l-4 border-orange-500 rounded-lg p-4 mb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between shadow-sm">
                        <div className="flex items-center gap-3">
                            <Calendar className="h-6 w-6 text-orange-500" />
                            <div>
                                <div className="text-lg font-semibold text-gray-900">{selectedEvent.name}</div>
                                <div className="text-sm text-gray-600">{new Date(selectedEvent.date).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</div>
                            </div>
                        </div>
                        <span className="mt-2 sm:mt-0 px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-medium w-max">Public Registration</span>
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Event Selection */}
                    {!(eventIdFromUrl && selectedEvent) && (
                        <div className="bg-white rounded-lg shadow-sm border p-6">
                            <h2 className="text-xl font-medium text-gray-900 mb-6">
                                <Calendar className="h-5 w-5 inline mr-2" />
                                Event Selection
                            </h2>
                            <div>
                                <label htmlFor="eventId" className="block text-sm font-medium text-gray-700 mb-2">
                                    Select Event *
                                </label>
                                <select
                                    id="eventId"
                                    required
                                    value={formData.eventId}
                                    onChange={(e) => setFormData(prev => ({ ...prev, eventId: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                >
                                    <option value="">Choose an event...</option>
                                    {mockEvents.map((event) => (
                                        <option key={event.id} value={event.id}>
                                            {event.name} - {new Date(event.date).toLocaleDateString()}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    )}

                    {/* Personal Information */}
                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h2 className="text-xl font-medium text-gray-900 mb-6">
                            <User className="h-5 w-5 inline mr-2" />
                            Personal Information
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-2">
                                    First Name *
                                </label>
                                <input
                                    type="text"
                                    id="firstName"
                                    required
                                    value={formData.firstName}
                                    onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                />
                            </div>
                            <div>
                                <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-2">
                                    Last Name *
                                </label>
                                <input
                                    type="text"
                                    id="lastName"
                                    required
                                    value={formData.lastName}
                                    onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                                    <Mail className="h-4 w-4 inline mr-1" />
                                    Email Address *
                                </label>
                                <input
                                    type="email"
                                    id="email"
                                    required
                                    value={formData.email}
                                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                />
                            </div>
                            <div>
                                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                                    <Phone className="h-4 w-4 inline mr-1" />
                                    Phone Number
                                </label>
                                <input
                                    type="tel"
                                    id="phone"
                                    value={formData.phone}
                                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                />
                            </div>
                            <div>
                                <label htmlFor="jobTitle" className="block text-sm font-medium text-gray-700 mb-2">
                                    Job Title *
                                </label>
                                <input
                                    type="text"
                                    id="jobTitle"
                                    required
                                    value={formData.jobTitle}
                                    onChange={(e) => setFormData(prev => ({ ...prev, jobTitle: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                    placeholder="e.g., VP of Technology"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Company Information */}
                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h2 className="text-xl font-medium text-gray-900 mb-6">
                            <Building className="h-5 w-5 inline mr-2" />
                            Company Information
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-2">
                                    Company Name *
                                </label>
                                <input
                                    type="text"
                                    id="company"
                                    required
                                    value={formData.company}
                                    onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                />
                            </div>
                            <div>
                                <label htmlFor="industry" className="block text-sm font-medium text-gray-700 mb-2">
                                    Industry *
                                </label>
                                <select
                                    id="industry"
                                    required
                                    value={formData.industry}
                                    onChange={(e) => setFormData(prev => ({ ...prev, industry: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                >
                                    <option value="">Select industry...</option>
                                    {industries.map((industry) => (
                                        <option key={industry} value={industry}>{industry}</option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="companySize" className="block text-sm font-medium text-gray-700 mb-2">
                                    <Users className="h-4 w-4 inline mr-1" />
                                    Company Size
                                </label>
                                <select
                                    id="companySize"
                                    value={formData.companySize}
                                    onChange={(e) => setFormData(prev => ({ ...prev, companySize: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                >
                                    <option value="">Select size...</option>
                                    {companySizes.map((size) => (
                                        <option key={size} value={size}>{size}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </div>

                    {/* Interests & Preferences */}
                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h2 className="text-xl font-medium text-gray-900 mb-6">Interests & Preferences</h2>
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-3">
                                    Sandbox Modules of Interest
                                </label>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {sandboxModules.map((module) => (
                                        <label key={module} className="flex items-center">
                                            <input
                                                type="checkbox"
                                                checked={formData.interests.includes(module)}
                                                onChange={() => handleInterestChange(module)}
                                                className="h-4 w-4 text-orange-500 focus:ring-orange-500 border-gray-300 rounded"
                                            />
                                            <span className="ml-2 text-sm text-gray-700">{module}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <label htmlFor="howDidYouHear" className="block text-sm font-medium text-gray-700 mb-2">
                                    How did you hear about us?
                                </label>
                                <select
                                    id="howDidYouHear"
                                    value={formData.howDidYouHear}
                                    onChange={(e) => setFormData(prev => ({ ...prev, howDidYouHear: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                >
                                    <option value="">Select source...</option>
                                    <option value="website">Website</option>
                                    <option value="linkedin">LinkedIn</option>
                                    <option value="referral">Referral</option>
                                    <option value="event">Industry Event</option>
                                    <option value="email">Email Campaign</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div>
                                <label htmlFor="specialRequests" className="block text-sm font-medium text-gray-700 mb-2">
                                    Special Requests or Notes
                                </label>
                                <textarea
                                    id="specialRequests"
                                    rows={3}
                                    value={formData.specialRequests}
                                    onChange={(e) => setFormData(prev => ({ ...prev, specialRequests: e.target.value }))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                                    placeholder="Any specific requirements or questions..."
                                />
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end space-x-4">
                        <button
                            type="button"
                            onClick={() => navigate(-1)}
                            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors duration-200"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-6 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors duration-200"
                        >
                            Register
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
} 