import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Cloud, Rocket, CheckCircle, AlertCircle, Server, DollarSign, Clock, Shield } from 'lucide-react';
import type { Customer } from '../../CustomerTypes';

export default function LaunchCTA() {
  const navigate = useNavigate();
  const [isLaunching, setIsLaunching] = useState(false);
  const [launched, setLaunched] = useState(false);
  const [awsRegion, setAwsRegion] = useState('us-east-1');

  const handleLaunch = async () => {
    setIsLaunching(true);
    
    // Simulate launch process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setIsLaunching(false);
    setLaunched(true);
  };

  const launchDetails = {
    estimatedCost: '$45-75/month',
    setupTime: '15-20 minutes',
    region: awsRegion,
    modules: [
      { name: 'PolicyPal Assistant', instances: 1, cost: '$12/month' },
      { name: 'BankAssist Suite', instances: 1, cost: '$18/month' },
      { name: 'FreightLens', instances: 1, cost: '$15/month' }
    ]
  };

  if (launched) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full">
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-6">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sandbox Launched!</h2>
            <p className="text-gray-600 mb-6">
              Your GenAI Sandbox has been successfully deployed to your AWS account.
            </p>
            
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-gray-900 mb-2">Access Details:</h3>
              <div className="text-sm text-gray-600 space-y-1">
                <p><strong>Region:</strong> {awsRegion}</p>
                <p><strong>Stack Name:</strong> genai-sandbox-prod</p>
                <p><strong>Access URL:</strong> https://sandbox-{Date.now()}.aws.com</p>
              </div>
            </div>
            
            <button
              onClick={() => navigate('/customer/sandbox')}
              className="w-full px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors duration-200"
            >
              Return to Sandbox
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <button
          onClick={() => navigate('/customer/sandbox')}
          className="flex items-center text-gray-600 hover:text-orange-500 transition-colors duration-200 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Sandbox
        </button>
        
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Launch Your Sandbox</h1>
          <p className="text-gray-600 mt-2">Deploy GenAI Sandbox directly to your AWS environment</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Overview */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-4">
              <Cloud className="h-5 w-5 inline mr-2" />
              AWS Deployment Overview
            </h2>
            
            <div className="space-y-4">
              <p className="text-gray-600">
                Launch your personalized GenAI Sandbox environment directly in your AWS account. 
                This will create a production-ready deployment with all the modules you've explored.
              </p>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-2" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium">What happens next:</p>
                    <ul className="mt-2 space-y-1">
                      <li>• CloudFormation stack will be deployed to your AWS account</li>
                      <li>• All necessary IAM roles and policies will be created</li>
                      <li>• EC2 instances will be launched for each module</li>
                      <li>• Load balancers and security groups will be configured</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Configuration */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-4">Deployment Configuration</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">AWS Region</label>
                <select
                  value={awsRegion}
                  onChange={(e) => setAwsRegion(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="us-east-1">US East (N. Virginia)</option>
                  <option value="us-west-2">US West (Oregon)</option>
                  <option value="eu-west-1">Europe (Ireland)</option>
                  <option value="ap-southeast-1">Asia Pacific (Singapore)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Environment Name</label>
                <input
                  type="text"
                  value="genai-sandbox-prod"
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50"
                />
              </div>
            </div>
          </div>

          {/* Modules to Deploy */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-4">
              <Server className="h-5 w-5 inline mr-2" />
              Modules to Deploy
            </h2>
            
            <div className="space-y-3">
              {launchDetails.modules.map((module) => (
                <div key={module.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{module.name}</p>
                    <p className="text-sm text-gray-600">{module.instances} instance(s)</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{module.cost}</p>
                    <p className="text-sm text-gray-600">estimated</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Cost Estimate */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              <DollarSign className="h-5 w-5 inline mr-2" />
              Cost Estimate
            </h3>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Monthly Cost:</span>
                <span className="font-medium">{launchDetails.estimatedCost}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Setup Time:</span>
                <span className="font-medium">{launchDetails.setupTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Region:</span>
                <span className="font-medium">{launchDetails.region}</span>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Note:</strong> Costs may vary based on usage. You can monitor and adjust resources through AWS console.
              </p>
            </div>
          </div>

          {/* Security & Compliance */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              <Shield className="h-5 w-5 inline mr-2" />
              Security & Compliance
            </h3>
            
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>VPC with private subnets</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>IAM roles with least privilege</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>Encrypted data at rest</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                <span>CloudTrail logging enabled</span>
              </div>
            </div>
          </div>

          {/* Launch Button */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Ready to Launch?</h3>
            
            <button
              onClick={handleLaunch}
              disabled={isLaunching}
              className="w-full flex items-center justify-center px-4 py-3 bg-orange-500 text-white rounded-md hover:bg-orange-600 disabled:opacity-50 transition-colors duration-200"
            >
              {isLaunching ? (
                <>
                  <div className="animate-spin h-5 w-5 mr-2 border-2 border-white border-t-transparent rounded-full" />
                  Launching...
                </>
              ) : (
                <>
                  <Rocket className="h-5 w-5 mr-2" />
                  Launch Sandbox
                </>
              )}
            </button>
            
            <p className="text-xs text-gray-500 mt-3 text-center">
              By launching, you agree to AWS charges and our terms of service.
            </p>
          </div>

          {/* Support */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              <Clock className="h-5 w-5 inline mr-2" />
              Need Help?
            </h3>
            
            <div className="space-y-3 text-sm">
              <p className="text-gray-600">
                Our team is here to help with your deployment and any questions you may have.
              </p>
              
              <div className="space-y-2">
                <a href="#" className="block text-orange-600 hover:text-orange-700">
                  📧 Contact Support
                </a>
                <a href="#" className="block text-orange-600 hover:text-orange-700">
                  📚 Deployment Guide
                </a>
                <a href="#" className="block text-orange-600 hover:text-orange-700">
                  💬 Schedule a Call
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}