import React, { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Eye, EyeOff } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
// import type { Customer } from '../../CustomerTypes';

export default function CustomerLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const { setProjectType } = useAppContext();
  const { user, login, isLoading } = useAuth();
  const navigate = useNavigate();

  // Get the current stack selection from environment variables
  const currentStack = import.meta.env.VITE_STACK_SELECTION;
  
  // Define available login options based on stack selection
  const getAvailableLoginOptions = () => {
    const allOptions = [
      {
        email: 'demo@insurance.com',
        password: 'InsuranceDemo2025!',
        name: 'Insurance Demo',
        stack: 'insurance'
      },
      {
        email: 'demo@banking.com',
        password: 'BankingDemo@2025!',
        name: 'Banking Demo',
        stack: 'banking'
      },
      {
        email: 'demo@retail.com',
        password: 'RetailDemo@2025!',
        name: 'Retail Demo',
        stack: 'retail'
      },
      {
        email: 'demo@healthcare.com',
        password: 'HealthcareDemo@2025!',
        name: 'Healthcare Demo',
        stack: 'healthcare'
      },
      {
        email: 'demo@manufacturing.com',
        password: 'ManufacturingDemo@2025!',
        name: 'Manufacturing Demo',
        stack: 'manufacturing'
      }
    ];

    // Normalize stack selection (handle typo: 'manafacturing' -> 'manufacturing')
    const normalizedStack = currentStack === 'manafacturing' ? 'manufacturing' : currentStack;

    // If a specific stack is selected, return only that option
    if (normalizedStack && ['retail', 'insurance', 'banking', 'healthcare', 'manufacturing'].includes(normalizedStack)) {
      return allOptions.filter(option => option.stack === normalizedStack);
    }

    // If no stack is selected or invalid, return all options
    return allOptions;
  };

  const availableOptions = getAvailableLoginOptions();

  // Redirect if already logged in as customer
  if (user && user.role === 'customer') {
    
    if (user.email === 'demo@insurance.com') {
      setProjectType('insurance');
      return <Navigate to="/customer/sandbox/insurancehome" replace />;
    }
    if (user.email === 'demo@banking.com') {
      setProjectType('banking');
      return <Navigate to="/customer/sandbox/bankinghome" replace />;
    }
    if (user.email === 'demo@retail.com') {
      setProjectType('retail');
      return <Navigate to="/customer/sandbox/retailhome" replace />;
    }
    if (user.email === 'demo@healthcare.com') {
      setProjectType('healthcare');
      return <Navigate to="/customer/sandbox/healthcarehome" replace />;
    }
    if (user.email === 'demo@manufacturing.com') {
      setProjectType('manufacturing');
      return <Navigate to="/customer/sandbox/manufacturinghome" replace />;
    }
    return <Navigate to="/customer/sandbox" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Check if the email is in available options (stack-based filtering)
    const isValidOption = availableOptions.some(option => option.email === email);
    if (!isValidOption) {
      setError('This login option is not available for the current stack configuration.');
      return;
    }
    
    const success = await login(email, password);
    if (success) {
      // Navigate based on email domain
      if (email === 'demo@insurance.com') {
        navigate('/customer/sandbox/insurancehome');
      } else if (email === 'demo@banking.com') {
        navigate('/customer/sandbox/bankinghome');
      } else if (email === 'demo@retail.com') {
        navigate('/customer/sandbox/retailhome');
      } else if (email === 'demo@healthcare.com') {
        navigate('/customer/sandbox/healthcarehome');
      } else if (email === 'demo@manufacturing.com') {
        navigate('/customer/sandbox/manufacturinghome');
      } else {
        setProjectType(null);
        navigate('/customer/login');
      }
    } else {
      setError('Invalid credentials. Please check your email and password.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center mb-4"></div>
        <div className="glass-card rounded-lg shadow-md p-8 overflow-hidden bg-white">
          <div className="flex justify-center mb-6">
            <img src="/banner/1chblack (1).jpg" alt="1CH Logo" className="h-12 w-auto rounded" />
          </div>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="Enter your email"
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <div className="mt-1 relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full px-3 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
            </div>
            {error && (
              <div className="text-red-600 text-sm">{error}</div>
            )}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 transition-colors duration-200"
            >
              {isLoading ? 'Signing in...' : 'Access My Sandbox'}
            </button>
          </form>
          {availableOptions.length > 0 && (
            <div className="mt-8 pt-6 border-t border-gray-200">
              <h3 className="text-sm font-medium text-gray-700 mb-3">
                {currentStack ? `${currentStack.charAt(0).toUpperCase() + currentStack.slice(1)} Demo Credentials:` : 'Available Demo Credentials:'}
              </h3>
              <div className="grid grid-cols-1 gap-2">  
                {availableOptions.map((option) => (
                  <button
                    key={option.email}
                    onClick={() => {
                      setEmail(option.email);
                      setPassword(option.password);
                    }}
                    className="text-left p-2 text-xs bg-gray-50 hover:bg-gray-100 rounded border transition-colors duration-200 w-full"
                  >
                    <div className="font-medium text-gray-900">{option.email}</div>
                    <div className="text-gray-500">
                      {option.name} • Password: {option.password}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}