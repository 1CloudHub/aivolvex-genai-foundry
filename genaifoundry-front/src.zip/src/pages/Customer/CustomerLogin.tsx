import React, { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Cloud, Eye, EyeOff, Lock, User } from 'lucide-react';
// import type { Customer } from '../../CustomerTypes';

export default function CustomerLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const { user, login, isLoading } = useAuth();
  const navigate = useNavigate();

  // Redirect if already logged in as customer
  if (user && user.role === 'customer') {
    
    if (user.email === 'demo@insurance.com') {
      return <Navigate to="/customer/sandbox/insurancehome" replace />;
    }
    if (user.email === 'demo@banking.com') {
      return <Navigate to="/customer/sandbox/bankinghome" replace />;
    }
    return <Navigate to="/customer/sandbox" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const success = await login(email, password);
    if (success) {
      
      if (email === 'demo@insurance.com') {
        navigate('/customer/sandbox/insurancehome');
      } else if (email === 'demo@banking.com') {
        navigate('/customer/sandbox/bankinghome');
      } else {
      navigate('/customer/sandbox');
      }
    } else {
      setError('Invalid credentials. Please check your email and password.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center mb-4"></div>
        <div className="glass-card rounded-lg shadow-md p-8 overflow-hidden bg-white">
          <div className="flex justify-center mb-6">
            <img src="/banner/1chblack (1).jpg" alt="1CH Logo" className="h-12 w-auto rounded" />
          </div>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="Enter your email"
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <div className="mt-1 relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full px-3 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
            </div>
            {error && (
              <div className="text-red-600 text-sm">{error}</div>
            )}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-orange-500 hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 transition-colors duration-200"
            >
              {isLoading ? 'Signing in...' : 'Access My Sandbox'}
            </button>
          </form>
          <div className="mt-8 pt-6 border-t border-gray-200">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Demo Credentials:</h3>
            <div className="grid grid-cols-1 gap-2">  
              <button
                onClick={() => {
                  setEmail('demo@insurance.com');
                  setPassword('InsuranceDemo2025!');
                }}
                className="text-left p-2 text-xs bg-gray-50 hover:bg-gray-100 rounded border transition-colors duration-200 w-full"
              >
                <div className="font-medium text-gray-900">demo@insurance.com</div>
                <div className="text-gray-500">Insurance Demo • Password: InsuranceDemo2025!</div>
              </button>
              <button
                onClick={() => {
                  setEmail('demo@banking.com');
                  setPassword('BankingDemo@2025!');
                }}
                className="text-left p-2 text-xs bg-gray-50 hover:bg-gray-100 rounded border transition-colors duration-200 w-full"
              >
                <div className="font-medium text-gray-900">demo@banking.com</div>
                <div className="text-gray-500">Banking Demo • Password: BankingDemo@2025!</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}