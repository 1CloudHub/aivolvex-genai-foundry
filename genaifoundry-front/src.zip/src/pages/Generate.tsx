import { useState, useEffect, useRef } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  Button,
  Separator,
  Input,
  Label,
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
  Calendar,
  Popover,
  PopoverTrigger,
  PopoverContent,
} from '@/components/ui/index';
import {
  FileText,
  CheckSquare,
  FileOutput,
  Home as HomeIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';

interface FormData {
  applicantName: string;
  applicantAddress: string;
  loanType: string;
  loanAmount: number;
  interestRate: number;
  tenure: number;
  emi: number | "";
  sanctionDate: string;
  validityDate: string;
}

interface TemplateItem {
  id: string;
  name: string;
  description: string;
  type: 'loan' | 'insurance';
  icon: React.ReactNode;
}

const calculateEMI = (principal: number, rate: number, tenure: number) => {
  if (!principal || !rate || !tenure) return '';
  // Convert interest rate from annual to monthly percentage
  const monthlyRate = rate / 12 / 100;
  // Convert tenure from years to months
  const tenureMonths = tenure * 12;
  
  // EMI formula: P * r * (1+r)^n / ((1+r)^n - 1)
  const emi = principal * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths) / 
              (Math.pow(1 + monthlyRate, tenureMonths) - 1);
  
  if (!isFinite(emi)) return '';
  return Math.round(emi);
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
};

const templates: TemplateItem[] = [
  {
    id: 'loan-sanction',
    name: 'Loan Sanction Letter',
    description: 'Official loan approval document with terms and conditions',
    type: 'loan',
    icon: <FileText className="h-5 w-5 text-primary" />
  },
  {
    id: 'insurance-policy',
    name: 'Insurance Policy Document',
    description: 'Comprehensive insurance policy with coverage details',
    type: 'insurance',
    icon: <FileText className="h-5 w-5 text-primary" />
  }
];

const Generate = () => {
  // Prefilled sample data
  const initialSanctionDate = new Date();
  const initialValidityDate = new Date();
  initialValidityDate.setMonth(initialValidityDate.getMonth() + 3);

  const [formData, setFormData] = useState<FormData>({
    applicantName: 'Raj Kumar Singh',
    applicantAddress: '123 Main St, Bangalore, Karnataka - 560001',
    loanType: 'Home Loan',
    loanAmount: 1200000,
    interestRate: 8.5,
    tenure: 10,
    emi: calculateEMI(1200000, 8.5, 10),
    sanctionDate: format(initialSanctionDate, 'yyyy-MM-dd'),
    validityDate: format(initialValidityDate, 'yyyy-MM-dd'),
  });
  
  const [selectedTemplate, setSelectedTemplate] = useState<string>('loan-sanction');
  const [showCrmNotification, setShowCrmNotification] = useState(false);
  const [isSendingCrm, setIsSendingCrm] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Generate a static reference number per page load
  const refNumber = useRef(`UB/${Math.floor(Math.random() * 10000)}/2025`);
  
  const navigate = useNavigate();
  
  // Prefill date pickers
  const [sanctionDateObj, setSanctionDateObj] = useState<Date | undefined>(initialSanctionDate);
  const [validityDateObj, setValidityDateObj] = useState<Date | undefined>(initialValidityDate);
  const [sanctionPopoverOpen, setSanctionPopoverOpen] = useState(false);
  const [validityPopoverOpen, setValidityPopoverOpen] = useState(false);
  
  // Calculate EMI whenever loan details change
  useEffect(() => {
    const emi = calculateEMI(formData.loanAmount, formData.interestRate, formData.tenure);
    setFormData(prev => ({ ...prev, emi }));
  }, [formData.loanAmount, formData.interestRate, formData.tenure]);

  // Sync formData string with date objects
  useEffect(() => {
    if (sanctionDateObj) {
      setFormData(prev => ({ ...prev, sanctionDate: format(sanctionDateObj, 'yyyy-MM-dd') }));
    }
  }, [sanctionDateObj]);
  useEffect(() => {
    if (validityDateObj) {
      setFormData(prev => ({ ...prev, validityDate: format(validityDateObj, 'yyyy-MM-dd') }));
    }
  }, [validityDateObj]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'loanAmount' || name === 'interestRate' || name === 'tenure' 
        ? parseFloat(value) 
        : value
    }));
  };

  const handleTemplateChange = (value: string) => {
    setSelectedTemplate(value);
  };

  const handleSendToCrm = () => {
    setIsSendingCrm(true);
    setTimeout(() => {
      setIsSendingCrm(false);
      setShowCrmNotification(true);
      setTimeout(() => setShowCrmNotification(false), 3000);
    }, 2000 + Math.random() * 1000); // 2-3 seconds
  };

  // Helper to check if all form fields are filled
  const isFormComplete =
    formData.applicantName.trim() &&
    formData.applicantAddress.trim() &&
    formData.loanType.trim() &&
    formData.loanAmount > 0 &&
    formData.interestRate > 0 &&
    formData.tenure > 0 &&
    sanctionDateObj !== undefined &&
    validityDateObj !== undefined;

  return (
    <div className="container py-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-6">
        <button type="button" onClick={() => navigate('/')} className="flex items-center font-semibold " style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>
          <HomeIcon className="h-5 w-5 mr-1" />
          <span className="text-gray-600">Home</span>
        </button>
        <span className="text-gray-400">/</span>
        <span style={{ fontWeight: 600, color:'#e87722' }}>SanctionPad</span>
      </div>
      {/* Page Title and Subtitle */}
      <div className="flex items-center gap-6 mb-8">
        <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
          <FileOutput className="h-8 w-8 text-primary" />
        </div>
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
            SanctionPad
          </h1>
          <p className="text-lg text-gray-600">
            Create customized loan sanction letters and insurance policies with AI-powered document generation.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Document Details</CardTitle>
              <CardDescription>
                Enter information to generate document
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="applicantName">Applicant Name</Label>
                <Input
                  id="applicantName"
                  name="applicantName"
                  value={formData.applicantName}
                  onChange={handleInputChange}
                  ref={inputRef}
                  placeholder="Enter applicant name"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="applicantAddress">Applicant Address</Label>
                <Input
                  id="applicantAddress"
                  name="applicantAddress"
                  value={formData.applicantAddress}
                  onChange={handleInputChange}
                  placeholder="Enter address"
                />
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="loanType">Loan/Policy Type</Label>
                <Select
                  value={formData.loanType}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, loanType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select loan type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Home Loan">Home Loan</SelectItem>
                    <SelectItem value="Personal Loan">Personal Loan</SelectItem>
                    <SelectItem value="Business Loan">Business Loan</SelectItem>
                    <SelectItem value="Education Loan">Education Loan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="loanAmount">Amount (₹)</Label>
                  <Input
                    id="loanAmount"
                    name="loanAmount"
                    type="number"
                    value={formData.loanAmount}
                    onChange={handleInputChange}
                    placeholder="Enter amount"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    name="interestRate"
                    type="number"
                    step="0.1"
                    value={formData.interestRate}
                    onChange={handleInputChange}
                    placeholder="Enter interest rate"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tenure">Tenure (Years)</Label>
                  <Input
                    id="tenure"
                    name="tenure"
                    type="number"
                    value={formData.tenure}
                    onChange={handleInputChange}
                    placeholder="Enter tenure in years"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="emi">Monthly EMI (₹)</Label>
                  <Input
                    id="emi"
                    name="emi"
                    value={formData.emi}
                    placeholder="--"
                    disabled
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sanctionDate">Issue Date</Label>
                  <Popover open={sanctionPopoverOpen} onOpenChange={setSanctionPopoverOpen}>
                    <PopoverTrigger asChild>
                      <Input
                        id="sanctionDate"
                        name="sanctionDate"
                        type="text"
                        readOnly
                        value={sanctionDateObj ? format(sanctionDateObj, 'dd/MM/yyyy') : ''}
                        placeholder="Select issue date"
                        className="cursor-pointer"
                        onClick={() => setSanctionPopoverOpen(true)}
                      />
                    </PopoverTrigger>
                    <PopoverContent align="end" className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={sanctionDateObj}
                        onSelect={(date) => {
                          setSanctionDateObj(date);
                          setSanctionPopoverOpen(false);
                        }}
                        initialFocus
                        classNames={{ day_today: '' }}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="validityDate">Validity Date</Label>
                  <Popover open={validityPopoverOpen} onOpenChange={setValidityPopoverOpen}>
                    <PopoverTrigger asChild>
                      <Input
                        id="validityDate"
                        name="validityDate"
                        type="text"
                        readOnly
                        value={validityDateObj ? format(validityDateObj, 'dd/MM/yyyy') : ''}
                        placeholder="Select validity date"
                        className="cursor-pointer"
                        onClick={() => setValidityPopoverOpen(true)}
                      />
                    </PopoverTrigger>
                    <PopoverContent align="end" className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={validityDateObj}
                        onSelect={(date) => {
                          setValidityDateObj(date);
                          setValidityPopoverOpen(false);
                        }}
                        initialFocus
                        classNames={{ day_today: '' }}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Template Selection</CardTitle>
              <CardDescription>
                Choose the document template
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {templates.map((template) => (
                  <div 
                    key={template.id}
                    className={cn(
                      "flex items-start p-3 rounded-md border-2 cursor-pointer transition-all",
                      selectedTemplate === template.id 
                        ? "border-primary bg-primary/5" 
                        : "border-border hover:border-primary/50"
                    )}
                    onClick={() => handleTemplateChange(template.id)}
                  >
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      {template.icon}
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-medium">{template.name}</h3>
                        {selectedTemplate === template.id && (
                          <CheckSquare className="h-4 w-4 text-primary" />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {template.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="lg:col-span-7">
          {selectedTemplate === 'loan-sanction' && (
            <Card className="h-full flex flex-col">
              <CardHeader className="border-b flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Loan Sanction Letter</CardTitle>
                  <CardDescription>Preview of the official loan sanction letter</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    className="d-flex align-items-center gap-2 px-4 py-2 rounded-pill fw-bold border-0 text-white"
                    style={{ background: '#e87722' }}
                    onClick={handleSendToCrm}
                    disabled={!isFormComplete || isSendingCrm}
                  >
                    {isSendingCrm ? (
                      <>
                        <svg className="animate-spin mr-2" width="18" height="18" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="white" strokeWidth="4" />
                          <path className="opacity-75" fill="#fff" d="M4 12a8 8 0 018-8v8z" />
                        </svg>
                        Sending...
                      </>
                    ) : (
                      <>
                        <svg width="18" height="18" fill="white" viewBox="0 0 24 24" className="me-1"><path d="M2 21l21-9-21-9v7l15 2-15 2z"/></svg>
                        Send for approval
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-auto p-6 bg-white rounded-md border m-4 shadow-sm min-h-[500px]">
                <div className="relative bg-white rounded-lg border shadow-md" style={{ fontFamily: 'Inter, sans-serif', maxWidth: 600, margin: '0 auto', padding: 0 }}>
                  {/* Header */}
                  <div className="flex justify-between items-center pt-8 pb-2 px-8 border-b" style={{ borderBottomColor: '#d1d5db', borderBottomWidth: 2 }}>
                    <div className="flex items-center gap-3">
                      <div className="rounded-full bg-[#181f5a] flex items-center justify-center" style={{ width: 40, height: 40 }}>
                        <span className="text-white text-xl font-bold" style={{ fontFamily: 'Inter, sans-serif' }}>A</span>
                      </div>
                      <div className="text-2xl font-bold" style={{ color: '#222', fontFamily: 'Inter, sans-serif' }}>ABCBank</div>
                    </div>
                    <div className="text-right text-sm text-gray-500" style={{ lineHeight: 1.4 }}>
                      <div>contact@abcbank.com</div>
                      <div>1800-123-4567</div>
                      <div>abcbank.com</div>
                    </div>
                  </div>
                  {/* Title */}
                  <div className="text-center py-6 px-8">
                    <div className="text-xl font-bold tracking-wide" style={{ color: '#222', letterSpacing: 1 }}>BANK LOAN APPROVAL LETTER</div>
                  </div>
                  {/* Body */}
                  <div className="px-8 pb-8">
                    {/* Company Info (for loan) */}
                    {/* <div className="mb-2 text-sm text-gray-700 font-semibold">[Your Company Name]</div>
                    <div className="mb-2 text-sm text-gray-700">[Your Company Address]</div>
                    <div className="mb-2 text-sm text-gray-700">[Your Company Number]</div> */}
                    {/* Date */}
                    <div className="mb-2 text-sm">{formData.sanctionDate ? new Date(formData.sanctionDate).toLocaleDateString() : <span className="text-gray-400">[Issue Date]</span>}</div>
                    <div className="mb-4 text-sm">Ref: {refNumber.current}</div>
                    {/* Applicant Info */}
                    <div className="mb-4 text-sm">
                      <div className="font-semibold">{formData.applicantName ? formData.applicantName : <span className="text-gray-400">[Applicant Name]</span>}</div>
                      <div>{formData.applicantAddress ? formData.applicantAddress : <span className="text-gray-400">[Applicant Address]</span>}</div>
                    </div>
                    {/* Salutation */}
                    <div className="mb-4 text-sm">Dear <span className="font-semibold">{formData.applicantName ? formData.applicantName : <span className="text-gray-400">[Applicant Name]</span>}</span>,</div>
                    {/* Letter Body */}
                    {selectedTemplate === 'loan-sanction' ? (
                      <>
                        <div className="mb-4 text-sm">We are pleased to inform you that your loan request has been approved by our bank. We have carefully reviewed your application and based on your financial profile, credit history, and our internal policies, we are confident in your ability to repay the loan amount requested.</div>
                        <div className="font-bold text-sm mb-2" style={{ color: '#222' }}>Loan Details:</div>
                        <div className="border border-gray-300 rounded p-4 mb-4 text-sm bg-white">
                          <div>Loan Amount: <span className="font-semibold">{formData.loanAmount ? formatCurrency(formData.loanAmount) : <span className="text-gray-400">[Amount]</span>}</span></div>
                          <div>Loan Term: <span className="font-semibold">{formData.tenure ? formData.tenure + ' years' : <span className="text-gray-400">[Tenure]</span>}</span></div>
                          <div>Interest Rate: <span className="font-semibold">{formData.interestRate ? formData.interestRate + '%' : <span className="text-gray-400">[Rate]</span>}</span></div>
                          <div>EMI: <span className="font-semibold">{typeof formData.emi === 'number' && !isNaN(formData.emi) && formData.emi !== 0 ? formatCurrency(formData.emi) : <span className="text-gray-400">[EMI]</span>}</span></div>
                          <div>Sanction Validity: <span className="font-semibold">{formData.validityDate ? new Date(formData.validityDate).toLocaleDateString() : <span className="text-gray-400">[Validity Date]</span>}</span></div>
                        </div>
                        <div className="mb-4 text-sm">Please note that there may be additional documentation or paperwork required to process the loan. Our loan officer will be in contact with you shortly to provide further instructions and to address any queries you may have.</div>
                        {/* <div className="mb-4 text-sm">If you have any concerns or require further information, please feel free to contact our customer service department at <span className="font-semibold" style={{ color: '#e87722' }}>[Your Company Website]</span>. We are here to assist you throughout the loan process and ensure a smooth experience for you.</div> */}
                      </>
                    ) : (
                      <>
                        <div className="font-bold text-sm mb-2" style={{ color: '#222' }}>Policy Details:</div>
                        <div className="border border-gray-300 rounded p-4 mb-4 text-sm bg-white">
                          <div>Sum Assured: <span className="font-semibold">{formData.loanAmount ? formatCurrency(formData.loanAmount) : <span className="text-gray-400">[Amount]</span>}</span></div>
                          <div>Premium: <span className="font-semibold">{formData.loanAmount ? formatCurrency(formData.loanAmount * 0.01) + ' per annum' : <span className="text-gray-400">[Premium]</span>}</span></div>
                          <div>Policy Term: <span className="font-semibold">{formData.tenure ? formData.tenure + ' years' : <span className="text-gray-400">[Term]</span>}</span></div>
                          <div>Commencement Date: <span className="font-semibold">{formData.sanctionDate ? new Date(formData.sanctionDate).toLocaleDateString() : <span className="text-gray-400">[Start Date]</span>}</span></div>
                          <div>Maturity Date: <span className="font-semibold">{formData.sanctionDate && formData.tenure ? new Date(new Date(formData.sanctionDate).setFullYear(new Date(formData.sanctionDate).getFullYear() + Number(formData.tenure))).toLocaleDateString() : <span className="text-gray-400">[Maturity Date]</span>}</span></div>
                        </div>
                        <div className="mb-2 text-sm font-bold" style={{ color: '#222' }}>Benefits:</div>
                        <ul className="pl-4 mb-4 space-y-1 text-sm">
                          <li>1. Death Benefit: Sum Assured payable to nominee</li>
                          <li>2. Tax Benefits: As per prevailing tax laws</li>
                          <li>3. Loan Facility: Available after 3 years</li>
                        </ul>
                        <div className="mb-4 text-sm">Please read the terms and conditions carefully. For any clarifications, please contact our customer service at <span className="font-semibold" style={{ color: '#e87722' }}>contact@abcbank.com</span> or call <span className="font-semibold" style={{ color: '#e87722' }}>1800-123-4567</span>.</div>
                      </>
                    )}
                    <div className="mt-8 text-sm">
                      <div>Yours sincerely,</div>
                      <div className="mt-4 font-semibold">Loan Department</div>
                      <div>ABCBank</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          {selectedTemplate === 'insurance-policy' && (
            <Card className="h-full flex flex-col">
              <CardHeader className="border-b flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Insurance Policy Document</CardTitle>
                  <CardDescription>Preview of the insurance policy document</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    className="d-flex align-items-center gap-2 px-4 py-2 rounded-pill fw-bold border-0 text-white"
                    style={{ background: '#e87722' }}
                    onClick={handleSendToCrm}
                    disabled={!isFormComplete || isSendingCrm}
                  >
                    {isSendingCrm ? (
                      <>
                        <svg className="animate-spin mr-2" width="18" height="18" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="white" strokeWidth="4" />
                          <path className="opacity-75" fill="#fff" d="M4 12a8 8 0 018-8v8z" />
                        </svg>
                        Sending...
                      </>
                    ) : (
                      <>
                        <svg width="18" height="18" fill="white" viewBox="0 0 24 24" className="me-1"><path d="M2 21l21-9-21-9v7l15 2-15 2z"/></svg>
                        Send for approval
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-auto p-6 bg-white rounded-md border m-4 shadow-sm min-h-[500px]">
                <div className="relative bg-white rounded-lg border shadow-md" style={{ fontFamily: 'Inter, sans-serif', maxWidth: 600, margin: '0 auto', padding: 0 }}>
                  {/* Header */}
                  <div className="flex justify-between items-center pt-8 pb-2 px-8 border-b" style={{ borderBottomColor: '#d1d5db', borderBottomWidth: 2 }}>
                    <div className="flex items-center gap-3">
                      <div className="rounded-full bg-[#181f5a] flex items-center justify-center" style={{ width: 40, height: 40 }}>
                        <span className="text-white text-xl font-bold" style={{ fontFamily: 'Inter, sans-serif' }}>A</span>
                      </div>
                      <div className="text-2xl font-bold" style={{ color: '#222', fontFamily: 'Inter, sans-serif' }}>ABCBank</div>
                    </div>
                    <div className="text-right text-sm text-gray-500" style={{ lineHeight: 1.4 }}>
                      <div>contact@abcbank.com</div>
                      <div>1800-123-4567</div>
                      <div>abcbank.com</div>
                    </div>
                  </div>
                  {/* Title */}
                  <div className="text-center py-6 px-8">
                    <div className="text-xl font-bold tracking-wide" style={{ color: '#222', letterSpacing: 1 }}>INSURANCE POLICY DOCUMENT</div>
                  </div>
                  {/* Body */}
                  <div className="px-8 pb-8">
                    {/* Date */}
                    <div className="mb-2 text-sm">{formData.sanctionDate ? new Date(formData.sanctionDate).toLocaleDateString() : <span className="text-gray-400">[Issue Date]</span>}</div>
                    <div className="mb-4 text-sm">Ref: {refNumber.current}</div>
                    {/* Applicant Info */}
                    <div className="mb-4 text-sm">
                      <div className="font-semibold">{formData.applicantName ? formData.applicantName : <span className="text-gray-400">[Applicant Name]</span>}</div>
                      <div>{formData.applicantAddress ? formData.applicantAddress : <span className="text-gray-400">[Applicant Address]</span>}</div>
                    </div>
                    {/* Salutation */}
                    <div className="mb-4 text-sm">Dear <span className="font-semibold">{formData.applicantName ? formData.applicantName : <span className="text-gray-400">[Applicant Name]</span>}</span>,</div>
                    {/* Letter Body */}
                    <div className="font-bold text-sm mb-2" style={{ color: '#222' }}>Policy Details:</div>
                    <div className="border border-gray-300 rounded p-4 mb-4 text-sm bg-white">
                      <div>Sum Assured: <span className="font-semibold">{formData.loanAmount ? formatCurrency(formData.loanAmount) : <span className="text-gray-400">[Amount]</span>}</span></div>
                      <div>Premium: <span className="font-semibold">{formData.loanAmount ? formatCurrency(formData.loanAmount * 0.01) + ' per annum' : <span className="text-gray-400">[Premium]</span>}</span></div>
                      <div>Policy Term: <span className="font-semibold">{formData.tenure ? formData.tenure + ' years' : <span className="text-gray-400">[Term]</span>}</span></div>
                      <div>Commencement Date: <span className="font-semibold">{formData.sanctionDate ? new Date(formData.sanctionDate).toLocaleDateString() : <span className="text-gray-400">[Start Date]</span>}</span></div>
                      <div>Maturity Date: <span className="font-semibold">{formData.sanctionDate && formData.tenure ? new Date(new Date(formData.sanctionDate).setFullYear(new Date(formData.sanctionDate).getFullYear() + Number(formData.tenure))).toLocaleDateString() : <span className="text-gray-400">[Maturity Date]</span>}</span></div>
                    </div>
                    <div className="mb-2 text-sm font-bold" style={{ color: '#222' }}>Benefits:</div>
                    <ul className="pl-4 mb-4 space-y-1 text-sm">
                      <li>1. Death Benefit: Sum Assured payable to nominee</li>
                      <li>2. Tax Benefits: As per prevailing tax laws</li>
                      <li>3. Loan Facility: Available after 3 years</li>
                    </ul>
                    <div className="mb-4 text-sm">Please read the terms and conditions carefully. For any clarifications, please contact our customer service at <span className="font-semibold" >contact@abcbank.com</span> or call <span className="font-semibold" >1800-123-4567</span>.</div>
                    <div className="mt-8 text-sm">
                      <div>Yours sincerely,</div>
                      <div className="mt-4 font-semibold">Insurance Department</div>
                      <div>ABCBank</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      {showCrmNotification && (
        <div
          className="fixed top-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 px-7 py-5 rounded-3xl bg-white border shadow-lg animate-fade-in-out"
          style={{ borderColor: '#e87722', boxShadow: '0 8px 32px 0 #e8772222', animation: 'fade-in-out 3s', minWidth: 420, maxWidth: '90vw' }}
        >
          <svg width="36" height="36" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#fff7f0" stroke="#e87722" strokeWidth="2"/><path d="M9.5 12.5l2 2 4-4" stroke="#e87722" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          <div>
            <div className="fw-bold" style={{ color: '#e87722', fontSize: '1.18rem', letterSpacing: 0.2 }}>Sent for approval successfully!</div>
            <div style={{ color: '#4B5563', fontWeight: 500, fontSize: '1rem', marginTop: 2 }}>Your application has been sent for approval and will be reviewed shortly.</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Generate;