import React, { useState, useMemo, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Table, Tag, Button, Space, Card, Typography, Tooltip, Spin, Alert } from 'antd';
import type { TableProps } from 'antd';
import { 
  Calendar, 
  Users, 
  CheckCircle, 
  Clock, 
  Plus, 
  CreditCard, 
  Copy, 
  Filter, 
  BarChart3,
  MapPin
} from 'lucide-react';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbSeparator,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbHome,
} from '../../components/ui/breadcrumb';

const { Title, Text, Link: AntdLink } = Typography;

interface Event {
  eventid: string;
  eventname: string;
  eventdesc: string;
  eventdate: string;
  eventtime: string;
  eventlocation: string;
  eventstatus: 'upcoming' | 'live' | 'completed';
}

interface ApiResponse {
  total_records: number;
  page: number;
  records_per_page: number;
  events: Event[];
}

export default function EventDashboard() {
  const { user } = useAuth();
  const location = useLocation();
  const [copiedEventId, setCopiedEventId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalRecords, setTotalRecords] = useState(0);

  const fetchEvents = async (page: number, recordsPerPage: number) => {
    setLoading(true);
    setError(null);
    
    try {
      const myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");
      
      const raw = JSON.stringify({
        "event_type": "list_event_data",
        "data": {
          "page": page,
          "records_per_page": recordsPerPage
        }
      });
      
      const requestOptions: RequestInit = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow" as RequestRedirect
      };
      
      const response = await fetch(import.meta.env.VITE_EVENT_API_URL, requestOptions);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.text();
      console.log('Raw API response:', result);
      
      // Parse the response - it might be wrapped in a body field
      let parsedResult;
      try {
        parsedResult = JSON.parse(result);
      } catch (e) {
        throw new Error('Invalid JSON response from API');
      }
      
      // Handle the case where the response is wrapped in a body field
      const responseData = parsedResult.body ? JSON.parse(parsedResult.body) : parsedResult;
      console.log('Parsed response data:', responseData);
      
      const data: ApiResponse = responseData;
      
      console.log('Setting events:', data.events);
      console.log('Setting total records:', data.total_records);
      setEvents(data.events);
      setTotalRecords(data.total_records);
    } catch (err) {
      console.error('Error fetching events:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch events');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents(currentPage, pageSize);
  }, [currentPage, pageSize]);

  // Refresh data when component mounts or when navigating back from event creation
  useEffect(() => {
    // This will trigger a refresh when the component is focused
    const handleFocus = () => {
      fetchEvents(currentPage, pageSize);
    };

    window.addEventListener('focus', handleFocus);
    
    // Also refresh on mount
    fetchEvents(currentPage, pageSize);

    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, []);

  // Handle refresh when navigating back from event creation
  useEffect(() => {
    if (location.state?.refresh) {
      fetchEvents(currentPage, pageSize);
      // Clear the refresh state
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const handleCopy = (eventId: string) => {
    const url = `${window.location.origin}/register?event=${eventId}`;
    navigator.clipboard.writeText(url);
    setCopiedEventId(eventId);
    setTimeout(() => setCopiedEventId(null), 1500);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handlePageSizeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newPageSize = Number(e.target.value);
    setPageSize(newPageSize);
    setCurrentPage(1);
  };



  const totalPages = Math.ceil(totalRecords / pageSize);
  
  // Debug logging
  console.log('Current events state:', events);
  console.log('Current loading state:', loading);
  console.log('Current error state:', error);

  const columns: TableProps<Event>['columns'] = [
    {
      title: 'Event',
      dataIndex: 'eventname',
      key: 'event',
      render: (text: string, record: Event) => (
        <div>
          <Title level={5} style={{ margin: 0 }}>{record.eventname}</Title>
          <Text type="secondary" className="block text-sm mt-1">{record.eventdesc}</Text>
          <Space size="middle" wrap className="text-gray-500 text-xs mt-1">
            <span><Calendar className="inline h-3 w-3 mr-1" />{new Date(record.eventdate).toLocaleDateString()}</span>
            <span><Clock className="inline h-3 w-3 mr-1" />{record.eventtime}</span>
            <span><MapPin className="inline h-3 w-3 mr-1" />{record.eventlocation}</span>
          </Space>
          {user?.role !== 'marketing' && (
            <div className="mt-2">
              <Space>
                <AntdLink href={`/register?event=${record.eventid}`} target="_blank" style={{ color: '#f97316' }}>
                  Public Registration Link
                </AntdLink>
                <Tooltip title={copiedEventId === record.eventid ? 'Copied!' : 'Copy Link'}>
                  <Button icon={<Copy size={14} />} onClick={() => handleCopy(record.eventid)} size="small" />
                </Tooltip>
              </Space>
            </div>
          )}
        </div>
      ),
    },
    {
      title: 'Status',
      dataIndex: 'eventstatus',
      key: 'status',
      filters: [
        { text: 'Upcoming', value: 'upcoming' },
        { text: 'Live', value: 'live' },
        { text: 'Completed', value: 'completed' },
      ],
      onFilter: (value, record) => record.eventstatus === value,
      render: (status: string) => {
        if (status === 'live') {
          return (
            <Tag 
              color="green"
              style={{ 
                fontWeight: '600',
                textAlign: 'center'
              }}
            >
              Live
            </Tag>
          );
        }
        
        const color = status === 'upcoming' ? 'blue' : 'default';
        let label = status.charAt(0).toUpperCase() + status.slice(1);
        return <Tag color={color}>{label}</Tag>;
      },
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record: Event) => (
        <Space direction="vertical" align="start">
          {(user?.role === 'marketing' || user?.role === 'sales') && (
            <Link to={`/reports/customers?event=${record.eventid}`} style={{ textDecoration: 'none' }}>
              <Button
                icon={<Users size={14} />}
                style={{ 
                  display: 'flex', 
                  alignItems: 'center',
                  borderColor: '#4f46e5',
                  color: '#4f46e5'
                }}
              >
                Customer List
              </Button>
            </Link>
          )}
          {user?.role === 'sales' && record.eventstatus === 'upcoming' && (
            <Link to={`/events/${record.eventid}/credit-check`}>
              <Button icon={<CreditCard size={14} />}>
                Review Credits
              </Button>
            </Link>
          )}
        </Space>
      ),
    },
  ];

  if (loading && events.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <div className="flex items-center mb-0 mt-2">
              <Breadcrumb>
                <BreadcrumbList className="flex items-center text-base font-semibold gap-0 align-middle">
                  <BreadcrumbItem>
                    <BreadcrumbLink to="/" className="flex items-center align-middle">
                      <BreadcrumbHome />
                    </BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbSeparator>
                    <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
                  </BreadcrumbSeparator>
                  <BreadcrumbItem>
                    <BreadcrumbPage className="text-orange-600 font-semibold align-middle">Events</BreadcrumbPage>
                  </BreadcrumbItem>
                </BreadcrumbList>
              </Breadcrumb>
            </div> 
            <Title level={2} style={{ margin: 2 }} className="mb-10">Event Dashboard</Title>
          </div>
          {user?.role === 'marketing' && (
            <Link to="/events/new">
              <Button type="primary" icon={<Plus size={16} />} size="large" style={{ backgroundColor: '#f97316', borderColor: '#f97316' }}>
                Create Event
              </Button>
            </Link>
          )}
        </div>
        <Card bordered={false} style={{ boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
          <div className="flex justify-center items-center py-12">
            <Spin size="large" />
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <style>
        {`
          @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
          }
        `}
      </style>
      <div className="flex justify-between items-center">
        <div>
        <div className="flex items-center mb-0 mt-2">
            <Breadcrumb>
              <BreadcrumbList className="flex items-center text-base font-semibold gap-0 align-middle">
                <BreadcrumbItem>
                  <BreadcrumbLink to="/" className="flex items-center align-middle">
                    <BreadcrumbHome />
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator>
                  <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
                </BreadcrumbSeparator>
                <BreadcrumbItem>
                  <BreadcrumbPage className="text-orange-600 font-semibold align-middle">Events</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div> 
          <Title level={2} style={{ margin: 2 }} className="mb-10">Event Dashboard</Title>
        </div>
        {user?.role === 'marketing' && (
          <Link to="/events/new">
            <Button type="primary" icon={<Plus size={16} />} size="large" style={{ backgroundColor: '#f97316', borderColor: '#f97316' }}>
            Create Event
            </Button>
          </Link>
        )}
      </div>

      {error && (
        <Alert
          message="Error"
          description={error}
          type="error"
          showIcon
          closable
          onClose={() => setError(null)}
        />
      )}

      <Card bordered={false} style={{ boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>  
        <Table 
          columns={columns} 
          dataSource={events}
          rowKey="eventid"
          pagination={false}
          loading={loading}
        />
        <div className="custom-pagination-bar flex items-center justify-between mt-4">
          <div className="flex items-center gap-3">
            <span className="font-semibold">Rows per page</span>
            <select
              className="rounded-lg border border-gray-200 px-4 py-2 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
              value={pageSize}
              onChange={handlePageSizeChange}
            >
              {[5, 10, 20, 50].map(size => (
                <option key={size} value={size}>{size}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-semibold">Page {currentPage} of {totalPages}</span>
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
            >{'<<'}</button>
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(currentPage - 1)}
              disabled={currentPage === 1}
            >{'<'}</button>
            <input
              type="number"
              min={1}
              max={totalPages}
              value={currentPage}
              onChange={e => {
                let val = Number(e.target.value);
                if (val < 1) val = 1;
                if (val > totalPages) val = totalPages;
                setCurrentPage(val);
              }}
              className="w-12 text-center border border-gray-200 rounded-lg px-2 py-1 mx-1 shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
            />
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >{'>'}</button>
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages}
            >{'>>'}</button>
          </div>
        </div>
      </Card>
    </div>
  );
}