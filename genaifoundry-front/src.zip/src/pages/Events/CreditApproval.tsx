import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, XCircle, DollarSign, Users, Clock, Check, Calendar, ClipboardList } from 'lucide-react';
import ApprovalSuccessModal from '../../components/ui/ApprovalSuccessModal';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbSeparator,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbHome,
} from '../../components/ui/breadcrumb';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../hooks/useNotification';

export default function CreditApproval() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showNotification } = useNotification();
  const [status, setStatus] = useState<'pending' | 'approved' | 'rejected'>('pending');
  
  const event = {
    id: id,
    name: 'GenAI for Banking Summit',
    date: '2025-02-15',
    location: 'San Francisco, CA',
    estimatedAttendees: 45,
    estimatedCosts: 750,
    requestedBy: 'Sarah Marketing',
    targetIndustries: ['Banking & Finance', 'Insurance']
  };

  const [allocatedCredits, setAllocatedCredits] = useState(event.estimatedCosts);
  const [expectedAttendees, setExpectedAttendees] = useState(event.estimatedAttendees);
  const [awsAccountId, setAwsAccountId] = useState('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [additionalNote, setAdditionalNote] = useState('');
  const [errors, setErrors] = useState({
    allocatedCredits: '',
    expectedAttendees: '',
    awsAccountId: '',
  });

  const timelineSteps = [
    {
      name: 'Request',
      description: 'Submitted by Marketing',
      status: 'complete',
    },
    {
      name: 'Review',
      description: 'Under review by Sales',
      status: 'current',
    },
    {
      name: 'Launch',
      description: 'Sandbox environment setup',
      status: 'upcoming',
    },
  ];

  const validateForm = () => {
    const newErrors = { allocatedCredits: '', expectedAttendees: '', awsAccountId: '' };
    let isValid = true;

    if (allocatedCredits <= 0) {
      newErrors.allocatedCredits = 'Credits must be a positive number.';
      isValid = false;
    }
    if (expectedAttendees <= 0) {
      newErrors.expectedAttendees = 'Attendees must be a positive number.';
      isValid = false;
    }
    if (!awsAccountId.trim()) {
      newErrors.awsAccountId = 'AWS Account ID is required.';
      isValid = false;
    } else if (!/^[0-9]{12}$/.test(awsAccountId.trim())) {
      newErrors.awsAccountId = 'AWS Account ID must be exactly 12 digits.';
      isValid = false;
    }
    setErrors(newErrors);
    return isValid;
  };

  const handleApproval = (approved: boolean) => {
    if (approved) {
      if (validateForm()) {
        setStatus('approved');
        console.log('Event approved with data:', { allocatedCredits, expectedAttendees, awsAccountId, additionalNote });
        if (user?.role === 'sales') {
          showNotification('success', 'Credits approved successfully!');
          setTimeout(() => {
            navigate('/events');
          }, 1000); // Give time for notification to show
        } else {
          setShowSuccessModal(true);
        }
      }
    } else {
      setStatus('rejected');
      alert('Event rejected successfully!');
      navigate('/events');
    }
  };

  const handleModalClose = () => {
    setShowSuccessModal(false);
    navigate('/events');
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-2">
          <Breadcrumb>
            <BreadcrumbList className="flex items-center text-base font-semibold gap-0">
              <BreadcrumbItem>
                <BreadcrumbLink to="/">
                  <BreadcrumbHome />
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator>
                <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
              </BreadcrumbSeparator>
              <BreadcrumbItem>
                <BreadcrumbLink to="/events" className="text-gray-700 hover:text-orange-600 font-semibold">Events</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator>
                <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
              </BreadcrumbSeparator>
              <BreadcrumbItem>
                <BreadcrumbPage className="text-orange-600 font-semibold">Credit Approval</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        <h1 className="text-3xl font-medium text-gray-900 mb-4">Credit Approval</h1>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-5 gap-8">
        {/* Left Column */}
        <div className="xl:col-span-2 space-y-8">
          <div className="bg-white rounded-lg shadow-sm border p-6" >
            <h2 className="text-xl font-medium text-gray-900 mb-6">Event Information</h2>
            
            <div className="space-y-6">
              <div className="flex justify-between">
                <div>
                  <label className="block text-sm font-medium text-gray-500">Event Name</label>
                  <p className="mt-1 text-gray-900">{event.name}</p>
                </div>
                <div className="text-right">
                  <label className="block text-sm font-medium text-gray-500">Date & Location</label>
                  <p className="mt-1 text-gray-900">{new Date(event.date).toLocaleDateString()} - {event.location}</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-500">Requested By</label>
                <p className="mt-1 text-gray-900">{event.requestedBy}</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-500">Target Industries</label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {event.targetIndustries.map((industry) => (
                    <span key={industry} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                      {industry}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Clock className="h-5 w-5 mr-3 text-gray-400" />
              Timeline
            </h3>
            
            <ul className="space-y-4 text-sm">
              <li className="flex items-center justify-between">
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>Event Created</span>
                </div>
                <span className="font-medium text-gray-900">{new Date(event.date).toLocaleDateString()}</span>
              </li>
              <li className="flex items-center justify-between">
                <div className="flex items-center text-gray-600">
                  <ClipboardList className="h-4 w-4 mr-2" />
                  <span>Credit Review</span>
                </div>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-orange-100 text-orange-600">Pending</span>
              </li>
              <li className="flex items-center justify-between">
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>Event Date</span>
                </div>
                <span className="font-medium text-gray-900">{new Date(event.date).toLocaleDateString()}</span>
              </li>
            </ul>
          </div>
        </div>
        {/* Right Column */}
        <div className="xl:col-span-3">
          <div className="bg-white rounded-lg shadow-sm border p-6" style={{height: '34rem'}}>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Approval Decision</h3>
            
            <div className="space-y-4">
              <div className="space-y-4">
                <div>
                  <label htmlFor="allocatedCredits" className="block text-sm font-medium text-gray-700">Allocated AWS Credits <span className="text-red-500">*</span></label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="pointer-events-none absolute inset-y-0 left-0 pl-3 flex items-center">
                      <span className="text-gray-500 sm:text-sm">$</span>
                    </div>
                    <input
                      type="number"
                      id="allocatedCredits"
                      value={allocatedCredits}
                      onChange={(e) => setAllocatedCredits(Number(e.target.value) || 0)}
                      className="w-full pl-7 pr-12 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                      placeholder="0"
                    />
                    {errors.allocatedCredits && <p className="mt-1 text-xs text-red-600">{errors.allocatedCredits}</p>}
                  </div>
                </div>

                <div>
                  <label htmlFor="expectedAttendees" className="block text-sm font-medium text-gray-700">Expected Attendees <span className="text-red-500">*</span></label>
                  <input
                    type="number"
                    id="expectedAttendees"
                    value={expectedAttendees}
                    onChange={(e) => setExpectedAttendees(Number(e.target.value) || 0)}
                    className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="0"
                  />
                  {errors.expectedAttendees && <p className="mt-1 text-xs text-red-600">{errors.expectedAttendees}</p>}
                </div>

                <div>
                  <label htmlFor="awsAccountId" className="block text-sm font-medium text-gray-700">AWS Account ID <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    id="awsAccountId"
                    value={awsAccountId}
                    onChange={(e) => setAwsAccountId(e.target.value)}
                    className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Enter your 12 digit AWS Account ID"
                  />
                  {errors.awsAccountId && <p className="mt-1 text-xs text-red-600">{errors.awsAccountId}</p>}
                </div>

                <div>
                  <label htmlFor="additionalNote" className="block text-sm font-medium text-gray-700">Additional Note</label>
                  <textarea
                    id="additionalNote"
                    value={additionalNote}
                    onChange={(e) => setAdditionalNote(e.target.value)}
                    className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Add any notes (optional)"
                  />
                </div>
              </div>

              {status === 'pending' && (
                <div className="flex space-x-3 pt-4">
                  <button
                    onClick={() => handleApproval(true)}
                    className="flex-1 flex items-center justify-center px-4 py-2 rounded-md"
                    style={{ background: '#ec580c', color: '#fff' }}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" style={{ color: '#fff' }} />
                    Approve
                  </button>
                </div>
              )}

              {status === 'approved' && (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    <span className="text-green-800 font-medium">Credits Approved</span>
                  </div>
                </div>
              )}

              {status === 'rejected' && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center">
                    <XCircle className="h-5 w-5 text-red-600 mr-2" />
                    <span className="text-red-800 font-medium">Credits Rejected</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {showSuccessModal && <ApprovalSuccessModal onClose={handleModalClose} />}
    </div>
  );
}