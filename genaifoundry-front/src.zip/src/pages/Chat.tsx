import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent as _CardContent } from '@/components/ui/card';
// import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
// import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar } from '@/components/ui/avatar';
import { Badge as _Badge } from '@/components/ui/badge';
import { Separator as _Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
// import { Progress } from '@/components/ui/progress';
import { MessageSquare } from 'lucide-react';
import {
  Send,
  Mic,
  MicOff,
  User,
  Bot,
  PanelRight as _PanelRight,
  PanelLeftClose as _PanelLeftClose,
  BarChart,
  FileText as _FileText,
  AlertCircle as _AlertCircle,
  Phone as _Phone,
  ChevronRight as _ChevronRight,
  ChevronDown as _ChevronDown,
  Home as HomeIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';
// @ts-ignore: If types are missing for react-speech-recognition
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  audioUrl?: string;
  audioDuration?: number;
  questionId?: string;
  isProcessing?: boolean;
  error?: boolean;
}

interface InsightPanel {
  intent: string;
  intentConfidence: number;
  entities: {
    name: string;
    value: string;
    confidence: number;
  }[];
  sentiment: 'positive' | 'neutral' | 'negative';
  leadScore: number;
}

const SUPPORTED_LANGUAGES = ['english', 'தமிழ்', 'हिन्दी', 'മലയാളം', 'తెలుగు'] as const;
type SupportedLanguage = typeof SUPPORTED_LANGUAGES[number];

interface UserInfo {
  name: string;
  whatsappNumber: string;
  language: SupportedLanguage | '';
}

const kycUploadMessages: Record<SupportedLanguage, string> = {
  english: "If you are interested in availing our services, use this link to upload your KYC documents:",
  தமிழ்: "எங்கள் சேவைகளை பெற விரும்பினால், உங்கள் KYC ஆவணங்களை இந்த இணைப்பில் பதிவேற்றவும்:",
  हिन्दी: "यदि आप हमारी सेवाओं का लाभ उठाना चाहते हैं, तो इस लिंक का उपयोग करके अपने KYC दस्तावेज़ अपलोड करें:",
  മലയാളം: "നമ്മുടെ സേവനങ്ങൾ ലഭിക്കാൻ താൽപ്പര്യമുണ്ടെങ്കിൽ, ഈ ലിങ്ക് ഉപയോഗിച്ച് നിങ്ങളുടെ KYC രേഖകൾ അപ്‌ലോഡ് ചെയ്യുക:",
  తెలుగు: "మీరు ఏ విధమైన లోన్లు అందిస్తారు?",
};

const languageResponseMessages: Record<SupportedLanguage, string> = {
  english: "Thank you! I'll communicate with you in English. How can I assist you with your banking needs today? You can ask me about loans, insurance, or any other banking services.",
  தமிழ்: "நன்றி! நான் இனிமேல் உங்களுடன் தமிழ் மொழியில் தொடர்பு கொள்கிறேன். இன்று உங்கள் வங்கிச் சேவைகளில் எவ்வாறு உதவலாம்? நீங்கள் கடன்கள், காப்பீடு அல்லது பிற வங்கிச் சேவைகள் குறித்து கேட்கலாம்.",
  हिन्दी: "धन्यवाद! अब मैं आपसे हिंदी में संवाद करूंगा। आज मैं आपकी बैंकिंग आवश्यकताओं में कैसे सहायता कर सकता हूँ? आप मुझसे ऋण, बीमा या अन्य बैंकिंग सेवाओं के बारे में पूछ सकते हैं।",
  മലയാളം: "നന്ദി! ഇനി ഞാൻ മലയാളത്തിൽ നിങ്ങളുമായി സംവദിക്കും. ഇന്ന് നിങ്ങളുടെ ബാങ്കിംഗ് ആവശ്യങ്ങളിൽ എങ്ങനെ സഹായിക്കാമെന്ന് പറയൂ. നിങ്ങൾ വായ്പകൾ, ഇൻഷുറൻസ് അല്ലെങ്കിൽ മറ്റ് ബാങ്കിംഗ് സേവനങ്ങളെക്കുറിച്ച് ചോദിക്കാം.",
  తెలుగు: "ధన్యవాదాలు! నేను ఇకపై మీతో తెలుగు లో మాట్లాడతాను. మీ బ్యాంకింగ్ అవసరాలకు నేను ఎలా సహాయపడగలను? మీరు నన్ను లోన్లు, ఇన్సూరెన్స్ లేదా ఇతర బ్యాంకింగ్ సేవల గురించి అడగవచ్చు.",
};


const LANGUAGE_INPUT_MAP: Record<string, SupportedLanguage> = {
  english: "english",
  tamil: "தமிழ்",
  hindi: "हिन्दी",
  malayalam: "മലയാളം",
  telugu: "తెలుగు",
};

const LanguageSlideshow = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % SUPPORTED_LANGUAGES.length);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center min-w-[80px] gap-1">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -20, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="w-24 flex items-center justify-center overflow-hidden"
        >
          <span className="text-sm text-[#e87722] font-bold text-center truncate w-full">
            {SUPPORTED_LANGUAGES[currentIndex].charAt(0).toUpperCase() +
              SUPPORTED_LANGUAGES[currentIndex].slice(1)}
          </span>
        </motion.div>
      </AnimatePresence>
      {/* Info button with tooltip */}
      {/* <div className="relative flex items-center">
        <button
          type="button"
          className="ml-1 w-5 h-5 flex items-center justify-center rounded-full border border-[#e87722] bg-white text-[#e87722] focus:outline-none focus:ring-2 focus:ring-[#e87722] transition-colors hover:bg-[#fbeee6]"
          aria-label="Supported languages"
          tabIndex={0}
          onMouseEnter={() => setShowTooltip(true)}
          onMouseLeave={() => setShowTooltip(false)}
          onFocus={() => setShowTooltip(true)}
          onBlur={() => setShowTooltip(false)}
        >
          <svg width="16" height="16" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <rect x="9.25" y="8" width="1.5" height="5" rx="0.75" fill="#e87722" />
            <circle cx="10" cy="6" r="1" fill="#e87722" />
          </svg>
        </button>

      </div> */}
    </div>
  );
};

const Chat = () => {
  const continuous = false;
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hello! I'm your Digital RM. Which language would you like to use? (English/Tamil/Hindi/Malayalam/Telugu)",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const navigate = useNavigate();
  const [isPanelOpen, _setIsPanelOpen] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [_insights, _setInsights] = useState<InsightPanel | null>(null);
  // const [followupExpanded, _setFollowupExpanded] = useState(false);
  const [postChatAnalyticsGenerated, setPostChatAnalyticsGenerated] = useState(false);
  const [postChatAnalysis, setPostChatAnalysis] = useState<{
    sentiment?: string;
    opportunity?: string;
    title?: string;
    summary?: string;
    whatsappMessage?: string;
    enquiryType?: string;
  } | null>(null);

  const messagesViewRef = useRef<HTMLDivElement>(null);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const audioRefs = useRef<{ [id: string]: HTMLAudioElement | null }>({});
  const [audioProgress, setAudioProgress] = useState<{ [id: string]: number }>({});

  const [userInfo, setUserInfo] = useState<UserInfo>({
    name: '',
    whatsappNumber: '',
    language: ''
  });
  const [currentQuestion, setCurrentQuestion] = useState<'language' | 'complete'>('language');

  const [connectionId, setConnectionId] = useState<string | null>(null);
  const [webSocket, setWebSocket] = useState<WebSocket | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [questionCounter, setQuestionCounter] = useState<number>(1);

  const [postChatAudioUrl, setPostChatAudioUrl] = useState<string | null>(null);

  const { transcript, listening, resetTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();

  const [isGeneratingAnalysis, setIsGeneratingAnalysis] = useState(false);

  const [renderedBotMessageId, setRenderedBotMessageId] = useState<string | null>(null);

  const [isPostAudioPlaying, setIsPostAudioPlaying] = useState(false);
  const postAudioRef = useRef<HTMLAudioElement | null>(null);

  const [hotChips, setHotChips] = useState([
    "What types of loans do you offer?",
    "What is the minimum and maximum loan amount I can apply for?",
    "What documents do I need to submit?",
    "Can I change my EMI date?",
    "Q: Can I cancel my loan application?"
  ])

  const promptChips_english = [
    "What types of loans do you offer?",
    "What is the minimum and maximum loan amount I can apply for?",
    "What documents do I need to submit?",
    "Can I change my EMI date?",
    "Q: Can I cancel my loan application?"
  ];
  const promptChips_hindi = [
    "आप किस प्रकार के ऋण प्रदान करते हैं?",
    "मैं कितने न्यूनतम और अधिकतम ऋण राशि के लिए आवेदन कर सकता/सकती हूँ?",
    "मुझे कौन-कौन से दस्तावेज़ जमा करने होंगे?",
    "क्या मैं अपनी ईएमआई की तिथि बदल सकता/सकती हूँ?",
    "प्र: क्या मैं अपने ऋण आवेदन को रद्द कर सकता/सकती हूँ?"
  ];
  const promptChips_tamil = [
    "நீங்கள் என்னென் வகையான கடன்களை வழங்குகிறீர்கள்?",
    "நான் குறைந்தபட்சம் மற்றும் அதிகபட்சமாக எவ்வளவு கடனுக்கு விண்ணப்பிக்கலாம்?",
    "எந்தெந்த ஆவணங்களை சமர்ப்பிக்க வேண்டும்?",
    "நான் என் EMI தேதியை மாற்ற முடியுமா?",
    "கே: நான் கடன் விண்ணப்பத்தை ரத்து செய்ய முடியுமா?"
  ];
  const promptChips_telugu = [
    "మీరు ఏ విధమైన లోన్లు అందిస్తారు?",
    "నేను కనీసం మరియు గరిష్ఠంగా ఎంత లోన్‌కు అప్లై చేయవచ్చు?",
    "నేను ఏ డాక్యుమెంట్లు సమర్పించాలి?",
    "నేను నా EMI తేదీని మార్చగలనా?",
    "ప్ర: నేను నా లోన్ దరఖాస్తును రద్దు చేయవచ్చా?"
  ];
  const promptChips_malayalam = [
    "നിങ്ങൾ ഏതു തരം വായ്പകൾ നൽകുന്നു?",
    "ഞാൻ അപേക്ഷിക്കാവുന്ന കുറഞ്ഞതും കൂടിയതുമായ വായ്പ തുക എത്ര?",
    "എനിക്ക് ഏത് രേഖകൾ സമർപ്പിക്കേണ്ടതുണ്ട്?",
    "എൻ്റെ EMI തീയതി ഞാൻ മാറ്റാമോ?",
    "ചോ: ഞാൻ എൻ്റെ വായ്പ അപേക്ഷ റദ്ദാക്കാമോ?"
  ];



  useEffect(() => {
    switch (userInfo.language) {
      case "தமிழ்":
        setHotChips(promptChips_tamil)
        break;
      case "हिन्दी":
        setHotChips(promptChips_hindi)
        break;
      case "తెలుగు":
        setHotChips(promptChips_telugu)
        break;
      case "മലയാളം":
        setHotChips(promptChips_malayalam)
        break;
      default:
        setHotChips(promptChips_english)
    }

  }, [userInfo.language])

  //   // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (messagesViewRef.current) {
      messagesViewRef.current.scrollTo({ top: messagesViewRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages]);

  // Mock data for insights
  // const mockInsightsData = {
  //   loan: {
  //     intent: 'loan_inquiry',
  //     intentConfidence: 0.95,
  //     entities: [
  //       { name: 'loan_type', value: 'home loan', confidence: 0.92 },
  //       { name: 'amount', value: '₹50,00,000', confidence: 0.88 },
  //       { name: 'tenure', value: '20 years', confidence: 0.85 }
  //     ],
  //     sentiment: 'positive' as const,
  //     leadScore: 85
  //   },
  //   insurance: {
  //     intent: 'insurance_inquiry',
  //     intentConfidence: 0.91,
  //     entities: [
  //       { name: 'insurance_type', value: 'term life', confidence: 0.89 },
  //       { name: 'coverage', value: '₹1 crore', confidence: 0.87 },
  //       { name: 'duration', value: '30 years', confidence: 0.82 }
  //     ],
  //     sentiment: 'positive' as const,
  //     leadScore: 78
  //   }
  // };

  const handleSendMessage = () => {
    setIsProcessing(true)
    // Generate questionId for this message
    const questionId = questionCounter.toString();
    setQuestionCounter((prev) => prev + 1);

    // Add user message
    const newUserMessage = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user' as const,
      timestamp: new Date(),
      questionId: questionId,
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInputValue('');

    // Add an initial empty bot response (placeholder)
    const initialBotResponse = {
      id: (Date.now() + 1).toString(),
      content: '',
      sender: 'bot' as const,
      timestamp: new Date(),
      questionId: questionId,
    };
    setMessages(prev => [...prev, initialBotResponse]);

    // If language selection, handle immediately and update placeholder
    if (currentQuestion === 'language') {
      setIsProcessing(false);
      const userLanguageInput = inputValue.toLowerCase().trim();
      const mappedLanguage = LANGUAGE_INPUT_MAP[userLanguageInput];
      let responseMessage = '';
      if (!mappedLanguage) {
        responseMessage = "Please select one of the supported languages: English, Tamil, Hindi, Malayalam, or Telugu.";
      } else {
        setUserInfo(prev => ({ ...prev, language: mappedLanguage }));
        setCurrentQuestion('complete');
        responseMessage = languageResponseMessages[mappedLanguage] || languageResponseMessages['english'];
      }
      setTimeout(() => {
        setMessages(prev =>
          prev.map(m =>
            m.id === initialBotResponse.id
              ? { ...m, content: responseMessage }
              : m
          )
        );
        setIsProcessing(false);
      }, 1500);
      return;
    }

    // Send POST request to chat_api
    if (connectionId && sessionId) {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      const raw = JSON.stringify({
        event_type: 'chat_text',
        connection_id: connectionId,
        question_id: questionId,
        sessionid: sessionId,
        user_input: newUserMessage.content,
        language: mapLanguageForApi(userInfo.language || 'english'),
      });
      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow' as RequestRedirect,
      };
      fetch('https://schihgaxma.execute-api.ap-south-1.amazonaws.com/demo/chat_api', requestOptions)
        .then((response) => response.text())
        .then((result) => console.log(result))
        .catch((error) => console.error(error));
    }

    
    // setTimeout(() => {
    //   // let responseMessage = '';
    //   switch (currentQuestion) {
    //     case 'language':
    //       // Already handled above
    //       break;
    //   }
    //   // No-op for other cases
    // }, 1500);
  };


  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    console.log("qqqqqqqqqqqqqqqq", transcript)
    console.log("qqqqqqqqqqqqqqqq", listening)
    if (!listening && transcript) {
      setInputValue(prev => prev + (prev && !prev.endsWith(' ') ? ' ' : '') + transcript);
      resetTranscript();
      // console.log("qqqqqqqqqqqqqqqq", transcript)
    }
  }, [listening, transcript, resetTranscript]);

  const handlePostChatAnalytics = () => {

    setIsGeneratingAnalysis(true); // Set loading state to true
    setPostChatAnalyticsGenerated(true);
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
      event_type: 'ub_post_chat',
      sessionid: sessionId,
      user_name: userInfo.name,
      language: mapLanguageForApi(userInfo.language || 'english'),
    });

    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow" as RequestRedirect
    };

    fetch("https://schihgaxma.execute-api.ap-south-1.amazonaws.com/demo/chat_api", requestOptions)
      .then((response) => response.text())
      .then((result) => {
        try {
          const arr = JSON.parse(result);
          setPostChatAnalysis({
            sentiment: arr[0],
            opportunity: arr[1],
            title: arr[2],
            summary: arr[3],
            whatsappMessage: arr[4],
            enquiryType: arr[5],
          });

          // --- ADD THIS BLOCK ---
          const myHeaders = new Headers();
          myHeaders.append("Content-Type", "application/json");

          const raw = JSON.stringify({
            language: mapLanguageForApi(userInfo.language || 'english'),
            session_id: sessionId,
            text: arr[6], // WhatsApp text from previous response
          });

          const requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: raw,
            // mode: 'no-cors',
            redirect: "follow" as RequestRedirect,
          };

          fetch('https://schihgaxma.execute-api.ap-south-1.amazonaws.com/demo/wa', requestOptions)
            .then((response) => response.text())
            .then((result) => {
              setPostChatAudioUrl(result.replace(/"/g, ""));
              setIsGeneratingAnalysis(false); // Set loading state to false after all data is loaded
            })
            .catch((error) => {
              console.error(error);
              setIsGeneratingAnalysis(false); // Set loading state to false on error
            });
        } catch (error) {
          console.error("Error parsing JSON:", error);
          setPostChatAnalysis(null);
          setIsGeneratingAnalysis(false); // Set loading state to false on error
        }
      })
      .catch((error) => {
        console.error(error);
        setPostChatAnalysis(null);
        setIsGeneratingAnalysis(false); // Set loading state to false on error
      });
  }

  const handlePlayPause = (id: string) => {
    if (playingAudioId && playingAudioId !== id) {
      // Pause any other audio
      const prevAudio = audioRefs.current[playingAudioId];
      if (prevAudio) prevAudio.pause();
    }
    const audio = audioRefs.current[id];
    if (audio) {
      if (audio.paused) {
        audio.play();
        setPlayingAudioId(id);
        // Listen for timeupdate
        audio.ontimeupdate = () => {
          setAudioProgress((prev) => ({ ...prev, [id]: audio.currentTime }));
        };
        audio.onended = () => {
          setPlayingAudioId(null);
          setAudioProgress((prev) => ({ ...prev, [id]: 0 }));
        };
      } else {
        audio.pause();
        setPlayingAudioId(null);
      }
    }
  };

  // Pause audio when unmounting
  useEffect(() => {
    return () => {
      Object.values(audioRefs.current).forEach((audio) => audio?.pause());
    };
  }, []);

  // Centered placeholder for all tabs before button is pressed
  // const aiInsightsPlaceholder = (
  //   <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '260px', height: '100%', width: '100%' }}>
  //     {isGeneratingAnalysis ? (
  //       <div className="flex flex-col items-center gap-4">
  //         <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87722]"></div>
  //         <span className="text-[#e87722] font-medium">Generating Analysis...</span>
  //       </div>
  //     ) : (
  //       <span style={{ color: '#bbb', fontSize: '1.1rem', fontWeight: 400, textAlign: 'center', lineHeight: 1.5 }}>
  //         Click <span style={{ fontWeight: 700, color: '#e87722' }}>'Generate Post Chat Analysis'</span><br />
  //         to unlock your personalized summary!
  //       </span>
  //     )}
  //   </div>
  // );

  useEffect(() => {
    if (currentQuestion !== 'complete') {
      // Clean up if not complete
      if (webSocket) {
        webSocket.close();
        setWebSocket(null);
      }
      return;
    }

    // Generate sessionId if not already set
    if (!sessionId) {
      const newSessionId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      setSessionId(newSessionId);
    }

    // Open WebSocket connection
    const ws = new WebSocket('wss://r46tofhx79.execute-api.ap-south-1.amazonaws.com/production/');
    setWebSocket(ws);

    ws.onopen = () => {
      ws.send('hey');
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.connectionid) {
          setConnectionId(data.connectionid);
          console.log('Connection ID:', data.connectionid);
        }
        // Log all received messages
        console.log('WebSocket message received:', data);

        // Handle streaming bot responses in messages array
        if (data.status === 'in-progress' && data.question_id && typeof data.privateMessage === 'string') {
          console.log('data.privateMessageaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
          setMessages(prevMessages => {
            // Find the latest bot message with this questionId
            const idx = prevMessages.findIndex(
              m => m.sender === 'bot' && m.questionId === data.question_id
            );
            if (idx !== -1) {
              // Append to existing bot message
              const updated = [...prevMessages];
              updated[idx] = {
                ...updated[idx],
                content: updated[idx].content + data.privateMessage,
              };
              return updated;
            } else {
              // Create new bot message for this questionId
              return [
                ...prevMessages,
                {
                  id: Date.now().toString() + Math.random().toString(36).slice(2),
                  content: data.privateMessage,
                  sender: 'bot',
                  timestamp: new Date(),
                  questionId: data.question_id,
                },
              ];
            }
          });
        } else if (data.status === 'done') {
          console.log('data.statusaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
          setIsProcessing(false);
        }
      } catch (err) {
        // Optionally handle error
        console.log('WebSocket message received (non-JSON):', event.data);
      }
    };

    ws.onerror = (err) => {
      console.error('WebSocket error:', err);
    };

    ws.onclose = () => {
      setWebSocket(null);
    };

    // Cleanup on unmount or currentQuestion change
    return () => {
      ws.close();
      setWebSocket(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentQuestion]);

  // Robust speak function: handles long texts, waits for voices, speaks all content
  // const speak = (text: string) => {
  //   // Helper: Split text into sentences/chunks (max 200 chars per chunk, split on sentence boundaries)
  //   const splitTextIntoChunks = (input: string, maxLen = 200) => {
  //     const sentences = input.match(/[^.!?\n]+[.!?\n]*/g) || [input];
  //     const chunks: string[] = [];
  //     let current = '';
  //     for (const sentence of sentences) {
  //       if ((current + sentence).length > maxLen && current) {
  //         chunks.push(current.trim());
  //         current = '';
  //       }
  //       current += sentence;
  //     }
  //     if (current) chunks.push(current.trim());
  //     return chunks;
  //   };

  //   // Map the user's language to the appropriate language code
  //   const languageMap: Record<string, string> = {
  //     'english': 'en-US',
  //     'tamil': 'ta-IN',
  //     'hindi': 'hi-IN',
  //     'malayalam': 'ml-IN',
  //     'telugu': 'te-IN',
  //   };
  //   const langCode = userInfo.language && languageMap[userInfo.language] ? languageMap[userInfo.language] : 'en-US';

  //   // Wait for voices to be loaded (returns a Promise)
  //   const getVoicesAsync = () => {
  //     return new Promise<SpeechSynthesisVoice[]>((resolve) => {
  //       const voices = window.speechSynthesis.getVoices();
  //       if (voices.length) {
  //         resolve(voices);
  //       } else {
  //         window.speechSynthesis.onvoiceschanged = () => {
  //           resolve(window.speechSynthesis.getVoices());
  //         };
  //       }
  //     });
  //   };

  //   // Speak all chunks sequentially
  //   const speakChunks = async (chunks: string[]) => {
  //     const voices = await getVoicesAsync();
  //     const preferredVoice = voices.find(voice => voice.lang.startsWith(langCode.split('-')[0]));
  //     // let speaking = false;
  //     // Cancel any ongoing speech before starting a new one
  //     window.speechSynthesis.cancel();
  //     const speakChunk = (idx: number) => {
  //       if (idx >= chunks.length) return;
  //       const utterance = new window.SpeechSynthesisUtterance(chunks[idx]);
  //       utterance.lang = langCode;
  //       utterance.voice = preferredVoice || voices[0];
  //       utterance.onend = () => speakChunk(idx + 1);
  //       utterance.onerror = () => speakChunk(idx + 1); // skip on error
  //       window.speechSynthesis.speak(utterance);
  //     };
  //     speakChunk(0);
  //   };

  //   const chunks = splitTextIntoChunks(text);
  //   speakChunks(chunks);
  // };

  // const handleSpeakMessage = (content: string) => {
  //   speak(content);
  // };

  const [isMicActive, setIsMicActive] = useState(false);
  const [isStopping, setIsStopping] = useState(false);

  const handleMicClick = () => {
    if (!browserSupportsSpeechRecognition) {
      alert("Browser doesn't support speech recognition.");
      return;
    }
    if (isMicActive) {
      setIsMicActive(false);
      setIsStopping(true);
      SpeechRecognition.stopListening();
    } else {
      setIsMicActive(true);
      const languageMap: Record<string, string> = {
        'english': 'en-IN',
        'தமிழ்': 'ta-IN',
        'हिन्दी': 'hi-IN',
        'മലയാളം': 'ml-IN',
        'తెలుగు': 'te-IN',
      };
      const lang = userInfo.language && languageMap[userInfo.language]
        ? languageMap[userInfo.language]
        : languageMap['english'];
      try {
        SpeechRecognition.startListening({
          language: lang,
          continuous: false, // keep as false
        });
      } catch (e) {
        console.error("Error starting mic:", e);
      }
    }
  };

  useEffect(() => {
    // Auto-restart if user wants mic on and it stopped
    if (isMicActive && !listening) {
      const languageMap: Record<string, string> = {
        'english': 'en-IN',
        'தமிழ்': 'ta-IN',
        'हिन्दी': 'hi-IN',
        'മലയാളം': 'ml-IN',
        'తెలుగు': 'te-IN',
      };
      const lang = userInfo.language && languageMap[userInfo.language]
        ? languageMap[userInfo.language]
        : languageMap['english'];
      try {
        SpeechRecognition.startListening({
          language: lang,
          continuous: false,
        });
      } catch (e) {
        console.error("Error restarting mic:", e);
      }
    }
    // Hide loader when mic is off and browser has stopped listening
    if (!isMicActive && !listening && isStopping) {
      setIsStopping(false);
    }
  }, [isMicActive, listening, isStopping, userInfo.language]);

  // Update renderedBotMessageId when a new bot message is added
  useEffect(() => {
    // Find the latest bot message
    const lastBotMsg = [...messages].reverse().find(m => m.sender === 'bot');
    if (lastBotMsg && lastBotMsg.id !== renderedBotMessageId) {
      setRenderedBotMessageId(lastBotMsg.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages]);

  // Add effect to handle play/pause/end events for post-chat audio
  useEffect(() => {
    const audio = postAudioRef.current;
    if (!audio) return;
    const handlePlay = () => setIsPostAudioPlaying(true);
    const handlePause = () => setIsPostAudioPlaying(false);
    const handleEnded = () => setIsPostAudioPlaying(false);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('ended', handleEnded);
    return () => {
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [postChatAudioUrl]);

  // Loader control: stop loader when a new bot message appears at the end

  // Add the isLanguageSelection function
  const isLanguageSelection = (msg: string) => {
    const lower = msg.trim().toLowerCase();
    return [
      'english',
      'tamil',
      'hindi',
      'malayalam',
      'telugu',
    ].includes(lower);
  };

  const [isPostChatAllReady, setIsPostChatAllReady] = useState(false);

  // Update isPostChatAllReady when both postChatAnalysis and postChatAudioUrl are ready
  useEffect(() => {
    if (postChatAnalyticsGenerated && postChatAnalysis && postChatAudioUrl) {
      setIsPostChatAllReady(true);
    }
  }, [postChatAnalyticsGenerated, postChatAnalysis, postChatAudioUrl]);

  // --- Add a helper function for API language mapping ---
  function mapLanguageForApi(lang: string) {
    switch (lang) {
      case 'தமிழ்': return 'tamil';
      case 'हिन्दी': return 'hindi';
      case 'తెలుగు': return 'telugu';
      case 'മലയാളം': return 'malayalam';
      default: return lang;
    }
  }

  return (
    <div className="container py-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-6">
        <button type="button" onClick={() => navigate('/')} className="flex items-center font-semibold " style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>
          <HomeIcon className="h-5 w-5  mr-1" />
          <span className="text-gray-600">Home</span>
        </button>
        <span className="text-gray-400">/</span>
        <span style={{ fontWeight: 600, color: '#e87722' }}>Digital RM</span>
      </div>
      {/* Page Title and Subtitle */}
      <div className="flex items-center gap-6 mb-8 ">
        <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
          <MessageSquare className="h-8 w-8 text-primary" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-4xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
              Digital RM
            </h1>

          </div>
          <p className="text-lg text-gray-600">
            Engage with an AI chatbot that understands banking queries and processes both voice and text inputs.
          </p>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 ">
        <motion.div
          className={cn(
            "lg:col-span-7 xl:col-span-8",
            isPanelOpen ? "" : "lg:col-span-12 xl:col-span-12"
          )}
          layout
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
          <Card className="h-[75vh] flex flex-col">
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                <h2 className="text-lg font-semibold">Digital RM </h2>
                <div className="flex items-center">
                  <LanguageSlideshow />
                </div>
              </div>
            </div>

            <div className="flex-1 min-h-0">
              <div className="h-full overflow-y-auto p-4" id="messages-view" ref={messagesViewRef}>
                <div className="space-y-4">
                  {messages.map((message, idx) => {
                    const isLastMessage = idx === messages.length - 1;
                    const isBotMessage = message.sender === 'bot';
                    const showCursor = isLastMessage && isBotMessage && isProcessing;
                    return (
                      <>
                        <div
                          key={message.id}
                          className={cn(
                            "flex items-start gap-3 rounded-lg p-3",
                            message.sender === 'user'
                              ? "ml-auto flex-row-reverse"
                              : "mr-auto max-w-[80%]"
                          )}
                        >
                          {message.sender === 'bot' && (
                            <Avatar className="h-8 w-8 bg-[#e87722] text-white flex items-center justify-center">
                              <Bot className="h-4 w-4" />
                            </Avatar>
                          )}
                          {message.audioUrl ? (
                            <div
                              style={{ position: 'relative', minWidth: 80, maxWidth: 160 }}
                              className={
                                message.sender === 'user'
                                  ? 'bg-[#e87722] px-3 py-2 rounded-3xl flex flex-col items-start'
                                  : 'bg-[#f3f4f6] px-3 py-2 rounded-3xl flex flex-col items-start border border-border shadow-none'
                              }
                            >
                              <div className="flex items-center gap-2">
                                {message.isProcessing ? (
                                  <div className="flex items-center gap-2">
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                                    <span className="text-white text-sm">Processing...</span>
                                  </div>
                                ) : (
                                  <>
                                    <button
                                      className="btn btn-light btn-sm rounded-circle d-flex align-items-center justify-content-center p-0"
                                      style={
                                        message.sender === 'user'
                                          ? { width: 24, height: 24, background: '#fff', color: '#e87722', border: 'none' }
                                          : { width: 24, height: 24, background: '#181f5a', color: '#fff', border: 'none' }
                                      }
                                      onClick={() => handlePlayPause(message.id)}
                                    >
                                      {playingAudioId === message.id ? (
                                        <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16" style={{ display: 'block', margin: 'auto' }}><rect x="3" y="2" width="3" height="12" /><rect x="10" y="2" width="3" height="12" /></svg>
                                      ) : (
                                        <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16" style={{ display: 'block', margin: 'auto' }}><path d="M3 2.5v11l9-5.5-9-5.5z" /></svg>
                                      )}
                                    </button>
                                    <audio
                                      ref={el => (audioRefs.current[message.id] = el)}
                                      src={message.audioUrl}
                                      onEnded={() => setPlayingAudioId(null)}
                                      style={{ display: 'none' }}
                                      onPlay={() => setAudioProgress((prev) => ({ ...prev, [message.id]: 0 }))}
                                    />
                                    <span
                                      className={
                                        message.sender === 'user'
                                          ? 'text-white text-base font-semibold'
                                          : 'text-[#181f5a] text-base font-semibold'
                                      }
                                      style={{ minWidth: 40, textAlign: 'center' }}
                                    >
                                      {playingAudioId === message.id
                                        ? `0:${Math.floor(audioProgress[message.id] || 0).toString().padStart(2, '0')}`
                                        : message.audioDuration
                                          ? `0:${message.audioDuration.toString().padStart(2, '0')}`
                                          : '0:00'}
                                    </span>
                                  </>
                                )}
                              </div>
                              {/* Simple waveform bar */}
                              <div className="w-full mt-1 flex items-center">
                                <svg height="16" width="100%" viewBox="0 0 60 16" style={{ minWidth: 60 }}>
                                  <rect x="2" y="8" width="2" height="6" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="7" y="4" width="2" height="10" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="12" y="10" width="2" height="4" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="17" y="6" width="2" height="8" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="22" y="8" width="2" height="6" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="27" y="4" width="2" height="10" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="32" y="10" width="2" height="4" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="37" y="6" width="2" height="8" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="42" y="8" width="2" height="6" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="47" y="4" width="2" height="10" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="52" y="10" width="2" height="4" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                  <rect x="57" y="6" width="2" height="8" fill={message.sender === 'user' ? '#fff' : '#181f5a'} rx="1" />
                                </svg>
                              </div>
                            </div>
                          ) : message.sender === 'user' ? (
                            <div style={{ position: 'relative' }}>
                              <div className="bg-[#e87722] px-3 py-2" style={{ borderRadius: 20, position: 'relative' }}>
                                <span style={{ position: 'absolute', top: 6, left: 10, width: 20, height: 20, display: 'flex', alignItems: 'center' }}>
                                  <User className="h-4 w-4 text-white" />
                                </span>
                                <span className="text-white text-sm break-words block pl-6">{message.content}</span>
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <p className="text-sm leading-relaxed flex-1">
                                  {message.content}
                                  {showCursor && (
                                    <span
                                      className="inline-block w-[1px] bg-[#181f5a] animate-blink-cursor ml-1"
                                      style={{ height: '1.25em', verticalAlign: 'middle' }}
                                      aria-label="Bot is typing"
                                    ></span>
                                  )}
                                </p>
                                {/* Speaker button for every bot message, only if content is non-empty and not during loader */}
                                {/* {message.content.trim() !== '' && !isProcessing && (
                                <button
                                  onClick={() => handleSpeakMessage(message.content)}
                                  className="p-1 hover:bg-gray-100 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
                                  aria-label="Speak message"
                                  tabIndex={0}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter' || e.key === ' ') {
                                      e.preventDefault();
                                      handleSpeakMessage(message.content);
                                    }
                                  }}
                                >
                                  <Volume2 className="h-4 w-4 text-gray-500" />
                                </button>
                              )} */}
                              </div>
                              <div className="flex items-center gap-2" >
                                {/* Only show timestamp if not showing the cursor/loader */}
                                {!showCursor && (
                                  <p className="text-xs opacity-70">
                                    {message.timestamp.toLocaleTimeString([], {
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    })}
                                  </p>
                                )}
                                {/* Generate Post Chat Analysis button only for the latest rendered bot message, after content appears and not during loader */}
                                {(() => {
                                  // Find the last user message before this bot message
                                  const prevUserMsgIdx = [...messages].slice(0, idx).reverse().findIndex(m => m.sender === 'user');
                                  if (prevUserMsgIdx === -1) return false;
                                  const prevUserMsg = messages[messages.length - 1 - prevUserMsgIdx - (messages.length - idx)];
                                  return prevUserMsg && !isLanguageSelection(prevUserMsg.content);
                                })() &&
                                  !postChatAnalyticsGenerated &&
                                  message.id === renderedBotMessageId &&
                                  message.content.trim() !== '' &&
                                  !isProcessing &&
                                  currentQuestion === 'complete' &&
                                  idx !== 0 && // Not the initial greeting
                                  messages.some(m => m.sender === 'user') && (
                                    <button
                                      className="border border-[#e87722] text-[#e87722] bg-white hover:bg-[#fbeee6] focus:bg-[#fbeee6] rounded-full px-3 py-1 flex items-center gap-2 shadow-sm text-xs font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-[#e87722] focus:ring-offset-2"
                                      onClick={() => { handlePostChatAnalytics() }}
                                      disabled={!messages.some(m => m.sender === 'user')}
                                      tabIndex={0}
                                      aria-label="Generate Post Chat Analysis"
                                    >
                                      <BarChart className="w-3 h-3 text-[#e87722]" />
                                      Generate Post Chat Analysis
                                    </button>
                                  )}
                              </div>
                            </div>
                          )}
                          {message.sender === 'user' && (
                            <span className="text-xs opacity-70 self-start ml-2 mt-1">{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          )}
                        </div>
                      </>
                    );
                  })}
                  {/* Loader: show when waiting for bot response */}
                  {isProcessing && messages.length > 0 && messages[messages.length - 1].sender === 'user' && (
                    <div
                      className={cn(
                        'flex items-start gap-3 rounded-lg p-3 mr-auto max-w-[80%]'
                      )}
                    >
                      <Avatar className="h-8 w-8 bg-[#e87722] text-white flex items-center justify-center">
                        <Bot className="h-4 w-4" />
                      </Avatar>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-2">
                            <span
                              className="inline-block w-[1px] bg-[#181f5a] animate-blink-cursor"
                              style={{ height: '1.25em', verticalAlign: 'middle' }}
                              aria-label="Bot is typing"
                            ></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>


            {/* {messages.length > 1 && messages[messages.length-1].sender === 'bot' && (
              <div className="px-4 py-2 bg-muted/50 border-t">
                <div className="flex items-center gap-2 mb-1">
                  <Phone className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-medium">WhatsApp Follow-up</h3>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6 ml-auto"
                    onClick={() => setFollowupExpanded(!followupExpanded)}
                  >
                    {followupExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </Button>
                </div>
                
                {followupExpanded && (
                  <div className="space-y-2 text-sm text-muted-foreground mt-2 mb-1">
                    <p>• Text summary of conversation</p>
                    <p>• Voice note with personalized recommendations</p>
                    <p>• Links to required documentation</p>
                  </div>
                )}
              </div>
            )} */}

            <div className="p-4 border-t">
              {/* Prompt Chips Row */}
              {currentQuestion === 'complete' && (
                <div className="flex gap-2 overflow-x-auto mb-3 pb-1" role="list" aria-label="Prompt suggestions">
                  {hotChips.map((chip, _) => (
                    <button
                      key={chip}
                      type="button"
                      className="whitespace-nowrap px-3 py-1 rounded-full border border-gray-300 bg-white text-gray-700 text-sm font-medium shadow-sm hover:bg-[#fbeee6] focus:bg-[#fbeee6] focus:outline-none focus:ring-2 focus:ring-[#e87722] transition-colors"
                      tabIndex={0}
                      aria-label={`Insert prompt: ${chip}`}
                      onClick={() => setInputValue(chip)}
                      onKeyDown={e => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          setInputValue(chip);
                        }
                      }}
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              )}
              {/* End Prompt Chips Row */}
              <div className="flex gap-2">
                  <Textarea
                    placeholder="Type your message here..."
                    value={listening ? inputValue + transcript : inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    className="min-h-10 resize-none"
                    disabled={postChatAnalyticsGenerated || (isMicActive && continuous)}
                  />
                  <div className="flex flex-col gap-2">
                    <Button
                      size="icon"
                      onClick={handleMicClick}
                      variant={isMicActive ? "destructive" : "secondary"}
                      className="rounded-full"
                      disabled={postChatAnalyticsGenerated}
                      aria-label={isMicActive ? "Stop recording" : "Start recording"}
                      tabIndex={0}
                    >
                      {isStopping ? (
                        <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white block"></span>
                      ) : isMicActive ? (
                        <MicOff className="h-4 w-4" />
                      ) : (
                        <Mic className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      size="icon"
                      onClick={handleSendMessage}
                      disabled={inputValue.trim() === '' || postChatAnalyticsGenerated || isMicActive}
                      className="rounded-full"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              {listening && (
                <div className="mt-3 mb-2 flex items-center gap-3 px-4 py-3 rounded-lg bg-[#fff7f0] border border-[#ffe0cc] shadow-sm animate-fade-in">
                  <span className="relative flex h-5 w-5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-5 w-5 bg-red-500"></span>
                  </span>
                  <div className="flex flex-col">
                    <span className="font-semibold text-red-600 text-base flex items-center gap-2">
                      <Mic className="h-4 w-4 mr-1 text-red-500 animate-mic" />
                      Listening...
                    </span>
                    <span className="text-xs text-muted-foreground mt-1">Speak now, your message is being transcribed in real time.</span>
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* WhatsApp Preview Card (always visible, now below chat card) */}
          <div className="mt-4" >
            <div className="border rounded-lg bg-white shadow-sm p-0" style={{ height: '22.3rem', minHeight: '22.3rem', maxHeight: '22.3rem' }}>
              <div className="flex items-center gap-2 px-4 pt-3 pb-2">
                <span className="flex items-center justify-center rounded-full bg-green-500 text-white w-6 h-6 mr-2" tabIndex={0} aria-label="WhatsApp Message">
                  <MessageSquare className="w-4 h-4" />
                </span>
                <span className="font-semibold text-lg text-gray-800" tabIndex={0} aria-label="WhatsApp Preview">WhatsApp Preview</span>
              </div>
              <div className="border-t mx-4" />
              <div className="px-4 py-5">
                {isGeneratingAnalysis ? (
                  <div className="h-[19rem] w-full flex items-center justify-center">
                    <div className="flex flex-col items-center gap-4" >
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87722]"></div>
                      <span className="text-[#e87722] font-medium">Generating Analysis...</span>
                    </div>
                  </div>
                ) : isPostChatAllReady ? (
                  <>
                    <div className="w-full text-left mb-3">
                      <p className="text-xs mb-2 font-bold">Text Message Content (English)</p>
                      <div className="text-sm max-h-34 overflow-y-auto pr-2">
                        {postChatAnalysis?.whatsappMessage && (
                          <span>
                            {postChatAnalysis.whatsappMessage} {' '}
                            {kycUploadMessages[userInfo.language || 'english']} {' '}
                            <a
                              href="https://www.sandbox.1cloudhub.com/documents"
                              className="text-blue-600 underline break-all"
                              target="_blank"
                              rel="noopener noreferrer"
                              tabIndex={0}
                              aria-label="Upload your documents"
                            >
                              https://www.sandbox.1cloudhub.com/documents
                            </a>
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="w-full">
                      <p className="text-xs mb-2 font-bold">Voice Note Content</p>
                      {!postChatAudioUrl ? (
                        <span className="text-xs text-gray-400">Generating voice note...</span>
                      ) : (
                        <div
                          style={{ position: 'relative', minWidth: 220, maxWidth: 340 }}
                          className="bg-[#f3f4f6] px-3 py-2 rounded-3xl flex flex-col items-start border border-border shadow-none"
                        >
                          <div className="flex items-center gap-2 w-full">
                            {/* Play/Pause Button */}
                            <button
                              className="flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-[#e87722]"
                              style={{ 
                                width: 32, 
                                height: 32, 
                                background: '#181f5a', 
                                color: '#fff', 
                                border: 'none', 
                                borderRadius: '16px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                              }}
                              onClick={() => {
                                const audio = postAudioRef.current;
                                if (audio) {
                                  if (audio.paused) {
                                    audio.play();
                                    setIsPostAudioPlaying(true);
                                  } else {
                                    audio.pause();
                                    setIsPostAudioPlaying(false);
                                  }
                                }
                              }}
                              tabIndex={0}
                              aria-label={isPostAudioPlaying ? 'Pause voice note' : 'Play voice note'}
                            >
                              {isPostAudioPlaying ? (
                                <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                                  <rect x="3" y="2" width="3" height="12"/>
                                  <rect x="10" y="2" width="3" height="12"/>
                                </svg>
                              ) : (
                                <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                                  <path d="M5 3.5v9l7-4.5-7-4.5z"/>
                                </svg>
                              )}
                            </button>
                            {/* Stop Button */}
                            <button
                              className="flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-[#e87722]"
                              style={{ 
                                width: 32, 
                                height: 32, 
                                background: '#e87722', 
                                color: '#fff', 
                                border: 'none', 
                                borderRadius: '16px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                              }}
                              onClick={() => {
                                const audio = postAudioRef.current;
                                if (audio) {
                                  audio.pause();
                                  audio.currentTime = 0;
                                  setIsPostAudioPlaying(false);
                                }
                              }}
                              tabIndex={0}
                              aria-label="Stop voice note"
                            >
                              <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                                <rect x="3" y="3" width="10" height="10" rx="2"/>
                              </svg>
                            </button>
                            {/* Replay Button */}
                            <button
                              className="flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-[#e87722]"
                              style={{ 
                                width: 32, 
                                height: 32, 
                                background: '#fff', 
                                color: '#e87722', 
                                border: '1.5px solid #e87722', 
                                borderRadius: '16px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                              }}
                              onClick={() => {
                                const audio = postAudioRef.current;
                                if (audio) {
                                  audio.currentTime = 0;
                                  audio.play();
                                  setIsPostAudioPlaying(true);
                                }
                              }}
                              tabIndex={0}
                              aria-label="Replay voice note"
                            >
                              <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M8 3a5 5 0 1 1-4.546 2.914.75.75 0 1 1 1.342-.67A3.5 3.5 0 1 0 8 4.5V6a.75.75 0 0 1-1.5 0V2.75A.75.75 0 0 1 7.25 2h2.5a.75.75 0 0 1 0 1.5H8Z"/>
                              </svg>
                            </button>
                            <audio
                              id="postcall-audio"
                              ref={postAudioRef}
                              src={postChatAudioUrl}
                              style={{ display: 'none' }}
                            />
                            <div className="flex items-center ml-2">
                              {/* Static Audio Waveform Icon */}
                              <svg width="60" height="20" viewBox="0 0 60 20" className="mr-2">
                                <rect x="2" y="8" width="1.5" height="4" fill="#e87722" rx="0.75"/>
                                <rect x="5" y="6" width="1.5" height="8" fill="#e87722" rx="0.75"/>
                                <rect x="8" y="10" width="1.5" height="2" fill="#e87722" rx="0.75"/>
                                <rect x="11" y="5" width="1.5" height="10" fill="#e87722" rx="0.75"/>
                                <rect x="14" y="7" width="1.5" height="6" fill="#e87722" rx="0.75"/>
                                <rect x="17" y="4" width="1.5" height="12" fill="#e87722" rx="0.75"/>
                                <rect x="20" y="9" width="1.5" height="3" fill="#e87722" rx="0.75"/>
                                <rect x="23" y="6" width="1.5" height="8" fill="#e87722" rx="0.75"/>
                                <rect x="26" y="8" width="1.5" height="4" fill="#e87722" rx="0.75"/>
                                <rect x="29" y="3" width="1.5" height="14" fill="#e87722" rx="0.75"/>
                                <rect x="32" y="7" width="1.5" height="6" fill="#e87722" rx="0.75"/>
                                <rect x="35" y="5" width="1.5" height="10" fill="#e87722" rx="0.75"/>
                                <rect x="38" y="9" width="1.5" height="3" fill="#e87722" rx="0.75"/>
                                <rect x="41" y="6" width="1.5" height="8" fill="#e87722" rx="0.75"/>
                                <rect x="44" y="4" width="1.5" height="12" fill="#e87722" rx="0.75"/>
                                <rect x="47" y="8" width="1.5" height="4" fill="#e87722" rx="0.75"/>
                                <rect x="50" y="7" width="1.5" height="6" fill="#e87722" rx="0.75"/>
                                <rect x="53" y="5" width="1.5" height="10" fill="#e87722" rx="0.75"/>
                                <rect x="56" y="9" width="1.5" height="3" fill="#e87722" rx="0.75"/>
                              </svg>
                              <span className="text-[#181f5a] text-base font-semibold" style={{ minWidth: 40, textAlign: 'center' }}>Voice Note</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="h-[19rem] w-full flex items-center justify-center">
                    <span className="text-[#bbb] text-center w-full" style={{ fontSize: '1.1rem', fontWeight: 400, lineHeight: 1.5 }}>
                      Click <span style={{ fontWeight: 700, color: '#e87722' }}>'Generate Post Chat Analysis'</span><br />
                      to unlock your personalized summary!
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {isPanelOpen && (
          <motion.div
            className="lg:col-span-5 xl:col-span-4"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Conversation Summary Card (always visible) */}
            <div className="mb-4">
              <div className="border rounded-lg bg-white shadow-sm p-0" style={{ height: '19rem' }}>
                <div className="flex items-center gap-2 px-4 pt-3 pb-2">
                  <_FileText className="h-5 w-5 text-[#e87722]" aria-hidden="true" />
                  <span className="font-semibold text-lg text-gray-800" tabIndex={0} aria-label="Summary">Summary</span>
                </div>
                <div className="border-t mx-4" />

                <div className="px-4 py-3">
                  {isGeneratingAnalysis || !isPostChatAllReady ? (
                    <div className="h-[16rem] w-full flex items-center justify-center">
                      {isGeneratingAnalysis ? (
                        <div className="flex flex-col items-center gap-4">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87722]"></div>
                          <span className="text-[#e87722] font-medium">Generating Analysis...</span>
                        </div>
                      ) : (
                        <span className="text-[#bbb] text-center w-full" style={{ fontSize: '1.1rem', fontWeight: 400, lineHeight: 1.5 }}>
                          Click <span style={{ fontWeight: 700, color: '#e87722' }}>'Generate Post Chat Analysis'</span><br />
                          to unlock your personalized summary!
                        </span>
                      )}
                    </div>
                  ) : (
                    <span className="w-full" style={{ textAlign: 'justify' }}><span className="font-bold"></span> <span className="text-gray-700">{postChatAnalysis!.summary}</span></span>
                  )}
                </div>
              </div>
            </div>

            {/* Interaction Summary Card (always visible) */}
            <div className="mb-4">
              <div className="border rounded-lg bg-white shadow-sm p-0" style={{ height: '18.5rem' }}>
                <div className="flex items-center gap-2 px-4 pt-3 pb-2">
                  <svg width="20" height="20" fill="none" viewBox="0 0 20 20" className="text-[#e87722]"><rect x="2" y="2" width="16" height="16" rx="3" stroke="#e87722" strokeWidth="1.5"/><path d="M6 7h8M6 10h8M6 13h5" stroke="#e87722" strokeWidth="1.5" strokeLinecap="round"/></svg>
                  <span className="font-semibold text-lg text-gray-800" tabIndex={0} aria-label="Interaction Summary">Interaction Summary</span>
                </div>
                <div className="border-t mx-4" />
                <div className="px-4 py-3">
                  {isGeneratingAnalysis || !isPostChatAllReady ? (
                    <div className="h-[15rem] w-full flex items-center justify-center">
                      {isGeneratingAnalysis ? (
                        <div className="flex flex-col items-center gap-4">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e87722]"></div>
                          <span className="text-[#e87722] font-medium">Generating Analysis...</span>
                        </div>
                      ) : (
                        <span className="text-[#bbb] text-center w-full" style={{ fontSize: '1.1rem', fontWeight: 400, lineHeight: 1.5 }}>
                          Click <span style={{ fontWeight: 700, color: '#e87722' }}>'Generate Post Chat Analysis'</span><br />
                          to unlock your personalized summary!
                        </span>
                      )}
                    </div>
                  ) : (
                    <div className="rounded-lg p-2" style={{ maxWidth: 360, width: '100%' }}>
                      <div className="grid grid-cols-2 gap-y-6 gap-x-8 items-center" style={{ minWidth: 0, textAlign: 'left' }}>
                        <div className="text-gray-600 text-base">Sentiment Analysis</div>
                        <div className="font-bold text-right text-gray-900 text-base">{postChatAnalysis!.sentiment}</div>
                        <div className="text-gray-600 text-base">Enquiry Type</div>
                        <div className="font-bold text-right text-gray-900 text-base">{postChatAnalysis!.enquiryType}</div>
                        <div className="text-gray-600 text-base">Opportunity</div>
                        <div className="font-bold text-right text-gray-900 text-base">{postChatAnalysis!.opportunity}</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            {/* Optional Features Card */}
            <div className="mb-4">
              <div className="border rounded-lg bg-white shadow-sm p-0" style={{ height: '18.5rem' }}>
                <div className="flex items-center gap-2 px-4 pt-3 pb-2">
                  <_FileText className="h-5 w-5 text-[#e87722]" aria-hidden="true" />
                  <span className="font-semibold text-lg text-gray-800" tabIndex={0} aria-label="Optional Features">Additional Features</span>
                </div>
                <div className="border-t mx-4" />
                <ul className="px-4 py-5 space-y-3" aria-label="List of optional features">
                  {['CRM Logging', 'RM Handoff', 'Real-Time Lead Scoring', 'Journey', 'Continuity'].map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-gray-800 text-base" tabIndex={0} aria-label={feature}>
                      <svg className="w-5 h-5 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
export default Chat;