import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Building, Mail, Phone, CheckCircle, XCircle, Clock, Save } from 'lucide-react';

export default function AttendeeStatus() {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [attendeeData, setAttendeeData] = useState({
    id: id,
    name: 'John Smith',
    email: 'john@techbank.com',
    phone: '+1 (555) 123-4567',
    company: 'TechBank Corp',
    jobTitle: 'VP of Technology',
    industry: 'Banking & Finance',
    companySize: '201-1000 employees',
    status: 'attended' as 'registered' | 'attended' | 'no-show',
    salesQualified: true,
    interests: ['BankAssist Suite', 'PolicyPal Assistant'],
    notes: 'Very interested in AI solutions for customer service. Mentioned they have budget approved for Q2.',
    leadScore: 85,
    followUpDate: '2025-01-25',
    budget: '$50,000 - $100,000',
    timeline: 'Q2 2025',
    decisionMaker: true
  });

  const handleSave = () => {
    console.log('Saving attendee data:', attendeeData);
    alert('Attendee status updated successfully!');
    navigate(-1);
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium";
    switch (status) {
      case 'registered':
        return `${baseClasses} bg-blue-100 text-blue-800`;
      case 'attended':
        return `${baseClasses} bg-green-100 text-green-800`;
      case 'no-show':
        return `${baseClasses} bg-red-100 text-red-800`;
      default:
        return baseClasses;
    }
  };

  const getLeadScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 hover:text-orange-500 transition-colors duration-200 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Attendees
        </button>
        
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{attendeeData.name}</h1>
            <p className="text-gray-600 mt-2">Sales Qualification & Status Management</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className={getStatusBadge(attendeeData.status)}>
              {attendeeData.status === 'attended' && <CheckCircle className="h-4 w-4 mr-1" />}
              {attendeeData.status === 'no-show' && <XCircle className="h-4 w-4 mr-1" />}
              {attendeeData.status === 'registered' && <Clock className="h-4 w-4 mr-1" />}
              {attendeeData.status.charAt(0).toUpperCase() + attendeeData.status.slice(1).replace('-', ' ')}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Contact Information */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-4">
              <User className="h-5 w-5 inline mr-2" />
              Contact Information
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Name</label>
                <p className="text-gray-900">{attendeeData.name}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Job Title</label>
                <p className="text-gray-900">{attendeeData.jobTitle}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">
                  <Mail className="h-4 w-4 inline mr-1" />
                  Email
                </label>
                <p className="text-gray-900">{attendeeData.email}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">
                  <Phone className="h-4 w-4 inline mr-1" />
                  Phone
                </label>
                <p className="text-gray-900">{attendeeData.phone}</p>
              </div>
            </div>
          </div>

          {/* Company Information */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-4">
              <Building className="h-5 w-5 inline mr-2" />
              Company Information
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Company</label>
                <p className="text-gray-900">{attendeeData.company}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Industry</label>
                <p className="text-gray-900">{attendeeData.industry}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-500 mb-1">Company Size</label>
                <p className="text-gray-900">{attendeeData.companySize}</p>
              </div>
            </div>
          </div>

          {/* Sales Qualification */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-4">Sales Qualification</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-700">Sales Qualified Lead</label>
                <button
                  onClick={() => setAttendeeData(prev => ({ ...prev, salesQualified: !prev.salesQualified }))}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 ${
                    attendeeData.salesQualified ? 'bg-orange-500' : 'bg-gray-200'
                  }`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    attendeeData.salesQualified ? 'translate-x-6' : 'translate-x-1'
                  }`} />
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Budget Range</label>
                <select
                  value={attendeeData.budget}
                  onChange={(e) => setAttendeeData(prev => ({ ...prev, budget: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="">Not disclosed</option>
                  <option value="$10,000 - $25,000">$10,000 - $25,000</option>
                  <option value="$25,000 - $50,000">$25,000 - $50,000</option>
                  <option value="$50,000 - $100,000">$50,000 - $100,000</option>
                  <option value="$100,000+">$100,000+</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Implementation Timeline</label>
                <select
                  value={attendeeData.timeline}
                  onChange={(e) => setAttendeeData(prev => ({ ...prev, timeline: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="">Not specified</option>
                  <option value="Q1 2025">Q1 2025</option>
                  <option value="Q2 2025">Q2 2025</option>
                  <option value="Q3 2025">Q3 2025</option>
                  <option value="Q4 2025">Q4 2025</option>
                  <option value="2026">2026</option>
                </select>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="decisionMaker"
                  checked={attendeeData.decisionMaker}
                  onChange={(e) => setAttendeeData(prev => ({ ...prev, decisionMaker: e.target.checked }))}
                  className="h-4 w-4 text-orange-500 focus:ring-orange-500 border-gray-300 rounded"
                />
                <label htmlFor="decisionMaker" className="ml-2 text-sm text-gray-700">
                  Primary decision maker
                </label>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-4">Sales Notes</h2>
            
            <textarea
              rows={4}
              value={attendeeData.notes}
              onChange={(e) => setAttendeeData(prev => ({ ...prev, notes: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              placeholder="Add notes about this lead..."
            />
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Lead Score */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Lead Score</h3>
            
            <div className="text-center">
              <div className={`text-4xl font-bold ${getLeadScoreColor(attendeeData.leadScore)}`}>
                {attendeeData.leadScore}
              </div>
              <p className="text-sm text-gray-500 mt-1">out of 100</p>
              
              <div className="mt-4">
                <div className="bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${attendeeData.leadScore >= 80 ? 'bg-green-500' : attendeeData.leadScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
                    style={{ width: `${attendeeData.leadScore}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Interests */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Interests</h3>
            
            <div className="space-y-2">
              {attendeeData.interests.map((interest) => (
                <span key={interest} className="inline-block px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm mr-2 mb-2">
                  {interest}
                </span>
              ))}
            </div>
          </div>

          {/* Follow-up */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Follow-up</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Next Follow-up Date</label>
              <input
                type="date"
                value={attendeeData.followUpDate}
                onChange={(e) => setAttendeeData(prev => ({ ...prev, followUpDate: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Actions</h3>
            
            <div className="space-y-3">
              <button
                onClick={handleSave}
                className="w-full flex items-center justify-center px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors duration-200"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </button>
              
              {attendeeData.status === 'attended' && attendeeData.salesQualified && (
                <button
                  onClick={() => navigate(`/attendees/${id}/email`)}
                  className="w-full flex items-center justify-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors duration-200"
                >
                  <Mail className="h-4 w-4 mr-2" />
                  Send Sandbox Email
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}