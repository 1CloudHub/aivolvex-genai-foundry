import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Users, CheckCircle, XCircle, Clock, Mail, Eye, UserCheck } from 'lucide-react';

interface Attendee {
  id: string;
  name: string;
  email: string;
  company: string;
  jobTitle: string;
  status: 'registered' | 'attended' | 'no-show';
  salesQualified: boolean;
  interests: string[];
  notes: string;
}

const mockAttendees: Attendee[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@techbank.com',
    company: 'TechBank Corp',
    jobTitle: 'VP of Technology',
    status: 'attended',
    salesQualified: true,
    interests: ['BankAssist Suite', 'PolicyPal Assistant'],
    notes: 'Very interested in AI solutions for customer service'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah@insureco.com',
    company: 'InsureCo',
    jobTitle: 'Digital Innovation Manager',
    status: 'attended',
    salesQualified: false,
    interests: ['PolicyPal Assistant'],
    notes: 'Still evaluating budget and timeline'
  },
  {
    id: '3',
    name: 'Mike Chen',
    email: 'mchen@retailplus.com',
    company: 'RetailPlus',
    jobTitle: 'CTO',
    status: 'registered',
    salesQualified: false,
    interests: ['Product Vision Search'],
    notes: ''
  }
];

export default function AttendeeTracker() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [attendees, setAttendees] = useState(mockAttendees);

  const event = {
    id: id,
    name: 'GenAI for Banking Summit',
    date: '2025-02-15',
    location: 'San Francisco, CA'
  };

  const updateAttendeeStatus = (attendeeId: string, status: 'attended' | 'no-show') => {
    setAttendees(prev => prev.map(attendee => 
      attendee.id === attendeeId ? { ...attendee, status } : attendee
    ));
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "px-3 py-1 rounded-full text-xs font-medium";
    switch (status) {
      case 'registered':
        return `${baseClasses} bg-blue-100 text-blue-800`;
      case 'attended':
        return `${baseClasses} bg-green-100 text-green-800`;
      case 'no-show':
        return `${baseClasses} bg-red-100 text-red-800`;
      default:
        return baseClasses;
    }
  };

  const stats = {
    total: attendees.length,
    attended: attendees.filter(a => a.status === 'attended').length,
    qualified: attendees.filter(a => a.salesQualified).length,
    pending: attendees.filter(a => a.status === 'registered').length
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <button
          onClick={() => navigate('/events')}
          className="flex items-center text-gray-600 hover:text-orange-500 transition-colors duration-200 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Events
        </button>
        
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{event.name}</h1>
          <p className="text-gray-600 mt-2">Attendee Management & Sales Qualification</p>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Registered</p>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-green-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Attended</p>
              <p className="text-2xl font-bold text-gray-900">{stats.attended}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <UserCheck className="h-8 w-8 text-orange-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Sales Qualified</p>
              <p className="text-2xl font-bold text-gray-900">{stats.qualified}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Clock className="h-8 w-8 text-yellow-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-gray-900">{stats.pending}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Attendee List */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Attendee List</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Attendee
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Sales Qualified
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Interests
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {attendees.map((attendee) => (
                <tr key={attendee.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{attendee.name}</div>
                      <div className="text-sm text-gray-500">{attendee.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm text-gray-900">{attendee.company}</div>
                      <div className="text-sm text-gray-500">{attendee.jobTitle}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={getStatusBadge(attendee.status)}>
                      {attendee.status.charAt(0).toUpperCase() + attendee.status.slice(1).replace('-', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {attendee.salesQualified ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Qualified
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        <Clock className="h-3 w-3 mr-1" />
                        Pending
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">
                      {attendee.interests.slice(0, 2).join(', ')}
                      {attendee.interests.length > 2 && <span className="text-gray-500"> +{attendee.interests.length - 2}</span>}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    {attendee.status === 'registered' && (
                      <>
                        <button
                          onClick={() => updateAttendeeStatus(attendee.id, 'attended')}
                          className="text-green-600 hover:text-green-900 inline-flex items-center"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Attended
                        </button>
                        <button
                          onClick={() => updateAttendeeStatus(attendee.id, 'no-show')}
                          className="text-red-600 hover:text-red-900 inline-flex items-center"
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          No Show
                        </button>
                      </>
                    )}
                    
                    <Link
                      to={`/attendees/${attendee.id}/status`}
                      className="text-orange-600 hover:text-orange-900 inline-flex items-center"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      View
                    </Link>
                    
                    {attendee.status === 'attended' && attendee.salesQualified && (
                      <Link
                        to={`/attendees/${attendee.id}/email`}
                        className="text-blue-600 hover:text-blue-900 inline-flex items-center"
                      >
                        <Mail className="h-4 w-4 mr-1" />
                        Email
                      </Link>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}