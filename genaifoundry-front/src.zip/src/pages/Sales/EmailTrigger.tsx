import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Mail, Send, CheckCircle, Eye, User, Calendar } from 'lucide-react';

export default function EmailTrigger() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [emailSent, setEmailSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const attendee = {
    id: id,
    name: 'John Smith',
    email: 'john@techbank.com',
    company: 'TechBank Corp',
    jobTitle: 'VP of Technology',
    interests: ['BankAssist Suite', 'PolicyPal Assistant']
  };

  const emailTemplate = {
    subject: 'Your GenAI Sandbox Access - Ready to Explore!',
    body: `Dear ${attendee.name},

Thank you for attending the GenAI for Banking Summit! We're excited to provide you with exclusive access to our GenAI Sandbox environment.

Based on your interest in AI solutions for banking, we've prepared a personalized sandbox experience featuring:

• BankAssist Suite - AI-powered customer service solutions
• PolicyPal Assistant - Intelligent document processing for financial services

Your sandbox access details:
• Login URL: https://sandbox.genai.com/customer/login
• Username: ${attendee.email}
• Temporary Password: GenAI2025!
• Access Duration: 30 days

Getting Started:
1. Click the login link above
2. Use your credentials to sign in
3. Explore the modules tailored to your interests
4. Schedule a follow-up call with our team when ready

Our team is standing by to answer any questions and discuss how these solutions can transform your banking operations.

Best regards,
GenAI Sandbox Team

P.S. Don't forget to try the "Launch My Sandbox" feature to see how these solutions would work in your AWS environment!`
  };

  const handleSendEmail = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    console.log('Sending email to:', attendee.email);
    console.log('Email content:', emailTemplate);
    
    setEmailSent(true);
    setIsLoading(false);
  };

  const handlePreview = () => {
    alert('Email preview would open in a new window/modal');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 hover:text-orange-500 transition-colors duration-200 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Attendee
        </button>
        
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Send Sandbox Access Email</h1>
          <p className="text-gray-600 mt-2">Send login credentials and access instructions to qualified attendee</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Email Compose */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-medium text-gray-900 mb-6">
              <Mail className="h-5 w-5 inline mr-2" />
              Email Details
            </h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">To</label>
                <div className="flex items-center p-3 bg-gray-50 rounded-md border">
                  <User className="h-4 w-4 text-gray-400 mr-2" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">{attendee.name}</p>
                    <p className="text-sm text-gray-500">{attendee.email}</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                <input
                  type="text"
                  value={emailTemplate.subject}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-900"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message Body</label>
                <textarea
                  rows={16}
                  value={emailTemplate.body}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-900 font-mono text-sm"
                />
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={handlePreview}
                  className="flex items-center px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors duration-200"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  Preview
                </button>
                
                {!emailSent ? (
                  <button
                    onClick={handleSendEmail}
                    disabled={isLoading}
                    className="flex items-center px-6 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 disabled:opacity-50 transition-colors duration-200"
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Send Email
                      </>
                    )}
                  </button>
                ) : (
                  <div className="flex items-center px-6 py-2 bg-green-500 text-white rounded-md">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Email Sent Successfully
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Attendee Info */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Attendee Information</h3>
            
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-500">Name</label>
                <p className="text-gray-900">{attendee.name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Company</label>
                <p className="text-gray-900">{attendee.company}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Job Title</label>
                <p className="text-gray-900">{attendee.jobTitle}</p>
              </div>
            </div>
          </div>

          {/* Sandbox Access Details */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Sandbox Access</h3>
            
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-500">Login URL</label>
                <p className="text-sm text-gray-900 break-all">https://sandbox.genai.com/customer/login</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Username</label>
                <p className="text-sm text-gray-900">{attendee.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Temporary Password</label>
                <p className="text-sm text-gray-900">GenAI2025!</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-500">Access Duration</label>
                <p className="text-sm text-gray-900">30 days</p>
              </div>
            </div>
          </div>

          {/* Personalized Modules */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Personalized Modules</h3>
            
            <div className="space-y-2">
              {attendee.interests.map((interest) => (
                <div key={interest} className="flex items-center p-2 bg-orange-50 rounded-md">
                  <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                  <span className="text-sm text-gray-900">{interest}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Email Status */}
          {emailSent && (
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                <Calendar className="h-5 w-5 inline mr-2" />
                Email Status
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-center text-green-600">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  <span className="text-sm">Email sent successfully</span>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Sent at</label>
                  <p className="text-sm text-gray-900">{new Date().toLocaleString()}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Next follow-up</label>
                  <p className="text-sm text-gray-900">3 days from now</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}