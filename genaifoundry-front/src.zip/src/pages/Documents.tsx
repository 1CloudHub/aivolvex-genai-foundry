import { useState, useEffect } from 'react';
import { 
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  Separator,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/index';
import { 
  FileText,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Home as HomeIcon
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

interface DocumentType {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

interface ExtractedField {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'error';
  message?: string;
}

interface ProcessedDocument {
  id: string;
  name: string;
  type: string;
  status: 'processing' | 'completed' | 'failed';
  confidence: number;
  fields: ExtractedField[];
  uploadTime: Date;
}

const documentTypes: DocumentType[] = [
  {
    id: 'aadhaar',
    name: 'Aadhaar Card',
    description: 'Upload both sides of your Aadhaar card',
    icon: <FileText className="h-6 w-6 text-primary" />
  },
  {
    id: 'pan',
    name: 'PAN Card',
    description: 'Clear image of your PAN card',
    icon: <FileText className="h-6 w-6 text-primary" />
  },
  {
    id: 'bank_statement',
    name: 'Bank Statement',
    description: 'Last 3 months statement (PDF format)',
    icon: <FileText className="h-6 w-6 text-primary" />
  },
  {
    id: 'salary_slip',
    name: 'Salary Slip',
    description: 'Upload your latest salary slip',
    icon: <FileText className="h-6 w-6 text-primary" />
  }
];

// Mock processed document data
const mockDocuments: Record<string, ProcessedDocument> = {
  aadhaar: {
    id: 'aadhaar-001',
    name: 'Aadhaar_Card.jpg',
    type: 'Aadhaar Card',
    status: 'completed',
    confidence: 92,
    fields: [
      { name: 'Full Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Date of Birth', value: '15/04/1985', status: 'success' },
      { name: 'Gender', value: 'Male', status: 'success' },
      { name: 'Address', value: '123 Main St, Bangalore, Karnataka - 560001', status: 'success' },
      { name: 'Aadhaar Number', value: 'XXXX XXXX 4567', status: 'success' }
    ],
    uploadTime: new Date()
  },
  pan: {
    id: 'pan-001',
    name: 'PAN_Card.jpg',
    type: 'PAN Card',
    status: 'completed',
    confidence: 88,
    fields: [
      { name: 'Full Name', value: 'RAJ KUMAR SINGH', status: 'success' },
      { name: 'PAN Number', value: 'ABCPS1234D', status: 'success' },
      { name: 'Date of Birth', value: '10/06/2010', status: 'success' },
      { name: "Father's Name", value: 'AMARNATH SINGH', status: 'success' }
    ],
    uploadTime: new Date()
  },
  bank_statement: {
    id: 'statement-001',
    name: 'Bank_Statement_Jan_Mar_2025.pdf',
    type: 'Bank Statement',
    status: 'completed',
    confidence: 95,
    fields: [
      { name: 'Account Holder Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Bank Name & Branch', value: 'State Bank of India, Bangalore Main Branch', status: 'success' },
      { name: 'Statement Period', value: 'Jan 2025 - Mar 2025', status: 'success' },
      { name: 'Monthly Salary Credits', value: '₹85,000', status: 'success' },
      { name: 'EMI/Loan Debits', value: '₹28,500', status: 'success' },
      { name: 'Utility/Recurring Payments', value: '₹5,000', status: 'success' },
      { name: 'Minimum Balance Trends', value: '₹25,000 - ₹72,456', status: 'success' },
      { name: 'NSF/Bounce Charges', value: '₹0', status: 'success' },
      { name: 'Cash Deposits/Transfers', value: '₹50,000', status: 'success' },
      { name: 'End-of-Month Balances', value: '₹72,456', status: 'success' }
    ],
    uploadTime: new Date()
  },
  salary_slip: {
    id: 'salary-slip-001',
    name: 'Salary_Slip_Mar_2025.pdf',
    type: 'Salary Slip',
    status: 'completed',
    confidence: 93,
    fields: [
      { name: 'Employee Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Designation', value: 'Senior Software Engineer', status: 'success' },
      { name: 'Gross Monthly Income', value: '₹90,000', status: 'success' },
      { name: 'Deductions', value: '₹8,000', status: 'success' },
      { name: 'Net Take-Home Pay', value: '₹82,000', status: 'success' },
      { name: 'Pay Period', value: 'Mar 2025', status: 'success' }
    ],
    uploadTime: new Date()
  }
};

const Documents = () => {
  const [uploadedDocuments, setUploadedDocuments] = useState<Record<string, ProcessedDocument>>({});
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<'three' | 'all' | null>(null);
  const [loaderProgress, setLoaderProgress] = useState(0);
  const navigate = useNavigate();

  // Helper: all uploaded?
  const allUploaded = documentTypes.every(doc => uploadedDocuments[doc.id]);
  // Helper: checklist status
  const checklist = documentTypes.map(doc => ({
    ...doc,
    uploaded: !!uploadedDocuments[doc.id],
  }));

  const getStatusIcon = (status: ExtractedField['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  // New: Submit 3 Documents
  const handleSubmitThree = () => {
    setIsSubmitting('three');
    setTimeout(() => {
      const newDocs: Record<string, ProcessedDocument> = {};
      for (let i = 0; i < 3; i++) {
        const doc = documentTypes[i];
        newDocs[doc.id] = {
          ...mockDocuments[doc.id],
          uploadTime: new Date(),
        };
      }
      setUploadedDocuments(newDocs);
      setActiveTab(documentTypes[0].id);
      setIsSubmitting(null);
    }, 2000 + Math.random() * 1000);
  };

  // New: Submit All Documents
  const handleSubmitAll = () => {
    setIsSubmitting('all');
    setTimeout(() => {
      const newDocs: Record<string, ProcessedDocument> = {};
      for (let i = 0; i < documentTypes.length; i++) {
        const doc = documentTypes[i];
        newDocs[doc.id] = {
          ...mockDocuments[doc.id],
          uploadTime: new Date(),
        };
      }
      setUploadedDocuments(newDocs);
      setActiveTab(documentTypes[0].id);
      setIsSubmitting(null);
    }, 2000 + Math.random() * 1000);
  };

  // Animate loader progress in steps when uploading
  useEffect(() => {
    if (isSubmitting !== null) {
      setLoaderProgress(0);
      const steps = [25, 50, 75, 100];
      let idx = 0;
      const interval = setInterval(() => {
        setLoaderProgress(steps[idx]);
        idx++;
        if (idx === steps.length) clearInterval(interval);
      }, 500);
      return () => clearInterval(interval);
    } else {
      setLoaderProgress(0);
    }
  }, [isSubmitting]);

  return (
    <div className="container py-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-6">
        <button type="button" onClick={() => navigate('/')} className="flex items-center font-semibold " style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>
          <HomeIcon className="h-5 w-5  mr-1" />
          <span className="text-gray-600">Home</span>
        </button>
        <span className="text-gray-400">/</span>
        <span style={{ fontWeight: 600, color:'#e87722' }}>DocIQ</span>
      </div>
      {/* Page Title and Subtitle */}
      <div className="flex items-center gap-6 mb-8">
        <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
          <FileText className="h-8 w-8 text-primary" />
        </div>
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
            DocIQ
          </h1>
          <p className="text-lg text-gray-600">
            Upload and analyze financial documents with AI-powered extraction of key information.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <section>
          <h3 className="text-lg font-medium mb-4">Required Documents</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {checklist.map((doc) => {
              // Determine if this is the Salary Slip card and should be highlighted as not uploaded
              const isSalarySlip = doc.id === 'salary_slip';
              const isPartialMissingSalary =
                isSalarySlip &&
                Object.keys(uploadedDocuments).length > 0 &&
                !uploadedDocuments['salary_slip'];
              return (
                <Card
                  key={doc.id}
                  className={cn(
                    'flex flex-col items-center justify-center p-4 gap-2 border-2 relative',
                    doc.uploaded
                      ? 'border-green-400 bg-green-50'
                      : isPartialMissingSalary
                      ? 'border-red-400 bg-red-50'
                      : 'border-gray-200 bg-gray-50'
                  )}
                >
                  <div className="flex items-center gap-2">
                    {doc.uploaded ? (
                      <FileText className="h-6 w-6 text-primary" />
                    ) : isPartialMissingSalary ? (
                      <FileText className="h-6 w-6 text-red-400" />
                    ) : (
                      <FileText className="h-6 w-6 text-gray-300" />
                    )}
                    <span className="font-semibold text-base">{doc.name}</span>
                  </div>
                  <div className="text-xs text-gray-500 mb-2">{doc.description}</div>
                  <div className="flex items-center gap-2 mt-2">
                    {doc.uploaded ? (
                      <>
                        <CheckCircle className="text-green-500 w-5 h-5" />
                        <span className="text-green-700 font-medium">Uploaded</span>
                      </>
                    ) : isPartialMissingSalary ? (
                      <>
                        <XCircle className="text-red-400 w-5 h-5" />
                        <span className="text-red-500 font-medium">Upload Required</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="text-gray-300 w-5 h-5" />
                        <span className="text-gray-400">Pending</span>
                      </>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
          {/* Loader: show only while uploading */}
          {isSubmitting !== null && (
            <div className="w-full flex justify-center mb-6">
              <div className="bg-[#f8fafc] rounded-xl shadow border border-gray-100 px-6 py-4 flex flex-col w-full">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold text-gray-700">Uploading document...</span>
                  <span className="font-semibold text-gray-700">{loaderProgress}%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-[#fbeee6] overflow-hidden">
                  <div className="h-3 rounded-full bg-[#e87722] transition-all duration-500" style={{ width: `${loaderProgress}%` }}></div>
                </div>
              </div>
            </div>
          )}
          {/* Buttons: hide while uploading */}
          {isSubmitting === null && (
            <div className="flex flex-col items-center gap-4 mb-6">
              <div className="flex gap-4">
                <Button
                  className="bg-[#e87722] text-white px-6 py-2 rounded-pill fw-bold flex items-center gap-2"
                  onClick={handleSubmitThree}
                  disabled={isSubmitting !== null}
                >
                  {isSubmitting === 'three' ? 'Uploading...' : 'Partial Upload'}
                </Button>
                <Button
                  className="bg-[#e87722] text-white px-6 py-2 rounded-pill fw-bold flex items-center gap-2"
                  onClick={handleSubmitAll}
                  disabled={isSubmitting !== null}
                >
                  {isSubmitting === 'all' ? 'Uploading...' : 'Full Upload'}
                </Button>
                <Button
                  className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-pill fw-bold flex items-center gap-2"
                  onClick={() => setUploadedDocuments({})}
                  disabled={Object.keys(uploadedDocuments).length === 0}
                  type="button"
                >
                  Remove All
                </Button>
              </div>
            </div>
          )}
        </section>

        {/* Uploaded Documents Tabs and Document Validation Summary */}
        {Object.keys(uploadedDocuments).length > 0 && (
          <>
            <section className="mt-8">
              <h3 className="text-lg font-medium mb-4">Uploaded Documents</h3>
              <Tabs value={activeTab || Object.keys(uploadedDocuments)[0]} onValueChange={setActiveTab}>
                <TabsList className="mb-4 ">
                  {Object.entries(uploadedDocuments).map(([key, doc], idx, arr) => (
                    <>
                      <TabsTrigger key={key} value={key}>{doc.type}</TabsTrigger>
                      {idx < arr.length - 1 && (
                        <span key={key + '-divider'} className="mx-1 h-5 w-px bg-gray-300 rounded" />
                      )}
                    </>
                  ))}
                </TabsList>
                {Object.entries(uploadedDocuments).map(([key, doc]) => (
                  <TabsContent key={key} value={key}>
                    <Card>
                      <CardHeader>
                        <div className="flex justify-between items-center">
                          <div>
                            <CardTitle className="text-lg">{doc.type}</CardTitle>
                            <CardDescription>Uploaded: {doc.uploadTime.toLocaleTimeString()}</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between text-sm">
                            <span className="font-medium">Document Name</span>
                            <span>{doc.name}</span>
                          </div>
                          <Separator />
                          <div>
                            <h4 className="text-sm font-medium mb-3">Extracted Information</h4>
                            <div className="space-y-3">
                              {doc.fields.map((field, index) => (
                                <div key={index} className="flex items-start justify-between">
                                  <div className="flex items-center gap-2">
                                    {getStatusIcon(field.status)}
                                    <span className="text-sm">{field.name}</span>
                                  </div>
                                  <div className="text-right">
                                    <span className="text-sm font-medium">{field.value}</span>
                                    {field.message && (
                                      <p className={cn(
                                        "text-xs mt-0.5",
                                        field.status === 'warning' ? "text-amber-600" :
                                        field.status === 'error' ? "text-red-600" : ""
                                      )}>
                                        {field.message}
                                      </p>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                ))}
              </Tabs>
            </section>
            {/* Document Validation Summary */}
            <div className="flex justify-center mt-8">
              <div className="w-full rounded-3xl border border-gray-200 bg-white shadow p-8 flex flex-col items-center">
                <h2 className="text-2xl font-bold mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>Document Validation Summary</h2>
                <p className="text-gray-500 mb-6">Overall assessment of your uploaded documents</p>
                <div className="mb-4 text-center text-gray-600">
                  Please upload all required documents for complete validation
                </div>
                <div className="flex items-center justify-center gap-2 mb-6">
                  {documentTypes.map((doc) => (
                    <span key={doc.id} className={uploadedDocuments[doc.id] ? 'bg-green-500' : 'bg-gray-300'} style={{ display: 'inline-block', width: 16, height: 16, borderRadius: 8 }}></span>
                  ))}
                </div>
                <Button
                  className={cn('w-full py-3 rounded-lg text-lg font-semibold', allUploaded ? ' text-white' : 'bg-gray-300 text-gray-400 cursor-not-allowed')}
                  disabled={!allUploaded}
                  onClick={() => allUploaded && navigate('/risk')}
                >
                  Proceed to RiskLens
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Documents;