import React, { useMemo, useState } from 'react';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';
import { useNavigate } from 'react-router-dom';
import { Home as HomeIcon, FileText, ClipboardCheck, Info, Download, Share2, X, CheckCircle, AlertCircle } from 'lucide-react';

type CodeType = 'ICD-10' | 'CPT' | 'HCPCS';

interface EncounterHeaderMeta {
  encounterId: string;
  patient: { display: string; id: string; age: number; sex: 'M'|'F'|'Other' };
  clinician: { name: string; specialty: string };
  datetime: string;
  visitType: 'Outpatient'|'Telehealth'|'Inpatient'|'ED';
  location?: string;
}

interface TranscriptTurn { id: string; t: string; speaker: 'DOCTOR'|'PATIENT'; text: string; }

interface SoapNote { subjective: string; objective: string; assessment: string; plan: string; }

interface SuggestionRow { code: string; description: string; confidence: number; rationale: string; excerpts: string[] }

interface CodingSuggestion { icd10: SuggestionRow[]; cpt: SuggestionRow[]; hcpcs: SuggestionRow[] }

interface SelectedCode { type: CodeType; code: string; description: string; modifier?: string }

const mockEncounter: EncounterHeaderMeta = {
  encounterId: 'E-10021',
  patient: { display: 'Rob M.', id: 'P-10293', age: 48, sex: 'M' },
  clinician: { name: 'Dr. Anya Sharma', specialty: 'General Practice' },
  datetime: '2025-07-08T10:00:00Z',
  visitType: 'Outpatient',
  location: 'General Practice Clinic'
};

const mockTranscript: TranscriptTurn[] = [
  { id: 't1', t: '00:00', speaker: 'DOCTOR', text: 'Good morning, what brings you in today?' },
  { id: 't2', t: '00:05', speaker: 'PATIENT', text: 'I have chest discomfort radiating to my left arm with shortness of breath.' },
  { id: 't3', t: '00:20', speaker: 'DOCTOR', text: 'We will get an ECG and troponin levels.' },
  { id: 't4', t: '00:35', speaker: 'DOCTOR', text: 'How long have you been experiencing these symptoms?' },
  { id: 't5', t: '00:42', speaker: 'PATIENT', text: 'It started about 2 hours ago while I was at work. The pain comes and goes but it\'s getting worse.' },
  { id: 't6', t: '00:55', speaker: 'DOCTOR', text: 'Any associated symptoms like nausea, sweating, or dizziness?' },
  { id: 't7', t: '01:08', speaker: 'PATIENT', text: 'Yes, I felt a bit dizzy earlier and I\'m sweating more than usual.' },
  { id: 't8', t: '01:20', speaker: 'DOCTOR', text: 'Any history of heart disease or similar episodes?' },
  { id: 't9', t: '01:32', speaker: 'PATIENT', text: 'My father had a heart attack at 50, but I\'ve never had anything like this before.' },
  { id: 't10', t: '01:45', speaker: 'DOCTOR', text: 'Let me check your vital signs and then we\'ll proceed with the ECG and blood work.' },
  { id: 't11', t: '02:00', speaker: 'DOCTOR', text: 'Blood pressure is 145/95, heart rate 88, oxygen saturation 96%. I\'m ordering a chest X-ray as well.' },
  { id: 't12', t: '02:15', speaker: 'PATIENT', text: 'Should I be worried? This is really concerning me.' },
  { id: 't13', t: '02:25', speaker: 'DOCTOR', text: 'We\'re taking this seriously and ruling out any cardiac issues. The tests will give us a clear picture.' },
  { id: 't14', t: '02:40', speaker: 'DOCTOR', text: 'I\'ll also check your cholesterol levels and recommend lifestyle modifications if needed.' },
  { id: 't15', t: '02:55', speaker: 'PATIENT', text: 'Thank you, doctor. I appreciate you taking the time to explain everything.' }
];

const mockSoap: SoapNote = {
  subjective: '48-year-old male presents with acute onset chest pain radiating to left arm, associated with dyspnea, diaphoresis, and dizziness. Symptoms began 2 hours ago and have been progressively worsening. Patient reports no prior similar episodes but has family history of premature coronary artery disease (father had MI at age 50). No known cardiac history, diabetes, or hypertension. Current medications: none. Allergies: none known.',
  objective: 'Vital signs: BP 145/95, HR 88, RR 18, Temp 98.6°F, O2 Sat 96% on room air. General: Alert, oriented, appears anxious but in no acute distress. Cardiovascular: Regular rate and rhythm, no murmurs, gallops, or rubs. Lungs: Clear to auscultation bilaterally. Abdomen: Soft, non-tender, non-distended. Extremities: No edema, pulses 2+ throughout. Skin: Warm, diaphoretic. ECG ordered, troponin levels ordered, chest X-ray ordered, lipid panel ordered.',
  assessment: 'Primary: Acute chest pain, rule out acute coronary syndrome (ACS). Secondary: Hypertension (newly diagnosed), hyperlipidemia (likely given family history). Differential diagnosis includes: 1) Acute coronary syndrome, 2) Stable angina, 3) Gastroesophageal reflux disease, 4) Costochondritis, 5) Anxiety/panic attack. Risk factors: Male gender, age >45, family history of premature CAD, likely hyperlipidemia.',
  plan: '1) Immediate: ECG, troponin levels, chest X-ray, lipid panel. 2) If ACS confirmed: Immediate cardiology consultation, aspirin 325mg, statin therapy, beta-blocker if no contraindications. 3) If ACS ruled out: Stress test, echocardiogram, lifestyle modifications (diet, exercise, smoking cessation if applicable). 4) Follow-up: Return in 1 week for results review, establish primary care relationship for ongoing management of cardiovascular risk factors. 5) Education: Heart-healthy diet, regular exercise, smoking cessation counseling, recognition of cardiac symptoms.'
};

const mockSuggestions: CodingSuggestion = {
  icd10: [
    { code: 'R07.9', description: 'Chest pain, unspecified', confidence: 0.89, rationale: 'Primary symptom across transcript.', excerpts: ['"chest discomfort"', '"radiating to my left arm"'] },
  ],
  cpt: [
    { code: '93000', description: 'Electrocardiogram, routine ECG with at least 12 leads; with interpretation and report', confidence: 0.82, rationale: 'ECG explicitly ordered.', excerpts: ['"get an ECG"'] },
    { code: '84484', description: 'Troponin, quantitative', confidence: 0.78, rationale: 'Troponin test ordered.', excerpts: ['"troponin levels"'] },
  ],
  hcpcs: [
    { code: 'G0442', description: 'Alcohol misuse screening', confidence: 0.35, rationale: 'Consider if screening performed', excerpts: [] },
  ],
};

const themeCard = 'rounded-2xl border bg-white p-4 shadow-sm';

const MedicalCodingAssistant: React.FC = () => {
  const navigate = useNavigate();
  const [activeSourceTab, setActiveSourceTab] = useState<'transcript'|'soap'>('transcript');
  const [activeCodesTab, setActiveCodesTab] = useState<CodeType>('ICD-10');
  const [selectedCodes, setSelectedCodes] = useState<SelectedCode[]>([]);
  const [audit, setAudit] = useState<string[]>([]);
  const [activeExportTab, setActiveExportTab] = useState<'json'|'csv'|'claim'|'summary'>('json');

  const suggestionsForTab = useMemo(() => {
    if (activeCodesTab === 'ICD-10') return mockSuggestions.icd10;
    if (activeCodesTab === 'CPT') return mockSuggestions.cpt;
    return mockSuggestions.hcpcs;
  }, [activeCodesTab]);

  const addCode = (type: CodeType, row: SuggestionRow) => {
    setSelectedCodes(prev => {
      // Check if code already exists
      const existingIndex = prev.findIndex(selected => selected.type === type && selected.code === row.code);
      if (existingIndex !== -1) {
        // Unselect the code if it already exists (toggle off)
        const newCodes = prev.filter((_, i) => i !== existingIndex);
        setAudit(auditPrev => [...auditPrev, `${new Date().toISOString()} • remove • ${type} ${row.code}`]);
        return newCodes;
      } else {
        // Select the code if it doesn't exist (toggle on)
        setAudit(auditPrev => [...auditPrev, `${new Date().toISOString()} • add • ${type} ${row.code}`]);
        return [...prev, { type, code: row.code, description: row.description }];
      }
    });
  };

  const removeCode = (idx: number) => {
    setSelectedCodes(prev => prev.filter((_, i) => i !== idx));
    setAudit(prev => [...prev, `${new Date().toISOString()} • remove • index ${idx}`]);
  };

  const exportCodes = (format: 'json'|'csv') => {
    const payload = selectedCodes;
    if (format === 'json') {
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a');
      a.href = url; a.download = 'codes.json'; a.click(); URL.revokeObjectURL(url);
    } else {
      const header = 'type,code,description,modifier';
      const rows = payload.map(r => `${r.type},${r.code},"${r.description}",${r.modifier ?? ''}`).join('\n');
      const blob = new Blob([`${header}\n${rows}`], { type: 'text/csv' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a');
      a.href = url; a.download = 'codes.csv'; a.click(); URL.revokeObjectURL(url);
    }
    setAudit(prev => [...prev, `${new Date().toISOString()} • export • ${format}`]);
  };

  const generateClaim = () => {
    const claim = { encounter: mockEncounter, selectedCodes };
    const blob = new Blob([JSON.stringify(claim, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = 'claim-837p-demo.json'; a.click(); URL.revokeObjectURL(url);
    setAudit(prev => [...prev, `${new Date().toISOString()} • generate-claim`]);
  };

  const copySummary = async () => {
    const text = selectedCodes.map(c => `${c.type} ${c.code} — ${c.description}`).join('\n');
    await navigator.clipboard.writeText(text);
    setAudit(prev => [...prev, `${new Date().toISOString()} • copy-summary`]);
  };

  const complianceWarnings = useMemo(() => {
    const warnings: string[] = [];
    const hasECG = selectedCodes.some(c => c.code === '93000');
    const hasVisit = selectedCodes.some(c => /^99/.test(c.code));
    if (hasVisit && !selectedCodes.some(c => c.type === 'ICD-10')) warnings.push('Visit code requires at least one ICD-10 diagnosis.');
    if (hasECG && hasVisit && !selectedCodes.some(c => c.modifier === '25')) warnings.push('Modifier 25 may be required with ECG + E/M visit.');
    return warnings;
  }, [selectedCodes]);

  return (
    <>
      <LoginNavbar />
      <div className="flex-grow container mx-auto px-4 py-4 max-w-7xl">
        {/* Breadcrumb (matches ClinicalNoteGeneration) */}
        <nav className="flex text-sm text-gray-500 mb-6" aria-label="Breadcrumb" style={{marginTop: '2rem'}}>
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button 
                type="button" 
                onClick={() => navigate('/customer/sandbox/healthcarehome')} 
                className="flex items-center text-gray-500 hover:text-gray-700"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <HomeIcon size={16} className="mr-1" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
                <span className="text-orange-600 font-medium">MedCode AI</span>
            </li>
          </ol>
        </nav>

        {/* Header (theme-aligned) */}
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="ub-feature-icon mr-3">
              <ClipboardCheck size={30} />
            </div>
            <div>
              <h2 className="mb-0 text-3xl font-bold" data-testid="coding-header">MedCode AI</h2>
              <p className="text-gray-500">Generate, validate, and export ICD‑10, CPT, and HCPCS codes from transcripts or SOAP notes</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Source Document Panel - Left Side */}
          <div className="col-span-12 lg:col-span-8">
            <div className={`${themeCard}  top-4`} data-testid="source-panel" style={{height: '800px',overflow:'hidden'}}>
              <div className="flex border-b sticky top-0 bg-white z-10">
                <button className={`px-3 py-2 text-sm ${activeSourceTab==='transcript'?'text-orange-600 border-b-2 border-orange-500':'text-gray-500'}`} onClick={()=>setActiveSourceTab('transcript')}>Transcript</button>
                <button className={`px-3 py-2 text-sm ${activeSourceTab==='soap'?'text-orange-600 border-b-2 border-orange-500':'text-gray-500'}`} onClick={()=>setActiveSourceTab('soap')}>SOAP</button>
              </div>
              <div style={{height: 'calc(100% - 48px)', overflow:'auto'}}>
                {activeSourceTab==='transcript'? (
                  <div className="p-3 space-y-3">
                    {mockTranscript.map(turn => (
                      <div key={turn.id} className="flex gap-3 text-sm">
                        <div className={`px-2 py-1 rounded-md ${turn.speaker==='DOCTOR'?'bg-blue-50 text-blue-700':'bg-rose-50 text-rose-700'}`}>{turn.speaker==='DOCTOR'?'Doctor':'Patient'}</div>
                        <div className="text-gray-500">{turn.t}</div>
                        <div className="text-gray-900">{turn.text}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 grid grid-cols-1 gap-3 text-sm">
                    <div className="bg-gray-50 rounded-lg p-3"><div className="text-gray-500 mb-1">Subjective</div><div>{mockSoap.subjective}</div></div>
                    <div className="bg-gray-50 rounded-lg p-3"><div className="text-gray-500 mb-1">Objective</div><div>{mockSoap.objective}</div></div>
                    <div className="bg-gray-50 rounded-lg p-3"><div className="text-gray-500 mb-1">Assessment</div><div>{mockSoap.assessment}</div></div>
                    <div className="bg-gray-50 rounded-lg p-3"><div className="text-gray-500 mb-1">Plan</div><div>{mockSoap.plan}</div></div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Side Panel - Coding Suggestions */}
          <div className="col-span-12 lg:col-span-4">
            <div className={`${themeCard} mb-6`} data-testid="coding-suggestions" style={{height: '370px', position: 'relative'}}>
              <div className="flex border-b bg-white z-10" style={{position: 'sticky', top: 0}}>
                {(['ICD-10','CPT','HCPCS'] as CodeType[]).map(tab => (
                  <button key={tab} className={`px-3 py-2 text-sm ${activeCodesTab===tab?'text-orange-600 border-b-2 border-orange-500':'text-gray-500'}`} onClick={()=>setActiveCodesTab(tab)}>{tab}</button>
                ))}
              </div>
              <div className="mt-3" style={{height: 'calc(100% - 48px)', overflow:'auto'}}>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-gray-500 border-b">
                      <th className="py-2 px-2 w-20">Code</th>
                      <th className="py-2 px-2 flex-1">Description</th>
                      <th className="py-2 px-2 w-20 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {suggestionsForTab.map((row, i) => (
                      <tr key={i} className="border-t hover:bg-gray-50">
                        <td className="py-3 px-2 font-medium text-gray-900">{row.code}</td>
                        <td className="py-3 px-2">
                          <div className="font-medium text-gray-800 mb-1">{row.description}</div>
                          <div className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                            <Info size={14} className="text-gray-400"/>
                            {row.rationale}
                          </div>
                          {row.excerpts.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {row.excerpts.map((e, ix) => (
                                <span key={ix} className="inline-block bg-gray-100 px-2 py-1 rounded-full text-xs text-gray-600">
                                  {e}
                                </span>
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-2 text-center">
                          {(() => {
                            const isSelected = selectedCodes.some(selected => selected.type === activeCodesTab && selected.code === row.code);
                            return (
                              <button 
                                className={`px-3 py-1.5 rounded text-white text-xs font-medium transition-colors ${
                                  isSelected 
                                    ? 'bg-red-500 hover:bg-red-600' 
                                    : 'bg-orange-500 hover:bg-orange-600'
                                }`}
                                onClick={() => addCode(activeCodesTab, row)}
                              >
                                {isSelected ? 'Unselect' : 'Select'}
                              </button>
                            );
                          })()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Selected Codes */}
            <div className={`${themeCard}  top-4`} data-testid="selected-codes" style={{height: '400px'}}>
              <div className="flex items-center justify-between mb-3">
                <div className="font-semibold">Selected Codes</div>
                <div className="text-xs text-gray-500 bg-orange-100 px-2 py-1 rounded-full">{selectedCodes.length} selected</div>
              </div>
              <div className="space-y-2 overflow-y-auto" style={{height: 'calc(100% - 48px)'}}>
                {selectedCodes.map((row, idx) => (
                  <div key={idx} className="border rounded-lg p-2 bg-gray-50">
                    <div className="flex items-center gap-2 text-sm mb-2">
                      <span className="px-2 py-0.5 rounded bg-orange-100 text-orange-700 text-xs font-medium">{row.type}</span>
                      <span className="font-medium">{row.code}</span>
                      <button className="text-rose-600 hover:text-rose-700 ml-auto" onClick={()=>removeCode(idx)} aria-label="Unselect"><X size={16}/></button>
                    </div>
                    <div className="text-gray-700 text-xs mb-2">{row.description}</div>
                    <select className="w-full border rounded px-2 py-1 text-xs" value={row.modifier ?? ''} onChange={(e)=>{
                      const v = e.target.value || undefined;
                      setSelectedCodes(prev => prev.map((c,i)=> i===idx? { ...c, modifier: v } : c));
                      setAudit(prev => [...prev, `${new Date().toISOString()} • set-modifier • ${row.code}=${v ?? ''}`]);
                    }}>
                      <option value="">No modifier</option>
                      <option value="25">25</option>
                      <option value="59">59</option>
                      <option value="LT">LT</option>
                      <option value="RT">RT</option>
                    </select>
                  </div>
                ))}
                {selectedCodes.length === 0 && (
                  <div className="flex flex-col items-center justify-center text-gray-500 text-sm" style={{height: 'calc(100% - 48px)'}}>
                    <ClipboardCheck size={48} className="mb-4 text-gray-300" />
                    <div>No codes selected yet</div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Row - Audit and Actions */}
        <div className="grid grid-cols-12 gap-6 mt-6">
          {/* Audit Trail */}
          <div className="col-span-12 lg:col-span-6">
            <div className={`${themeCard}`} data-testid="audit-panel" style={{height: '340px',overflow:'auto'}}>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <div className="font-semibold">Audit Trail</div>
              </div>
              <div className="max-h-48 overflow-y-auto">
                <ul className="text-sm space-y-1 text-gray-700">
                  {audit.map((e,i)=> <li key={i} className="py-1 border-b border-gray-100 last:border-b-0">{e}</li>)}
            </ul>
                {audit.length === 0 && (
                  <div className="text-center text-gray-500 text-sm py-8">
                    <Info size={24} className="mx-auto mb-2 text-gray-300" />
                    No audit events yet
                  </div>
          )}
        </div>
            </div>
        </div>

        {/* Actions */}
          <div className="col-span-12 lg:col-span-6">
            <div className={`${themeCard}`} data-testid="actions-bar" style={{height: '21.5rem',overflow:'auto'}}>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="font-semibold">Preview</div>
              </div>
              {/* Export Information Display */}
              <div>
                <div className="flex border-b">
                  <button className={`px-3 py-2 text-sm ${activeExportTab==='json'?'text-orange-600 border-b-2 border-orange-500':'text-gray-500'}`} onClick={()=>setActiveExportTab('json')}>JSON</button>
                  <button className={`px-3 py-2 text-sm ${activeExportTab==='csv'?'text-orange-600 border-b-2 border-orange-500':'text-gray-500'}`} onClick={()=>setActiveExportTab('csv')}>CSV</button>
                  <button className={`px-3 py-2 text-sm ${activeExportTab==='claim'?'text-orange-600 border-b-2 border-orange-500':'text-gray-500'}`} onClick={()=>setActiveExportTab('claim')}>Claim Data</button>
                  <button className={`px-3 py-2 text-sm ${activeExportTab==='summary'?'text-orange-600 border-b-2 border-orange-500':'text-gray-500'}`} onClick={()=>setActiveExportTab('summary')}>Summary</button>
                </div>
                
                <div className="mt-3 p-3 bg-gray-50 rounded-lg min-h-[200px]">
                  {activeExportTab === 'json' && (
                    <div>
                      <div className="text-sm font-medium mb-2">JSON  Preview:</div>
                      <pre className="text-xs bg-white p-3 rounded border overflow-auto max-h-48">{JSON.stringify(selectedCodes, null, 2)}</pre>
                    </div>
                  )}
                  
                  {activeExportTab === 'csv' && (
                    <div>
                      <div className="text-sm font-medium mb-2">CSV Preview:</div>
                      <div className="bg-white rounded border overflow-auto max-h-48">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="bg-gray-50 border-b">
                              <th className="text-left py-2 px-3 font-medium text-gray-700">Type</th>
                              <th className="text-left py-2 px-3 font-medium text-gray-700">Code</th>
                              <th className="text-left py-2 px-3 font-medium text-gray-700">Description</th>
                              <th className="text-left py-2 px-3 font-medium text-gray-700">Modifier</th>
                            </tr>
                          </thead>
                          <tbody>
                            {selectedCodes.map((code, idx) => (
                              <tr key={idx} className="border-b hover:bg-gray-50">
                                <td className="py-2 px-3 text-gray-800">{code.type}</td>
                                <td className="py-2 px-3 text-gray-800 font-medium">{code.code}</td>
                                <td className="py-2 px-3 text-gray-800">{code.description}</td>
                                <td className="py-2 px-3 text-gray-800">{code.modifier || '-'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {selectedCodes.length === 0 && (
                          <div className="text-center text-gray-500 py-8">
                            No codes selected
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {activeExportTab === 'claim' && (
                    <div>
                      <div className="text-sm font-medium mb-2">Claim Data Preview:</div>
                      <div className="bg-white p-3 rounded border overflow-auto max-h-48">
                        <div className="text-xs">
                          <div className="grid grid-cols-2 gap-2">
                            <div><strong>Encounter ID:</strong> {mockEncounter.encounterId}</div>
                            <div><strong>Patient:</strong> {mockEncounter.patient.display}</div>
                            <div><strong>Date:</strong> {new Date(mockEncounter.datetime).toLocaleDateString()}</div>
                            <div><strong>Codes:</strong> {selectedCodes.length}</div>
                          </div>
                          <div className="mt-2">
                            <strong>Selected Codes:</strong>
                            <ul className="mt-1 space-y-1">
                              {selectedCodes.map((code, idx) => (
                                <li key={idx} className="text-gray-700">• {code.type} {code.code} - {code.description}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {activeExportTab === 'summary' && (
                    <div>
                      <div className="text-sm font-medium mb-2">Summary Preview:</div>
                      <div className="bg-white p-3 rounded border overflow-auto max-h-48">
                        <div className="text-xs space-y-2">
                          {selectedCodes.map((code, idx) => (
                            <div key={idx} className="text-gray-800 border-b pb-2 last:border-b-0">
                              <strong>{code.type} {code.code}</strong> — {code.description}
                              {code.modifier && <span className="text-gray-600 ml-2">(Modifier: {code.modifier})</span>}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <HealthcareFooter />
    </>
  );
};

export default MedicalCodingAssistant;

