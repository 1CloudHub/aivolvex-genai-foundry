import React, { useState, useRef, useEffect } from 'react';
import { Row, Col, Card, Form, Button, Modal, Spinner } from 'react-bootstrap';
import { Send, User, Bot, Share, MessageSquare, ThumbsUp, ThumbsDown, PieChart, BarChart4, Heart, FileText, ReceiptCent, Info, Key } from 'lucide-react';
import { PromptChip, AnalyticsData, promptChips, sampleConversation, whatsAppPreview } from '../../components/HealthCare/HealthCareConversations';
import Markdown from 'react-markdown'
import './custom.scss';
import { useNavigate } from 'react-router-dom';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  contextSource?: string
}

interface Conversation {
  id: string;
  messages: Message[];
}

// Helper function to process markdown text
const processMarkdownText = (text: string): string => {
  return text
    .replace(/\\n\\n/g, '\n\n')
    .replace(/\\n/g, '\n')
    .replace(/•\s/g, '- ') // Convert bullet points to markdown list format
    .replace(/\*\s/g, '- ') // Convert * to markdown list format
    .replace(/-\s/g, '- '); // Ensure - is used for lists
};

const TypingStreamLoader: React.FC = () => (
  <span className="typing-stream" style={{ 
    display: 'inline-flex',
    alignItems: 'center',
    gap: '4px',
    color: '#1C6E8C',
    fontStyle: 'italic'
  }}>
    <span>Typing</span>
    <span style={{ display: 'inline-flex', gap: '2px' }}>
      <span style={{ 
        width: '4px', 
        height: '4px', 
        borderRadius: '50%', 
        backgroundColor: '#1C6E8C',
        animation: 'wave 1.5s infinite',
        animationDelay: '0s'
      }}></span>
      <span style={{ 
        width: '4px', 
        height: '4px', 
        borderRadius: '50%', 
        backgroundColor: '#1C6E8C',
        animation: 'wave 1.5s infinite',
        animationDelay: '0.3s'
      }}></span>
      <span style={{ 
        width: '4px', 
        height: '4px', 
        borderRadius: '50%', 
        backgroundColor: '#1C6E8C',
        animation: 'wave 1.5s infinite',
        animationDelay: '0.6s'
      }}></span>
    </span>
    <style>{`
      @keyframes wave {
        0%, 60%, 100% { 
          transform: translateY(0px);
          opacity: 0.4;
        }
        30% { 
          transform: translateY(-8px);
          opacity: 1;
        }
      }
    `}</style>
  </span>
);




const BotTypingLoader: React.FC = () => (
  <span className="streaming-cursor" style={{
    display: 'inline-block',
    width: '2px',
    height: '1.2em',
    backgroundColor: '#1C6E8C',
    marginLeft: '2px',
    animation: 'cursor-blink 1s infinite'
  }}>
    <style>{`
      @keyframes cursor-blink {
        0%, 50% { opacity: 1; }
        51%, 100% { opacity: 0; }
      }
    `}</style>
  </span>
);



const RetailAssistantTool: React.FC = () => {
  const emptyConversation: Conversation = { id: 'active-conversation', messages: [] };
  const [conversation, setConversation] = useState<Conversation>(emptyConversation);
  const [inputText, setInputText] = useState('');
  const [connectionId, setConnectionId] = useState<string | null>(null);
  const [streamingMessage, setStreamingMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [activeTab, setActiveTab] = useState<'features' | 'credentials'>('features');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatTranscriptRef = useRef<HTMLDivElement>(null);

  const [chatEnded, setChatEnded] = useState(false);
  const [showLoader, setShowLoader] = useState(true);
  const [sessionId, setSessionId] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEndChatLoading, setIsEndChatLoading] = useState(false);
  const [summaryData, setSummaryData] = useState<any>(null);
  const [transcriptData, setTranscriptData] = useState<any>(null);
  const [isSummaryGenerating, setIsSummaryGenerating] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  const [showInfo, setShowInfo] = useState(false);
  const [showFaqs, setShowFaqs] = useState(true);
  const sawTextDeltaRef = useRef(false);

  const promptChips = [
    "What hospital services do you offer?",
    "Can I book an appointment with a cardiologist?",
    "What insurance plans do you accept?",
    "How do I access my medical records?",
    "What are your visiting hours?",
    "Do you have emergency services?",
    "I need to schedule a follow-up appointment",
    "What specialists do you have available?",
    "How do I get my lab results?",
    "Can I reschedule my appointment?",
    "What should I bring to my appointment?",
    "Do you offer telemedicine consultations?",
    "How do I request a prescription refill?",
    "What are your COVID-19 protocols?",
    "Can I get a copy of my medical records?",
    "What payment methods do you accept?",
    "How do I contact my doctor?"
  ];
 
  const faqs = [
    // Hospital Information & Services
    "What hospital services do you offer?",
    "What are your visiting hours?",
    "How do I get a cost estimate for my procedure?",
    "What departments do you have?",
    "What amenities do you have?",
    "Hospital locations and directions",
    "What insurance plans do you accept?",
    
    // Appointment Management
    "Can I book an appointment with a cardiologist?",
    "I need to reschedule my appointment",
    "I want to cancel my appointment",
    "What should I bring to my appointment?",
    "Do you offer telemedicine consultations?",
    
    // Medical Records & Health Information
    "I want to view my medical records",
    "What medications am I currently taking?",
    "When are my medication refills due?",
    "What are my recent visits?",
    "How do I get my lab results?",
    
    // Hospital Policies & Procedures
    "How do I prepare for an MRI scan?",
    "What should I bring for admission?",
    "What are your COVID-19 protocols?",
    "What payment methods do you accept?",
    "How do I contact my doctor?"
  ];
 

  useEffect(() => {
    if (chatTranscriptRef.current) {
      chatTranscriptRef.current.scrollTop = chatTranscriptRef.current.scrollHeight;
    }
  }, [conversation.messages, transcriptData, streamingMessage]);



const openWebsocketConnection = (): Promise<string> => {
  return new Promise((resolve, reject) => {
    // Close existing connection if any
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }

    const socket = new WebSocket(
      import.meta.env.VITE_WEBSOCKET_URL
    );
    
    // Store accumulated message text locally
    let accumulatedMessage = '';
    sawTextDeltaRef.current = false; // reset for each new connection
    
    socket.onopen = () => {
      console.log('WebSocket Connected');
      socket.send(JSON.stringify({ type: "connection_init" }));
    };

    socket.onmessage = (e) => {
      try {
        const messageData = JSON.parse(e.data);
        console.log(messageData, "receivedData_connectid");
        
        // Handle connection ID
        if (messageData.connectionid && !connectionId) {
          console.log("Connection ID received:", messageData.connectionid);
          setConnectionId(messageData.connectionid);
          resolve(messageData.connectionid);
        }

        // Track if we have seen a text_delta in this stream
        if (messageData.type === "content_block_delta" && messageData.delta?.type === "text_delta") {
          sawTextDeltaRef.current = true;
          accumulatedMessage += messageData.delta.text;
          setStreamingMessage(accumulatedMessage);
          setIsStreaming(true);
        }

        // Handle stream completion
        if (messageData.type === "content_block_stop" || messageData.type === "message_stop") {
          if (sawTextDeltaRef.current) {
            // This is the final answer's stop, safe to close
            setIsStreaming(false);
            setIsLoading(false);
            
            if (accumulatedMessage.trim()) {
              setConversation((prev) => ({
                ...prev,
                messages: [
                  ...prev.messages,
                  {
                    id: `bot-${Date.now()}`,
                    sender: 'bot',
                    text: accumulatedMessage, 
                    timestamp: new Date().toISOString(),
                  }
                ]
              }));
            }
            setStreamingMessage('');
            socket.close();
            setConnectionId(null);
            sawTextDeltaRef.current = false; // reset for next stream
          } else {
            // This was just the tool input, do not close yet
            // Wait for the next stream (the answer)
            accumulatedMessage = '';
            setStreamingMessage('');
            // Do not close the socket!
          }
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
        reject(error);
      }
    };

    socket.onclose = () => {
      console.log('WebSocket Disconnected');
      setConnectionId(null);
      setIsLoading(false); 
      setIsStreaming(false); 
    };

    socket.onerror = (error) => {
      console.error('WebSocket Error:', error);
      setIsLoading(false); 
      setIsStreaming(false); 
      reject(error);
    };

    socketRef.current = socket;
    
    // Set timeout for connection
    setTimeout(() => {
      if (!connectionId) {
        reject(new Error('Connection timeout'));
      }
    }, 10000);
  });
};
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() === '') return;
    
    // if (!sessionId) {
    //   const newSessionId = generateSessionId();
    //   setSessionId(newSessionId);
    // }
    
    // Add user message
    const newUserMessage: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: inputText,
      timestamp: new Date().toISOString()
    };
    
    setConversation(prev => ({
      ...prev,
      messages: [...prev.messages, newUserMessage]
    }));
    
    const currentInput = inputText;
    setInputText('');
    setIsLoading(true);
    
    // Hide FAQ only after first send
    if (conversation.messages.length === 0 && showFaqs) {
      setShowFaqs(false);
    }
    
    try {
      // Generate new connection ID for each API call
      const newConnectionId = await openWebsocketConnection();
      console.log("New connection established with ID:", newConnectionId);
      
      // Call the chat API with new connection ID
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      const raw = JSON.stringify({
        event_type: 'healthcare_chat_tool',
        chat: currentInput,
        session_id: sessionId || '',
        connectionId: newConnectionId
      });

      console.log("API Request:", raw);
      
      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow' as const
      };
      
      const response = await fetch(import.meta.env.VITE_API_BASE_URL, requestOptions);
      const data = await response.json();
      
      if (data.session_id) {
        console.log("Received session ID from API:", data.session_id);
        setSessionId(data.session_id);
      } else {
        console.warn("No session_id received from chat API response:", data);
      }
      
      setIsLoading(false);
      
    } catch (error) {
      console.error("Error in handleSubmit:", error);
      
      // Add error message if WebSocket fails
      const errorMessage: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: 'Sorry, there was a problem connecting to the healthcare chat service. Please try again.',
        timestamp: new Date().toISOString(),
      };
      
      setConversation(prev => ({
        ...prev,
        messages: [...prev.messages, errorMessage]
      }));
      
      setIsLoading(false);
      setIsStreaming(false);
      setStreamingMessage('');
    }
  };

  const handlePromptChipClick = (text: string) => {
    setInputText(text);
  };

const handleEndChat = async () => {
  // Capture current sessionId to prevent race conditions
  const currentSessionId = sessionId;
  
  // Validate sessionId exists before proceeding
  if (!currentSessionId) {
    console.error("No session ID available for generating summary");
    alert("Unable to generate post chat analysis: No active session found. Please start a new conversation.");
    return;
  }

  console.log("Starting end chat process with session ID:", currentSessionId);
  
  setIsEndChatLoading(true);
  setIsSummaryGenerating(true);
  setChatEnded(true);
  setShowLoader(false);

  // Close WebSocket connection if open
  if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
    socketRef.current.close();
  }

  try {
    console.log("Calling generate_summary with session ID:", currentSessionId);
    const generateResponse = await fetch(import.meta.env.VITE_API_BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event_type: 'generate_retail_summary', session_id: currentSessionId }),
    });

    if (!generateResponse.ok) {
      throw new Error(`Generate summary failed with status: ${generateResponse.status}`);
    }

    const pollInterval = setInterval(async () => {
      try {
        console.log("Polling for summary with session ID:", currentSessionId);
        const resp = await fetch(import.meta.env.VITE_API_BASE_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ event_type: 'list_retail_summary', session_id: currentSessionId }),
        });

        if (!resp.ok) {
          throw new Error(`List summary failed with status: ${resp.status}`);
        }

        const data = await resp.json();
        console.log("Summary response:", data);

        if (data?.final_summary) {
          console.log("Summary retrieved successfully");
          clearInterval(pollInterval); // stop polling
          setSummaryData(data.final_summary);
          setTranscriptData(data.transcript);
          setIsSummaryGenerating(false);
          setIsEndChatLoading(false);
          // Clear sessionId only after successful retrieval
          setSessionId('');
          setConversation(emptyConversation);
        } else {
          console.log("Summary not ready yet, continuing to poll...");
        }
      } catch (err) {
        console.error("Polling error:", err);
        clearInterval(pollInterval);
        setIsSummaryGenerating(false);
        setIsEndChatLoading(false);
        alert("Failed to retrieve post chat analysis. Please try again.");
      }
    }, 5000); // Reduced polling interval to 5 seconds for faster response

    // Add timeout to prevent infinite polling
    setTimeout(() => {
      clearInterval(pollInterval);
      if (isSummaryGenerating) {
        console.error("Summary generation timeout");
        setIsSummaryGenerating(false);
        setIsEndChatLoading(false);
        alert("Post chat analysis generation timed out. Please try again.");
      }
    }, 120000); // 2 minute timeout

  } catch (e) {
    console.error("Generate post-chat analysis error:", e);
    setSummaryData(null);
    setTranscriptData(null);
    setIsSummaryGenerating(false);
    setIsEndChatLoading(false);
    alert("Failed to generate post chat analysis. Please try again.");
  }
};

  const handleStartNewChat = () => {
    setChatEnded(false);
    setConversation(emptyConversation); 
    setInputText('');
    setShowLoader(true);
    setStreamingMessage('');
    setIsStreaming(false);
    setConnectionId(null);
    setShowFaqs(true);
    
    // Close existing WebSocket connection
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }
  };

  // Clean up WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, []);

  const navigate = useNavigate();

  const handleTableValueClick = (value: string) => {
    setInputText(value);
    // Add visual feedback - you can customize this further
    console.log(`Copied "${value}" to chat input`);
  };

  // Add hover effect styles
  const tableCellStyle = {
    padding: '8px',
    borderBottom: '1px solid #f1f3f4',
    fontSize: '11px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    ':hover': {
      backgroundColor: '#f8f9fa',
      color: '#e87722',
      fontWeight: '600'
    }
  };

  return (
    <div>
      <Row>
        <Col lg={8}>
          <Card className="mb-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            {/* Modern Header */}
            <div 
              className="d-flex align-items-center justify-content-between px-4 py-3"
              style={{ 
                backgroundColor: 'white',
                color: 'black',
                fontFamily: 'Inter, sans-serif',
                borderBottom: '1px solid #e9ecef'
              }}
            >
              <div className="d-flex align-items-center">
                                 <div 
                   className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3"
                 >
                   <Bot size={16} className="text-white" />
                  </div>
                                <div>
                  <div className="d-flex align-items-center">
                    <h5 className="mb-0 fw-bold me-2" style={{ fontSize: '18px', letterSpacing: '-0.5px' }}>
                      Healthcare Assistant
                    </h5>
                  </div>
                </div>
              </div>
              
              
            </div>

                        {/* Chat Area */}
            <Card.Body className="p-0 d-flex flex-column" style={{ height: '450px', backgroundColor: 'white' }}>
              {/* Messages Container */}
              <div
                className="px-4 py-3 flex-grow-1 position-relative"
                ref={chatTranscriptRef}
                      style={{
                  overflowY: 'auto',
                  fontFamily: 'Inter, sans-serif',
                  minHeight: '0'
                }}
              >
                 {/* Opening message - always visible during active chat */}
                 {(!chatEnded || isSummaryGenerating) && (
                   <div className="d-flex justify-content-start mb-3">
                     <div style={{ maxWidth: '75%' }}>
                       <div 
                         className="text-dark"
                      style={{
                           fontSize: '15px',
                           lineHeight: '1.4',
                           fontWeight: '400'
                         }}
                       >
                         How may I help you with your healthcare needs?
                    </div>
                    
                       <div className="mt-1">
                         <span className="small text-muted" style={{ fontSize: '12px' }}>
                           {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                         </span>
                  </div>
              </div>
                   </div>
                 )}

                 {/* Render conversation messages */}
                 {(!chatEnded || isSummaryGenerating) && conversation.messages.map((message) => (
                  <div key={message.id} className={`d-flex ${message.sender === 'user' ? 'justify-content-end' : 'justify-content-start'} mb-3`}>
                    <div style={{ maxWidth: '75%' }}>
                      {/* Message Bubble */}
                                            <div 
                        className={message.sender === 'user' ? 'px-4 py-3 text-white' : 'text-dark'}
                         style={{
                           backgroundColor: message.sender === 'user' ? '#e87722' : 'transparent',
                           borderRadius: message.sender === 'user' ? '18px 18px 4px 18px' : '0',
                           fontSize: '15px',
                           lineHeight: '1.4',
                           fontWeight: '400',

                           border: message.sender === 'user' ? 'none' : 'none'
                         }}
                      >
                        {message.sender === 'bot' ? (
                          <div style={{ lineHeight: '1.6' }}>
                            <Markdown 
                              components={{
                                ul: ({ children }) => <ul style={{ margin: '8px 0', paddingLeft: '20px', listStyleType: 'disc' }}>{children}</ul>,
                                li: ({ children }) => <li style={{ margin: '4px 0', display: 'list-item' }}>{children}</li>,
                                p: ({ children }) => <p style={{ margin: '8px 0' }}>{children}</p>
                              }}
                            >
                              {processMarkdownText(message.text)}
                            </Markdown>
                          </div>
                        ) : message.text}
                      </div>
                      
                      {/* Generate post chat analysis button - only for latest bot message */}
                      {message.sender === 'bot' && conversation.messages.indexOf(message) === conversation.messages.length - 1 && !chatEnded && !streamingMessage && (
                        <div className="mt-2">
                          <button
                            className="btn btn-outline-primary btn-sm px-3 py-1"
                            style={{ 
                              borderRadius: '8px',
                              fontSize: '11px',
                              fontWeight: '500',
                              borderColor: '#e87722',
                              color: '#e87722',
                              backgroundColor: 'transparent'
                            }}
                            onClick={handleEndChat}
                            disabled={isEndChatLoading || conversation.messages.length === 0 || !sessionId}
                          >
                            {isEndChatLoading ? (
                              <div className="spinner-border spinner-border-sm me-1" role="status" style={{ width: '10px', height: '10px' }}></div>
                            ) : null}
                            Generate post chat analysis
                          </button>
                        </div>
                      )}
                      
                      {/* Timestamp */}
                      <div className={`mt-1 ${message.sender === 'user' ? 'text-end' : 'text-start'}`}>
                        <span className="small text-muted" style={{ fontSize: '12px' }}>
                        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    </div>
                  </div>
                ))}

                {/* Streaming message */}
                {streamingMessage && isStreaming && (!chatEnded || isSummaryGenerating) && (
                  <div className="d-flex justify-content-start mb-3">
                    <div style={{ maxWidth: '75%' }}>
                      <div 
                        className="text-dark"
                        style={{
                          fontSize: '15px',
                          lineHeight: '1.4',
                          fontWeight: '400'
                        }}
                      >
                        <div style={{ lineHeight: '1.6' }}>
                          <Markdown 
                            components={{
                              ul: ({ children }) => <ul style={{ margin: '8px 0', paddingLeft: '20px', listStyleType: 'disc' }}>{children}</ul>,
                              li: ({ children }) => <li style={{ margin: '4px 0', display: 'list-item' }}>{children}</li>,
                              p: ({ children }) => <p style={{ margin: '8px 0' }}>{children}</p>
                            }}
                          >
                            {processMarkdownText(streamingMessage)}
                          </Markdown>
                        </div>
                      </div>
                      
                      {/* Generate post chat analysis button for streaming message */}
                      {!chatEnded && !streamingMessage && (
                        <div className="mt-2">
                          <button
                            className="btn btn-outline-primary btn-sm px-3 py-1"
                            style={{ 
                              borderRadius: '8px',
                              fontSize: '11px',
                              fontWeight: '500',
                              borderColor: '#e87722',
                              color: '#e87722',
                              backgroundColor: 'transparent'
                            }}
                            onClick={handleEndChat}
                            disabled={isEndChatLoading || conversation.messages.length === 0 || !sessionId}
                          >
                            {isEndChatLoading ? (
                              <div className="spinner-border spinner-border-sm me-1" role="status" style={{ width: '10px', height: '10px' }}></div>
                            ) : null}
                            Generate post chat analysis
                          </button>
                        </div>
                      )}
                      
                      <div className="mt-1">
                        <span className="small text-muted" style={{ fontSize: '12px' }}>
                          {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Loading indicator */}
                {isLoading && !isStreaming && (!chatEnded || isSummaryGenerating) && (
                  <div className="d-flex justify-content-start mb-3">
                    <div style={{ maxWidth: '75%' }}>
                      <div 
                        className="text-dark"
                        style={{
                          fontSize: '15px'
                        }}
                      >
                        <BotTypingLoader />
                      </div>
                    </div>
                  </div>
                )}

                {/* Transcript data when chat ended */}
                {chatEnded && transcriptData && !isSummaryGenerating && (
                  <>
                    {transcriptData.map((item: any, idx: number) => (
                      <React.Fragment key={idx}>
                        {/* User message */}
                        <div className="d-flex justify-content-end mb-3">
                          <div style={{ maxWidth: '75%' }}>
                                                         <div 
                               className="px-4 py-3 text-white"
                               style={{
                                 backgroundColor: '#e87722',
                                 borderRadius: '18px 18px 4px 18px',
                                 fontSize: '15px',
                                 lineHeight: '1.4',
                                 fontWeight: '400'
                               }}
                             >
                              {item.Human}
                            </div>
                            <div className="mt-1 text-end">
                              <span className="small text-muted" style={{ fontSize: '12px' }}>
                                {conversation.messages.length > idx * 2 && conversation.messages[idx * 2].timestamp 
                                  ? new Date(conversation.messages[idx * 2].timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                                  : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        {/* Bot message */}
                        <div className="d-flex justify-content-start mb-3">
                          <div style={{ maxWidth: '75%' }}>
                            <div 
                              className="text-dark"
                              style={{
                                fontSize: '15px',
                                lineHeight: '1.4',
                                fontWeight: '400'
                              }}
                            >
                              <div style={{ lineHeight: '1.6' }}>
                                <Markdown 
                                  components={{
                                    ul: ({ children }) => <ul style={{ margin: '8px 0', paddingLeft: '20px', listStyleType: 'disc' }}>{children}</ul>,
                                    li: ({ children }) => <li style={{ margin: '4px 0', display: 'list-item' }}>{children}</li>,
                                    p: ({ children }) => <p style={{ margin: '8px 0' }}>{children}</p>
                                  }}
                                >
                                  {processMarkdownText(item.Bot)}
                                </Markdown>
                              </div>
                            </div>
                            <div className="mt-1">
                              <span className="small text-muted" style={{ fontSize: '12px' }}>
                                {conversation.messages.length > idx * 2 + 1 && conversation.messages[idx * 2 + 1].timestamp 
                                  ? new Date(conversation.messages[idx * 2 + 1].timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                                  : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </>
                )}

                <div ref={messagesEndRef} />


                      </div>

                             {/* Quick Reply Suggestions */}
               {conversation.messages.length === 0 && !chatEnded && showFaqs && (
                 <div className="px-4 py-2 flex-shrink-0" style={{ borderTop: '1px solid #e9ecef' }}>
                   <div
                     style={{
                       display: 'flex',
                       gap: '8px',
                       overflowX: 'auto',
                       paddingBottom: '8px',
                       WebkitOverflowScrolling: 'touch'
                     }}
                     className="faq-scroll"
                   >
                     {faqs.map((faq, idx) => (
                       <button
                         key={idx}
                         className="btn btn-outline-secondary"
                         style={{
                           borderRadius: '8px',
                           fontSize: '13px',
                           fontWeight: '500',
                           padding: '8px 16px',
                           whiteSpace: 'nowrap',
                           border: '1px solid #e9ecef',
                           color: '#6c757d',
                           backgroundColor: 'white',
                           minWidth: 'fit-content'
                         }}
                         onClick={() => handlePromptChipClick(faq)}
                         onMouseEnter={(e) => {
                           e.currentTarget.style.backgroundColor = 'white';
                           e.currentTarget.style.borderColor = '#e87722';
                           e.currentTarget.style.color = '#e87722';
                         }}
                         onMouseLeave={(e) => {
                           e.currentTarget.style.backgroundColor = 'white';
                           e.currentTarget.style.borderColor = '#e9ecef';
                           e.currentTarget.style.color = '#6c757d';
                         }}
                       >
                         {faq}
                       </button>
                     ))}
                    </div>
                  </div>
                )}

               {/* Input Area */}
               <div 
                 className="px-4 py-3 flex-shrink-0" 
                 style={{ 
                   backgroundColor: 'white',
                   borderTop: '1px solid #e9ecef'
                 }}
               >
                {!chatEnded ? (
                  <Form onSubmit={handleSubmit}>
                    <div className="d-flex align-items-center">
                      <div className="flex-grow-1 position-relative">
                      <Form.Control
                        placeholder="Type your message here..."
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        disabled={isLoading || isStreaming}
                          style={{
                            borderRadius: '8px',
                            border: '1px solid #e9ecef',
                            padding: '12px 20px',
                            fontSize: '15px',
                            fontFamily: 'Inter, sans-serif',
                            backgroundColor: 'white'
                          }}
                                                     onFocus={(e) => {
                             e.target.style.borderColor = '#e87722';
                             e.target.style.backgroundColor = 'white';
                           }}
                           onBlur={(e) => {
                             e.target.style.borderColor = '#e9ecef';
                             e.target.style.backgroundColor = 'white';
                           }}
                        />
                      </div>
                      
                      {/* Send Button */}
                      <Button 
                        type="submit" 
                        disabled={isLoading || isStreaming || !inputText.trim()}
                        className="ms-2"
                                                                         style={{
                          borderRadius: '8px',
                          width: '46px',
                          height: '46px',
                          border: 'none',
                          backgroundColor: inputText.trim() ? '#e87722' : '#e9ecef',
                          color: 'white',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          padding: '0'
                        }}
                      >
                        <Send size={19} />
                      </Button>
                    </div>
                  </Form>
                ) : (
                                    <Button 
                    variant="primary" 
                    className="w-100"
                    onClick={() => window.location.reload()}
                    disabled={isSummaryGenerating}
                     style={{
                       borderRadius: '8px',
                       backgroundColor: isSummaryGenerating ? '#ccc' : '#e87722',
                       border: 'none',
                       padding: '12px 24px',
                       fontSize: '15px',
                       fontWeight: '500',
                       cursor: isSummaryGenerating ? 'not-allowed' : 'pointer',
                       color: 'white'
                     }}
                  >
                    {isSummaryGenerating ? 'Generating post chat analysis...' : 'Start a New Chat'}
                  </Button>
                )}
              </div>

            </Card.Body>
          </Card>
          
          {/* WhatsApp Preview Card */}
          <Card className="mt-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between border-0" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <Share size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>WhatsApp Preview</h5>
              </div>
            </div>
            <Card.Body className="position-relative" style={{ minHeight: 340, height: 340, maxHeight: 340, fontFamily: 'Inter, sans-serif' }}>
              {(!chatEnded || !summaryData) ? (
                <div
                  className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                  style={{
                    minHeight: 240,
                    height: 240,
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    background: 'inherit',
                    fontFamily: 'Inter, sans-serif'
                  }}
                >
                  <span>
                    Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: '"Inter", "Segoe UI", Roboto, sans-serif' }}>'Generate post chat analysis'</span>
                  </span>
                  <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your personalized post chat analysis!
                  </span>
                </div>
              ) : (
                <div className="h-100" style={{ minHeight: 240, height: 240, maxHeight: 240, overflowY: 'auto' }}>
                  <div className="d-flex align-items-start">
                    <div className="me-3">
                      <div className="w-6 h-6 bg-green-500 rounded flex items-center justify-center">
                        <MessageSquare size={16} className="text-white" />
                      </div>  
                    </div>
                    <div>
                      <div className="bg-white p-3 rounded-lg shadow-sm border border-gray-200" style={{ maxWidth: '400px', borderRadius: '18px 18px 18px 4px' }}>
                        <p className="mb-0" style={{ whiteSpace: 'pre-line' }}>{summaryData.whatsapp_content}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
        
        <Col lg={4}>
          {/* Tabbed Interface Card */}
          <Card className="mb-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between border-0" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <FileText size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Healthcare Assistant</h5>
              </div>
            </div>
            
            {/* Tab Navigation */}
            <div className="d-flex border-bottom" style={{ backgroundColor: 'white' }}>
              <button
                className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeTab === 'features' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                style={{ 
                  fontSize: '14px',
                  fontFamily: 'Inter, sans-serif',
                  borderBottom: activeTab === 'features' ? '2px solid #e87722' : 'none',
                  transition: 'all 0.2s ease'
                }}
                onClick={() => setActiveTab('features')}
              >
                Features
              </button>
              <button
                className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeTab === 'credentials' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                style={{ 
                  fontSize: '14px',
                  fontFamily: 'Inter, sans-serif',
                  borderBottom: activeTab === 'credentials' ? '2px solid #e87722' : 'none',
                  transition: 'all 0.2s ease'
                }}
                onClick={() => setActiveTab('credentials')}
              >
                Sample CRN Workflow
              </button>
            </div>
            
            <Card.Body className='card_body_custom' style={{ position: 'relative', minHeight: 220, height: 220, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: 'white' }}>
              <div style={{ minHeight: 220, height: 220, maxHeight: 220, overflowY: 'auto' }}>
                {activeTab === 'features' && (
                  <div className="p-3 rounded mb-3">
                    <ul className="list-unstyled mb-0">
                      {/* Appointment Management Flow */}
                      <li className="mb-3 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Appointment Management Flow</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>Complete appointment lifecycle management including booking, rescheduling, and cancellation.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "Book appointment" | "Reschedule my appointment" | "Cancel appointment"</span>
                          </div>
                        </div>
                      </li>
                      
                      {/* Current Medications */}
                      <li className="mb-3 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Current Medications</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>View current medications, dosages, schedules, and upcoming refill dates.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "What medications am I taking?" | "When are my refills due?"</span>
                          </div>
                        </div>
                      </li>
                      
                      {/* Medical Records */}
                      <li className="mb-3 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Medical Records</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>Access complete medical history, recent visits, lab results, and health conditions.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "Show my medical records" | "What are my recent visits?"</span>
                          </div>
                        </div>
                      </li>
                      
                      {/* Hospital Information */}
                      <li className="mb-3 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Hospital Information</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>Get details about hospital locations, visiting hours, amenities, services, and departments.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "What are your visiting hours?" | "What amenities do you have?" | "Hospital locations"</span>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                )}
                
                {activeTab === 'credentials' && (
                  <div className="p-3 rounded mb-3">
                    <div className="mb-3">
                      <div className="d-flex align-items-center mb-2">
                        <Key size={16} className="text-orange-600 me-2" />
                          <span className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Healthcare Demo Accounts</span>
                      </div>
                      <div className="bg-white rounded border" style={{ fontSize: '11px' }}>
                        <table className="table table-sm mb-0" style={{ fontSize: '11px', width: '100%', tableLayout: 'auto' }}>
                          <thead>
                            <tr style={{ backgroundColor: 'white' }}>
                              <th style={{ padding: '8px 6px', borderBottom: '1px solid #dee2e6', fontSize: '10px', fontWeight: '600', whiteSpace: 'nowrap' }}>Patient Name</th>
                              <th style={{ padding: '8px 6px', borderBottom: '1px solid #dee2e6', fontSize: '10px', fontWeight: '600', whiteSpace: 'nowrap' }}>Phone</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', fontWeight: '600', color: '#e87722', whiteSpace: 'nowrap' }}>John Smith</td>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', whiteSpace: 'nowrap' }}>91234567</td>
                            </tr>
                            <tr>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', fontWeight: '600', color: '#e87722', whiteSpace: 'nowrap' }}>Sarah Johnson</td>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', whiteSpace: 'nowrap' }}>98765432</td>
                            </tr>
                            <tr>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', fontWeight: '600', color: '#e87722', whiteSpace: 'nowrap' }}>Michael Brown</td>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', whiteSpace: 'nowrap' }}>83456721</td>
                            </tr>
                            <tr>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', fontWeight: '600', color: '#e87722', whiteSpace: 'nowrap' }}>Emily Davis</td>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', whiteSpace: 'nowrap' }}>97651823</td>
                            </tr>
                            <tr>
                              <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', fontWeight: '600', color: '#e87722', whiteSpace: 'nowrap' }}>David Wilson</td>
                                <td style={{ padding: '8px 6px', borderBottom: '1px solid #f1f3f4', fontSize: '10px', whiteSpace: 'nowrap' }}>84569034</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    

                  
                    <div className="bg-light p-2 rounded" style={{ fontSize: '11px', color: '#6c757d' }}>
                      <span className="fw-semibold">Note:</span> This is a sandbox demo. Only headphones and TV products are supported. All customers, orders, and products are simulated for demonstration purposes.
                    </div>
                  </div>
                )}
              </div>
            </Card.Body>
          </Card>
          
          {/* Summary Card */}
          <Card className="mb-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between border-0" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <FileText size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Summary</h5>
              </div>
            </div>
            <Card.Body className='card_body_custom' style={{ position: 'relative', minHeight: 227, height: 227, fontFamily: 'Inter, sans-serif' }}>
              {(!chatEnded || !summaryData) ? (
                <div
                  className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                  style={{
                    minHeight: 227,
                    height: 227,
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    background: 'inherit',
                    fontFamily: 'Inter, sans-serif'
                  }}
                >
                  <span>
                    Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: '"Inter", "Segoe UI", Roboto, sans-serif' }}>'Generate post chat analysis'</span>
                  </span>
                  <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your personalized post chat analysis!
                  </span>
                </div>
              ) : (
                <div className="bg-light p-3 rounded mb-3" style={{ minHeight: 227, height: 227, maxHeight: 227, overflowY: 'auto' }}>
                  <div className="mb-2"><span className="small mb-0">{summaryData.summary}</span></div>
                </div>
              )}
            </Card.Body>
          </Card>
          {/* Interaction Summary Card */}
          <Card className="border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between border-0" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <MessageSquare size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Interaction Summary</h5>
              </div>
            </div>
            <Card.Body className='card_body_custom' style={{ position: 'relative', minHeight: 227, height: 227, padding: '0% !important', fontFamily: 'Inter, sans-serif' }}>
              {(!chatEnded || !summaryData) ? (
                <div
                  className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                  style={{
                    minHeight: 227,
                    height: 227,
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    background: 'inherit',
                    fontFamily: 'Inter, sans-serif'
                  }}
                >
                  <span>
                    Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: '"Inter", "Segoe UI", Roboto, sans-serif' }}>'Generate post chat analysis'</span>
                  </span>
                  <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your personalized post chat analysis!
                  </span>
                </div>
              ) : (
                <div className="bg-light p-3 rounded mb-3" style={{ minHeight: 227, height: 227, maxHeight: 227, overflowY: 'auto' }}>
                  {summaryData.Topic && (
                    <div className="mb-2 d-flex justify-content-between">
                      <span className="text-muted small">Topic</span>
                      <span className="fw-bold">{summaryData.Topic}</span>
                    </div>
                  )}
                  <div className="mb-2 d-flex justify-content-between">
                    <span className="text-muted small">Sentiment</span>
                    <span className="fw-bold">{summaryData.sentiment || ''}</span>
                  </div>
                  <div className="mb-2 d-flex justify-content-between">
                    <span className="text-muted small">Escalation Triggered</span>
                    <span className="fw-bold">No</span>
                  </div>
                  <div className="mb-2 d-flex justify-content-between">
                    <span className="text-muted small">Follow-Up Required</span>
                    <span className="fw-bold">Yes – whatsapp</span>
                  </div>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default RetailAssistantTool;