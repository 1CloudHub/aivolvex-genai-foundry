import React, { useState, useEffect } from 'react';
import { 
  FileText,
  Home as HomeIcon,
  Activity,
  Stethoscope,
  Pill,
  X
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { setExtractedData, clearExtractedData } from '../../store/slices/extractedDataSlice';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';
import DocumentWorkflow from '../../components/ui/DocumentWorkflow';

interface DocumentType {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

interface ExtractedField {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'error';
  message?: string;
}

interface ProcessedDocument {
  id: string;
  name: string;
  type: string;
  status: 'processing' | 'completed' | 'failed';
  confidence: number;
  fields: ExtractedField[];
  uploadTime: Date;
}

const documentTypes: DocumentType[] = [
  {
    id: 'blood_biomarker',
    name: 'Blood Biomarker Report',
    description: 'Comprehensive blood test results and biomarker analysis',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <Activity className="w-6 h-6 text-white" />
    </div>
  },
  {
    id: 'cms_1500',
    name: 'CMS-1500 Claim Form',
    description: 'Standard healthcare claim form for insurance billing',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <FileText className="w-6 h-6 text-white" />
    </div>
  },
  {
    id: 'prescription',
    name: 'Prescription',
    description: 'Medication prescriptions and dosage instructions',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <Pill className="w-6 h-6 text-white" />
    </div>
  },
  {
    id: 'radiology_report',
    name: 'Radiology Report',
    description: 'Imaging study reports and diagnostic findings',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <X className="w-6 h-6 text-white" />
    </div>
  },
];

// Mock processed document data
const mockDocuments: Record<string, ProcessedDocument> = {
  blood_biomarker: {
    id: 'biomarker-001',
    name: 'Blood_Biomarker_Report.pdf',
    type: 'Blood Biomarker Report',
    status: 'completed',
    confidence: 94,
    fields: [
      { name: 'Patient Name', value: 'John Tan', status: 'success' },
      { name: 'Patient ID', value: 'P-34219', status: 'success' },
      { name: 'Date of Test', value: '2025-07-22', status: 'success' },
      { name: 'Provider', value: 'AnyDiagnostics Laboratory Services', status: 'success' },
      { name: 'Hemoglobin', value: '11.8 g/dL', status: 'warning' },
      { name: 'White Blood Cell', value: '9.6 ×10^9/L', status: 'success' },
      { name: 'Platelets', value: '210 ×10^9/L', status: 'success' },
      { name: 'Fasting Glucose', value: '138 mg/dL', status: 'warning' },
      { name: 'HbA1c', value: '6.8%', status: 'warning' },
      { name: 'ALT (Liver Enzyme)', value: '72 U/L', status: 'warning' },
      { name: 'Creatinine', value: '1.2 mg/dL', status: 'success' }
    ],
    uploadTime: new Date()
  },
  cms_1500: {
    id: 'cms-001',
    name: 'CMS1500_Claim_Form.pdf',
    type: 'CMS-1500 Claim Form',
    status: 'completed',
    confidence: 96,
    fields: [
      { name: 'Patient Name', value: 'Jane Lim', status: 'success' },
      { name: 'Patient ID', value: 'P-88901', status: 'success' },
      { name: 'Member/Subscriber Name', value: 'Jane Lim', status: 'success' },
      { name: 'Date of Birth', value: '1990-04-18', status: 'success' },
      { name: 'Sex', value: 'Female', status: 'success' },
      { name: 'Relationship', value: 'Self', status: 'success' },
      { name: 'Member Address', value: '25 Tampines Ave 3, #10-12, Singapore 529705', status: 'success' },
      { name: 'City', value: 'Singapore', status: 'success' },
      { name: 'State', value: 'SG', status: 'success' },
      { name: 'ZIP', value: '529705', status: 'success' },
      { name: 'Date of Service', value: '2025-07-18', status: 'success' },
      { name: 'Prescriber/Provider', value: 'Dr. Michael Lee, General Practice', status: 'success' },
      { name: 'Provider NPI', value: '1427365987', status: 'success' },
      { name: 'Clinic Phone', value: '+65 6123 4567', status: 'success' },
      { name: 'ICD-10 Code(s)', value: 'E11.9 (Type 2 Diabetes)', status: 'success' },
      { name: 'CPT Code(s)', value: '99213 (Office visit), 83036 (HbA1c test)', status: 'success' },
      { name: 'Diagnosis Description', value: 'Type 2 diabetes mellitus without complications', status: 'success' },
      { name: 'Total Charges', value: 'SGD 220.00', status: 'success' },
      { name: 'Amount Paid', value: 'SGD 0.00', status: 'success' },
      { name: 'Balance Due', value: 'SGD 220.00', status: 'success' },
      { name: 'Receipt/Invoice No.', value: 'INV-2025-0718-4432', status: 'success' },
      { name: 'Primary Insurance', value: 'AnyInsurance Health SG', status: 'success' },
      { name: 'Policy/Member No.', value: 'SG-AI-77880012', status: 'success' },
      { name: 'Group No.', value: 'GRP-AHS-1021', status: 'success' },
      { name: 'Customer Service Phone', value: '+65 6000 1122', status: 'success' },
      { name: 'Other Coverage', value: 'No', status: 'success' },
      { name: 'Coverage Type', value: '—', status: 'success' },
      { name: 'Accident/Workers Comp', value: 'No', status: 'success' },
      { name: 'Medicare/Medicaid', value: 'No', status: 'success' },
      { name: 'Rx #1', value: '100234', status: 'success' },
      { name: 'Date Filled #1', value: '2025-07-18', status: 'success' },
      { name: 'Drug Name/Strength #1', value: 'Metformin 500 mg', status: 'success' },
      { name: 'NDC #1', value: '00093-1045-01', status: 'success' },
      { name: 'Quantity #1', value: '60', status: 'success' },
      { name: 'Days Supply #1', value: '30', status: 'success' },
      { name: 'Charge #1', value: 'SGD 150.00', status: 'success' },
      { name: 'Rx #2', value: '100235', status: 'success' },
      { name: 'Date Filled #2', value: '2025-07-18', status: 'success' },
      { name: 'Drug Name/Strength #2', value: 'HbA1c Test (Lab)', status: 'success' },
      { name: 'Quantity #2', value: '1', status: 'success' },
      { name: 'Days Supply #2', value: '1', status: 'success' },
      { name: 'Charge #2', value: 'SGD 70.00', status: 'success' },
      { name: 'Rx #3', value: '100236', status: 'success' },
      { name: 'Date Filled #3', value: '2025-07-18', status: 'success' },
      { name: 'Drug Name/Strength #3', value: 'Consult/Office Visit (CPT 99213)', status: 'success' },
      { name: 'Quantity #3', value: '1', status: 'success' },
      { name: 'Days Supply #3', value: '1', status: 'success' },
      { name: 'Charge #3', value: 'SGD 0.00', status: 'success' },
      { name: 'Member Signature Date', value: '2025-07-18', status: 'success' }
    ],
    uploadTime: new Date()
  },
  prescription: {
    id: 'prescription-001',
    name: 'Prescription.pdf',
    type: 'Prescription',
    status: 'completed',
    confidence: 92,
    fields: [
      { name: 'Clinic Name', value: 'Care Clinic', status: 'success' },
      { name: 'Clinic Specialty', value: 'Family Medicine • General Practice • Chronic Care', status: 'success' },
      { name: 'Clinic Address', value: '12 Orchard Link, #03-15, Singapore 238850', status: 'success' },
      { name: 'Clinic Phone', value: '+65 6123 4567', status: 'success' },
      { name: 'Clinic Email', value: 'hello@careclinic.sg', status: 'success' },
      { name: 'Clinic Hours', value: 'Mon–Sat 8:30 AM – 6:30 PM (Thu till 8 PM)', status: 'success' },
      { name: 'Prescriber', value: 'Dr. Anya Sharma, GP', status: 'success' },
      { name: 'MCR', value: 'M12345', status: 'success' },
      { name: 'Clinic Code', value: 'CC-07', status: 'success' },
      { name: 'Date Prescribed', value: '2025-08-10', status: 'success' },
      { name: 'Encounter No.', value: 'ENC-2025-0810-0042', status: 'success' },
      { name: 'Patient Name', value: 'Robert Miller', status: 'success' },
      { name: 'DOB', value: '1984-11-02', status: 'success' },
      { name: 'Sex', value: 'Male', status: 'success' },
      { name: 'Patient ID', value: 'RM-001872', status: 'success' },
      { name: 'Address', value: '88 River Valley Rd, #14-06, Singapore 179030', status: 'success' },
      { name: 'Contact', value: '+65 9000 1122', status: 'success' },
      { name: 'Allergies', value: 'NKDA', status: 'success' },
      { name: 'BP', value: '126/78 mmHg', status: 'success' },
      { name: 'HR', value: '72 bpm', status: 'success' },
      { name: 'Temp', value: '36.7 °C', status: 'success' },
      { name: 'Weight', value: '78 kg', status: 'success' },
      { name: 'Height', value: '178 cm', status: 'success' },
      { name: 'Primary Diagnosis', value: 'Type 2 Diabetes Mellitus (ICD-10: E11.9)', status: 'success' },
      { name: 'Secondary Diagnosis', value: 'Hyperlipidemia (ICD-10: E78.5)', status: 'success' },
      { name: 'Clinical Notes', value: 'Stable; target HbA1c < 7%. No acute complaints today.', status: 'success' },
      { name: 'Insurer', value: 'AnyInsurance Health SG', status: 'success' },
      { name: 'Policy #', value: 'SG-AI-77880012', status: 'success' },
      { name: 'Group', value: 'GRP-AHS-1021', status: 'success' },
      { name: 'Eligibility', value: 'Verified 2025-08-10', status: 'success' },
      { name: 'Copay', value: 'SGD 0.00', status: 'success' },
      { name: 'Auth', value: 'Not required', status: 'success' },
      { name: 'Medication 1', value: 'Metformin 500 mg – Take 1 tablet orally twice daily with meals for 30 days', status: 'success' },
      { name: 'Qty 1', value: '60', status: 'success' },
      { name: 'Refills 1', value: '0', status: 'success' },
      { name: 'Medication 2', value: 'Atorvastatin 20 mg – Take 1 tablet nightly for 30 days', status: 'success' },
      { name: 'Qty 2', value: '30', status: 'success' },
      { name: 'Refills 2', value: '0', status: 'success' },
      { name: 'Medication 3', value: 'Vitamin D3 1000 IU – Take 1 capsule daily for 60 days', status: 'success' },
      { name: 'Qty 3', value: '60', status: 'success' },
      { name: 'Refills 3', value: '0', status: 'success' },
      { name: 'Medication 4', value: 'Blood Glucose Test Strips – Use to test fasting glucose daily', status: 'success' },
      { name: 'Qty 4', value: '50', status: 'success' },
      { name: 'Refills 4', value: '1', status: 'success' },
      { name: 'Notes/Instructions', value: 'Continue lifestyle modification (diet + exercise). Recheck blood glucose in 3 months. Educated on hypoglycemia signs; advised to maintain hydration and foot care. Follow-up visit in 6 weeks or earlier if adverse effects occur.', status: 'success' },
      { name: 'Generic Substitution', value: 'Permitted', status: 'success' },
      { name: 'DAW', value: '0', status: 'success' },
      { name: 'Pharmacy', value: 'Preferred Network', status: 'success' },
      { name: 'Additional Directions', value: 'Take evening doses at 8–9 PM. Avoid grapefruit with atorvastatin.', status: 'success' },
      { name: 'Next Appt', value: '2025-09-21 · 10:15 AM', status: 'success' },
      { name: 'Lab Orders', value: 'HbA1c, Fasting Lipid Panel', status: 'success' },
      { name: 'Result Routing', value: 'Patient Portal', status: 'success' }
    ],
    uploadTime: new Date()
  },
  radiology_report: {
    id: 'radiology-001',
    name: 'Radiology_Report.pdf',
    type: 'Radiology Report',
    status: 'completed',
    confidence: 89,
    fields: [
      { name: 'Lab Name', value: 'AnyDiagnostics Laboratory Services', status: 'success' },
      { name: 'Lab Specialty', value: 'Diagnostic Imaging & Clinical Laboratory', status: 'success' },
      { name: 'Regd. No.', value: 'ADLS-SG-45826X', status: 'success' },
      { name: 'Lab Phone', value: '+65 6123 4567', status: 'success' },
      { name: 'Lab Email', value: 'support@anydiagnostics.sg', status: 'success' },
      { name: 'Lab Address', value: '12 Science Park Dr, Singapore 118225', status: 'success' },
      { name: 'Lab Website', value: 'anydiagnostics.sg', status: 'success' },
      { name: 'Patient Name', value: 'Aishwarya Menon', status: 'success' },
      { name: 'Age/Sex', value: '32 Y / F', status: 'success' },
      { name: 'Patient ID', value: 'AM-002915', status: 'success' },
      { name: 'Referring Provider', value: 'Self-referred', status: 'success' },
      { name: 'Consultant Radiologist', value: 'Dr. K. Raghavan, FRCR', status: 'success' },
      { name: 'Address', value: '21 Bukit Timah Rd, #05-04, Singapore 309999', status: 'success' },
      { name: 'Contact', value: '+65 9234 5678', status: 'success' },
      { name: 'Study Type', value: 'Chest X-ray (PA and lateral)', status: 'success' },
      { name: 'Study Date', value: '2025-08-05', status: 'success' },
      { name: 'Accession #', value: 'ACC-25-0805-1142', status: 'success' },
      { name: 'Modality', value: 'X-ray', status: 'success' },
      { name: 'Views', value: 'PA and Left Lateral', status: 'success' },
      { name: 'Comparison', value: 'No prior available', status: 'success' },
      { name: 'Report ID', value: 'XR-CHEST-2025-0805-AM', status: 'success' },
      { name: 'Received/Reported', value: '05-Aug-2025 / 05-Aug-2025 · 3:15 PM', status: 'success' },
      { name: 'Signed by', value: 'Dr. A. K. Asthana, MD (Radiology)', status: 'success' },
      { name: 'Provider', value: 'AnyDiagnostics Laboratory Services', status: 'success' },
      { name: 'Technique', value: 'Digital radiography; PA at full inspiration; lateral view', status: 'success' },
      { name: 'Exposure', value: '110 kVp · 1.4 mAs · 180 cm SID', status: 'success' },
      { name: 'Findings', value: 'Heart size within normal limits; lungs clear bilaterally without focal consolidation or pleural effusion. No pneumothorax identified. Mild multilevel degenerative changes are noted in the thoracic spine. No acute osseous abnormalities visualized.', status: 'success' },
      { name: 'Impression', value: 'Normal chest X-ray. Age-related degenerative spinal changes; no urgent findings.', status: 'success' },
      { name: 'Comments', value: 'Correlate clinically if symptoms persist or worsen. If shortness of breath or chest pain develops, seek immediate medical attention. Follow-up imaging only if clinically indicated.', status: 'success' },
      { name: 'Lab In-charge', value: 'Dr. Sachin Sharma, DMLT', status: 'success' },
      { name: 'Reporting Radiologist', value: 'Dr. A. K. Asthana, MBBS, MD Radiology', status: 'success' },
      { name: 'Work Timings', value: 'Monday to Sunday, 8 am to 8 pm', status: 'success' }
    ],
    uploadTime: new Date()
  }
};

const docUrls: Record<string, string> = {
  blood_biomarker: '/HealthCare/Blood_Biomarker_Report.pdf',
  cms_1500: '/HealthCare/CMS1500_Claim_Form.pdf',
  prescription: '/HealthCare/Prescription.pdf',
  radiology_report: '/HealthCare/Radiology_Report.pdf'
};

const getPdfUrl = (url: string) => {
  if (url.endsWith('.pdf')) {
    return `${url}#toolbar=0&navpanes=0&scrollbar=0&view=FitH`;
  }
  return url;
};

// Healthcare-specific field data
const bloodBiomarkerFields = [
  { field: 'Patient Name', value: 'John Tan', note: 'Primary patient identifier' },
  { field: 'Patient ID', value: 'P-34219', note: 'Internal patient identifier' },
  { field: 'Date of Test', value: '2025-07-22', note: 'Date when blood was drawn' },
  { field: 'Provider', value: 'AnyDiagnostics Laboratory Services', note: 'Laboratory performing the tests' },
  { field: 'Hemoglobin', value: '11.8 g/dL', note: 'Red blood cell protein (Normal: 13.0-17.0 g/dL) - Low' },
  { field: 'White Blood Cell', value: '9.6 ×10^9/L', note: 'Immune system cells (Normal: 4.0-11.0 ×10^9/L) - Normal' },
  { field: 'Platelets', value: '210 ×10^9/L', note: 'Blood clotting cells (Normal: 150-400 ×10^9/L) - Normal' },
  { field: 'Fasting Glucose', value: '138 mg/dL', note: 'Blood sugar level (Normal: 70-100 mg/dL) - High' },
  { field: 'HbA1c', value: '6.8%', note: 'Diabetes control indicator (Normal: <5.7%) - High' },
  { field: 'ALT (Liver Enzyme)', value: '72 U/L', note: 'Liver function marker (Normal: <45 U/L) - High' },
  { field: 'Creatinine', value: '1.2 mg/dL', note: 'Kidney function marker (Normal: 0.7-1.3 mg/dL) - Normal' }
];

const cms1500Fields = [
  { field: 'Patient Name', value: 'Jane Lim', note: 'Primary patient identifier' },
  { field: 'Patient ID', value: 'P-88901', note: 'Internal patient identifier' },
  { field: 'Member/Subscriber Name', value: 'Jane Lim', note: 'Insurance member name' },
  { field: 'Date of Birth', value: '1990-04-18', note: 'Patient date of birth' },
  { field: 'Sex', value: 'Female', note: 'Patient gender' },
  { field: 'Relationship', value: 'Self', note: 'Relationship to subscriber' },
  { field: 'Member Address', value: '25 Tampines Ave 3, #10-12, Singapore 529705', note: 'Patient address' },
  { field: 'City', value: 'Singapore', note: 'Patient city' },
  { field: 'State', value: 'SG', note: 'Patient state/region' },
  { field: 'ZIP', value: '529705', note: 'Patient postal code' },
  { field: 'Date of Service', value: '2025-07-18', note: 'Date when service was provided' },
  { field: 'Prescriber/Provider', value: 'Dr. Michael Lee, General Practice', note: 'Treating physician and specialty' },
  { field: 'Provider NPI', value: '1427365987', note: 'National Provider Identifier' },
  { field: 'Clinic Phone', value: '+65 6123 4567', note: 'Provider contact number' },
  { field: 'ICD-10 Code(s)', value: 'E11.9 (Type 2 Diabetes)', note: 'Diagnosis code(s) for billing' },
  { field: 'CPT Code(s)', value: '99213 (Office visit), 83036 (HbA1c test)', note: 'Procedure/service codes' },
  { field: 'Diagnosis Description', value: 'Type 2 diabetes mellitus without complications', note: 'Detailed diagnosis description' },
  { field: 'Total Charges', value: 'SGD 220.00', note: 'Total amount billed' },
  { field: 'Amount Paid', value: 'SGD 0.00', note: 'Amount paid by insurance or patient' },
  { field: 'Balance Due', value: 'SGD 220.00', note: 'Outstanding balance' },
  { field: 'Receipt/Invoice No.', value: 'INV-2025-0718-4432', note: 'Invoice reference number' },
  { field: 'Primary Insurance', value: 'AnyInsurance Health SG', note: 'Primary insurance carrier' },
  { field: 'Policy/Member No.', value: 'SG-AI-77880012', note: 'Insurance policy number' },
  { field: 'Group No.', value: 'GRP-AHS-1021', note: 'Insurance group number' },
  { field: 'Customer Service Phone', value: '+65 6000 1122', note: 'Insurance customer service' },
  { field: 'Other Coverage', value: 'No', note: 'Additional insurance coverage' },
  { field: 'Coverage Type', value: '—', note: 'Type of coverage' },
  { field: 'Accident/Workers Comp', value: 'No', note: 'Workers compensation claim' },
  { field: 'Medicare/Medicaid', value: 'No', note: 'Government insurance coverage' },
  { field: 'Rx #1', value: '100234', note: 'First prescription number' },
  { field: 'Date Filled #1', value: '2025-07-18', note: 'First prescription fill date' },
  { field: 'Drug Name/Strength #1', value: 'Metformin 500 mg', note: 'First medication details' },
  { field: 'NDC #1', value: '00093-1045-01', note: 'First medication NDC code' },
  { field: 'Quantity #1', value: '60', note: 'First prescription quantity' },
  { field: 'Days Supply #1', value: '30', note: 'First prescription days supply' },
  { field: 'Charge #1', value: 'SGD 150.00', note: 'First prescription charge' },
  { field: 'Rx #2', value: '100235', note: 'Second prescription number' },
  { field: 'Date Filled #2', value: '2025-07-18', note: 'Second prescription fill date' },
  { field: 'Drug Name/Strength #2', value: 'HbA1c Test (Lab)', note: 'Second medication details' },
  { field: 'Quantity #2', value: '1', note: 'Second prescription quantity' },
  { field: 'Days Supply #2', value: '1', note: 'Second prescription days supply' },
  { field: 'Charge #2', value: 'SGD 70.00', note: 'Second prescription charge' },
  { field: 'Rx #3', value: '100236', note: 'Third prescription number' },
  { field: 'Date Filled #3', value: '2025-07-18', note: 'Third prescription fill date' },
  { field: 'Drug Name/Strength #3', value: 'Consult/Office Visit (CPT 99213)', note: 'Third service details' },
  { field: 'Quantity #3', value: '1', note: 'Third service quantity' },
  { field: 'Days Supply #3', value: '1', note: 'Third service days supply' },
  { field: 'Charge #3', value: 'SGD 0.00', note: 'Third service charge' },
  { field: 'Member Signature Date', value: '2025-07-18', note: 'Date of member signature' }
];

const prescriptionFields = [
  { field: 'Clinic Name', value: 'Care Clinic', note: 'Prescribing clinic name' },
  { field: 'Clinic Specialty', value: 'Family Medicine • General Practice • Chronic Care', note: 'Clinic specialties' },
  { field: 'Clinic Address', value: '12 Orchard Link, #03-15, Singapore 238850', note: 'Clinic location' },
  { field: 'Clinic Phone', value: '+65 6123 4567', note: 'Clinic contact number' },
  { field: 'Clinic Email', value: 'hello@careclinic.sg', note: 'Clinic email address' },
  { field: 'Clinic Hours', value: 'Mon–Sat 8:30 AM – 6:30 PM (Thu till 8 PM)', note: 'Operating hours' },
  { field: 'Prescriber', value: 'Dr. Anya Sharma, GP', note: 'Prescribing clinician' },
  { field: 'MCR', value: 'M12345', note: 'Medical Council Registration number' },
  { field: 'Clinic Code', value: 'CC-07', note: 'Internal clinic identifier' },
  { field: 'Date Prescribed', value: '2025-08-10', note: 'Prescription date' },
  { field: 'Encounter No.', value: 'ENC-2025-0810-0042', note: 'Visit encounter number' },
  { field: 'Patient Name', value: 'Robert Miller', note: 'Primary patient identifier' },
  { field: 'DOB', value: '1984-11-02', note: 'Patient date of birth' },
  { field: 'Sex', value: 'Male', note: 'Patient gender' },
  { field: 'Patient ID', value: 'RM-001872', note: 'Internal patient identifier' },
  { field: 'Address', value: '88 River Valley Rd, #14-06, Singapore 179030', note: 'Patient address' },
  { field: 'Contact', value: '+65 9000 1122', note: 'Patient contact number' },
  { field: 'Allergies', value: 'NKDA', note: 'Known allergies (No Known Drug Allergies)' },
  { field: 'BP', value: '126/78 mmHg', note: 'Blood pressure reading' },
  { field: 'HR', value: '72 bpm', note: 'Heart rate' },
  { field: 'Temp', value: '36.7 °C', note: 'Body temperature' },
  { field: 'Weight', value: '78 kg', note: 'Patient weight' },
  { field: 'Height', value: '178 cm', note: 'Patient height' },
  { field: 'Primary Diagnosis', value: 'Type 2 Diabetes Mellitus (ICD-10: E11.9)', note: 'Main diagnosis' },
  { field: 'Secondary Diagnosis', value: 'Hyperlipidemia (ICD-10: E78.5)', note: 'Secondary diagnosis' },
  { field: 'Clinical Notes', value: 'Stable; target HbA1c < 7%. No acute complaints today.', note: 'Clinical observations' },
  { field: 'Insurer', value: 'AnyInsurance Health SG', note: 'Insurance provider' },
  { field: 'Policy #', value: 'SG-AI-77880012', note: 'Insurance policy number' },
  { field: 'Group', value: 'GRP-AHS-1021', note: 'Insurance group number' },
  { field: 'Eligibility', value: 'Verified 2025-08-10', note: 'Insurance eligibility status' },
  { field: 'Copay', value: 'SGD 0.00', note: 'Patient copayment amount' },
  { field: 'Auth', value: 'Not required', note: 'Prior authorization status' },
  { field: 'Medication 1', value: 'Metformin 500 mg – Take 1 tablet orally twice daily with meals for 30 days', note: 'First medication prescription' },
  { field: 'Qty 1', value: '60', note: 'First medication quantity' },
  { field: 'Refills 1', value: '0', note: 'First medication refills' },
  { field: 'Medication 2', value: 'Atorvastatin 20 mg – Take 1 tablet nightly for 30 days', note: 'Second medication prescription' },
  { field: 'Qty 2', value: '30', note: 'Second medication quantity' },
  { field: 'Refills 2', value: '0', note: 'Second medication refills' },
  { field: 'Medication 3', value: 'Vitamin D3 1000 IU – Take 1 capsule daily for 60 days', note: 'Third medication prescription' },
  { field: 'Qty 3', value: '60', note: 'Third medication quantity' },
  { field: 'Refills 3', value: '0', note: 'Third medication refills' },
  { field: 'Medication 4', value: 'Blood Glucose Test Strips – Use to test fasting glucose daily', note: 'Fourth medication/prescription' },
  { field: 'Qty 4', value: '50', note: 'Fourth medication quantity' },
  { field: 'Refills 4', value: '1', note: 'Fourth medication refills' },
  { field: 'Notes/Instructions', value: 'Continue lifestyle modification (diet + exercise). Recheck blood glucose in 3 months. Educated on hypoglycemia signs; advised to maintain hydration and foot care. Follow-up visit in 6 weeks or earlier if adverse effects occur.', note: 'Patient instructions and follow-up guidance' },
  { field: 'Generic Substitution', value: 'Permitted', note: 'Generic substitution policy' },
  { field: 'DAW', value: '0', note: 'Dispense As Written code' },
  { field: 'Pharmacy', value: 'Preferred Network', note: 'Pharmacy network preference' },
  { field: 'Additional Directions', value: 'Take evening doses at 8–9 PM. Avoid grapefruit with atorvastatin.', note: 'Special medication instructions' },
  { field: 'Next Appt', value: '2025-09-21 · 10:15 AM', note: 'Next appointment date and time' },
  { field: 'Lab Orders', value: 'HbA1c, Fasting Lipid Panel', note: 'Laboratory tests ordered' },
  { field: 'Result Routing', value: 'Patient Portal', note: 'How lab results will be delivered' }
];

const radiologyReportFields = [
  { field: 'Lab Name', value: 'AnyDiagnostics Laboratory Services', note: 'Diagnostic laboratory name' },
  { field: 'Lab Specialty', value: 'Diagnostic Imaging & Clinical Laboratory', note: 'Laboratory specialties' },
  { field: 'Regd. No.', value: 'ADLS-SG-45826X', note: 'Laboratory registration number' },
  { field: 'Lab Phone', value: '+65 6123 4567', note: 'Laboratory contact number' },
  { field: 'Lab Email', value: 'support@anydiagnostics.sg', note: 'Laboratory email address' },
  { field: 'Lab Address', value: '12 Science Park Dr, Singapore 118225', note: 'Laboratory location' },
  { field: 'Lab Website', value: 'anydiagnostics.sg', note: 'Laboratory website' },
  { field: 'Patient Name', value: 'Aishwarya Menon', note: 'Primary patient identifier' },
  { field: 'Age/Sex', value: '32 Y / F', note: 'Patient age and gender' },
  { field: 'Patient ID', value: 'AM-002915', note: 'Internal patient identifier' },
  { field: 'Referring Provider', value: 'Self-referred', note: 'Referring physician or source' },
  { field: 'Consultant Radiologist', value: 'Dr. K. Raghavan, FRCR', note: 'Consulting radiologist' },
  { field: 'Address', value: '21 Bukit Timah Rd, #05-04, Singapore 309999', note: 'Patient address' },
  { field: 'Contact', value: '+65 9234 5678', note: 'Patient contact number' },
  { field: 'Study Type', value: 'Chest X-ray (PA and lateral)', note: 'Type of imaging study' },
  { field: 'Study Date', value: '2025-08-05', note: 'Date imaging was performed' },
  { field: 'Accession #', value: 'ACC-25-0805-1142', note: 'Study accession number' },
  { field: 'Modality', value: 'X-ray', note: 'Imaging modality used' },
  { field: 'Views', value: 'PA and Left Lateral', note: 'Imaging projection views' },
  { field: 'Comparison', value: 'No prior available', note: 'Comparison with previous studies' },
  { field: 'Report ID', value: 'XR-CHEST-2025-0805-AM', note: 'Unique report identifier' },
  { field: 'Received/Reported', value: '05-Aug-2025 / 05-Aug-2025 · 3:15 PM', note: 'Study received and reported dates' },
  { field: 'Signed by', value: 'Dr. A. K. Asthana, MD (Radiology)', note: 'Reporting radiologist' },
  { field: 'Provider', value: 'AnyDiagnostics Laboratory Services', note: 'Diagnostic provider' },
  { field: 'Technique', value: 'Digital radiography; PA at full inspiration; lateral view', note: 'Imaging technique used' },
  { field: 'Exposure', value: '110 kVp · 1.4 mAs · 180 cm SID', note: 'X-ray exposure parameters' },
  { field: 'Findings', value: 'Heart size within normal limits; lungs clear bilaterally without focal consolidation or pleural effusion. No pneumothorax identified. Mild multilevel degenerative changes are noted in the thoracic spine. No acute osseous abnormalities visualized.', note: 'Detailed radiographic observations' },
  { field: 'Impression', value: 'Normal chest X-ray. Age-related degenerative spinal changes; no urgent findings.', note: 'Radiologist summary and clinical interpretation' },
  { field: 'Comments', value: 'Correlate clinically if symptoms persist or worsen. If shortness of breath or chest pain develops, seek immediate medical attention. Follow-up imaging only if clinically indicated.', note: 'Clinical correlation and follow-up recommendations' },
  { field: 'Lab In-charge', value: 'Dr. Sachin Sharma, DMLT', note: 'Laboratory in-charge' },
  { field: 'Reporting Radiologist', value: 'Dr. A. K. Asthana, MBBS, MD Radiology', note: 'Qualified reporting radiologist' },
  { field: 'Work Timings', value: 'Monday to Sunday, 8 am to 8 pm', note: 'Laboratory operating hours' }
];

const HealthCareDocumentProcessing = () => {
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [extractingDocId, setExtractingDocId] = useState<string | null>(null);
  const [showExtractedInfo, setShowExtractedInfo] = useState<{[key: string]: boolean}>({});
  const [showWorkflow, setShowWorkflow] = useState<{[key: string]: boolean}>({});
  const [isProcessing, setIsProcessing] = useState<{[key: string]: boolean}>({});
  const [activeTab, setActiveTab] = useState<'extracted' | 'workflow'>('workflow');
  // Redux state and dispatch
  const dispatch = useAppDispatch();
  const extractedData = useAppSelector((state) => state.extractedData);
  const [extractionCount, setExtractionCount] = useState<{[key: string]: number}>({});
  const [workflowCompleted, setWorkflowCompleted] = useState<{[key: string]: boolean}>({});
  const [isWorkflowAnimating, setIsWorkflowAnimating] = useState<{[key: string]: boolean}>({});
  const navigate = useNavigate();
  const selectedDocData = selectedDocId ? mockDocuments[selectedDocId] : null;

  // Helper to check if the selected doc is an image
  const isImage = (url: string) => /\.(jpg|jpeg|png|webp|gif)$/i.test(url);

  // API call function for Blood Biomarker Report
  const makeBloodBiomarkerApiCall = async (docId: string) => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    const documentData = `Blood Biomarker Report Extracted information
Field	Extracted Value
Patient Name	John Tan
Patient ID	P-34219
Date of Test	2025-07-22
Provider	AnyDiagnostics Laboratory Services
Hemoglobin	11.8 g/dL
White Blood Cell	9.6 ×10^9/L
Platelets	210 ×10^9/L
Fasting Glucose	138 mg/dL
HbA1c	6.8%
ALT (Liver Enzyme)	72 U/L
Creatinine	1.2 mg/dL`;

    const requestData = {
      event_type: "kyc_extraction",
      document_data: documentData
    };
    
    try {
      console.log('Making Blood Biomarker API call with data:', requestData);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('Blood Biomarker API response received:', result);
        // Store the API response for display in workflow
        dispatch(setExtractedData({ docId, data: result }));
        console.log('Blood Biomarker API response dispatched to Redux with docId:', docId);
        console.log('Redux state after dispatch:', extractedData);
      } else {
        console.error('Blood Biomarker API call failed:', response.status);
        // Set a default response for demo purposes matching the actual API structure
        console.log('Blood Biomarker API failed, setting fallback data with docId:', docId);
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: `Blood Biomarker Report Extracted information

Field	Extracted Value
Patient Name	John Tan
Patient ID	P-34219
Date of Test	2025-07-22
Provider	AnyDiagnostics Laboratory Services
Hemoglobin	11.8 g/dL
White Blood Cell	9.6 ×10^9/L
Platelets	210 ×10^9/L
Fasting Glucose	138 mg/dL
HbA1c	6.8%
ALT (Liver Enzyme)	72 U/L
Creatinine	1.2 mg/dL`,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    } catch (error) {
      console.error('Blood Biomarker API call error:', error);
      // Set a default response for demo purposes matching the actual API structure
      dispatch(setExtractedData({ 
        docId, 
        data: { 
          statusCode: 200,
          session_id: 'demo-session-' + Date.now(),
          response_data: {
            extracted_kyc_data: `Blood Biomarker Report Extracted information

Field	Extracted Value
Patient Name	John Tan
Patient ID	P-34219
Date of Test	2025-07-22
Provider	AnyDiagnostics Laboratory Services
Hemoglobin	11.8 g/dL
White Blood Cell	9.6 ×10^9/L
Platelets	210 ×10^9/L
Fasting Glucose	138 mg/dL
HbA1c	6.8%
ALT (Liver Enzyme)	72 U/L
Creatinine	1.2 mg/dL`,
            timestamp: new Date().toISOString(),
            session_id: 'demo-session-' + Date.now()
          }
        }
      }));
    }
  };

  // API call function for CMS-1500 Claim Form
  const makeCMS1500ApiCall = async (docId: string) => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    const documentData = `CMS-1500 Claim Form Extracted information
Field	Extracted Value
Patient Name	Jane Lim
Patient ID	P-88901
Member/Subscriber Name	Jane Lim
Date of Birth	1990-04-18
Sex	Female
Relationship	Self
Member Address	25 Tampines Ave 3, #10-12, Singapore 529705
City	Singapore
State	SG
ZIP	529705
Date of Service	2025-07-18
Prescriber/Provider	Dr. Michael Lee, General Practice
Provider NPI	1427365987
Clinic Phone	+65 6123 4567
ICD-10 Code(s)	E11.9 (Type 2 Diabetes)
CPT Code(s)	99213 (Office visit), 83036 (HbA1c test)
Diagnosis Description	Type 2 diabetes mellitus without complications
Total Charges	SGD 220.00
Amount Paid	SGD 0.00
Balance Due	SGD 220.00
Receipt/Invoice No.	INV-2025-0718-4432
Primary Insurance	AnyInsurance Health SG
Policy/Member No.	SG-AI-77880012
Group No.	GRP-AHS-1021
Customer Service Phone	+65 6000 1122
Other Coverage	No
Coverage Type	—
Accident/Workers Comp	No
Medicare/Medicaid	No
Rx #1	100234
Date Filled #1	2025-07-18
Drug Name/Strength #1	Metformin 500 mg
NDC #1	00093-1045-01
Quantity #1	60
Days Supply #1	30
Charge #1	SGD 150.00
Rx #2	100235
Date Filled #2	2025-07-18
Drug Name/Strength #2	HbA1c Test (Lab)
Quantity #2	1
Days Supply #2	1
Charge #2	SGD 70.00
Rx #3	100236
Date Filled #3	2025-07-18
Drug Name/Strength #3	Consult/Office Visit (CPT 99213)
Quantity #3	1
Days Supply #3	1
Charge #3	SGD 0.00
Member Signature Date	2025-07-18`;

    const requestData = {
      event_type: "kyc_extraction",
      document_data: documentData
    };
    
    try {
      console.log('Making CMS-1500 API call with data:', requestData);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('CMS-1500 API response received:', result);
        // Store the API response for display in workflow
        dispatch(setExtractedData({ docId, data: result }));
        console.log('Updated extractedData state:', { ...extractedData, [docId]: result });
      } else {
        console.error('CMS-1500 API call failed:', response.status);
        // Set a default response for demo purposes matching the actual API structure
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: `CMS-1500 Claim Form Extracted information

Field	Extracted Value
Patient Name	Jane Lim
Patient ID	P-88901
Member/Subscriber Name	Jane Lim
Date of Birth	1990-04-18
Sex	Female
Relationship	Self
Member Address	25 Tampines Ave 3, #10-12, Singapore 529705
City	Singapore
State	SG
ZIP	529705
Date of Service	2025-07-18
Prescriber/Provider	Dr. Michael Lee, General Practice
Provider NPI	1427365987
Clinic Phone	+65 6123 4567
ICD-10 Code(s)	E11.9 (Type 2 Diabetes)
CPT Code(s)	99213 (Office visit), 83036 (HbA1c test)
Diagnosis Description	Type 2 diabetes mellitus without complications
Total Charges	SGD 220.00
Amount Paid	SGD 0.00
Balance Due	SGD 220.00
Receipt/Invoice No.	INV-2025-0718-4432
Primary Insurance	AnyInsurance Health SG
Policy/Member No.	SG-AI-77880012
Group No.	GRP-AHS-1021
Customer Service Phone	+65 6000 1122
Other Coverage	No
Coverage Type	—
Accident/Workers Comp	No
Medicare/Medicaid	No
Rx #1	100234
Date Filled #1	2025-07-18
Drug Name/Strength #1	Metformin 500 mg
NDC #1	00093-1045-01
Quantity #1	60
Days Supply #1	30
Charge #1	SGD 150.00
Rx #2	100235
Date Filled #2	2025-07-18
Drug Name/Strength #2	HbA1c Test (Lab)
Quantity #2	1
Days Supply #2	1
Charge #2	SGD 70.00
Rx #3	100236
Date Filled #3	2025-07-18
Drug Name/Strength #3	Consult/Office Visit (CPT 99213)
Quantity #3	1
Days Supply #3	1
Charge #3	SGD 0.00
Member Signature Date	2025-07-18`,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    } catch (error) {
      console.error('CMS-1500 API call error:', error);
      // Set a default response for demo purposes matching the actual API structure
      dispatch(setExtractedData({ 
        docId, 
        data: { 
          statusCode: 200,
          session_id: 'demo-session-' + Date.now(),
          response_data: {
            extracted_kyc_data: `CMS-1500 Claim Form Extracted information

Field	Extracted Value
Patient Name	Jane Lim
Patient ID	P-88901
Member/Subscriber Name	Jane Lim
Date of Birth	1990-04-18
Sex	Female
Relationship	Self
Member Address	25 Tampines Ave 3, #10-12, Singapore 529705
City	Singapore
State	SG
ZIP	529705
Date of Service	2025-07-18
Prescriber/Provider	Dr. Michael Lee, General Practice
Provider NPI	1427365987
Clinic Phone	+65 6123 4567
ICD-10 Code(s)	E11.9 (Type 2 Diabetes)
CPT Code(s)	99213 (Office visit), 83036 (HbA1c test)
Diagnosis Description	Type 2 diabetes mellitus without complications
Total Charges	SGD 220.00
Amount Paid	SGD 0.00
Balance Due	SGD 220.00
Receipt/Invoice No.	INV-2025-0718-4432
Primary Insurance	AnyInsurance Health SG
Policy/Member No.	SG-AI-77880012
Group No.	GRP-AHS-1021
Customer Service Phone	+65 6000 1122
Other Coverage	No
Coverage Type	—
Accident/Workers Comp	No
Medicare/Medicaid	No
Rx #1	100234
Date Filled #1	2025-07-18
Drug Name/Strength #1	Metformin 500 mg
NDC #1	00093-1045-01
Quantity #1	60
Days Supply #1	30
Charge #1	SGD 150.00
Rx #2	100235
Date Filled #2	2025-07-18
Drug Name/Strength #2	HbA1c Test (Lab)
Quantity #2	1
Days Supply #2	1
Charge #2	SGD 70.00
Rx #3	100236
Date Filled #3	2025-07-18
Drug Name/Strength #3	Consult/Office Visit (CPT 99213)
Quantity #3	1
Days Supply #3	1
Charge #3	SGD 0.00
Member Signature Date	2025-07-18`,
            timestamp: new Date().toISOString(),
            session_id: 'demo-session-' + Date.now()
          }
        }
      }));
    }
  };

  // API call function for Prescription
  const makePrescriptionApiCall = async (docId: string) => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    const documentData = `Prescription Extracted information
Field	Extracted Value
Clinic Name	Care Clinic
Clinic Specialty	Family Medicine • General Practice • Chronic Care
Clinic Address	12 Orchard Link, #03-15, Singapore 238850
Clinic Phone	+65 6123 4567
Clinic Email	hello@careclinic.sg
Clinic Hours	Mon–Sat 8:30 AM – 6:30 PM (Thu till 8 PM)
Prescriber	Dr. Anya Sharma, GP
MCR	M12345
Clinic Code	CC-07
Date Prescribed	2025-08-10
Encounter No.	ENC-2025-0810-0042
Patient Name	Robert Miller
DOB	1984-11-02
Sex	Male
Patient ID	RM-001872
Address	88 River Valley Rd, #14-06, Singapore 179030
Contact	+65 9000 1122
Allergies	NKDA
BP	126/78 mmHg
HR	72 bpm
Temp	36.7 °C
Weight	78 kg
Height	178 cm
Primary Diagnosis	Type 2 Diabetes Mellitus (ICD-10: E11.9)
Secondary Diagnosis	Hyperlipidemia (ICD-10: E78.5)
Clinical Notes	Stable; target HbA1c < 7%. No acute complaints today.
Insurer	AnyInsurance Health SG
Policy #	SG-AI-77880012
Group	GRP-AHS-1021
Eligibility	Verified 2025-08-10
Copay	SGD 0.00
Auth	Not required
Medication 1	Metformin 500 mg – Take 1 tablet orally twice daily with meals for 30 days
Qty 1	60
Refills 1	0
Medication 2	Atorvastatin 20 mg – Take 1 tablet nightly for 30 days
Qty 2	30
Refills 2	0
Medication 3	Vitamin D3 1000 IU – Take 1 capsule daily for 60 days
Qty 3	60
Refills 3	0
Medication 4	Blood Glucose Test Strips – Use to test fasting glucose daily
Qty 4	50
Refills 4	1
Notes/Instructions	Continue lifestyle modification (diet + exercise). Recheck blood glucose in 3 months. Educated on hypoglycemia signs; advised to maintain hydration and foot care. Follow-up visit in 6 weeks or earlier if adverse effects occur.
Generic Substitution	Permitted
DAW	0
Pharmacy	Preferred Network
Additional Directions	Take evening doses at 8–9 PM. Avoid grapefruit with atorvastatin.
Next Appt	2025-09-21 · 10:15 AM
Lab Orders	HbA1c, Fasting Lipid Panel
Result Routing	Patient Portal`;

    const requestData = {
      event_type: "kyc_extraction",
      document_data: documentData
    };
    
    try {
      console.log('Making Prescription API call with data:', requestData);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('Prescription API response received:', result);
        // Store the API response for display in workflow
        dispatch(setExtractedData({ docId, data: result }));
        console.log('Updated extractedData state:', { ...extractedData, [docId]: result });
      } else {
        console.error('Prescription API call failed:', response.status);
        // Set a default response for demo purposes matching the actual API structure
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: `Prescription Extracted information

Field	Extracted Value
Clinic Name	Care Clinic
Clinic Specialty	Family Medicine • General Practice • Chronic Care
Clinic Address	12 Orchard Link, #03-15, Singapore 238850
Clinic Phone	+65 6123 4567
Clinic Email	hello@careclinic.sg
Clinic Hours	Mon–Sat 8:30 AM – 6:30 PM (Thu till 8 PM)
Prescriber	Dr. Anya Sharma, GP
MCR	M12345
Clinic Code	CC-07
Date Prescribed	2025-08-10
Encounter No.	ENC-2025-0810-0042
Patient Name	Robert Miller
DOB	1984-11-02
Sex	Male
Patient ID	RM-001872
Address	88 River Valley Rd, #14-06, Singapore 179030
Contact	+65 9000 1122
Allergies	NKDA
BP	126/78 mmHg
HR	72 bpm
Temp	36.7 °C
Weight	78 kg
Height	178 cm
Primary Diagnosis	Type 2 Diabetes Mellitus (ICD-10: E11.9)
Secondary Diagnosis	Hyperlipidemia (ICD-10: E78.5)
Clinical Notes	Stable; target HbA1c < 7%. No acute complaints today.
Insurer	AnyInsurance Health SG
Policy #	SG-AI-77880012
Group	GRP-AHS-1021
Eligibility	Verified 2025-08-10
Copay	SGD 0.00
Auth	Not required
Medication 1	Metformin 500 mg – Take 1 tablet orally twice daily with meals for 30 days
Qty 1	60
Refills 1	0
Medication 2	Atorvastatin 20 mg – Take 1 tablet nightly for 30 days
Qty 2	30
Refills 2	0
Medication 3	Vitamin D3 1000 IU – Take 1 capsule daily for 60 days
Qty 3	60
Refills 3	0
Medication 4	Blood Glucose Test Strips – Use to test fasting glucose daily
Qty 4	50
Refills 4	1
Notes/Instructions	Continue lifestyle modification (diet + exercise). Recheck blood glucose in 3 months. Educated on hypoglycemia signs; advised to maintain hydration and foot care. Follow-up visit in 6 weeks or earlier if adverse effects occur.
Generic Substitution	Permitted
DAW	0
Pharmacy	Preferred Network
Additional Directions	Take evening doses at 8–9 PM. Avoid grapefruit with atorvastatin.
Next Appt	2025-09-21 · 10:15 AM
Lab Orders	HbA1c, Fasting Lipid Panel
Result Routing	Patient Portal`,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    } catch (error) {
      console.error('Prescription API call error:', error);
      // Set a default response for demo purposes matching the actual API structure
      dispatch(setExtractedData({ 
        docId, 
        data: { 
          statusCode: 200,
          session_id: 'demo-session-' + Date.now(),
          response_data: {
            extracted_kyc_data: `Prescription Extracted information

Field	Extracted Value
Clinic Name	Care Clinic
Clinic Specialty	Family Medicine • General Practice • Chronic Care
Clinic Address	12 Orchard Link, #03-15, Singapore 238850
Clinic Phone	+65 6123 4567
Clinic Email	hello@careclinic.sg
Clinic Hours	Mon–Sat 8:30 AM – 6:30 PM (Thu till 8 PM)
Prescriber	Dr. Anya Sharma, GP
MCR	M12345
Clinic Code	CC-07
Date Prescribed	2025-08-10
Encounter No.	ENC-2025-0810-0042
Patient Name	Robert Miller
DOB	1984-11-02
Sex	Male
Patient ID	RM-001872
Address	88 River Valley Rd, #14-06, Singapore 179030
Contact	+65 9000 1122
Allergies	NKDA
BP	126/78 mmHg
HR	72 bpm
Temp	36.7 °C
Weight	78 kg
Height	178 cm
Primary Diagnosis	Type 2 Diabetes Mellitus (ICD-10: E11.9)
Secondary Diagnosis	Hyperlipidemia (ICD-10: E78.5)
Clinical Notes	Stable; target HbA1c < 7%. No acute complaints today.
Insurer	AnyInsurance Health SG
Policy #	SG-AI-77880012
Group	GRP-AHS-1021
Eligibility	Verified 2025-08-10
Copay	SGD 0.00
Auth	Not required
Medication 1	Metformin 500 mg – Take 1 tablet orally twice daily with meals for 30 days
Qty 1	60
Refills 1	0
Medication 2	Atorvastatin 20 mg – Take 1 tablet nightly for 30 days
Qty 2	30
Refills 2	0
Medication 3	Vitamin D3 1000 IU – Take 1 capsule daily for 60 days
Qty 3	60
Refills 3	0
Medication 4	Blood Glucose Test Strips – Use to test fasting glucose daily
Qty 4	50
Refills 4	1
Notes/Instructions	Continue lifestyle modification (diet + exercise). Recheck blood glucose in 3 months. Educated on hypoglycemia signs; advised to maintain hydration and foot care. Follow-up visit in 6 weeks or earlier if adverse effects occur.
Generic Substitution	Permitted
DAW	0
Pharmacy	Preferred Network
Additional Directions	Take evening doses at 8–9 PM. Avoid grapefruit with atorvastatin.
Next Appt	2025-09-21 · 10:15 AM
Lab Orders	HbA1c, Fasting Lipid Panel
Result Routing	Patient Portal`,
            timestamp: new Date().toISOString(),
            session_id: 'demo-session-' + Date.now()
          }
        }
      }));
    }
  };

  // API call function for Radiology Report
  const makeRadiologyReportApiCall = async (docId: string) => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    const documentData = `Radiology Report Extracted information
Field	Extracted Value
Lab Name	AnyDiagnostics Laboratory Services
Lab Specialty	Diagnostic Imaging & Clinical Laboratory
Regd. No.	ADLS-SG-45826X
Lab Phone	+65 6123 4567
Lab Email	support@anydiagnostics.sg
Lab Address	12 Science Park Dr, Singapore 118225
Lab Website	anydiagnostics.sg
Patient Name	Aishwarya Menon
Age/Sex	32 Y / F
Patient ID	AM-002915
Referring Provider	Self-referred
Consultant Radiologist	Dr. K. Raghavan, FRCR
Address	21 Bukit Timah Rd, #05-04, Singapore 309999
Contact	+65 9234 5678
Study Type	Chest X-ray (PA and lateral)
Study Date	2025-08-05
Accession #	ACC-25-0805-1142
Modality	X-ray
Views	PA and Left Lateral
Comparison	No prior available
Report ID	XR-CHEST-2025-0805-AM
Received/Reported	05-Aug-2025 / 05-Aug-2025 · 3:15 PM
Signed by	Dr. A. K. Asthana, MD (Radiology)
Provider	AnyDiagnostics Laboratory Services
Technique	Digital radiography; PA at full inspiration; lateral view
Exposure	110 kVp · 1.4 mAs · 180 cm SID
Findings	Heart size within normal limits; lungs clear bilaterally without focal consolidation or pleural effusion. No pneumothorax identified. Mild multilevel degenerative changes are noted in the thoracic spine. No acute osseous abnormalities visualized.
Impression	Normal chest X-ray. Age-related degenerative spinal changes; no urgent findings.
Comments	Correlate clinically if symptoms persist or worsen. If shortness of breath or chest pain develops, seek immediate medical attention. Follow-up imaging only if clinically indicated.
Lab In-charge	Dr. Sachin Sharma, DMLT
Reporting Radiologist	Dr. A. K. Asthana, MBBS, MD Radiology
Work Timings	Monday to Sunday, 8 am to 8 pm`;

    const requestData = {
      event_type: "kyc_extraction",
      document_data: documentData
    };
    
    try {
      console.log('Making Radiology Report API call with data:', requestData);
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('Radiology Report API response received:', result);
        // Store the API response for display in workflow
        dispatch(setExtractedData({ docId, data: result }));
        console.log('Updated extractedData state:', { ...extractedData, [docId]: result });
      } else {
        console.error('Radiology Report API call failed:', response.status);
        // Set a default response for demo purposes matching the actual API structure
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: `Radiology Report Extracted information

Field	Extracted Value
Lab Name	AnyDiagnostics Laboratory Services
Lab Specialty	Diagnostic Imaging & Clinical Laboratory
Regd. No.	ADLS-SG-45826X
Lab Phone	+65 6123 4567
Lab Email	support@anydiagnostics.sg
Lab Address	12 Science Park Dr, Singapore 118225
Lab Website	anydiagnostics.sg
Patient Name	Aishwarya Menon
Age/Sex	32 Y / F
Patient ID	AM-002915
Referring Provider	Self-referred
Consultant Radiologist	Dr. K. Raghavan, FRCR
Address	21 Bukit Timah Rd, #05-04, Singapore 309999
Contact	+65 9234 5678
Study Type	Chest X-ray (PA and lateral)
Study Date	2025-08-05
Accession #	ACC-25-0805-1142
Modality	X-ray
Views	PA and Left Lateral
Comparison	No prior available
Report ID	XR-CHEST-2025-0805-AM
Received/Reported	05-Aug-2025 / 05-Aug-2025 · 3:15 PM
Signed by	Dr. A. K. Asthana, MD (Radiology)
Provider	AnyDiagnostics Laboratory Services
Technique	Digital radiography; PA at full inspiration; lateral view
Exposure	110 kVp · 1.4 mAs · 180 cm SID
Findings	Heart size within normal limits; lungs clear bilaterally without focal consolidation or pleural effusion. No pneumothorax identified. Mild multilevel degenerative changes are noted in the thoracic spine. No acute osseous abnormalities visualized.
Impression	Normal chest X-ray. Age-related degenerative spinal changes; no urgent findings.
Comments	Correlate clinically if symptoms persist or worsen. If shortness of breath or chest pain develops, seek immediate medical attention. Follow-up imaging only if clinically indicated.
Lab In-charge	Dr. Sachin Sharma, DMLT
Reporting Radiologist	Dr. A. K. Asthana, MBBS, MD Radiology
Work Timings	Monday to Sunday, 8 am to 8 pm`,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    } catch (error) {
      console.error('Radiology Report API call error:', error);
      // Set a default response for demo purposes matching the actual API structure
      dispatch(setExtractedData({ 
        docId, 
        data: { 
          statusCode: 200,
          session_id: 'demo-session-' + Date.now(),
          response_data: {
            extracted_kyc_data: `Radiology Report Extracted information

Field	Extracted Value
Lab Name	AnyDiagnostics Laboratory Services
Lab Specialty	Diagnostic Imaging & Clinical Laboratory
Regd. No.	ADLS-SG-45826X
Lab Phone	+65 6123 4567
Lab Email	support@anydiagnostics.sg
Lab Address	12 Science Park Dr, Singapore 118225
Lab Website	anydiagnostics.sg
Patient Name	Aishwarya Menon
Age/Sex	32 Y / F
Patient ID	AM-002915
Referring Provider	Self-referred
Consultant Radiologist	Dr. K. Raghavan, FRCR
Address	21 Bukit Timah Rd, #05-04, Singapore 309999
Contact	+65 9234 5678
Study Type	Chest X-ray (PA and lateral)
Study Date	2025-08-05
Accession #	ACC-25-0805-1142
Modality	X-ray
Views	PA and Left Lateral
Comparison	No prior available
Report ID	XR-CHEST-2025-0805-AM
Received/Reported	05-Aug-2025 / 05-Aug-2025 · 3:15 PM
Signed by	Dr. A. K. Asthana, MD (Radiology)
Provider	AnyDiagnostics Laboratory Services
Technique	Digital radiography; PA at full inspiration; lateral view
Exposure	110 kVp · 1.4 mAs · 180 cm SID
Findings	Heart size within normal limits; lungs clear bilaterally without focal consolidation or pleural effusion. No pneumothorax identified. Mild multilevel degenerative changes are noted in the thoracic spine. No acute osseous abnormalities visualized.
Impression	Normal chest X-ray. Age-related degenerative spinal changes; no urgent findings.
Comments	Correlate clinically if symptoms persist or worsen. If shortness of breath or chest pain develops, seek immediate medical attention. Follow-up imaging only if clinically indicated.
Lab In-charge	Dr. Sachin Sharma, DMLT
Reporting Radiologist	Dr. A. K. Asthana, MBBS, MD Radiology
Work Timings	Monday to Sunday, 8 am to 8 pm`,
            timestamp: new Date().toISOString(),
            session_id: 'demo-session-' + Date.now()
          }
        }
      }));
    }
  };

  // Healthcare API call function for other documents
  const makeHealthcareApiCall = (docId: string) => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    // Build request body for healthcare document processing
    const payload = {
      event_type: 'healthcare_document_processing',
      document_type: docId,
      patient_info: {
        name: 'Sarah Johnson',
        age: 52,
        medical_record_number: 'P-10456'
      },
      clinical_context: {
        department: 'Primary Care',
        provider: 'Dr. Anya Sharma',
        encounter_date: '2025-03-20'
      },
      extraction_goals: {
        ehr_population: true,
        insurance_filing: true,
        clinical_decision_support: true
      }
    };
    
    // Non-blocking API call
    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(error => {
      console.log('Healthcare document processing call made (non-blocking):', payload, error);
    });
  };

  // Handle extract button click
  const handleExtract = async (docId: string) => {
    setExtractingDocId(docId);
    setShowExtractedInfo(prev => ({ ...prev, [docId]: false }));
    setShowWorkflow(prev => ({ ...prev, [docId]: true }));
    setIsProcessing(prev => ({ ...prev, [docId]: true }));
    
    // Reset workflow completion state for new extraction
    setWorkflowCompleted(prev => ({ ...prev, [docId]: false }));
    
    // Increment extraction count to force workflow re-render
    setExtractionCount(prev => ({ ...prev, [docId]: (prev[docId] || 0) + 1 }));
    
    // Trigger workflow animation
    setIsWorkflowAnimating(prev => ({ ...prev, [docId]: true }));
    
    // Data is now managed by Redux, no localStorage cleanup needed
    
    // Reset extractedData for fresh extraction
    dispatch(clearExtractedData(docId));
    
    // Automatically switch to workflow tab when starting new extraction
    setActiveTab('workflow');
    
    // Make appropriate API call based on document type
    if (docId === 'blood_biomarker') {
      console.log('Starting Blood Biomarker extraction...');
      await makeBloodBiomarkerApiCall(docId);
      console.log('Blood Biomarker extraction completed, extractedData state:', extractedData);
      
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else if (docId === 'cms_1500') {
      console.log('Starting CMS-1500 extraction...');
      await makeCMS1500ApiCall(docId);
      console.log('CMS-1500 extraction completed, extractedData state:', extractedData);
      
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else if (docId === 'prescription') {
      console.log('Starting Prescription extraction...');
      await makePrescriptionApiCall(docId);
      console.log('Prescription extraction completed, extractedData state:', extractedData);
      
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else if (docId === 'radiology_report') {
      console.log('Starting Radiology Report extraction...');
      await makeRadiologyReportApiCall(docId);
      console.log('Radiology Report extraction completed, extractedData state:', extractedData);
      
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else {
      // Make healthcare API call for other documents
      makeHealthcareApiCall(docId);
      
      // Show extracted info after 5-6 seconds for other documents
      setTimeout(() => {
        setShowExtractedInfo(prev => ({ ...prev, [docId]: true }));
        setIsProcessing(prev => ({ ...prev, [docId]: false }));
        setExtractingDocId(null);
      }, 5500); // 5.5 seconds
    }
    
    // The workflow completion will be handled by the DocumentWorkflow component callback for blood_biomarker
  };

  // Handle workflow completion
  const handleWorkflowComplete = (docId: string) => {
    setShowExtractedInfo(prev => ({ ...prev, [docId]: true }));
    setIsProcessing(prev => ({ ...prev, [docId]: false }));
    setIsWorkflowAnimating(prev => ({ ...prev, [docId]: false }));
    setWorkflowCompleted(prev => ({ ...prev, [docId]: true }));
    setExtractingDocId(null); // Reset the extracting state to stop the loading button
    setActiveTab('extracted');
  };

  // Prevent access to extracted tab if not available
  const handleTabChange = (tab: 'extracted' | 'workflow') => {
    if (tab === 'extracted' && selectedDocId && !showExtractedInfo[selectedDocId]) {
      return; // Block access to extracted tab
    }
    setActiveTab(tab);
  };

  // Auto-redirect to workflow tab if extracted tab is accessed before completion
  useEffect(() => {
    if (activeTab === 'extracted' && selectedDocId && !showExtractedInfo[selectedDocId]) {
      setActiveTab('workflow');
    }
  }, [activeTab, selectedDocId, showExtractedInfo]);

  // Data cleanup is now handled by Redux, no localStorage cleanup needed

  // Get field data based on document type
  const getFieldData = (docId: string) => {
    switch (docId) {
      case 'blood_biomarker':
        return bloodBiomarkerFields;
      case 'cms_1500':
        return cms1500Fields;
      case 'prescription':
        return prescriptionFields;
      case 'radiology_report':
        return radiologyReportFields;
      default:
        return [];
    }
  };

  return (
    <>
      <LoginNavbar />
      <div className="container py-6">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-2 -ml-1" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button 
                type="button" 
                onClick={() => navigate('/customer/sandbox/healthcarehome')} 
                className="flex items-center gap-2 text-gray-500 no-underline hover:text-gray-700"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <HomeIcon size={16} className="relative top-[-1px]" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-orange-600 font-medium">MedDocs</span>
            </li>
          </ol>
        </nav>
        
        {/* Page Title and Subtitle */}
        <div className="flex items-center gap-6 mb-4 ml-4">
          <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
            <Stethoscope className="h-8 w-8 text-primary" />
          </div>
          <div style={{marginTop: '1.5rem'}}>
            <h1 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
              MedDocs
            </h1>
            <p className="text-base text-gray-600">
              Extracts structured data from key healthcare documents including Blood Biomarker Reports, CMS-1500 Claim Forms, Prescriptions, and Radiology Reports. Enables EHR population, insurance filing, or clinical decision support workflows.
            </p>
          </div>
        </div>
        
        <div className="container mx-auto py-4 px-4 md:px-6 lg:px-8 min-h-screen">
          {/* Card Selector */}
          <div className="w-full mb-10">
            <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(220px, 1fr))` }}>
              {documentTypes.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => {
                    setSelectedDocId(doc.id);
                    // Reset workflow states for the newly selected document
                    setWorkflowCompleted(prev => ({ ...prev, [doc.id]: false }));
                    setShowExtractedInfo(prev => ({ ...prev, [doc.id]: false }));
                    dispatch(clearExtractedData(doc.id));
                    setIsWorkflowAnimating(prev => ({ ...prev, [doc.id]: false }));
                    setActiveTab('workflow');
                  }}
                  className="cursor-pointer transition-colors duration-200 p-4 rounded-lg bg-white"
                  style={{
                    backgroundColor: selectedDocId === doc.id ? 'rgb(255, 251, 245)' : 'white',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)',
                    border: selectedDocId === doc.id ? '2px solid #fb923c' : 'none'
                  }}
                >
                  <div className="flex items-start gap-4">
                    {doc.icon}
                    <div>
                      <h3 className="font-semibold text-base text-gray-800">{doc.name}</h3>
                      <p className="text-sm text-gray-500">{doc.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {selectedDocId && selectedDocData ? (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left: Document Display */}
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">{selectedDocData.type}</h2>
                  <div className="w-full h-[700px] rounded-md overflow-hidden bg-white flex flex-col" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                    <div className="flex-1 flex items-center justify-center" style={{ minHeight: 0 }}>
                      {isImage(docUrls[selectedDocId]) ? (
                        <img
                          src={docUrls[selectedDocId]}
                          alt="Document"
                          style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', width: '100%', height: '100%' }}
                        />
                      ) : (
                        <iframe
                          src={getPdfUrl(docUrls[selectedDocId])}
                          title="Document"
                          width="100%"
                          height="100%"
                          style={{ border: 'none' }}
                          allowFullScreen
                        />
                      )}
                    </div>
                    {/* Extract Button inside the card */}
                    <div className="p-4 border-t border-gray-200 bg-white" style={{ flexShrink: 0 }}>
                      <button
                        onClick={() => handleExtract(selectedDocId)}
                        disabled={extractingDocId === selectedDocId}
                        className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                          extractingDocId === selectedDocId
                            ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                            : 'bg-orange-500 text-white hover:bg-orange-600'
                        }`}
                      >
                        {extractingDocId === selectedDocId ? (
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                            Extracting...
                          </div>
                        ) : (
                          'Extract'
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Tabbed Interface */}
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">Document Analysis</h2>
                  <div className="w-full rounded-md bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                    {/* Tab Navigation */}
                    <div className="flex border-b border-gray-200 bg-gray-50">
                      <button
                        className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                          activeTab === 'workflow' 
                            ? 'bg-white text-orange-600 border-b-2 border-orange-500' 
                            : 'bg-transparent text-gray-500 hover:text-gray-700'
                        }`}
                        onClick={() => handleTabChange('workflow')}
                      >
                        Processing Workflow
                      </button>
                      <button
                        className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                          activeTab === 'extracted' 
                            ? 'bg-white text-orange-600 border-b-2 border-orange-500' 
                            : 'bg-transparent text-gray-500 hover:text-gray-700'
                        } ${selectedDocId && !showExtractedInfo[selectedDocId] ? 'opacity-50 cursor-not-allowed' : ''}`}
                        onClick={() => handleTabChange('extracted')}
                        disabled={!!(selectedDocId && !showExtractedInfo[selectedDocId])}
                      >
                        Extracted Information
                      </button>
                    </div>
                    
                    {/* Tab Content */}
                    <div className="card_body_custom" style={{ position: 'relative', minHeight: 650, height: 650, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: 'white' }}>
                      <div style={{ minHeight: 650, height: 650, maxHeight: 650, overflowY: 'auto' }}>
                        {activeTab === 'extracted' && (
                          <div className="p-6">
                            {!showExtractedInfo[selectedDocId] ? (
                              // Force redirect to workflow tab if extracted info is not available
                              <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                                style={{
                                  minHeight: 650,
                                  height: 650,
                                  color: '#b0b0b0',
                                  fontSize: '0.9rem',
                                  fontWeight: 400,
                                  letterSpacing: '0.01em',
                                  textAlign: 'center',
                                  background: 'inherit',
                                  fontFamily: 'Inter, sans-serif'
                                }}
                              >
                                <span>
                                  Processing not completed yet.
                                </span>
                                <span style={{ lineHeight: '1.2', marginTop: '10px' }}>
                                  Please complete the workflow first.
                                </span>
                                <button
                                  onClick={() => setActiveTab('workflow')}
                                  className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                                >
                                  Go to Workflow
                                </button>
                              </div>
                            ) : (
                              <>
                                <div className="text-lg font-bold mb-2">Extracted Fields</div>
                                <table className="w-full mb-6 text-sm">
                                  <thead>
                                    <tr className="text-left text-gray-500">
                                      <th className="py-2 text-left">Field</th>
                                      <th className="py-2 text-right">Extracted Value</th>
                                      <th className="py-2"></th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {getFieldData(selectedDocId).map((row) => (
                                      <tr key={row.field} className="border-b last:border-b-0">
                                        <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                        <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                                        <td className="py-2 text-left align-middle">
                                          {/* Info icon removed */}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </>
                            )}
                          </div>
                        )}
                        
                        {activeTab === 'workflow' && (
                          <div className="p-6">
                            {!isProcessing[selectedDocId] && !showExtractedInfo[selectedDocId] ? (
                              // Show initial message when workflow hasn't started
                              <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                                style={{
                                  minHeight: 650,
                                  height: 650,
                                  color: '#b0b0b0',
                                  fontSize: '0.9rem',
                                  fontWeight: 400,
                                  letterSpacing: '0.01em',
                                  textAlign: 'center',
                                  background: 'inherit',
                                  fontFamily: 'Inter, sans-serif'
                                }}
                              >
                                <span>
                                  Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
                                </span>
                                <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                                  to begin document processing!
                                </span>
                              </div>
                            ) : (
                              <DocumentWorkflow 
                                key={`${selectedDocId}-${extractionCount[selectedDocId] || 0}`}
                                isVisible={isProcessing[selectedDocId] || showExtractedInfo[selectedDocId]}
                                isAnimating={isWorkflowAnimating[selectedDocId]}
                                isCompleted={workflowCompleted[selectedDocId]}
                                documentType={selectedDocData.type}
                                onProcessingComplete={() => handleWorkflowComplete(selectedDocId)}
                                resetKey={selectedDocId}
                                extractedData={extractedData[selectedDocId]}
                              />
                            )}
                          </div>
                        )}
                      </div>  
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <div className="inline-block bg-gray-100 p-5 rounded-full mb-4">
                <Stethoscope className="h-12 w-12 text-gray-300" />
              </div>
              <p className="text-gray-500">Select a healthcare document to begin the extraction process</p>
            </div>
          )}
        </div>
      </div>
      <HealthcareFooter />
    </>
  );
};

export default HealthCareDocumentProcessing;
