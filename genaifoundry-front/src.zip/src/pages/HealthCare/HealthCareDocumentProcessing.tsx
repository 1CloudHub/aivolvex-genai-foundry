import { useState } from 'react';
import { 
  FileText,
  Home as HomeIcon,
  Info,
  Activity,
  Stethoscope,
  Pill,
  X
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';
import DocumentWorkflow from '../../components/ui/DocumentWorkflow';

interface DocumentType {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

interface ExtractedField {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'error';
  message?: string;
}

interface ProcessedDocument {
  id: string;
  name: string;
  type: string;
  status: 'processing' | 'completed' | 'failed';
  confidence: number;
  fields: ExtractedField[];
  uploadTime: Date;
}

const documentTypes: DocumentType[] = [
  {
    id: 'blood_biomarker',
    name: 'Blood Biomarker Report',
    description: 'Comprehensive blood test results and biomarker analysis',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <Activity className="w-6 h-6 text-white" />
    </div>
  },
  {
    id: 'cms_1500',
    name: 'CMS-1500 Claim Form',
    description: 'Standard healthcare claim form for insurance billing',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <FileText className="w-6 h-6 text-white" />
    </div>
  },
  {
    id: 'prescription',
    name: 'Prescription',
    description: 'Medication prescriptions and dosage instructions',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <Pill className="w-6 h-6 text-white" />
    </div>
  },
  {
    id: 'radiology_report',
    name: 'Radiology Report',
    description: 'Imaging study reports and diagnostic findings',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <X className="w-6 h-6 text-white" />
    </div>
  },
];

// Mock processed document data
const mockDocuments: Record<string, ProcessedDocument> = {
  blood_biomarker: {
    id: 'biomarker-001',
    name: 'Blood_Biomarker_Report.pdf',
    type: 'Blood Biomarker Report',
    status: 'completed',
    confidence: 94,
    fields: [
      { name: 'Patient Name', value: 'John Tan', status: 'success' },
      { name: 'Patient ID', value: 'P-34219', status: 'success' },
      { name: 'Date of Test', value: '2025-07-22', status: 'success' },
      { name: 'Provider', value: 'AnyDiagnostics Laboratory Services', status: 'success' },
      { name: 'Hemoglobin', value: '11.8 g/dL', status: 'warning' },
      { name: 'White Blood Cell', value: '9.6 ×10^9/L', status: 'success' },
      { name: 'Platelets', value: '210 ×10^9/L', status: 'success' },
      { name: 'Fasting Glucose', value: '138 mg/dL', status: 'warning' },
      { name: 'HbA1c', value: '6.8%', status: 'warning' },
      { name: 'ALT (Liver Enzyme)', value: '72 U/L', status: 'warning' },
      { name: 'Creatinine', value: '1.2 mg/dL', status: 'success' }
    ],
    uploadTime: new Date()
  },
  cms_1500: {
    id: 'cms-001',
    name: 'CMS1500_Claim_Form.pdf',
    type: 'CMS-1500 Claim Form',
    status: 'completed',
    confidence: 96,
    fields: [
      { name: 'Patient Name', value: 'Michael Chen', status: 'success' },
      { name: 'Patient DOB', value: '1980-05-15', status: 'success' },
      { name: 'Patient ID', value: 'P-10789', status: 'success' },
      { name: 'Provider Name', value: 'Dr. Anya Sharma', status: 'success' },
      { name: 'Provider NPI', value: '1234567890', status: 'success' },
      { name: 'Service Date', value: '2025-03-20', status: 'success' },
      { name: 'Diagnosis Code 1', value: 'I10', status: 'success' },
      { name: 'Diagnosis Code 2', value: 'R51.9', status: 'success' },
      { name: 'CPT Code 1', value: '99214', status: 'success' },
      { name: 'CPT Code 2', value: '36415', status: 'success' },
      { name: 'Total Charges', value: '$245.00', status: 'success' },
      { name: 'Insurance Provider', value: 'Blue Cross Blue Shield', status: 'success' }
    ],
    uploadTime: new Date()
  },
  prescription: {
    id: 'prescription-001',
    name: 'Prescription.pdf',
    type: 'Prescription',
    status: 'completed',
    confidence: 92,
    fields: [
      { name: 'Patient Name', value: 'Sarah Johnson', status: 'success' },
      { name: 'Patient DOB', value: '1973-08-22', status: 'success' },
      { name: 'Medication Name', value: 'Lisinopril', status: 'success' },
      { name: 'Strength', value: '20mg', status: 'success' },
      { name: 'Dosage Form', value: 'Tablet', status: 'success' },
      { name: 'Quantity', value: '30 tablets', status: 'success' },
      { name: 'Directions', value: 'Take 1 tablet daily by mouth', status: 'success' },
      { name: 'Prescriber Name', value: 'Dr. Anya Sharma', status: 'success' },
      { name: 'Prescriber NPI', value: '1234567890', status: 'success' },
      { name: 'Date Prescribed', value: '2025-03-15', status: 'success' },
      { name: 'Refills', value: '3 refills', status: 'success' },
      { name: 'Pharmacy', value: 'CVS Pharmacy', status: 'success' }
    ],
    uploadTime: new Date()
  },
  radiology_report: {
    id: 'radiology-001',
    name: 'Radiology_Report.pdf',
    type: 'Radiology Report',
    status: 'completed',
    confidence: 89,
    fields: [
      { name: 'Patient Name', value: 'Michael Chen', status: 'success' },
      { name: 'Patient ID', value: 'P-10789', status: 'success' },
      { name: 'Study Date', value: '2025-03-20', status: 'success' },
      { name: 'Study Type', value: 'Chest X-Ray (2 views)', status: 'success' },
      { name: 'Radiologist', value: 'Dr. Robert Wilson', status: 'success' },
      { name: 'Clinical History', value: 'Chest pain evaluation', status: 'success' },
      { name: 'Technique', value: 'PA and lateral chest radiographs', status: 'success' },
      { name: 'Findings', value: 'No acute cardiopulmonary abnormality', status: 'success' },
      { name: 'Cardiac Silhouette', value: 'Normal size and configuration', status: 'success' },
      { name: 'Lungs', value: 'Clear without infiltrate or effusion', status: 'success' },
      { name: 'Impression', value: 'Normal chest radiograph', status: 'success' },
      { name: 'Recommendations', value: 'No additional imaging required', status: 'success' }
    ],
    uploadTime: new Date()
  }
};

const docUrls: Record<string, string> = {
  blood_biomarker: '/HealthCare/Blood_Biomarker_Report.pdf',
  cms_1500: '/HealthCare/CMS1500_Claim_Form.pdf',
  prescription: '/HealthCare/Prescription.pdf',
  radiology_report: '/HealthCare/Radiology_Report.pdf'
};

const getPdfUrl = (url: string) => {
  if (url.endsWith('.pdf')) {
    return `${url}#toolbar=0&navpanes=0&scrollbar=0&view=FitH`;
  }
  return url;
};

// Healthcare-specific field data
const bloodBiomarkerFields = [
  { field: 'Patient Name', value: 'John Tan', note: 'Primary patient identifier' },
  { field: 'Patient ID', value: 'P-34219', note: 'Internal patient identifier' },
  { field: 'Date of Test', value: '2025-07-22', note: 'Date when blood was drawn' },
  { field: 'Provider', value: 'AnyDiagnostics Laboratory Services', note: 'Laboratory performing the tests' },
  { field: 'Hemoglobin', value: '11.8 g/dL', note: 'Red blood cell protein (Normal: 13.0-17.0 g/dL) - Low' },
  { field: 'White Blood Cell', value: '9.6 ×10^9/L', note: 'Immune system cells (Normal: 4.0-11.0 ×10^9/L) - Normal' },
  { field: 'Platelets', value: '210 ×10^9/L', note: 'Blood clotting cells (Normal: 150-400 ×10^9/L) - Normal' },
  { field: 'Fasting Glucose', value: '138 mg/dL', note: 'Blood sugar level (Normal: 70-100 mg/dL) - High' },
  { field: 'HbA1c', value: '6.8%', note: 'Diabetes control indicator (Normal: <5.7%) - High' },
  { field: 'ALT (Liver Enzyme)', value: '72 U/L', note: 'Liver function marker (Normal: <45 U/L) - High' },
  { field: 'Creatinine', value: '1.2 mg/dL', note: 'Kidney function marker (Normal: 0.7-1.3 mg/dL) - Normal' }
];

const cms1500Fields = [
  { field: 'Patient Name', value: 'Michael Chen', note: 'Primary patient identifier' },
  { field: 'Patient DOB', value: '1980-05-15', note: 'Date of birth for age verification' },
  { field: 'Patient ID', value: 'P-10789', note: 'Internal patient identifier' },
  { field: 'Provider Name', value: 'Dr. Anya Sharma', note: 'Treating physician' },
  { field: 'Provider NPI', value: '1234567890', note: 'National Provider Identifier' },
  { field: 'Service Date', value: '2025-03-20', note: 'Date of service provided' },
  { field: 'Diagnosis Code 1', value: 'I10', note: 'Primary diagnosis - Essential hypertension' },
  { field: 'Diagnosis Code 2', value: 'R51.9', note: 'Secondary diagnosis - Headache' },
  { field: 'CPT Code 1', value: '99214', note: 'Office visit, established patient, moderate complexity' },
  { field: 'CPT Code 2', value: '36415', note: 'Collection of venous blood' },
  { field: 'Total Charges', value: '$245.00', note: 'Total amount billed' },
  { field: 'Insurance Provider', value: 'Blue Cross Blue Shield', note: 'Primary insurance carrier' }
];

const prescriptionFields = [
  { field: 'Patient Name', value: 'Sarah Johnson', note: 'Primary patient identifier' },
  { field: 'Patient DOB', value: '1973-08-22', note: 'Date of birth for age verification' },
  { field: 'Medication Name', value: 'Lisinopril', note: 'Generic name of medication' },
  { field: 'Strength', value: '20mg', note: 'Dosage strength per unit' },
  { field: 'Dosage Form', value: 'Tablet', note: 'Physical form of medication' },
  { field: 'Quantity', value: '30 tablets', note: 'Total quantity prescribed' },
  { field: 'Directions', value: 'Take 1 tablet daily by mouth', note: 'Administration instructions' },
  { field: 'Prescriber Name', value: 'Dr. Anya Sharma', note: 'Prescribing physician' },
  { field: 'Prescriber NPI', value: '1234567890', note: 'National Provider Identifier' },
  { field: 'Date Prescribed', value: '2025-03-15', note: 'Date prescription was written' },
  { field: 'Refills', value: '3 refills', note: 'Number of refills authorized' },
  { field: 'Pharmacy', value: 'CVS Pharmacy', note: 'Dispensing pharmacy' }
];

const radiologyReportFields = [
  { field: 'Patient Name', value: 'Michael Chen', note: 'Primary patient identifier' },
  { field: 'Patient ID', value: 'P-10789', note: 'Internal patient identifier' },
  { field: 'Study Date', value: '2025-03-20', note: 'Date imaging was performed' },
  { field: 'Study Type', value: 'Chest X-Ray (2 views)', note: 'Type of imaging study' },
  { field: 'Radiologist', value: 'Dr. Robert Wilson', note: 'Interpreting radiologist' },
  { field: 'Clinical History', value: 'Chest pain evaluation', note: 'Reason for imaging' },
  { field: 'Technique', value: 'PA and lateral chest radiographs', note: 'Imaging technique used' },
  { field: 'Findings', value: 'No acute cardiopulmonary abnormality', note: 'Key imaging findings' },
  { field: 'Cardiac Silhouette', value: 'Normal size and configuration', note: 'Heart appearance' },
  { field: 'Lungs', value: 'Clear without infiltrate or effusion', note: 'Lung appearance' },
  { field: 'Impression', value: 'Normal chest radiograph', note: 'Radiologist interpretation' },
  { field: 'Recommendations', value: 'No additional imaging required', note: 'Follow-up recommendations' }
];

const HealthCareDocumentProcessing = () => {
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [extractingDocId, setExtractingDocId] = useState<string | null>(null);
  const [showExtractedInfo, setShowExtractedInfo] = useState<{[key: string]: boolean}>({});
  const [showWorkflow, setShowWorkflow] = useState<{[key: string]: boolean}>({});
  const [activeTab, setActiveTab] = useState<'extracted' | 'workflow'>('extracted');
  const navigate = useNavigate();
  const selectedDocData = selectedDocId ? mockDocuments[selectedDocId] : null;

  // Helper to check if the selected doc is an image
  const isImage = (url: string) => /\.(jpg|jpeg|png|webp|gif)$/i.test(url);

  // Healthcare API call function
  const makeHealthcareApiCall = (docId: string) => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    // Build request body for healthcare document processing
    const payload = {
      event_type: 'healthcare_document_processing',
      document_type: docId,
      patient_info: {
        name: 'Sarah Johnson',
        age: 52,
        medical_record_number: 'P-10456'
      },
      clinical_context: {
        department: 'Primary Care',
        provider: 'Dr. Anya Sharma',
        encounter_date: '2025-03-20'
      },
      extraction_goals: {
        ehr_population: true,
        insurance_filing: true,
        clinical_decision_support: true
      }
    };
    
    // Non-blocking API call
    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(error => {
      console.log('Healthcare document processing call made (non-blocking):', payload, error);
    });
  };

  // Handle extract button click
  const handleExtract = (docId: string) => {
    setExtractingDocId(docId);
    setShowExtractedInfo(prev => ({ ...prev, [docId]: false }));
    setShowWorkflow(prev => ({ ...prev, [docId]: true }));
    
    // Make healthcare API call
    makeHealthcareApiCall(docId);
    
    // Show extracted info after 5-6 seconds
    setTimeout(() => {
      setShowExtractedInfo(prev => ({ ...prev, [docId]: true }));
      setExtractingDocId(null);
    }, 5500); // 5.5 seconds
  };

  // Get field data based on document type
  const getFieldData = (docId: string) => {
    switch (docId) {
      case 'blood_biomarker':
        return bloodBiomarkerFields;
      case 'cms_1500':
        return cms1500Fields;
      case 'prescription':
        return prescriptionFields;
      case 'radiology_report':
        return radiologyReportFields;
      default:
        return [];
    }
  };

  return (
    <>
      <LoginNavbar />
      <div className="container py-6">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-2 -ml-1" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button 
                type="button" 
                onClick={() => navigate('/customer/sandbox/healthcarehome')} 
                className="flex items-center gap-2 text-orange-600 no-underline"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <HomeIcon size={16} className="relative top-[-1px]" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-gray-500">Document Processing Assistant</span>
            </li>
          </ol>
        </nav>
        
        {/* Page Title and Subtitle */}
        <div className="flex items-center gap-6 mb-4 ml-4">
          <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
            <Stethoscope className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
              Document Processing Assistant
            </h1>
            <p className="text-base text-gray-600">
              Extracts structured data from key healthcare documents including Blood Biomarker Reports, CMS-1500 Claim Forms, Prescriptions, and Radiology Reports. Enables EHR population, insurance filing, or clinical decision support workflows.
            </p>
          </div>
        </div>
        
        <div className="container mx-auto py-4 px-4 md:px-6 lg:px-8 min-h-screen">
          {/* Card Selector */}
          <div className="w-full mb-10">
            <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(220px, 1fr))` }}>
              {documentTypes.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => setSelectedDocId(doc.id)}
                  className="cursor-pointer transition-colors duration-200 p-4 rounded-lg bg-white"
                  style={{
                    backgroundColor: selectedDocId === doc.id ? 'rgb(255, 251, 245)' : 'white',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)',
                    border: selectedDocId === doc.id ? '2px solid #fb923c' : 'none'
                  }}
                >
                  <div className="flex items-start gap-4">
                    {doc.icon}
                    <div>
                      <h3 className="font-semibold text-base text-gray-800">{doc.name}</h3>
                      <p className="text-sm text-gray-500">{doc.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {selectedDocId && selectedDocData ? (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left: Document Display */}
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">{selectedDocData.type}</h2>
                  <div className="w-full h-[700px] rounded-lg overflow-hidden bg-white flex flex-col" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                    <div className="flex-1 flex items-center justify-center" style={{ minHeight: 0 }}>
                      {isImage(docUrls[selectedDocId]) ? (
                        <img
                          src={docUrls[selectedDocId]}
                          alt="Document"
                          style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', width: '100%', height: '100%' }}
                        />
                      ) : (
                        <iframe
                          src={getPdfUrl(docUrls[selectedDocId])}
                          title="Document"
                          width="100%"
                          height="100%"
                          style={{ border: 'none' }}
                          allowFullScreen
                        />
                      )}
                    </div>
                    {/* Extract Button inside the card */}
                    <div className="p-4 border-t border-gray-200 bg-white" style={{ flexShrink: 0 }}>
                      <button
                        onClick={() => handleExtract(selectedDocId)}
                        disabled={extractingDocId === selectedDocId}
                        className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                          extractingDocId === selectedDocId
                            ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                            : 'bg-orange-500 text-white hover:bg-orange-600'
                        }`}
                      >
                        {extractingDocId === selectedDocId ? (
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                            Extracting...
                          </div>
                        ) : (
                          'Extract'
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Tabbed Interface */}
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">Document Analysis</h2>
                  <div className="w-full rounded-lg bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                    {/* Tab Navigation */}
                    <div className="d-flex border-bottom" style={{ backgroundColor: '#f8f9fa' }}>
                      <button
                        className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeTab === 'extracted' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                        style={{ 
                          fontSize: '14px',
                          fontFamily: 'Inter, sans-serif',
                          borderBottom: activeTab === 'extracted' ? '2px solid #e87722' : 'none',
                          transition: 'all 0.2s ease'
                        }}
                        onClick={() => setActiveTab('extracted')}
                      >
                        Extracted Information
                      </button>
                      <button
                        className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeTab === 'workflow' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                        style={{ 
                          fontSize: '14px',
                          fontFamily: 'Inter, sans-serif',
                          borderBottom: activeTab === 'workflow' ? '2px solid #e87722' : 'none',
                          transition: 'all 0.2s ease'
                        }}
                        onClick={() => setActiveTab('workflow')}
                      >
                        Processing Workflow
                      </button>
                    </div>
                    
                    {/* Tab Content */}
                    <div className="card_body_custom" style={{ position: 'relative', minHeight: 600, height: 600, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: '#f8f9fa' }}>
                      <div style={{ minHeight: 600, height: 600, maxHeight: 600, overflowY: 'auto' }}>
                        {activeTab === 'extracted' && (
                          <div className="p-6">
                            {!showExtractedInfo[selectedDocId] ? (
                              // Placeholder content
                              <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                                style={{
                                  minHeight: 500,
                                  height: 500,
                                  color: '#b0b0b0',
                                  fontSize: '0.9rem',
                                  fontWeight: 400,
                                  letterSpacing: '0.01em',
                                  textAlign: 'center',
                                  background: 'inherit',
                                  fontFamily: 'Inter, sans-serif'
                                }}
                              >
                                <span>
                                  Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
                                </span>
                                <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                                  to begin document processing!
                                </span>
                              </div>
                            ) : (
                              <>
                                <div className="text-lg font-bold mb-2">Extracted Fields</div>
                                <table className="w-full mb-6 text-sm">
                                  <thead>
                                    <tr className="text-left text-gray-500">
                                      <th className="py-2 text-left">Field</th>
                                      <th className="py-2 text-right">Extracted Value</th>
                                      <th className="py-2"></th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {getFieldData(selectedDocId).map((row) => (
                                      <tr key={row.field} className="border-b last:border-b-0">
                                        <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                        <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                                        <td className="py-2 text-left align-middle">
                                          <span className="relative group cursor-pointer">
                                            <span className="flex items-center justify-center w-6 h-6 bg-white">
                                              <Info className="h-4 w-4 text-orange-500" />
                                            </span>
                                            <span
                                              className="absolute right-8 top-1/2 -translate-y-1/2 z-20 invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all duration-200 bg-white text-gray-900 text-xs rounded-lg px-4 py-3 min-w-[220px] max-w-[320px] whitespace-normal shadow-xl border-l-4 border-orange-400 flex flex-col items-start"
                                              style={{ boxShadow: '0 4px 24px 0 rgba(16,30,54,.12)' }}
                                            >
                                              <span className="text-sm text-gray-700">{row.note}</span>
                                            </span>
                                          </span>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </>
                            )}
                          </div>
                        )}
                        
                        {activeTab === 'workflow' && (
                          <div className="p-6">
                            {!showExtractedInfo[selectedDocId] ? (
                              // Placeholder content
                              <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                                style={{
                                  minHeight: 500,
                                  height: 500,
                                  color: '#b0b0b0',
                                  fontSize: '0.9rem',
                                  fontWeight: 400,
                                  letterSpacing: '0.01em',
                                  textAlign: 'center',
                                  background: 'inherit',
                                  fontFamily: 'Inter, sans-serif'
                                }}
                              >
                                <span>
                                  Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
                                </span>
                                <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                                  to begin document processing!
                                </span>
                              </div>
                            ) : (
                              <DocumentWorkflow 
                                isVisible={showWorkflow[selectedDocId] || false}
                                documentType={selectedDocData.type}
                              />
                            )}
                          </div>
                        )}
                      </div>  
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <div className="inline-block bg-gray-100 p-5 rounded-full mb-4">
                <Stethoscope className="h-12 w-12 text-gray-300" />
              </div>
              <p className="text-gray-500">Select a healthcare document to begin the extraction process</p>
            </div>
          )}
        </div>
      </div>
      <HealthcareFooter />
    </>
  );
};

export default HealthCareDocumentProcessing;
