import { Divider } from 'antd';
import { LinkIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

const HealthcareFooter = () => {
    const year = new Date().getFullYear();

    return (
        <footer className="w-full bg-[#f1f2f4] py-6 md:py-8">
            <div className="container mx-auto px-4 max-w-6xl">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 justify-evenly justify-items-center">
                    <div className="space-y-2">
                        <h3 className="text-base font-semibold text-[#282c34]">1Cloudhub AI Sandbox</h3>
                        <p className="text-sm text-[#282c34]">
                            Explore AI-powered tools designed to transform healthcare experiences
                        </p>
                    </div>
                
                    <div className="space-y-2">
                        <h3 className="text-base font-semibold text-[#282c34]">Healthcare Tools</h3>
                        <ul className="space-y-1 list-none p-0 m-0">
                            
                            <li className="p-0 m-0">
                                <Link to="/customer/sandbox/healthcarehome/hospital-assistant" className="text-sm text-[#282c34] transition-colors no-underline">
                                    Hospital Virtual Assistant
                                </Link>
                            </li>
                            <li className="p-0 m-0">
                                <Link to="/customer/sandbox/healthcarehome/clinical-notes" className="text-sm text-[#282c34] transition-colors no-underline">
                                    Clinical Note Generation
                                </Link>
                            </li>
                            <li className="p-0 m-0">
                                <Link to="/customer/sandbox/healthcarehome/document-processing" className="text-sm text-[#282c34] transition-colors no-underline">
                                    Document Processing Assistant
                                </Link>
                            </li>
                            <li className="p-0 m-0">
                                <Link to="/customer/sandbox/healthcarehome/medical-coding" className="text-sm text-[#282c34] transition-colors no-underline">
                                    Medical Coding Assistant
                                </Link>
                            </li>
                            <li className="p-0 m-0">
                                <Link to="/customer/sandbox/healthcarehome/research-assistant" className="text-sm text-[#282c34] transition-colors no-underline">
                                    Deep Research Assistant
                                </Link>
                            </li>
                            <li className="p-0 m-0">
                                <Link to="/customer/sandbox/healthcarehome/analytics-dashboard" className="text-sm text-[#282c34] transition-colors no-underline">
                                    Gen BI with QuickSight + Q
                                </Link>
                            </li>
                        </ul>
                    </div>
                
                    <div className="space-y-2">
                        <h3 className="text-base font-semibold text-[#282c34]">Resources</h3>
                        <ul className="space-y-1 list-none p-0 m-0">
                            <li className="p-0 m-0">
                                <a 
                                    href="https://www.1cloudhub.com/" 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="text-sm text-[#282c34] transition-colors flex items-center no-underline"
                                >
                                    1CloudHub
                                    <LinkIcon className='w-4 ml-2'/>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <Divider className="my-6" />
                
                <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                    <p className="text-xs text-[#282c34] text-center md:text-left">
                        © {year} 1Cloudhub Gen AI Healthcare Sandbox. All rights reserved.
                    </p>
                    <p className="text-xs text-[#282c34] text-center md:text-right">
                        <strong>Disclaimer:</strong> This is a demo sandbox environment. No real healthcare data is processed.
                    </p>
                </div>
            </div>
        </footer>
    )
}

export default HealthcareFooter;
