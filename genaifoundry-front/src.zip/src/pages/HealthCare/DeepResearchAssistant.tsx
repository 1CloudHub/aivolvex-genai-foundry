import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';
import { Home as HomeIcon, FileText, Search, ChevronDown, ChevronUp, ExternalLink, Calendar, Database } from 'lucide-react';

type SourceType = 'PubMed'|'WHO'|'Internal Docs';

interface ResearchItem { id: string; title: string; source: SourceType; date: string; confidence: number; summary: string; abstract: string; entities: { Drugs: string[]; Diseases: string[]; Genes: string[]; Outcomes: string[] }; url: string }

const mockResults: ResearchItem[] = [
  { id: 'r1', title: "Advances in the Treatment of Alzheimer's Disease", source: 'PubMed', date: '2023-07-23', confidence: 0.83, summary: 'Novel therapeutic classes including anti-amyloid mAbs; highlight paraminoacid clinical benefits.', abstract: 'Randomized controlled trials of anti-amyloid monoclonal antibodies demonstrate modest slowing of cognitive decline in early-stage Alzheimer\'s disease. Safety events include infusion reactions and ARIA.', entities: { Drugs: ['Lecanemab','Donanemab'], Diseases: ["Alzheimer's disease"], Genes: ['APOE'], Outcomes: ['Cognitive decline slowing','ARIA risk'] }, url: 'https://pubmed.ncbi.nlm.nih.gov' },
  { id: 'r2', title: 'WHO Guidelines for Dementia Diagnosis and Care', source: 'WHO', date: '2023-03-10', confidence: 0.82, summary: 'Updated diagnostic criteria and patient-centered care recommendations, including caregiver support.', abstract: 'WHO guidance emphasizes early detection, comprehensive assessment, non-pharmacologic interventions, and caregiver support. Pharmacotherapy considered case-by-case.', entities: { Drugs: ['Donepezil','Memantine'], Diseases: ['Dementia'], Genes: [], Outcomes: ['Quality of life','Caregiver burden'] }, url: 'https://www.who.int' },
  { id: 'r3', title: "Alzheimer's Disease Genomics Study", source: 'Internal Docs', date: '2022-11-25', confidence: 0.63, summary: 'Identified genetic risk factors and implications for therapies.', abstract: 'Multi-omic analysis implicates APOE variants and lipid metabolism pathways. Translational opportunities in risk stratification and prevention.', entities: { Drugs: [], Diseases: ["Alzheimer's disease"], Genes: ['APOE','CLU'], Outcomes: ['Risk stratification'] }, url: '#' },
];

const themeCard = 'rounded-2xl border bg-white p-4 shadow-sm';

// Add custom animation styles
const animationStyles = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeIn {
    animation: fadeIn 0.6s ease-out;
  }

  /* Document Analysis Animation */
  .document-scanner-container {
    position: relative;
    width: 120px;
    height: 120px;
    animation: float 3s ease-in-out infinite;
  }

  .document-stack {
    position: relative;
    width: 80px;
    height: 100px;
    margin: 0 auto;
  }

  .document {
    position: absolute;
    width: 60px;
    height: 80px;
    background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
    border: 2px solid #e2e8f0;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  }

  .document-1 {
    top: 0;
    left: 10px;
    animation: documentFloat 2s ease-in-out infinite;
  }

  .document-2 {
    top: 8px;
    left: 5px;
    animation: documentFloat 2s ease-in-out infinite 0.3s;
  }

  .document-3 {
    top: 16px;
    left: 0;
    animation: documentFloat 2s ease-in-out infinite 0.6s;
  }

  .scanning-beam {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, transparent, #f97316, #ea580c, #f97316, transparent);
    border-radius: 2px;
    box-shadow: 0 0 8px rgba(249, 115, 22, 0.6);
    animation: scanMove 2.5s ease-in-out infinite;
  }

  .analysis-icons {
    position: absolute;
    top: -20px;
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    height: 20px;
  }

  .analysis-icon {
    position: absolute;
    font-size: 16px;
    animation: iconFloat 3s ease-in-out infinite;
  }

  .analysis-icon-1 {
    left: 10%;
    animation-delay: 0s;
  }

  .analysis-icon-2 {
    left: 30%;
    animation-delay: 0.5s;
  }

  .analysis-icon-3 {
    left: 50%;
    animation-delay: 1s;
  }

  .analysis-icon-4 {
    left: 70%;
    animation-delay: 1.5s;
  }

  .data-flow {
    position: absolute;
    bottom: -30px;
    left: 0;
    width: 100%;
    height: 30px;
  }

  .data-line {
    position: absolute;
    height: 2px;
    background: linear-gradient(90deg, transparent, #f97316, transparent);
    border-radius: 1px;
    animation: dataFlow 2s ease-in-out infinite;
  }

  .data-line-1 {
    top: 5px;
    left: 20%;
    width: 60%;
    animation-delay: 0s;
  }

  .data-line-2 {
    top: 15px;
    left: 30%;
    width: 40%;
    animation-delay: 0.7s;
  }

  .data-line-3 {
    top: 25px;
    left: 40%;
    width: 20%;
    animation-delay: 1.4s;
  }


  @keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-8px); }
  }

  @keyframes documentFloat {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    50% { transform: translateY(-3px) rotate(1deg); }
  }

  @keyframes scanMove {
    0% { top: 0; opacity: 0; }
    20% { opacity: 1; }
    80% { opacity: 1; }
    100% { top: 100px; opacity: 0; }
  }

  @keyframes iconFloat {
    0%, 100% { transform: translateY(0px) scale(1); }
    50% { transform: translateY(-5px) scale(1.1); }
  }

  @keyframes dataFlow {
    0% { opacity: 0; transform: translateX(-20px); }
    50% { opacity: 1; transform: translateX(0); }
    100% { opacity: 0; transform: translateX(20px); }
  }

`;

/**
 * DeepResearchAssistant Component
 * 
 * A comprehensive research assistant for healthcare professionals to explore
 * scientific literature, clinical guidelines, and SOPs with AI-powered insights.
 * 
 * Features:
 * - Real-time research query processing
 * - Multi-source result aggregation
 * - Expandable findings with detailed source information
 * - Research metadata display including sub-questions and timestamps
 */
const DeepResearchAssistant: React.FC = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [results, setResults] = useState<ResearchItem[]>(mockResults);
  const [isLoading, setIsLoading] = useState(false);
  const [apiResponse, setApiResponse] = useState<any>(null);

  /**
   * Performs deep research query using the API
   * Sends research parameters and processes the response
   */
  const doSearch = async () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    try {
      const requestBody = {
        event_type: "deep_research",
        research_query: query,
        research_depth: "basic",
        max_sources: 3,
        time_range: "month",
        domain_filter: [],
        output_format: "summary"
      };

      console.log("Sending request:", requestBody);

      const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });

      const data = await response.json();
      console.log("API Response:", data);
      
      if (data.statusCode === 200) {
        const parsedBody = JSON.parse(data.body);
        setApiResponse(parsedBody);
        // Keep mock results for now, but you can replace with API data
        setResults(mockResults.filter(r =>
          r.title.toLowerCase().includes(query.toLowerCase()) || r.summary.toLowerCase().includes(query.toLowerCase())
        ));
      } else {
        console.error('API Error:', data);
        alert('Failed to fetch research results. Please try again.');
      }
    } catch (error) {
      console.error('Search Error:', error);
      alert('Failed to fetch research results. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Toggles the expanded state of a research finding or result
   * @param id - Unique identifier for the item to toggle
   */
  const toggleExpanded = (id: string) => setExpanded(prev => ({ ...prev, [id]: !prev[id] }));

  /**
   * Cleans and formats content by removing HTML tags, advertisements, and unwanted elements
   * @param content - Raw content string to clean
   * @returns Cleaned and formatted content
   */
  const cleanContent = (content: string): string => {
    if (!content) return '';
    
    let cleaned = content;
    
    // Remove HTML tags
    cleaned = cleaned.replace(/<[^>]*>/g, '');
    
    // Remove advertisement patterns
    cleaned = cleaned.replace(/Advertisement\s*!\[.*?\]\([^)]*\)/gi, '');
    cleaned = cleaned.replace(/!\[.*?\]\([^)]*doubleclick[^)]*\)/gi, '');
    cleaned = cleaned.replace(/!\[.*?\]\([^)]*pubads[^)]*\)/gi, '');
    cleaned = cleaned.replace(/!\[.*?\]\([^)]*gampad[^)]*\)/gi, '');
    
    // Remove image references
    cleaned = cleaned.replace(/!\[.*?\]\([^)]*\)/g, '');
    
    // Remove common web page elements
    cleaned = cleaned.replace(/Part of Springer Nature/gi, '');
    cleaned = cleaned.replace(/BMC/gi, '');
    cleaned = cleaned.replace(/Springer Nature/gi, '');
    
    // Remove excessive whitespace and normalize
    cleaned = cleaned.replace(/\s+/g, ' ');
    cleaned = cleaned.replace(/\n\s*\n/g, '\n\n');
    
    // Remove lines that are just punctuation or very short
    cleaned = cleaned.split('\n')
      .filter(line => {
        const trimmed = line.trim();
        return trimmed.length > 10 && 
               !trimmed.match(/^[^\w]*$/) && // Not just punctuation
               !trimmed.match(/^(Advertisement|BMC|Springer|Nature)$/i);
      })
      .join('\n');
    
    // Clean up the beginning and end
    cleaned = cleaned.trim();
    
    // If content is too short after cleaning, return a message
    if (cleaned.length < 50) {
      return 'Content extracted but may be incomplete. Please visit the source for full details.';
    }
    
    return cleaned;
  };


  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <style>{animationStyles}</style>
      <LoginNavbar />

      <div className="flex-grow container mx-auto px-4 py-4 max-w-6xl">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-4" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button
                type="button"
                onClick={() => navigate('/customer/sandbox/healthcarehome')}
                className="flex items-center text-gray-500 hover:text-gray-700"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <HomeIcon size={16} className="mr-1" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
                <span className="text-orange-600 font-medium">Deep Research Assistant</span>
            </li>
          </ol>
        </nav>

        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="ub-feature-icon mr-3">
              <FileText size={30} />
            </div>
            <div>
              <h2 className="mb-0 text-3xl font-bold">Deep Research Assistant</h2>
              <p className="text-gray-500">Explore scientific literature, clinical guidelines, and SOPs with AI-powered insights</p>
            </div>
          </div>
        </div>

        {/* Main Content - Full Width */}
        <div className="w-full">
            {/* Query Input Panel */}
          <div className={`${themeCard} mb-6`}>
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  placeholder="Ask anything, e.g., What are latest dementia treatments?"
                  value={query}
                  onChange={(e)=>setQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && !isLoading && doSearch()}
                  className="flex-1 bg-gray-100 rounded-lg px-4 py-3 text-sm border-0 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
               
                <button 
                  onClick={doSearch} 
                  disabled={isLoading || !query.trim()}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 text-white rounded-lg flex items-center gap-2" 
                  style={{height: '3.3rem'}}
                >
                  <Search size={16} /> Search
                </button>
              </div>
            </div>

            {/* Loading Animation */}
            {isLoading && (
              <div className={`${themeCard} mb-6`}>
                <div className="flex flex-col items-center justify-center py-20">
                  {/* Document Analysis Animation */}
                  <div className="relative mb-8">
                    <div className="document-scanner-container">
                      {/* Document Stack */}
                      <div className="document-stack">
                        <div className="document document-1"></div>
                        <div className="document document-2"></div>
                        <div className="document document-3"></div>
                      </div>
                      
                      {/* Scanning Beam */}
                      <div className="scanning-beam"></div>
                      
                      {/* Analysis Icons */}
                      <div className="analysis-icons">
                        <div className="analysis-icon analysis-icon-1">🔬</div>
                        <div className="analysis-icon analysis-icon-2">📊</div>
                        <div className="analysis-icon analysis-icon-3">🧬</div>
                        <div className="analysis-icon analysis-icon-4">💊</div>
                      </div>
                      
                      {/* Data Flow Lines */}
                      <div className="data-flow">
                        <div className="data-line data-line-1"></div>
                        <div className="data-line data-line-2"></div>
                        <div className="data-line data-line-3"></div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-gray-800 mb-3">Analyzing Research Database</h3>
                    <p className="text-sm text-gray-600 mb-6">Processing scientific literature, clinical trials, and medical guidelines...</p>
                    
                  </div>
                </div>
              </div>
            )}

            {/* Default Features Section - Show when no search has been performed */}
            {!apiResponse && !isLoading && (
              <div className={`${themeCard} mb-6`}>
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">Research Capabilities</h2>
                  <p className="text-gray-600">Explore our comprehensive research features and get started with your medical queries</p>
                </div>

                {/* Feature Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {/* PubMed Research */}
                  <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl p-6 border border-orange-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                        <Database size={20} className="text-white" />
                      </div>
                      <h3 className="font-semibold text-orange-900">PubMed Research</h3>
                    </div>
                    <p className="text-sm text-orange-800 mb-4">Access the latest peer-reviewed medical literature and clinical studies from PubMed database.</p>
                    <div className="text-xs text-orange-700">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Latest medical research</span>
                      </div>
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Clinical trial results</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Evidence-based medicine</span>
                      </div>
                    </div>
                  </div>

                  {/* WHO Guidelines */}
                  <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl p-6 border border-orange-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                        <FileText size={20} className="text-white" />
                      </div>
                      <h3 className="font-semibold text-orange-900">WHO Guidelines</h3>
                    </div>
                    <p className="text-sm text-orange-800 mb-4">Access World Health Organization guidelines, recommendations, and global health standards.</p>
                    <div className="text-xs text-orange-700">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Global health standards</span>
                      </div>
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Treatment protocols</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Public health policies</span>
                      </div>
                    </div>
                  </div>

                  {/* Clinical Guidelines */}
                  <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl p-6 border border-orange-200">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                        <Search size={20} className="text-white" />
                      </div>
                      <h3 className="font-semibold text-orange-900">Clinical Guidelines</h3>
                    </div>
                    <p className="text-sm text-orange-800 mb-4">Comprehensive clinical practice guidelines and standard operating procedures.</p>
                    <div className="text-xs text-orange-700">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Best practices</span>
                      </div>
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Diagnostic criteria</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <span>Treatment algorithms</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Example Queries */}
                <div className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-xl p-6 border border-orange-200">
                  <h3 className="font-semibold text-orange-900 mb-4 flex items-center gap-2">
                    <Search size={18} className="text-orange-600" />
                    Try These Example Queries
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <button 
                        onClick={() => setQuery("Latest treatments for diabetes")}
                        className="w-full text-left p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-300 hover:shadow-sm transition-all group"
                      >
                        <div className="font-medium text-gray-900 group-hover:text-orange-700">Latest treatments for diabetes</div>
                        <div className="text-xs text-gray-600 mt-1">Explore new medications and therapies</div>
                      </button>
                      <button 
                        onClick={() => setQuery("New cancer immunotherapy drugs")}
                        className="w-full text-left p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-300 hover:shadow-sm transition-all group"
                      >
                        <div className="font-medium text-gray-900 group-hover:text-orange-700">New cancer immunotherapy drugs</div>
                        <div className="text-xs text-gray-600 mt-1">Latest developments in cancer treatment</div>
                      </button>
                    </div>
                    <div className="space-y-3">
                      <button 
                        onClick={() => setQuery("Mental health interventions for depression")}
                        className="w-full text-left p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-300 hover:shadow-sm transition-all group"
                      >
                        <div className="font-medium text-gray-900 group-hover:text-orange-700">Mental health interventions for depression</div>
                        <div className="text-xs text-gray-600 mt-1">Evidence-based treatment approaches</div>
                      </button>
                      <button 
                        onClick={() => setQuery("Healthcare AI applications in diagnosis")}
                        className="w-full text-left p-3 bg-white rounded-lg border border-orange-200 hover:border-orange-300 hover:shadow-sm transition-all group"
                      >
                        <div className="font-medium text-gray-900 group-hover:text-orange-700">Healthcare AI applications in diagnosis</div>
                        <div className="text-xs text-gray-600 mt-1">Technology in medical practice</div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* API Response Results */}
            {apiResponse && !isLoading && (
              <div className={`${themeCard} mb-6 animate-fadeIn`}>
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">Research Results</h2>
                </div>
                
                {/* Parse and display research findings or validation results */}
                {(() => {
                  const reportText = apiResponse.report || '';
                  
                  // Check if this is a validation response
                  if (apiResponse.validation_result && !apiResponse.validation_result.is_medical) {
                    return (
                      <div className="bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200 rounded-lg p-6">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                            <span className="text-orange-600 text-lg">🔍</span>
                          </div>
                          <h3 className="text-lg font-semibold text-orange-800">Query Validation</h3>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-sm text-orange-700 mb-2">
                            <strong>Your Query:</strong> "{apiResponse.research_query}"
                          </p>
                          <div className="flex items-center gap-2 mb-3">
                            <span className="text-orange-500 text-lg">ℹ️</span>
                            <span className="font-medium text-orange-800">Please provide a medical/healthcare related query</span>
                          </div>
                        </div>
                        
                        <div className="bg-white rounded-lg p-4 border border-orange-200">
                          <h4 className="font-semibold text-gray-800 mb-3">Please provide a medical/healthcare query such as:</h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <h5 className="font-medium text-gray-700 mb-2">Medical Topics:</h5>
                              <ul className="space-y-1 text-gray-600">
                                <li>• Diseases, conditions, and treatments</li>
                                <li>• Medications and pharmaceuticals</li>
                                <li>• Medical procedures and surgeries</li>
                                <li>• Clinical trials and research</li>
                              </ul>
                            </div>
                            <div>
                              <h5 className="font-medium text-gray-700 mb-2">Healthcare Topics:</h5>
                              <ul className="space-y-1 text-gray-600">
                                <li>• Healthcare systems and policies</li>
                                <li>• Public health initiatives</li>
                                <li>• Healthcare technologies</li>
                                <li>• Medical education and training</li>
                              </ul>
                            </div>
                          </div>
                          
                          <div className="mt-4">
                            <h5 className="font-medium text-gray-700 mb-2">Example Queries:</h5>
                            <div className="space-y-1 text-sm text-gray-600">
                              <div>• "Latest treatments for diabetes"</div>
                              <div>• "New cancer immunotherapy drugs"</div>
                              <div>• "Healthcare AI applications in diagnosis"</div>
                              <div>• "Mental health interventions for depression"</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  }
                  
                  // Parse findings in the format: ### Finding X: Title [X]
                  const findings: Array<{ 
                    title: string; 
                    sources: Array<{ url: string; domain: string; content: string }>; 
                    index: number 
                  }> = [];
                  
                  // Split by finding blocks - use more specific regex to capture the full finding
                  const findingBlocks = reportText.split(/### Finding \d+:/);
                  
                  findingBlocks.forEach((block: string, blockIndex: number) => {
                    if (block.trim() && blockIndex > 0) { // Skip first empty block
                      
                      const lines = block.split('\n').map((line: string) => line.trim()).filter((line: string) => line);
                      
                      let title = '';
                      const sources: Array<{ url: string; domain: string; content: string }> = [];
                      let currentSource: { url: string; domain: string; content: string } | null = null;
                      let contentLines: string[] = [];
                      let isFirstLine = true;
                      
                      lines.forEach((line: string, lineIndex: number) => {
                        // Stop processing if we hit the Sources section
                        if (line.startsWith('## Sources')) {
                          return;
                        }
                        
                        if (line.startsWith('**Source:**')) {
                          // Save previous source if exists
                          if (currentSource) {
                            (currentSource as { url: string; domain: string; content: string }).content = contentLines.join('\n').trim();
                            sources.push(currentSource);
                            contentLines = [];
                          }
                          
                          const url = line.replace('**Source:**', '').trim();
                          const domain = url ? new URL(url).hostname.replace('www.', '') : 'Unknown';
                          currentSource = { url, domain, content: '' };
                        } else if (currentSource && line && !line.startsWith('**Source:**') && !line.startsWith('##')) {
                          // Collect content lines for current source, but stop at Sources section
                          contentLines.push(line);
                        } else if (!title && line && !line.startsWith('**Source:**') && !line.startsWith('##') && isFirstLine) {
                          // Extract title from the first non-source, non-section line
                          title = line.replace(/\[\d+\]$/, '').trim(); // Remove [X] suffix
                          isFirstLine = false;
                        }
                      });
                      
                      // Add the last source with its content
                      if (currentSource) {
                        (currentSource as { url: string; domain: string; content: string }).content = contentLines.join('\n').trim();
                        sources.push(currentSource);
                      }
                      
                      // Only add finding if we have a title or sources
                      if (title || sources.length > 0) {
                        findings.push({ title, sources, index: blockIndex });
                      }
                    }
                  });

                  return findings.map((finding, findingIndex: number) => (
                    <div key={findingIndex} className="border-b last:border-b-0 py-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-3">
                            <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 font-semibold text-sm">
                              {findingIndex + 1}
                            </div>
                            <h3 className="font-semibold text-gray-900 text-lg">{finding.title}</h3>
                          </div>
                          
                          {/* Display sources */}
                          {finding.sources.map((source, sourceIndex: number) => (
                            <div key={sourceIndex} className="mb-4 p-5 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                              <div className="flex items-center gap-2 mb-3">
                                <span className="text-xs px-3 py-1 rounded-full bg-white text-gray-700 border font-medium shadow-sm">
                                  {source.domain}
                                </span>
                              </div>
                              
                              {/* Source URL */}
                              <div className="mb-4">
                                <a 
                                  href={source.url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-blue-600 hover:text-blue-800 hover:underline text-sm break-all flex items-center gap-1 group"
                                >
                                  <span className="truncate">{source.url}</span>
                                  <ExternalLink size={12} className="text-blue-500 group-hover:text-blue-700 flex-shrink-0" />
                                </a>
                              </div>
                              
                              {/* Source Content */}
                              <div className="text-sm text-gray-700">
                                {source.content === 'No content available' ? (
                                  <div className="text-gray-500 italic bg-gray-200 p-3 rounded border-l-4 border-gray-400">
                                    <div className="flex items-center gap-2">
                                      <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                                      Content not available for this source
                                    </div>
                                  </div>
                                ) : (
                                  <div className="whitespace-pre-wrap bg-white p-3 rounded border-l-4 border-blue-400">
                                    {expanded[`finding-${findingIndex}`] ? cleanContent(source.content) : 
                                      cleanContent(source.content).length > 500 ? 
                                        cleanContent(source.content).substring(0, 500) + '...' : 
                                        cleanContent(source.content)
                                    }
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        <div className="text-right flex-shrink-0">
                          <button 
                            onClick={() => toggleExpanded(`finding-${findingIndex}`)} 
                            className="text-orange-600 text-sm inline-flex items-center gap-1 hover:text-orange-700"
                          >
                            {expanded[`finding-${findingIndex}`] ? <>Collapse <ChevronUp size={14}/></> : <>Expand <ChevronDown size={14}/></>}
                          </button>
                        </div>
                      </div>
                      
                    </div>
                  ));
                })()}
              </div>
            )}



        </div>
      </div>

      <HealthcareFooter />
    </div>
  );
};

export default DeepResearchAssistant;


