import React, { useState, useEffect, useRef } from 'react';
import { FileText, Home, Clock, User, Stethoscope, Calendar, MapPin, Filter, Download, Share2, CheckCircle, AlertCircle, XCircle, Play, Pause, Volume2, Edit3, Save, X, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';

// TypeScript Interfaces
export interface EncounterSummary {
  id: string;
  title: string;
  chiefComplaint: string;
  durationSec: number;
  tags: string[];
}

export interface EncounterMeta {
  encounterId: string;
  patient: { id: string; display: string; age: number; sex: 'M'|'F'|'Other' };
  clinician: { name: string; specialty: string };
  datetime: string;
  visitType: 'Outpatient'|'Telehealth'|'Inpatient';
  location?: string;
}

export interface TranscriptTurn {
  id: string;
  t: string;
  tSec: number; // seconds from audio start
  speaker: 'DOCTOR'|'PATIENT';
  text: string;
}

export type ClinicalEntityType =
  | 'Symptom' | 'Medication' | 'Allergy' | 'FamilyHistory' | 'SocialHistory'
  | 'Diagnosis' | 'Order' | 'Vital' | 'RiskFlag';

export interface HighlightSpan {
  turnId: string;
  start: number;
  end: number;
  type: ClinicalEntityType;
  label?: string;
}

export interface SoapNote {
  subjective: {
    chiefComplaint: string;
    hpi: string;
    pmh?: string;
    meds?: string;
    allergies?: string;
    fh?: string;
    sh?: string;
  };
  objective: {
    vitals?: string;
    exam?: string;
    labs?: string;
    imaging?: string;
  };
  assessment: {
    summary: string;
    diagnoses: Array<{ icd10?: string; name: string; confidence?: number }>;
    differentials?: string[];
  };
  plan: {
    medications?: string[];
    orders?: string[];
    followUp?: string;
    education?: string;
  };
}

export interface CodingRow { 
  code: string; 
  description: string; 
  confidence?: number; 
  rationale?: string; 
}

export interface CodingSuggestion {
  icd10: CodingRow[];
  cpt: CodingRow[];
  hcpcs: CodingRow[];
}

export interface TimelineEvent {
  t: number;
  type: ClinicalEntityType;
  label: string;
}

export interface QaCheck { 
  label: string; 
  state: 'pass'|'warn'|'fail'; 
  note?: string; 
}

// Mock Data for Different Encounters
const encounterData = {
  e1: {
    // Fatigue Encounter
    meta: {
      "encounterId":"e1",
      "patient":{"id":"P-10293","display":"Rob M.","age":48,"sex":"M"},
      "clinician":{"name":"Dr. Anya Sharma","specialty":"General Practice"},
      "datetime":"2025-07-08T10:00:00Z",
      "visitType":"Outpatient",
      "location":"General Practice Clinic"
    },
    transcript: [
      {"id":"t1","t":"00:00","tSec":0,"speaker":"DOCTOR" as const,"text":"Good morning, what brings you in today?"},
      {"id":"t2","t":"00:05","tSec":5,"speaker":"PATIENT" as const,"text":"I've had constant fatigue for months, worse by afternoon."},
      {"id":"t3","t":"00:20","tSec":20,"speaker":"DOCTOR" as const,"text":"Any headaches, weight changes, sleep issues?"},
      {"id":"t4","t":"00:28","tSec":28,"speaker":"PATIENT" as const,"text":"Mild headaches weekly, 2–3 kg weight gain, not refreshed after sleep."},
      {"id":"t5","t":"00:45","tSec":45,"speaker":"DOCTOR" as const,"text":"How's appetite and bowel habits?"},
      {"id":"t6","t":"00:51","tSec":51,"speaker":"PATIENT" as const,"text":"Appetite unchanged, bowel movements normal."},
      {"id":"t7","t":"01:04","tSec":64,"speaker":"DOCTOR" as const,"text":"Any hair changes or sensitivity to cold?"},
      {"id":"t8","t":"01:10","tSec":70,"speaker":"PATIENT" as const,"text":"Hair feels thinner; I feel cold more than others."},
      {"id":"t9","t":"01:30","tSec":90,"speaker":"DOCTOR" as const,"text":"Past medical history, medications, allergies?"},
      {"id":"t10","t":"01:36","tSec":96,"speaker":"PATIENT" as const,"text":"Borderline cholesterol previously; only multivitamin; allergic to penicillin (rash)."},
      {"id":"t11","t":"01:55","tSec":115,"speaker":"DOCTOR" as const,"text":"Family history of thyroid disease?"},
      {"id":"t12","t":"02:00","tSec":120,"speaker":"PATIENT" as const,"text":"My mother has hypothyroidism."},
      {"id":"t13","t":"02:15","tSec":135,"speaker":"DOCTOR" as const,"text":"Work stress or lifestyle changes?"},
      {"id":"t14","t":"02:22","tSec":142,"speaker":"PATIENT" as const,"text":"Some project deadlines; activity reduced, no major changes."},
      {"id":"t15","t":"02:40","tSec":160,"speaker":"DOCTOR" as const,"text":"We'll check labs: TSH, Free T3/T4, Ferritin, B12, Vitamin D, CMP."},
      {"id":"t16","t":"03:00","tSec":180,"speaker":"PATIENT" as const,"text":"Okay."},
      {"id":"t17","t":"03:15","tSec":195,"speaker":"DOCTOR" as const,"text":"If labs unrevealing, we may consider a sleep study."},
      {"id":"t18","t":"03:25","tSec":205,"speaker":"PATIENT" as const,"text":"Understood."},
      {"id":"t19","t":"03:40","tSec":220,"speaker":"DOCTOR" as const,"text":"Any chest pain, shortness of breath, or dizziness?"},
      {"id":"t20","t":"03:46","tSec":226,"speaker":"PATIENT" as const,"text":"No."},
      {"id":"t21","t":"03:55","tSec":235,"speaker":"DOCTOR" as const,"text":"We'll review results in 3 days."}
    ],
    highlights: [
      {"turnId":"t2","start":12,"end":19,"type":"Symptom" as const,"label":"fatigue"},
      {"turnId":"t4","start":4,"end":13,"type":"Symptom" as const,"label":"headaches"},
      {"turnId":"t4","start":23,"end":28,"type":"Symptom" as const,"label":"weight gain"},
      {"turnId":"t6","start":21,"end":35,"type":"FamilyHistory" as const,"label":"hypothyroidism"},
      {"turnId":"t6","start":41,"end":45,"type":"Symptom" as const,"label":"cold intolerance"},
      {"turnId":"t7","start":11,"end":14,"type":"Order" as const,"label":"TSH"}
    ],
    soap: {
      "subjective": {
        "chiefComplaint":"Persistent fatigue",
        "hpi":"Fatigue for ~6 months, worse as day progresses; mild weekly headaches; unrefreshing sleep; 2–3 kg weight gain.",
        "pmh":"Borderline cholesterol 2 yrs ago.",
        "allergies":"Penicillin (rash)",
        "fh":"Mother with hypothyroidism.",
        "sh":"Ex-smoker; moderate alcohol; active job stress."
      },
      "objective": {
        "vitals":"Not recorded today",
        "exam":"No acute distress; hair thinning noted.",
        "labs":"Ordered: TSH, Free T3/T4, Ferritin, B12, Vitamin D, CMP"
      },
      "assessment": {
        "summary":"Persistent fatigue with cold intolerance, hair thinning, weight gain → consider hypothyroidism; rule out anemia and B12 deficiency.",
        "diagnoses":[
          {"icd10":"R53.83","name":"Other fatigue","confidence":0.92},
          {"icd10":"E03.9","name":"Hypothyroidism, unspecified (suspected)","confidence":0.78}
        ],
        "differentials":["Anemia","Vitamin D deficiency","Sleep apnea"]
      },
      "plan": {
        "medications":[],
        "orders":["TSH","Free T3/T4","Ferritin","B12","Vitamin D","CMP"],
        "followUp":"Review labs in 3 days; consider sleep study if labs unrevealing.",
        "education":"Sleep hygiene; gradual activity resumption."
      }
    },
    codes: {
      "icd10":[
        {"code":"R53.83","description":"Other fatigue","confidence":0.92,"rationale":"Primary symptom captured across transcript."},
        {"code":"E03.9","description":"Hypothyroidism, unspecified (suspected)","confidence":0.78,"rationale":"Cold intolerance + hair thinning + family history."}
      ],
      "cpt":[
        {"code":"99203","description":"Office visit, new patient, low-moderate complexity","confidence":0.7,"rationale":"New patient visit with moderate complexity"},
        {"code":"36415","description":"Collection of venous blood","confidence":0.8,"rationale":"Blood collection for lab orders"}
      ],
      "hcpcs":[
        {"code":"G0447","description":"Face-to-face behavioral counseling, obesity (if applicable)","confidence":0.3,"rationale":"Potential weight management counseling"}
      ]
    },
    timeline: [
      {"t":5,"type":"Symptom" as const,"label":"Fatigue"},
      {"t":48,"type":"Symptom" as const,"label":"Headaches"},
      {"t":86,"type":"Symptom" as const,"label":"Cold intolerance"},
      {"t":190,"type":"Order" as const,"label":"TSH, T3/T4, Ferritin, B12, Vit D"}
    ],
    qa: [
      {"label":"Patient identified","state":"pass" as const},
      {"label":"Allergies captured","state":"pass" as const},
      {"label":"Medications reviewed","state":"warn" as const,"note":"Only multivitamin reported"},
      {"label":"Differential considered","state":"pass" as const},
      {"label":"Billing codes suggested","state":"pass" as const},
      {"label":"Documentation complete","state":"fail" as const,"note":"Missing vital signs"}
    ]
  },
     e2: {
     // Hypertension Follow-up
     meta: {
       "encounterId":"e2",
       "patient":{"id":"P-10456","display":"Sarah Johnson","age":52,"sex":"F"},
       "clinician":{"name":"Dr. Anya Sharma","specialty":"General Practice"},
       "datetime":"2025-07-15T14:30:00Z",
       "visitType":"Outpatient",
       "location":"General Practice Clinic"
     },
    transcript: [
      {"id":"t1","t":"00:00","tSec":0,"speaker":"DOCTOR" as const,"text":"Hello Rob, how have you been feeling since our last visit?"},
      {"id":"t2","t":"00:05","tSec":5,"speaker":"PATIENT" as const,"text":"Still having some headaches, and my blood pressure has been high."},
      {"id":"t3","t":"00:15","tSec":15,"speaker":"DOCTOR" as const,"text":"What readings have you been getting at home?"},
      {"id":"t4","t":"00:22","tSec":22,"speaker":"PATIENT" as const,"text":"Usually around 150/95, sometimes higher in the morning."},
      {"id":"t5","t":"00:35","tSec":35,"speaker":"DOCTOR" as const,"text":"Any chest pain, shortness of breath, or vision changes?"},
      {"id":"t6","t":"00:42","tSec":42,"speaker":"PATIENT" as const,"text":"No chest pain, but I do get short of breath climbing stairs."},
      {"id":"t7","t":"00:55","tSec":55,"speaker":"DOCTOR" as const,"text":"Are you taking the lisinopril I prescribed?"},
      {"id":"t8","t":"01:05","tSec":65,"speaker":"PATIENT" as const,"text":"Yes, 10mg daily, but I still feel the pressure is high."},
      {"id":"t9","t":"01:20","tSec":80,"speaker":"DOCTOR" as const,"text":"Let me check your blood pressure today."},
      {"id":"t10","t":"01:30","tSec":90,"speaker":"DOCTOR" as const,"text":"It's 155/98. We need to adjust your medication."},
      {"id":"t11","t":"01:45","tSec":105,"speaker":"PATIENT" as const,"text":"What do you recommend?"},
      {"id":"t12","t":"01:55","tSec":115,"speaker":"DOCTOR" as const,"text":"I'll increase lisinopril to 20mg and add hydrochlorothiazide 12.5mg."},
      {"id":"t13","t":"02:10","tSec":130,"speaker":"PATIENT" as const,"text":"Will that help with the headaches too?"},
      {"id":"t14","t":"02:18","tSec":138,"speaker":"DOCTOR" as const,"text":"Yes, controlling your blood pressure should reduce the headaches."},
      {"id":"t15","t":"02:30","tSec":150,"speaker":"DOCTOR" as const,"text":"Let's also check your kidney function and electrolytes."},
      {"id":"t16","t":"02:45","tSec":165,"speaker":"PATIENT" as const,"text":"When should I come back?"},
      {"id":"t17","t":"02:55","tSec":175,"speaker":"DOCTOR" as const,"text":"In 2 weeks to recheck your blood pressure."}
    ],
    highlights: [
      {"turnId":"t2","start":25,"end":32,"type":"Symptom" as const,"label":"headaches"},
      {"turnId":"t2","start":45,"end":55,"type":"Symptom" as const,"label":"high blood pressure"},
      {"turnId":"t4","start":8,"end":15,"type":"Vital" as const,"label":"150/95"},
      {"turnId":"t6","start":35,"end":45,"type":"Symptom" as const,"label":"shortness of breath"},
      {"turnId":"t8","start":8,"end":15,"type":"Medication" as const,"label":"lisinopril 10mg"},
      {"turnId":"t10","start":8,"end":15,"type":"Vital" as const,"label":"155/98"},
      {"turnId":"t12","start":25,"end":35,"type":"Medication" as const,"label":"lisinopril 20mg"},
      {"turnId":"t12","start":45,"end":60,"type":"Medication" as const,"label":"hydrochlorothiazide 12.5mg"},
      {"turnId":"t15","start":25,"end":35,"type":"Order" as const,"label":"kidney function"}
    ],
    soap: {
      "subjective": {
        "chiefComplaint":"Hypertension follow-up",
        "hpi":"Patient reports persistent headaches and elevated blood pressure readings at home (150/95). Taking lisinopril 10mg daily but pressure remains high.",
        "pmh":"Borderline cholesterol, fatigue evaluation",
        "allergies":"Penicillin (rash)",
        "fh":"Mother with hypothyroidism",
        "sh":"Ex-smoker; moderate alcohol; active job stress"
      },
      "objective": {
        "vitals":"BP: 155/98 mmHg",
        "exam":"No acute distress; no edema; heart sounds normal",
        "labs":"Ordered: CMP, electrolytes, creatinine"
      },
      "assessment": {
        "summary":"Uncontrolled hypertension despite lisinopril 10mg daily. Blood pressure readings consistently elevated.",
        "diagnoses":[
          {"icd10":"I10","name":"Essential hypertension","confidence":0.95},
          {"icd10":"R51.9","name":"Headache, unspecified","confidence":0.85}
        ],
        "differentials":["Secondary hypertension","Medication non-compliance"]
      },
      "plan": {
        "medications":["Lisinopril 20mg daily","Hydrochlorothiazide 12.5mg daily"],
        "orders":["CMP","Electrolytes","Creatinine"],
        "followUp":"Return in 2 weeks for blood pressure recheck",
        "education":"Low sodium diet, regular blood pressure monitoring"
      }
    },
    codes: {
      "icd10":[
        {"code":"I10","description":"Essential hypertension","confidence":0.95,"rationale":"Consistently elevated blood pressure readings"},
        {"code":"R51.9","description":"Headache, unspecified","confidence":0.85,"rationale":"Patient reports persistent headaches"}
      ],
      "cpt":[
        {"code":"99213","description":"Office visit, established patient, low complexity","confidence":0.8,"rationale":"Follow-up visit with medication adjustment"},
        {"code":"36415","description":"Collection of venous blood","confidence":0.7,"rationale":"Lab work ordered"}
      ],
      "hcpcs":[]
    },
    timeline: [
      {"t":5,"type":"Symptom" as const,"label":"Headaches"},
      {"t":22,"type":"Vital" as const,"label":"BP 150/95"},
      {"t":42,"type":"Symptom" as const,"label":"Shortness of breath"},
      {"t":65,"type":"Medication" as const,"label":"Lisinopril 10mg"},
      {"t":90,"type":"Vital" as const,"label":"BP 155/98"},
      {"t":115,"type":"Medication" as const,"label":"Lisinopril 20mg + HCTZ"},
      {"t":150,"type":"Order" as const,"label":"Kidney function labs"}
    ],
    qa: [
      {"label":"Patient identified","state":"pass" as const},
      {"label":"Blood pressure recorded","state":"pass" as const},
      {"label":"Medication review completed","state":"pass" as const},
      {"label":"Treatment plan updated","state":"pass" as const},
      {"label":"Follow-up scheduled","state":"pass" as const},
      {"label":"Labs ordered","state":"pass" as const}
    ]
  },
     e3: {
     // Chest Pain Evaluation
     meta: {
       "encounterId":"e3",
       "patient":{"id":"P-10789","display":"Michael Chen","age":45,"sex":"M"},
       "clinician":{"name":"Dr. Anya Sharma","specialty":"General Practice"},
       "datetime":"2025-07-20T09:15:00Z",
       "visitType":"Outpatient",
       "location":"Urgent Care Clinic"
     },
    transcript: [
      {"id":"t1","t":"00:00","tSec":0,"speaker":"DOCTOR" as const,"text":"What brings you in today, Rob?"},
      {"id":"t2","t":"00:05","tSec":5,"speaker":"PATIENT" as const,"text":"I've been having chest pain for the past 2 hours."},
      {"id":"t3","t":"00:12","tSec":12,"speaker":"DOCTOR" as const,"text":"Can you describe the pain? Where exactly is it?"},
      {"id":"t4","t":"00:20","tSec":20,"speaker":"PATIENT" as const,"text":"It's in the center of my chest, feels like pressure, and it radiates to my left arm."},
      {"id":"t5","t":"00:35","tSec":35,"speaker":"DOCTOR" as const,"text":"How severe is the pain on a scale of 1-10?"},
      {"id":"t6","t":"00:42","tSec":42,"speaker":"PATIENT" as const,"text":"About a 7. It's worse when I take a deep breath."},
      {"id":"t7","t":"00:55","tSec":55,"speaker":"DOCTOR" as const,"text":"Any shortness of breath, sweating, or nausea?"},
      {"id":"t8","t":"01:05","tSec":65,"speaker":"PATIENT" as const,"text":"Yes, I'm short of breath and feeling sweaty."},
      {"id":"t9","t":"01:15","tSec":75,"speaker":"DOCTOR" as const,"text":"This is concerning. Let me get an ECG right away."},
      {"id":"t10","t":"01:30","tSec":90,"speaker":"DOCTOR" as const,"text":"The ECG shows some ST changes. We need to check your troponin levels."},
      {"id":"t11","t":"01:45","tSec":105,"speaker":"PATIENT" as const,"text":"What does that mean?"},
      {"id":"t12","t":"01:55","tSec":115,"speaker":"DOCTOR" as const,"text":"It could indicate a heart problem. I'm ordering blood tests and a chest X-ray."},
      {"id":"t13","t":"02:10","tSec":130,"speaker":"PATIENT" as const,"text":"Should I be worried?"},
      {"id":"t14","t":"02:18","tSec":138,"speaker":"DOCTOR" as const,"text":"We need to rule out serious causes. I'll also give you aspirin and nitroglycerin."},
      {"id":"t15","t":"02:35","tSec":155,"speaker":"PATIENT" as const,"text":"Will I need to stay here?"},
      {"id":"t16","t":"02:45","tSec":165,"speaker":"DOCTOR" as const,"text":"Yes, we need to monitor you until the test results come back."}
    ],
    highlights: [
      {"turnId":"t2","start":25,"end":35,"type":"Symptom" as const,"label":"chest pain"},
      {"turnId":"t4","start":8,"end":18,"type":"Symptom" as const,"label":"chest pressure"},
      {"turnId":"t4","start":45,"end":55,"type":"Symptom" as const,"label":"radiating pain"},
      {"turnId":"t6","start":8,"end":12,"type":"Symptom" as const,"label":"pain 7/10"},
      {"turnId":"t8","start":8,"end":20,"type":"Symptom" as const,"label":"shortness of breath"},
      {"turnId":"t8","start":25,"end":32,"type":"Symptom" as const,"label":"sweating"},
      {"turnId":"t9","start":25,"end":28,"type":"Order" as const,"label":"ECG"},
      {"turnId":"t10","start":25,"end":35,"type":"RiskFlag" as const,"label":"ST changes"},
      {"turnId":"t12","start":35,"end":45,"type":"Order" as const,"label":"troponin"},
      {"turnId":"t12","start":55,"end":65,"type":"Order" as const,"label":"chest X-ray"},
      {"turnId":"t14","start":35,"end":42,"type":"Medication" as const,"label":"aspirin"},
      {"turnId":"t14","start":50,"end":62,"type":"Medication" as const,"label":"nitroglycerin"}
    ],
    soap: {
      "subjective": {
        "chiefComplaint":"Chest pain for 2 hours",
        "hpi":"Patient reports central chest pressure radiating to left arm, pain 7/10, worse with deep breathing. Associated with shortness of breath and diaphoresis.",
        "pmh":"Hypertension, fatigue evaluation",
        "allergies":"Penicillin (rash)",
        "fh":"Mother with hypothyroidism",
        "sh":"Ex-smoker; moderate alcohol; active job stress"
      },
      "objective": {
        "vitals":"BP: 160/100, HR: 95, RR: 22, O2: 96%",
        "exam":"Patient in mild distress; chest pain reproducible with palpation; heart sounds normal",
        "labs":"ECG shows ST changes; ordered: troponin, CMP, CBC, chest X-ray"
      },
      "assessment": {
        "summary":"Acute chest pain with concerning features including radiation, associated symptoms, and ECG changes. Rule out acute coronary syndrome.",
        "diagnoses":[
          {"icd10":"R07.9","name":"Chest pain, unspecified","confidence":0.90},
          {"icd10":"I20.9","name":"Angina pectoris, unspecified","confidence":0.75}
        ],
        "differentials":["Acute coronary syndrome","Pleuritis","GERD","Anxiety"]
      },
      "plan": {
        "medications":["Aspirin 325mg","Nitroglycerin 0.4mg SL PRN"],
        "orders":["Troponin","CMP","CBC","Chest X-ray","ECG monitoring"],
        "followUp":"Monitor in clinic until test results available",
        "education":"Return immediately if chest pain worsens"
      }
    },
    codes: {
      "icd10":[
        {"code":"R07.9","description":"Chest pain, unspecified","confidence":0.90,"rationale":"Primary presenting symptom"},
        {"code":"I20.9","description":"Angina pectoris, unspecified","confidence":0.75,"rationale":"Typical chest pain with radiation and ECG changes"}
      ],
      "cpt":[
        {"code":"99214","description":"Office visit, established patient, moderate complexity","confidence":0.8,"rationale":"Urgent evaluation with multiple diagnostic tests"},
        {"code":"71045","description":"Chest X-ray, 2 views","confidence":0.9,"rationale":"Chest pain evaluation"},
        {"code":"93010","description":"ECG, 12 leads","confidence":0.9,"rationale":"Chest pain workup"}
      ],
      "hcpcs":[]
    },
    timeline: [
      {"t":5,"type":"Symptom" as const,"label":"Chest pain"},
      {"t":20,"type":"Symptom" as const,"label":"Chest pressure"},
      {"t":42,"type":"Symptom" as const,"label":"Pain 7/10"},
      {"t":65,"type":"Symptom" as const,"label":"Shortness of breath"},
      {"t":90,"type":"Order" as const,"label":"ECG"},
      {"t":105,"type":"RiskFlag" as const,"label":"ST changes"},
      {"t":130,"type":"Order" as const,"label":"Troponin, X-ray"},
      {"t":155,"type":"Medication" as const,"label":"Aspirin, NTG"}
    ],
    qa: [
      {"label":"Patient identified","state":"pass" as const},
      {"label":"Vital signs recorded","state":"pass" as const},
      {"label":"ECG performed","state":"pass" as const},
      {"label":"Chest pain protocol initiated","state":"pass" as const},
      {"label":"Appropriate labs ordered","state":"pass" as const},
      {"label":"Monitoring established","state":"pass" as const}
    ]
  }
};

const encounters = [
  {"id":"e1","title":"Fatigue – Initial Consult (Rob M.)","chiefComplaint":"Persistent fatigue","durationSec":780,"tags":["New Patient","GP"],"audioUrl":"/audio/consult-fatigue.mp3"},
  {"id":"e2","title":"Hypertension Follow‑up (Sarah J.)","chiefComplaint":"BP monitoring","durationSec":540,"tags":["Follow‑up"],"audioUrl":"/audio/hypertension-followup.mp3"},
  {"id":"e3","title":"Chest Pain Evaluation (Michael C.)","chiefComplaint":"Chest discomfort","durationSec":920,"tags":["Urgent Care"],"audioUrl":"/audio/chest-pain-eval.mp3"}
];

// Main Component
const ClinicalNoteGeneration: React.FC = () => {
  const navigate = useNavigate();
  const [selectedEncounterId, setSelectedEncounterId] = useState<string>('e1');
  const [data, setData] = useState<any>(encounterData.e1); // Default to e1
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(780);
  const [volume, setVolume] = useState(80);
  const [activeFilters, setActiveFilters] = useState<ClinicalEntityType[]>([]);
  const [editingSoap, setEditingSoap] = useState<string | null>(null);
  const [soapData, setSoapData] = useState<any>(encounterData.e1.soap);
  const [selectedCode, setSelectedCode] = useState<CodingRow | null>(null);
  const [showCodeDrawer, setShowCodeDrawer] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const transcriptRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  const handleEncounterSelect = (id: string) => {
    setSelectedEncounterId(id);
    setCurrentTime(0);
    setIsPlaying(false);
    const newData = encounterData[id as keyof typeof encounterData];
    setData(newData as any);
    setSoapData(newData.soap as any);
    setActiveFilters([]); // Reset filters when switching encounters
    // In a real app, this would fetch new data for the selected encounter
    const encounter = encounters.find(e => e.id === id);
    if (encounter) {
      setDuration(encounter.durationSec);
    }
  };

  const handleToggleEntity = (type: ClinicalEntityType) => {
    setActiveFilters(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  const handlePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseInt(e.target.value);
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseInt(e.target.value);
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume / 100;
    }
  };

  const handleTranscriptClick = (turn: TranscriptTurn) => {
    setCurrentTime(turn.tSec);
    if (audioRef.current) {
      audioRef.current.currentTime = turn.tSec;
    }
    // Scroll to transcript line
    const element = transcriptRefs.current[turn.id];
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const handleTimelineClick = (event: TimelineEvent) => {
    setCurrentTime(event.t);
    if (audioRef.current) {
      audioRef.current.currentTime = event.t;
    }
    // Find and scroll to related transcript line
    const relatedTurn = data.transcript.find((turn: any) => turn.tSec >= event.t);
    if (relatedTurn) {
      const element = transcriptRefs.current[relatedTurn.id];
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  const handleSoapEdit = (section: string) => {
    setEditingSoap(section);
  };

  const handleSoapSave = (section: string, value: string) => {
    setSoapData((prev: any) => {
      if (section === 'chiefComplaint' || section === 'hpi') {
        return {
          ...prev,
          subjective: {
            ...prev.subjective,
            [section]: value
          }
        };
      } else if (section === 'assessment') {
        return {
          ...prev,
          assessment: {
            ...prev.assessment,
            summary: value
          }
        };
      } else if (section === 'plan') {
        return {
          ...prev,
          plan: {
            ...prev.plan,
            followUp: value
          }
        };
      }
      return prev;
    });
    setEditingSoap(null);
  };

  const handleSoapCancel = () => {
    setEditingSoap(null);
  };

  const handleCodeClick = (code: CodingRow) => {
    setSelectedCode(code);
    setShowCodeDrawer(true);
  };

  const handleQAClick = (check: QaCheck) => {
    // Scroll to relevant section based on check type
    if (check.label.includes('Allergies')) {
      // Scroll to subjective section
      document.querySelector('[data-testid="soap-panel"]')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const exportSOAP = () => {
    const soapText = `
SOAP Note
=========

Subjective:
Chief Complaint: ${soapData.subjective.chiefComplaint}
HPI: ${soapData.subjective.hpi}
Allergies: ${soapData.subjective.allergies}
Family History: ${soapData.subjective.fh}

Objective:
Vitals: ${soapData.objective.vitals}
Exam: ${soapData.objective.exam}
Labs: ${soapData.objective.labs}

Assessment:
Summary: ${soapData.assessment.summary}
Diagnoses: ${soapData.assessment.diagnoses.map((d: any) => `${d.icd10} - ${d.name}`).join(', ')}

Plan:
Follow-up: ${soapData.plan.followUp}
Orders: ${soapData.plan.orders?.join(', ')}
    `.trim();

    const blob = new Blob([soapText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'soap-note.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportCodes = () => {
    // Export JSON
    const codesJson = JSON.stringify(data.codes, null, 2);
    const jsonBlob = new Blob([codesJson], { type: 'application/json' });
    const jsonUrl = URL.createObjectURL(jsonBlob);
    const jsonA = document.createElement('a');
    jsonA.href = jsonUrl;
    jsonA.download = 'codes.json';
    jsonA.click();
    URL.revokeObjectURL(jsonUrl);

    // Export CSV
    const csvData = [
      ['Type', 'Code', 'Description', 'Confidence', 'Rationale'],
      ...data.codes.icd10.map((code: any) => ['ICD-10', code.code, code.description, `${Math.round((code.confidence || 0) * 100)}%`, code.rationale || '']),
      ...data.codes.cpt.map((code: any) => ['CPT', code.code, code.description, `${Math.round((code.confidence || 0) * 100)}%`, code.rationale || '']),
      ...data.codes.hcpcs.map((code: any) => ['HCPCS', code.code, code.description, `${Math.round((code.confidence || 0) * 100)}%`, code.rationale || ''])
    ];
    const csvText = csvData.map(row => row.map((cell: any) => `"${cell}"`).join(',')).join('\n');
    const csvBlob = new Blob([csvText], { type: 'text/csv' });
    const csvUrl = URL.createObjectURL(csvBlob);
    const csvA = document.createElement('a');
    csvA.href = csvUrl;
    csvA.download = 'codes.csv';
    csvA.click();
    URL.revokeObjectURL(csvUrl);
  };

  const generateClaim = () => {
    const claim = {
      patient: data.meta.patient,
      encounter: {
        id: data.meta.encounterId,
        date: data.meta.datetime,
        type: data.meta.visitType,
        location: data.meta.location
      },
      codes: data.codes,
      plan: {
        orders: soapData.plan.orders,
        followUp: soapData.plan.followUp
      }
    };

    const claimJson = JSON.stringify(claim, null, 2);
    const blob = new Blob([claimJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'claim-demo.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const shareToPortal = () => {
    const summary = `
Patient Summary
===============

Patient: ${data.meta.patient.display}
Date: ${new Date(data.meta.datetime).toLocaleDateString()}
Provider: ${data.meta.clinician.name}

Chief Complaint: ${soapData.subjective.chiefComplaint}

Assessment: ${soapData.assessment.summary}

Plan: ${soapData.plan.followUp}

Next Steps: ${soapData.plan.orders?.join(', ')}
    `.trim();

    const blob = new Blob([summary], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'patient-summary.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => setDuration(audio.duration);
    const handleEnded = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        handlePlayPause();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft') {
        e.preventDefault();
        const newTime = Math.max(0, currentTime - 5);
        setCurrentTime(newTime);
        if (audioRef.current) audioRef.current.currentTime = newTime;
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        const newTime = Math.min(duration, currentTime + 5);
        setCurrentTime(newTime);
        if (audioRef.current) audioRef.current.currentTime = newTime;
      }
    };

    document.addEventListener('keypress', handleKeyPress);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keypress', handleKeyPress);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [currentTime, duration]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <style>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 16px;
          width: 16px;
          border-radius: 50%;
          background: #e87722;
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .slider::-moz-range-thumb {
          height: 16px;
          width: 16px;
          border-radius: 50%;
          background: #e87722;
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
      `}</style>
      <LoginNavbar />
      
      <div className="flex-grow container mx-auto px-4 py-4 max-w-7xl">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-4" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button 
                type="button" 
                onClick={() => navigate('/customer/sandbox/healthcarehome')} 
                className="flex items-center text-orange-600 hover:underline"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <Home size={16} className="mr-1" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-gray-500">Clinical Documentation Assistant</span>
            </li>
          </ol>
        </nav>

        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mr-4">
              <FileText size={24} className="text-orange-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Clinical Documentation Assistant</h1>
              <p className="text-gray-600">Generate structured SOAP notes and codes from clinician–patient conversations</p>
            </div>
          </div>
        </div>

        {/* Encounter Selector */}
        <div className="mb-6">
          <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="encounter-selector">
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              <FileText size={20} className="mr-2 text-orange-600" />
              Select Encounter
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {encounters.map((encounter) => (
                <div
                  key={encounter.id}
                  onClick={() => handleEncounterSelect(encounter.id)}
                  className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedEncounterId === encounter.id
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">{encounter.title}</h4>
                    <div className="flex items-center text-xs text-gray-500">
                      <Clock size={12} className="mr-1" />
                      {Math.floor(encounter.durationSec / 60)}:{(encounter.durationSec % 60).toString().padStart(2, '0')}
                    </div>
                  </div>
                  <p className="text-xs text-gray-600 mb-2">{encounter.chiefComplaint}</p>
                  <div className="flex flex-wrap gap-1">
                    {encounter.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-700"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Audio Player */}
        <div className="mb-6">
          <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="audio-card">
            <audio
              ref={audioRef}
              src={encounters.find(e => e.id === selectedEncounterId)?.audioUrl || "/audio/consult-fatigue.mp3"}
              preload="metadata"
            />
            <div className="flex items-center space-x-4">
              <button
                onClick={handlePlayPause}
                className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center text-white hover:bg-orange-700 transition-colors"
                aria-label={isPlaying ? "Pause audio" : "Play audio"}
              >
                {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              </button>
              <div className="flex-1">
                <div className="text-sm font-medium text-gray-900 mb-1">
                  {encounters.find(e => e.id === selectedEncounterId)?.title || 'Fatigue – Initial Consult'}
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-xs text-gray-500">{formatTime(currentTime)}</span>
                  <div className="flex-1 relative">
                    <input
                      type="range"
                      min="0"
                      max={duration}
                      value={currentTime}
                      onChange={handleProgressChange}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                      style={{
                        background: `linear-gradient(to right, #e87722 0%, #e87722 ${(currentTime / duration) * 100}%, #e5e7eb ${(currentTime / duration) * 100}%, #e5e7eb 100%)`
                      }}
                    />
                  </div>
                  <span className="text-xs text-gray-500">{formatTime(duration)}</span>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Volume2 size={16} className="text-gray-500" />
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={handleVolumeChange}
                  className="w-16 h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Encounter Header */}
        <div className="mb-6">
          <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="encounter-header">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="flex items-center">
                <User size={16} className="mr-2 text-orange-600" />
                <div>
                  <p className="text-sm font-medium">{data.meta.patient.display}</p>
                  <p className="text-xs text-gray-500">ID: {data.meta.patient.id} • {data.meta.patient.age}yo {data.meta.patient.sex}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Stethoscope size={16} className="mr-2 text-orange-600" />
                <div>
                  <p className="text-sm font-medium">{data.meta.clinician.name}</p>
                  <p className="text-xs text-gray-500">{data.meta.clinician.specialty}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Calendar size={16} className="mr-2 text-orange-600" />
                <div>
                  <p className="text-sm font-medium">{new Date(data.meta.datetime).toLocaleDateString()}</p>
                  <p className="text-xs text-gray-500">{data.meta.visitType}</p>
                </div>
              </div>
              <div className="flex items-center">
                <MapPin size={16} className="mr-2 text-orange-600" />
                <div>
                  <p className="text-sm font-medium">{data.meta.location || 'Not specified'}</p>
                  <p className="text-xs text-gray-500">Encounter ID: {data.meta.encounterId}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Split */}
        <div className="grid grid-cols-12 gap-4 mb-6">
          <div className="col-span-12 md:col-span-7">
            <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="transcript-panel">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center">
                  <FileText size={20} className="mr-2 text-orange-600" />
                  Transcript
                </h3>
                <div className="flex items-center space-x-2">
                  <Filter size={16} className="text-gray-500" />
                                     <div className="flex flex-wrap gap-1">
                     {(['Symptom', 'FamilyHistory', 'Order'] as const).map(type => (
                       <button
                         key={type}
                         onClick={() => handleToggleEntity(type)}
                         className={`px-2 py-1 text-xs rounded-full transition-colors ${
                           activeFilters.includes(type)
                             ? 'bg-orange-100 text-orange-700'
                             : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                         }`}
                       >
                         {type}
                       </button>
                     ))}
                   </div>
                </div>
              </div>
                                            <div className="space-y-3 h-[920px] overflow-y-auto">
                 {data.transcript.map((turn: any, index: number) => {
                   const isActive = currentTime >= turn.tSec && 
                     (index === data.transcript.length - 1 || currentTime < data.transcript[index + 1].tSec);
                   const hasHighlights = data.highlights.some((h: any) => h.turnId === turn.id);
                   
                   return (
                     <div 
                       key={turn.id} 
                       ref={el => transcriptRefs.current[turn.id] = el}
                       className={`flex space-x-3 p-2 rounded-lg cursor-pointer transition-all ${
                         isActive ? 'bg-orange-50 border-l-4 border-orange-500' : 'hover:bg-gray-50'
                       }`}
                       onClick={() => handleTranscriptClick(turn)}
                     >
                       <div className={`flex-shrink-0 w-16 text-xs text-gray-500 ${turn.speaker === 'DOCTOR' ? 'text-blue-600' : 'text-green-600'}`}>
                         {turn.t}
                       </div>
                       <div className="flex-1">
                         <div className={`inline-block px-2 py-1 rounded text-xs font-medium mb-1 ${
                           turn.speaker === 'DOCTOR' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                         }`}>
                           {turn.speaker === 'DOCTOR' ? 'Doctor' : 'Patient'}
                         </div>
                         <p className="text-sm leading-relaxed">
                           {turn.text}
                           {hasHighlights && (
                             <div className="mt-1 flex flex-wrap gap-1">
                               {data.highlights
                                 .filter((h: any) => h.turnId === turn.id)
                                 .filter((h: any) => activeFilters.length === 0 || activeFilters.includes(h.type))
                                 .map((highlight: any, idx: number) => (
                                   <span
                                     key={idx}
                                                                            className={`px-2 py-1 text-xs rounded-full ${
                                         highlight.type === 'Symptom' ? 'bg-red-100 text-red-800' :
                                         highlight.type === 'FamilyHistory' ? 'bg-blue-100 text-blue-800' :
                                         highlight.type === 'Order' ? 'bg-purple-100 text-purple-800' :
                                         'bg-gray-100 text-gray-800'
                                       }`}
                                   >
                                     {highlight.label || highlight.type}
                                   </span>
                                 ))}
                             </div>
                           )}
                         </p>
                       </div>
                     </div>
                   );
                 })}
               </div>
            </div>
          </div>
          <div className="col-span-12 md:col-span-5 space-y-4">
                         <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="soap-panel">
               <h3 className="text-lg font-semibold mb-4 flex items-center">
                 <FileText size={20} className="mr-2 text-orange-600" />
                 SOAP Note
               </h3>
               <div className="space-y-4">
                 <div className="mb-4">
                   <div className="flex items-center justify-between mb-2">
                     <h4 className="font-semibold text-gray-800">Chief Complaint</h4>
                     {editingSoap !== 'chiefComplaint' && (
                       <button
                         onClick={() => handleSoapEdit('chiefComplaint')}
                         className="text-orange-600 hover:text-orange-700"
                       >
                         <Edit3 size={14} />
                       </button>
                     )}
                   </div>
                   {editingSoap === 'chiefComplaint' ? (
                     <div className="space-y-2">
                       <textarea
                         defaultValue={soapData.subjective.chiefComplaint}
                         className="w-full p-2 border rounded text-sm"
                         rows={2}
                       />
                       <div className="flex space-x-2">
                         <button
                           onClick={(e) => {
                             const textarea = e.currentTarget.parentElement?.previousElementSibling as HTMLTextAreaElement;
                             handleSoapSave('chiefComplaint', textarea.value);
                           }}
                           className="px-2 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700"
                         >
                           <Save size={12} className="inline mr-1" />
                           Save
                         </button>
                         <button
                           onClick={handleSoapCancel}
                           className="px-2 py-1 bg-gray-600 text-white text-xs rounded hover:bg-gray-700"
                         >
                           <X size={12} className="inline mr-1" />
                           Cancel
                         </button>
                       </div>
                     </div>
                   ) : (
                     <p className="text-sm text-gray-700">{soapData.subjective.chiefComplaint}</p>
                   )}
                 </div>
                 
                 <div className="mb-4">
                   <div className="flex items-center justify-between mb-2">
                     <h4 className="font-semibold text-gray-800">HPI</h4>
                     {editingSoap !== 'hpi' && (
                       <button
                         onClick={() => handleSoapEdit('hpi')}
                         className="text-orange-600 hover:text-orange-700"
                       >
                         <Edit3 size={14} />
                       </button>
                     )}
                   </div>
                   {editingSoap === 'hpi' ? (
                     <div className="space-y-2">
                       <textarea
                         defaultValue={soapData.subjective.hpi}
                         className="w-full p-2 border rounded text-sm"
                         rows={3}
                       />
                       <div className="flex space-x-2">
                         <button
                           onClick={(e) => {
                             const textarea = e.currentTarget.parentElement?.previousElementSibling as HTMLTextAreaElement;
                             handleSoapSave('hpi', textarea.value);
                           }}
                           className="px-2 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700"
                         >
                           <Save size={12} className="inline mr-1" />
                           Save
                         </button>
                         <button
                           onClick={handleSoapCancel}
                           className="px-2 py-1 bg-gray-600 text-white text-xs rounded hover:bg-gray-700"
                         >
                           <X size={12} className="inline mr-1" />
                           Cancel
                         </button>
                       </div>
                     </div>
                   ) : (
                     <p className="text-sm text-gray-700">{soapData.subjective.hpi}</p>
                   )}
                 </div>
                 
                 <div className="mb-4">
                   <div className="flex items-center justify-between mb-2">
                     <h4 className="font-semibold text-gray-800">Assessment</h4>
                     {editingSoap !== 'assessment' && (
                       <button
                         onClick={() => handleSoapEdit('assessment')}
                         className="text-orange-600 hover:text-orange-700"
                       >
                         <Edit3 size={14} />
                       </button>
                     )}
                   </div>
                   {editingSoap === 'assessment' ? (
                     <div className="space-y-2">
                       <textarea
                         defaultValue={soapData.assessment.summary}
                         className="w-full p-2 border rounded text-sm"
                         rows={3}
                       />
                       <div className="flex space-x-2">
                         <button
                           onClick={(e) => {
                             const textarea = e.currentTarget.parentElement?.previousElementSibling as HTMLTextAreaElement;
                             handleSoapSave('assessment', textarea.value);
                           }}
                           className="px-2 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700"
                         >
                           <Save size={12} className="inline mr-1" />
                           Save
                         </button>
                         <button
                           onClick={handleSoapCancel}
                           className="px-2 py-1 bg-gray-600 text-white text-xs rounded hover:bg-gray-700"
                         >
                           <X size={12} className="inline mr-1" />
                           Cancel
                         </button>
                       </div>
                     </div>
                   ) : (
                     <p className="text-sm text-gray-700">{soapData.assessment.summary}</p>
                   )}
                 </div>
                 
                 <div className="mb-4">
                   <div className="flex items-center justify-between mb-2">
                     <h4 className="font-semibold text-gray-800">Plan</h4>
                     {editingSoap !== 'plan' && (
                       <button
                         onClick={() => handleSoapEdit('plan')}
                         className="text-orange-600 hover:text-orange-700"
                       >
                         <Edit3 size={14} />
                       </button>
                     )}
                   </div>
                   {editingSoap === 'plan' ? (
                     <div className="space-y-2">
                       <textarea
                         defaultValue={soapData.plan.followUp}
                         className="w-full p-2 border rounded text-sm"
                         rows={3}
                       />
                       <div className="flex space-x-2">
                         <button
                           onClick={(e) => {
                             const textarea = e.currentTarget.parentElement?.previousElementSibling as HTMLTextAreaElement;
                             handleSoapSave('plan', textarea.value);
                           }}
                           className="px-2 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700"
                         >
                           <Save size={12} className="inline mr-1" />
                           Save
                         </button>
                         <button
                           onClick={handleSoapCancel}
                           className="px-2 py-1 bg-gray-600 text-white text-xs rounded hover:bg-gray-700"
                         >
                           <X size={12} className="inline mr-1" />
                           Cancel
                         </button>
                       </div>
                     </div>
                   ) : (
                     <p className="text-sm text-gray-700">{soapData.plan.followUp}</p>
                   )}
                 </div>
               </div>
             </div>
                         <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="coding-panel">
               <h3 className="text-lg font-semibold mb-4 flex items-center">
                 <FileText size={20} className="mr-2 text-orange-600" />
                 Medical Codes
               </h3>
               <div className="space-y-4">
                 <div>
                   <h4 className="font-semibold text-gray-800 mb-2">ICD-10 Codes</h4>
                   {data.codes.icd10.map((code: any, idx: number) => (
                     <div 
                       key={idx} 
                       className="p-2 bg-gray-50 rounded text-sm mb-2 cursor-pointer hover:bg-gray-100 transition-colors"
                       onClick={() => handleCodeClick(code)}
                     >
                       <div className="flex justify-between items-start">
                         <div className="flex-1">
                           <div className="font-medium">{code.code}</div>
                           <div className="text-gray-600">{code.description}</div>
                         </div>
                         {code.confidence && (
                           <div className="ml-2">
                             <div className="text-xs text-gray-500">Confidence</div>
                             <div className="text-sm font-medium text-orange-600">
                               {Math.round(code.confidence * 100)}%
                             </div>
                           </div>
                         )}
                       </div>
                     </div>
                   ))}
                 </div>
                 
                 <div>
                   <h4 className="font-semibold text-gray-800 mb-2">CPT Codes</h4>
                   {data.codes.cpt.map((code: any, idx: number) => (
                     <div 
                       key={idx} 
                       className="p-2 bg-gray-50 rounded text-sm mb-2 cursor-pointer hover:bg-gray-100 transition-colors"
                       onClick={() => handleCodeClick(code)}
                     >
                       <div className="flex justify-between items-start">
                         <div className="flex-1">
                           <div className="font-medium">{code.code}</div>
                           <div className="text-gray-600">{code.description}</div>
                         </div>
                         {code.confidence && (
                           <div className="ml-2">
                             <div className="text-xs text-gray-500">Confidence</div>
                             <div className="text-sm font-medium text-orange-600">
                               {Math.round(code.confidence * 100)}%
                             </div>
                           </div>
                         )}
                       </div>
                     </div>
                   ))}
                 </div>
               </div>
             </div>
          </div>
        </div>

        {/* Insights Row */}
        <div className="grid grid-cols-12 gap-4 mb-6">
          <div className="col-span-12 md:col-span-7">
            <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="entity-timeline">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Clock size={20} className="mr-2 text-orange-600" />
                Entity Timeline
              </h3>
              <div className="relative h-[280px] overflow-y-auto">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>
                                 <div className="space-y-3">
                   {data.timeline.map((event: any, idx: number) => (
                     <div 
                       key={idx} 
                       className="flex items-center cursor-pointer hover:bg-gray-50 p-2 rounded transition-colors"
                       onClick={() => handleTimelineClick(event)}
                     >
                       <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-xs font-medium z-10">
                         {Math.floor(event.t / 60)}:{(event.t % 60).toString().padStart(2, '0')}
                       </div>
                       <div className="ml-4 flex-1">
                         <div className="text-sm font-medium">{event.label}</div>
                         <div className="text-xs text-gray-500 capitalize">{event.type}</div>
                       </div>
                     </div>
                   ))}
                 </div>
              </div>
            </div>
          </div>
          <div className="col-span-12 md:col-span-5">
            <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="qa-checklist">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <CheckCircle size={20} className="mr-2 text-orange-600" />
                QA Checklist
              </h3>
                             <div className="space-y-3">
                 {data.qa.map((check: any, idx: number) => (
                   <div 
                     key={idx} 
                     className="flex items-start space-x-3 cursor-pointer hover:bg-gray-50 p-2 rounded transition-colors"
                     onClick={() => handleQAClick(check)}
                   >
                     {check.state === 'pass' && <CheckCircle size={16} className="text-green-600" />}
                     {check.state === 'warn' && <AlertCircle size={16} className="text-yellow-600" />}
                     {check.state === 'fail' && <XCircle size={16} className="text-red-600" />}
                     <div className="flex-1">
                       <div className={`text-sm font-medium ${
                         check.state === 'pass' ? 'text-green-600' : 
                         check.state === 'warn' ? 'text-yellow-600' : 
                         'text-red-600'
                       }`}>
                         {check.label}
                       </div>
                       {check.note && <div className="text-xs text-gray-500 mt-1">{check.note}</div>}
                     </div>
                   </div>
                 ))}
               </div>
            </div>
          </div>
        </div>

        {/* Actions Bar */}
        <div className="mb-6">
          <div className="bg-white rounded-2xl border p-4 shadow-sm" data-testid="actions-bar">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Download size={20} className="mr-2 text-orange-600" />
              Actions
            </h3>
                         <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
               <button 
                 onClick={exportSOAP}
                 className="flex items-center justify-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
               >
                 <Download size={16} className="mr-2" />
                 Export SOAP
               </button>
               <button 
                 onClick={exportCodes}
                 className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
               >
                 <FileText size={16} className="mr-2" />
                 Export Codes
               </button>
               <button 
                 onClick={generateClaim}
                 className="flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
               >
                 <FileText size={16} className="mr-2" />
                 Generate Claim
               </button>
               <button 
                 onClick={shareToPortal}
                 className="flex items-center justify-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
               >
                 <Share2 size={16} className="mr-2" />
                 Share to Portal
               </button>
             </div>
          </div>
        </div>
      </div>

             <HealthcareFooter />
       
       {/* Code Detail Drawer */}
       {showCodeDrawer && selectedCode && (
         <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
           <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 max-h-96 overflow-y-auto">
             <div className="flex items-center justify-between mb-4">
               <h3 className="text-lg font-semibold">Code Details</h3>
               <button
                 onClick={() => setShowCodeDrawer(false)}
                 className="text-gray-500 hover:text-gray-700"
               >
                 <X size={20} />
               </button>
             </div>
             <div className="space-y-4">
               <div>
                 <div className="font-medium text-gray-900">{selectedCode.code}</div>
                 <div className="text-sm text-gray-600">{selectedCode.description}</div>
               </div>
               {selectedCode.confidence && (
                 <div>
                   <div className="text-sm font-medium text-gray-700">Confidence</div>
                   <div className="text-lg font-bold text-orange-600">
                     {Math.round(selectedCode.confidence * 100)}%
                   </div>
                 </div>
               )}
               {selectedCode.rationale && (
                 <div>
                   <div className="text-sm font-medium text-gray-700 mb-2">Rationale</div>
                   <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                     {selectedCode.rationale}
                   </div>
                 </div>
               )}
             </div>
           </div>
         </div>
       )}
     </div>
   );
 };

export default ClinicalNoteGeneration;
