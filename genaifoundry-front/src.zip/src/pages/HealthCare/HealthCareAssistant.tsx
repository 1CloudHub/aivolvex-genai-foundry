import React from 'react';
import { MessageSquare, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import HealthCareAssistantTool from './HealthCareAssistantTool';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';

const HealthCareAssistantPage: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-white flex flex-col">
      <LoginNavbar />
      <div className="flex-grow container mx-auto px-4 py-4">
        <div className="mx-auto w-full max-w-10xl mt-8">
          <div className="mb-4">
            <div className="w-full">
              <nav className="flex text-sm text-gray-500 mb-2 -mt-6 -ml-5" aria-label="Breadcrumb">
                <ol className="inline-flex items-center space-x-1">
                  <li>
                    <button 
                      type="button" 
                      onClick={() => navigate('/customer/sandbox/healthcarehome')} 
                      className="flex items-center text-gray-500 hover:text-gray-700"
                      style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
                    >
                      <Home size={16} className="mr-1" />
                      Home
                    </button>
                  </li>
                  <li>
                    <span className="mx-2">/</span>
                    <span className="text-orange-600 font-medium">HealthCare Virtual Assistant</span>
                  </li>
                </ol>
              </nav>
              <div className="flex items-center mb-2">
                <div className="ub-feature-icon mr-3">
                  <MessageSquare size={30} />
                </div>
                <div>
                  <h2 className="mb-0 text-3xl font-bold">HealthCare Virtual Assistant</h2>
                  <p className="text-gray-500">AI-powered chatbot for hospital services, appointments, and patient inquiries using RAG technology</p>
                </div>
              </div>
            </div>
          </div>
          
          <HealthCareAssistantTool />
        </div>
      </div>
      <HealthcareFooter />
    </div>
  );
};

export default HealthCareAssistantPage;