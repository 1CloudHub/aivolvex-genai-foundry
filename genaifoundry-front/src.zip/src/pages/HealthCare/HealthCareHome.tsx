import React, { useEffect, useState } from 'react';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import { useAppContext } from '../../context/AppContext';
import {
    Mic ,
    Edit3 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    FileText,
    Home,
    ClipboardCheck,
    PieChart,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';
import HomeCard from '../../components/ui/HomeCard';

const GenAISandboxHome = () => {
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');
    const { projectType } = useAppContext();

    useEffect(() => {
        console.log("🔍 Current Project Type from Context:", projectType);
    }, [projectType]);

const solutions = [
  {
    title: 'Hospital Virtual Assistant',
    area: 'Patient Care',
    icon: <MessageSquare size={24} />,
    description: 'Conversational AI assistant that helps patients inquire about hospital services, specialties, facilities, departments, accepted insurance panels, and book appointments with doctors or specialists using RAG and Tool Calling.',
    buttonText: 'Try Now',
    tags: ['Digital Health', 'AI Chat', 'RAG'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🏥',
      heading: 'Hospital Virtual Assistant',
      subheading: 'Conversational AI for Healthcare Services',
      points: [
        'Inquire about hospital services and specialties',
        'Check facilities and departments',
        'Verify accepted insurance panels',
        'Book appointments with doctors or specialists',
        'Uses RAG and Tool Calling for accurate responses'
      ]
    }
  },
  {
    title: 'Clinical Note Generation',
    area: 'Clinical Documentation',
    icon: <FileText size={24} />,
    description: 'Transforms doctor-patient conversations into structured SOAP-format notes. Identifies symptoms, red flags, medical history, and recommends ICD codes, labs, and assessments.',
    buttonText: 'Try Now',
    tags: ['SOAP Notes', 'Clinical AI', 'Documentation'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📋',
      heading: 'Clinical Note Generation Assistant',
      subheading: 'SOAP-Format Clinical Documentation',
      points: [
        'Transforms conversations into SOAP-format notes',
        'Identifies symptoms and red flags',
        'Captures medical history and context',
        'Recommends ICD codes and lab assessments',
        'Optimized for downstream documentation'
      ]
    }
  },
  {
    title: 'MedDocs',
    area: 'Operations',
    icon: <FileSearch size={24} />,
    description: 'Extracts structured data from key healthcare documents including Blood Biomarker Reports',
    buttonText: 'Try Now',
    tags: ['Document AI', 'EHR', 'Claims Processing'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📄',
      heading: 'Healthcare Document Processor',
      subheading: 'AI Document Extraction for Healthcare',
      points: [
        'Blood Biomarker Reports processing',
        'CMS-1500 Claim Forms extraction',
        'Prescription data extraction',
        'Radiology Reports analysis',
        'Enables EHR population and insurance filing'
      ]
    }
  },
  {
    title: 'MedCode AI',
    area: 'Billing & Compliance',
    icon: <ClipboardCheck size={24} />,
    description: 'Generates ICD, CPT, and HCPCS codes from SOAP-formatted clinical notes or transcripts to support claims generation, billing, and insurance compliance.',
    buttonText: 'Try Now',
    tags: ['Medical Coding', 'ICD/CPT', 'Billing'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🏷️',
      heading: 'Medical Coding Assistant',
      subheading: 'AI-Powered Medical Coding',
      points: [
        'Generates ICD, CPT, and HCPCS codes',
        'Processes SOAP-formatted clinical notes',
        'Supports claims generation and billing',
        'Enhances coding accuracy and turnaround',
        'Ensures insurance compliance'
      ]
    }
  },
  {
    title: 'Clinical IQ',
    area: 'Clinical Research',
    icon: <Sparkles size={24} />,
    description: 'Allows clinicians and researchers to query external academic and medical literature repositories using natural language. Returns enriched, referenced summaries.',
    buttonText: 'Try Now',
    tags: ['Research', 'Literature Review', 'Evidence-Based'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🔬',
      heading: 'Clinical IQ',
      subheading: 'Medical Literature Research AI',
      points: [
        'Query academic and medical literature',
        'Natural language research interface',
        'Returns enriched, referenced summaries',
        'Supports evidence-based decision-making',
        'Access to external research repositories'
      ]
    }
  },
];

// Navigation handler for Healthcare solutions
const handleHealthcareNavigation = (solution: any) => {
  switch (solution.title) {
    case "Hospital Virtual Assistant":
      navigate('/customer/sandbox/healthcarehome/hospital-assistant');
      break;
    case "Clinical Note Generation":
      navigate('/customer/sandbox/healthcarehome/clinical-notes');
      break;
    case "MedDocs":
      navigate('/customer/sandbox/healthcarehome/document-processing');
      break;
    case "MedCode AI":
      navigate('/customer/sandbox/healthcarehome/medical-coding');
      break;
    case "Clinical IQ":
      navigate('/customer/sandbox/healthcarehome/research-assistant');
      break;
    default:
      // Handle default case or external links
      break;
  }
};

return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Login Navbar */}
        <LoginNavbar />
        
        {/* Spacing below navbar */}
        <div className="flex-grow px-15 mx-auto py-3">
            {/* Header Section */}
            <div className="text-center">
                <div className="flex flex-col items-center justify-center mt-8 mb-2">
                    <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                        <span style={{ color: '#e87722' }}>GenAI</span>
                        <span style={{ color: '#181f5a' }}> Sandbox</span>
                    </h1>
                </div>
                <div className="mb-8">
                    <span className="text-lg text-gray-700">
                        Explore AI-powered healthcare tools designed to transform clinical operations, patient care, and medical research.
                    </span>
                </div>
            </div>

            {/* Solution Cards Section */}
            <div className="max-w-7xl mx-auto px-4">
                <Row
                    gutter={[16, 16]}
                    justify="center"
                    className="p-4"
                    style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                >
                    {solutions.map((solution, index) => (
                        <Col 
                            key={index} 
                            xs={24}
                            sm={24}
                            md={8}
                            lg={8}
                            xl={8}
                            style={{ 
                                marginBottom: "16px"
                            }}
                        >
                            <HomeCard
                                solution={solution}
                                cardHeight="h-[350px]"
                                buttonHeight="36px"
                                onNavigate={handleHealthcareNavigation}
                            />
                        </Col>
                    ))}
                </Row>
            </div>
        </div>
        <HealthcareFooter />
    </div>
);

};

export default GenAISandboxHome;