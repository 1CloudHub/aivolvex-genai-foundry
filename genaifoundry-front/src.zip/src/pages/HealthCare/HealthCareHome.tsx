import React, { useEffect, useState } from 'react';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import { useAppContext } from '../../context/AppContext';
import {
    Mic ,
    Edit3 ,
    BarChart2 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    FileText,
    Home,
    ClipboardCheck,
    PieChart,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import HealthcareFooter from './HealthCareFooter';

const GenAISandboxHome = () => {
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');
    const { projectType } = useAppContext();

    useEffect(() => {
        console.log("🔍 Current Project Type from Context:", projectType);
    }, [projectType]);

const solutions = [
  {
    title: 'Hospital Virtual Assistant',
    area: 'Patient Care',
    icon: <MessageSquare size={24} />,
    description: 'Conversational AI assistant that helps patients inquire about hospital services, specialties, facilities, departments, accepted insurance panels, and book appointments with doctors or specialists using RAG and Tool Calling.',
    buttonText: 'Try Now',
    tags: ['Digital Health', 'AI Chat', 'RAG'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🏥',
      heading: 'Hospital Virtual Assistant',
      subheading: 'Conversational AI for Healthcare Services',
      points: [
        'Inquire about hospital services and specialties',
        'Check facilities and departments',
        'Verify accepted insurance panels',
        'Book appointments with doctors or specialists',
        'Uses RAG and Tool Calling for accurate responses'
      ]
    }
  },
  {
    title: 'Clinical Note Generation',
    area: 'Clinical Documentation',
    icon: <FileText size={24} />,
    description: 'Transforms doctor-patient conversations into structured SOAP-format notes. Identifies symptoms, red flags, medical history, and recommends ICD codes, labs, and assessments.',
    buttonText: 'Try Now',
    tags: ['SOAP Notes', 'Clinical AI', 'Documentation'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📋',
      heading: 'Clinical Note Generation Assistant',
      subheading: 'SOAP-Format Clinical Documentation',
      points: [
        'Transforms conversations into SOAP-format notes',
        'Identifies symptoms and red flags',
        'Captures medical history and context',
        'Recommends ICD codes and lab assessments',
        'Optimized for downstream documentation'
      ]
    }
  },
  {
    title: 'Document Processing Assistant',
    area: 'Operations',
    icon: <FileSearch size={24} />,
    description: 'Extracts structured data from key healthcare documents including Blood Biomarker Reports',
    buttonText: 'Try Now',
    tags: ['Document AI', 'EHR', 'Claims Processing'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📄',
      heading: 'Healthcare Document Processor',
      subheading: 'AI Document Extraction for Healthcare',
      points: [
        'Blood Biomarker Reports processing',
        'CMS-1500 Claim Forms extraction',
        'Prescription data extraction',
        'Radiology Reports analysis',
        'Enables EHR population and insurance filing'
      ]
    }
  },
  {
    title: 'Medical Coding Assistant',
    area: 'Billing & Compliance',
    icon: <ClipboardCheck size={24} />,
    description: 'Generates ICD, CPT, and HCPCS codes from SOAP-formatted clinical notes or transcripts to support claims generation, billing, and insurance compliance.',
    buttonText: 'Try Now',
    tags: ['Medical Coding', 'ICD/CPT', 'Billing'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🏷️',
      heading: 'Medical Coding Assistant',
      subheading: 'AI-Powered Medical Coding',
      points: [
        'Generates ICD, CPT, and HCPCS codes',
        'Processes SOAP-formatted clinical notes',
        'Supports claims generation and billing',
        'Enhances coding accuracy and turnaround',
        'Ensures insurance compliance'
      ]
    }
  },
  {
    title: 'Deep Research Assistant',
    area: 'Clinical Research',
    icon: <Sparkles size={24} />,
    description: 'Allows clinicians and researchers to query external academic and medical literature repositories using natural language. Returns enriched, referenced summaries.',
    buttonText: 'Explore',
    tags: ['Research', 'Literature Review', 'Evidence-Based'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🔬',
      heading: 'Deep Research Assistant',
      subheading: 'Medical Literature Research AI',
      points: [
        'Query academic and medical literature',
        'Natural language research interface',
        'Returns enriched, referenced summaries',
        'Supports evidence-based decision-making',
        'Access to external research repositories'
      ]
    }
  },
  {
    title: 'Gen BI with QuickSight + Q',
    area: 'Analytics & Insights',
    icon: <BarChart2 size={24} />,
    description: 'Interactive healthcare dashboard that is built with Amazon Q for real-time natural language Q&A.',
    buttonText: 'View Dashboard',
    tags: ['Analytics', 'QuickSight', 'Amazon Q'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📊',
      heading: 'Healthcare Analytics Dashboard',
      subheading: 'Gen BI with QuickSight + Amazon Q',
      points: [
        'Interactive healthcare metrics visualization',
        'Patient intake and diagnostics tracking',
        'Treatment timeline analysis',
        'Amazon Q for natural language Q&A',
        'Real-time healthcare insights'
      ]
    }
  },
];

// Navigation handler for Healthcare solutions
const handleHealthcareNavigation = (solution: any) => {
  switch (solution.title) {
    case "Hospital Virtual Assistant":
      navigate('/customer/sandbox/healthcarehome/hospital-assistant');
      break;
    case "Clinical Note Generation":
      navigate('/customer/sandbox/healthcarehome/clinical-notes');
      break;
    case "Document Processing Assistant":
      navigate('/customer/sandbox/healthcarehome/document-processing');
      break;
    case "Medical Coding Assistant":
      navigate('/customer/sandbox/healthcarehome/medical-coding');
      break;
    case "Deep Research Assistant":
      navigate('/customer/sandbox/healthcarehome/research-assistant');
      break;
    case "Gen BI with QuickSight + Q":
      navigate('/customer/sandbox/healthcarehome/analytics-dashboard');
      break;
    default:
      // Handle default case or external links
      break;
  }
};

return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Login Navbar */}
        <LoginNavbar />
        
        {/* Spacing below navbar */}
        <div className="flex-grow px-4 md:px-8 lg:px-16 mx-auto py-4 max-w-7xl">
            {/* Header Section */}
            <div className="text-center">
                <div className="flex flex-col items-center justify-center mt-8 mb-2">
                    <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                        <span style={{ color: '#e87722' }}>GenAI</span>
                        <span style={{ color: '#181f5a' }}> Sandbox</span>
                    </h1>
                </div>
                <div className="mb-8">
                    <span className="text-lg text-gray-700">
                        Explore AI-powered healthcare tools designed to transform clinical operations, patient care, and medical research.
                    </span>
                </div>
            </div>

            {/* Solution Cards Section */}
            <Row
                gutter={[24, 24]}
                justify="center"
                className="p-4 md:p-6 lg:p-8"
                style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
            >
                {solutions.map((solution, index) => (
                    <Col key={index} xs={24} sm={12} lg={8} xl={8}>
                        <Card
                            className="relative w-full h-[340px] border-2 border-transparent rounded-lg shadow-md
                                hover:shadow-lg transition-all duration-300 ease-in-out
                                hover:!border-[#e87822] flex flex-col"
                            bodyStyle={{
                                height: '100%',
                                display: 'flex',
                                flexDirection: 'column',
                                overflow: 'hidden',
                                padding: '1rem',
                            }}
                        >
                            <div className="absolute top-2 right-2 z-10">
                                <Tooltip
                                    placement="topRight"
                                    color="white" 
                                    overlayInnerStyle={{
                                        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
                                        borderRadius: '10px',
                                        padding: '0', 
                                        maxWidth: '250px',
                                    }}
                                    title={
                                        <div className="p-[1px]">
                                            <div className="flex bg-[#f9fafb] rounded-md border-l-[4px] border-[#e87722] p-4">
                                                <div className="flex flex-col">
                                                    <div className="font-bold text-[#181f5a] text-sm mb-1">
                                                        {solution.tooltip.icon} {solution.tooltip.heading}
                                                    </div>
                                                    <div className="text-black text-xs font-semibold mb-2">
                                                        {solution.tooltip.subheading}
                                                    </div>
                                                    <ul className="list-disc pl-5 space-y-1 text-xs text-gray-700">
                                                        {solution.tooltip.points.map((point, idx) => (
                                                            <li key={idx}>{point}</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    }
                                >
                                    <Info className="text-[#e87722] hover:cursor-pointer" size={16} />
                                </Tooltip>
                            </div>

                            <div className="flex flex-col h-full">
                                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-[#e8782222] mb-3">
                                    {React.cloneElement(solution.icon, {
                                        size: 24,
                                        className: "text-[#e87722]",
                                    })}
                                </div>

                                <div className="mb-2 min-h-[24px] flex gap-2 flex-wrap">
                                    {solution.tags?.map((tag, index) => (
                                        <span key={index} className="inline-block bg-[#e8782222] text-[#e87722] text-xs font-medium px-2.5 py-0.5 rounded-md">
                                            {tag}
                                        </span>
                                    ))}
                                </div>

                                {/* Title */}
                                <Typography.Title level={5} className="!text-xl !font-bold !mb-2 !text-gray-900" style={{ height: '48px', lineHeight: '1.2' }}>
                                    {solution.title}
                                </Typography.Title>

                                {/* Description */}
                                <div 
                                    className="flex-grow mb-4 min-h-[72px] max-h-[72px] overflow-y-auto thin-scrollbar"
                                    style={{
                                        scrollbarWidth: 'thin',
                                        scrollbarColor: '#e5e7eb #f9fafb'
                                    }}
                                >
                                    <Typography.Text className="text-gray-600 !text-xs leading-relaxed">
                                        {solution.description}
                                    </Typography.Text>
                                </div>

                                {/* Button - Always at bottom */}
                                <div className="mt-auto">
                                    <button
                                        onClick={() => handleHealthcareNavigation(solution)}
                                        className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                                            hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                                            !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                                        style={{ height: '36px', textDecoration: 'none' }}
                                    >
                                        {solution.buttonText}
                                    </button>
                                </div>
                            </div>
                        </Card>
                    </Col>
                ))}
            </Row>
        </div>
        <HealthcareFooter />
    </div>
);

};

export default GenAISandboxHome;