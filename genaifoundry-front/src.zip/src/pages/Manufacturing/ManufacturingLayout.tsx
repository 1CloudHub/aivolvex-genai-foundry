import React from 'react';
import LoginNavbar from '../../components/layout/LoginNavbar';
import ManufacturingFooter from './ManufacturingFooter';

/**
 * Manufacturing Layout Component
 * Reusable wrapper component that provides consistent header and footer
 * for all Manufacturing pages
 */
interface ManufacturingLayoutProps {
  children: React.ReactNode;
}

const ManufacturingLayout: React.FC<ManufacturingLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <LoginNavbar />
      
      {/* Main Content */}
      <div className="flex-grow">
        {children}
      </div>
      
      {/* Footer */}
      <ManufacturingFooter />
    </div>
  );
};

export default ManufacturingLayout;

