import React, { useState, useEffect } from 'react';
import { FileText, Home as HomeIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import ManufacturingFooter from './ManufacturingFooter';
import DocumentWorkflow from '../../components/ui/DocumentWorkflow';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { setExtractedData, clearExtractedData } from '../../store/slices/extractedDataSlice';

/**
 * Document Type Interface
 * Defines the structure for manufacturing document types
 */
interface DocumentType {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

/**
 * Extracted Field Interface
 * Represents a single extracted field from a document
 */
interface ExtractedField {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'error';
  message?: string;
}

/**
 * Processed Document Interface
 * Represents a processed manufacturing document with extracted data
 */
interface ProcessedDocument {
  id: string;
  name: string;
  type: string;
  status: 'processing' | 'completed' | 'failed';
  confidence: number;
  fields: ExtractedField[];
  uploadTime: Date;
}

/**
 * Manufacturing Document Types Configuration
 * Defines the four main document types supported
 */
const documentTypes: DocumentType[] = [
  {
    id: 'purchase_order',
    name: 'Purchase Order (PO)',
    description: 'Extract supplier info, quantities, and unit costs',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
        <path d="M14 2v6h6"/>
        <path d="M16 13H8"/>
        <path d="M16 17H8"/>
        <path d="M10 9H8"/>
      </svg>
    </div>
  },
  {
    id: 'inspection_report',
    name: 'Inspection Report',
    description: 'Capture measurement data, test results, and status',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
        <path d="M14 2v6h6"/>
        <path d="M16 13H8"/>
        <path d="M16 17H8"/>
        <path d="M10 9H8"/>
      </svg>
    </div>
  },
  {
    id: 'safety_checklist',
    name: 'Safety Checklist',
    description: 'Identify missing compliance fields',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
        <path d="M14 2v6h6"/>
        <path d="M16 13H8"/>
        <path d="M16 17H8"/>
        <path d="M10 9H8"/>
      </svg>
    </div>
  },
  {
    id: 'maintenance_log',
    name: 'Maintenance Log',
    description: 'Record task completions and service intervals',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
        <path d="M14 2v6h6"/>
        <path d="M16 13H8"/>
        <path d="M16 17H8"/>
        <path d="M10 9H8"/>
      </svg>
    </div>
  }
];

/**
 * Mock Processed Document Data
 * Sample data for manufacturing documents
 */
const mockDocuments: Record<string, ProcessedDocument> = {
  purchase_order: {
    id: 'po-001',
    name: 'PO_2025_001.pdf',
    type: 'Purchase Order',
    status: 'completed',
    confidence: 92,
    fields: [
      { name: 'PO Number', value: 'PO-2025-001', status: 'success' },
      { name: 'Supplier Name', value: 'ABC Manufacturing Supplies', status: 'success' },
      { name: 'Supplier Address', value: '123 Industrial Ave, City, State 12345', status: 'success' },
      { name: 'Order Date', value: '2025-01-15', status: 'success' },
      { name: 'Delivery Date', value: '2025-02-01', status: 'success' },
      { name: 'Total Quantity', value: '500 units', status: 'success' },
      { name: 'Unit Cost', value: '$25.50', status: 'success' },
      { name: 'Total Amount', value: '$12,750.00', status: 'success' },
      { name: 'Payment Terms', value: 'Net 30', status: 'success' }
    ],
    uploadTime: new Date()
  },
  inspection_report: {
    id: 'inspection-001',
    name: 'Inspection_Report_Batch_2025.pdf',
    type: 'Inspection Report',
    status: 'completed',
    confidence: 88,
    fields: [
      { name: 'Batch Number', value: 'BATCH-2025-042', status: 'success' },
      { name: 'Product Name', value: 'Component XYZ-100', status: 'success' },
      { name: 'Inspection Date', value: '2025-01-20', status: 'success' },
      { name: 'Inspector Name', value: 'John Smith', status: 'success' },
      { name: 'Measurement 1', value: '10.5mm (within tolerance)', status: 'success' },
      { name: 'Measurement 2', value: '15.2mm (within tolerance)', status: 'success' },
      { name: 'Test Result', value: 'PASS', status: 'success' },
      { name: 'Status', value: 'Approved', status: 'success' },
      { name: 'Defects Found', value: '0', status: 'success' }
    ],
    uploadTime: new Date()
  },
  safety_checklist: {
    id: 'safety-001',
    name: 'Safety_Checklist_2025_01_20.pdf',
    type: 'Safety Checklist',
    status: 'completed',
    confidence: 95,
    fields: [
      { name: 'Checklist Date', value: '2025-01-20', status: 'success' },
      { name: 'Location', value: 'Production Floor - Line 3', status: 'success' },
      { name: 'Inspector Name', value: 'Sarah Johnson', status: 'success' },
      { name: 'PPE Compliance', value: 'Complete', status: 'success' },
      { name: 'Equipment Safety', value: 'Verified', status: 'success' },
      { name: 'Emergency Exits', value: 'Clear', status: 'success' },
      { name: 'Fire Safety Equipment', value: 'In Place', status: 'success' },
      { name: 'Hazard Identification', value: 'No hazards found', status: 'success' },
      { name: 'Overall Status', value: 'Compliant', status: 'success' }
    ],
    uploadTime: new Date()
  },
  maintenance_log: {
    id: 'maintenance-001',
    name: 'Maintenance_Log_Machine_101.pdf',
    type: 'Maintenance Log',
    status: 'completed',
    confidence: 90,
    fields: [
      { name: 'Machine ID', value: 'MACH-101', status: 'success' },
      { name: 'Maintenance Date', value: '2025-01-18', status: 'success' },
      { name: 'Technician Name', value: 'Mike Davis', status: 'success' },
      { name: 'Task Completed', value: 'Routine maintenance and calibration', status: 'success' },
      { name: 'Service Interval', value: 'Monthly', status: 'success' },
      { name: 'Parts Replaced', value: 'Filter cartridge, Lubricant', status: 'success' },
      { name: 'Next Service Date', value: '2025-02-18', status: 'success' },
      { name: 'Machine Status', value: 'Operational', status: 'success' },
      { name: 'Notes', value: 'All systems functioning normally', status: 'success' }
    ],
    uploadTime: new Date()
  }
};

/**
 * Document URL Mapping
 * Maps document IDs to their file paths
 */
const docUrls: Record<string, string> = {
  purchase_order: '/manafacturing/dummy_purchase_order.pdf',
  inspection_report: '/manafacturing/detailed_inspection_report.pdf',
  safety_checklist: '/manafacturing/safety_compliance_checklist_updated.pdf',
  maintenance_log: '/manafacturing/maintenance_log.pdf'
};

/**
 * Helper function to format PDF URLs
 */
const getPdfUrl = (url: string) => {
  if (url.endsWith('.pdf')) {
    return `${url}#toolbar=0&navpanes=0&scrollbar=0&view=FitH`;
  }
  return url;
};

/**
 * Manufacturing Document Processing Component
 * Main component for processing manufacturing documents
 */
const ManufacturingDocumentProcessing = () => {
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [extractingDocId, setExtractingDocId] = useState<string | null>(null);
  const [showExtractedInfo, setShowExtractedInfo] = useState<{[key: string]: boolean}>({});
  const [showWorkflow, setShowWorkflow] = useState<{[key: string]: boolean}>({});
  const [activeTab, setActiveTab] = useState<'extracted' | 'workflow'>('workflow');
  const [isWorkflowAnimating, setIsWorkflowAnimating] = useState<{[key: string]: boolean}>({});
  const [workflowCompleted, setWorkflowCompleted] = useState<{[key: string]: boolean}>({});
  const [extractionCount, setExtractionCount] = useState<{[key: string]: number}>({});
  const [payloadData, setPayloadData] = useState<{[key: string]: string}>({}); // Store original payload data
  const selectedDocData = selectedDocId ? mockDocuments[selectedDocId] : null;

  // Redux state management
  const dispatch = useAppDispatch();
  const extractedData = useAppSelector((state) => state.extractedData);

  /**
   * Helper to check if the selected doc is an image
   */
  const isImage = (url: string) => /\.(jpg|jpeg|png|webp|gif)$/i.test(url);

  /**
   * Parse extracted data from API response
   */
  const parseExtractedData = (dataString: string) => {
    if (!dataString) return { explicit: [], inferred: [] };
    
    const lines = dataString.split('\n');
    const explicit: Array<{ field: string; value: string }> = [];
    const inferred: Array<{ field: string; value: string }> = [];
    
    let currentSection = 'explicit';
    let isHeader = true;
    
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed === 'Explicit Extraction' || trimmed.includes('Extracted information')) {
        continue;
      }
      
      if (trimmed === 'Inferred Fields') {
        currentSection = 'inferred';
        isHeader = true;
        continue;
      }
      
      if (trimmed === 'Field\tExtracted Value' || trimmed === 'Field\tInferred Value') {
        isHeader = false;
        continue;
      }
      
      if (!isHeader && trimmed.includes('\t')) {
        const [field, ...valueParts] = trimmed.split('\t');
        const value = valueParts.join('\t').trim();
        
        if (field && value) {
          if (currentSection === 'explicit') {
            explicit.push({ field: field.trim(), value });
          } else {
            inferred.push({ field: field.trim(), value });
          }
        }
      }
    }
    
    return { explicit, inferred };
  };

  /**
   * API call for Purchase Order extraction
   */
  const makePurchaseOrderApiCall = async (docId: string) => {
    if (docId === 'purchase_order') {
      const API_URL = import.meta.env.VITE_API_BASE_URL;
      
      const documentData = `Purchase Order Extracted information 
Explicit Extraction
Field	Extracted Value
PO Number	2025-PO-10842
Date	17/11/2025
Vendor Name	ABC Corp.
Vendor Address	123 Business Park Rd, New Delhi, IN 110001
Vendor Phone	(011) 2345-6789
Vendor Fax	(011) 2345-6790
Ship To Name	XYZ Manufacturing Plant
Ship To Address	456 Industrial Estate, Gurugram, IN 122001
Ship To Phone	(0124) 9876-5432
Ship To Fax	(0124) 9876-5433
Shipping Terms	Cost, Insurance & Freight
Shipping Method	FedEx
Delivery Date	24/11/2025
Item 1 Description	Industrial Motor 5HP
Item 1 Quantity	2
Item 1 Unit Price	₹25,000
Item 1 Total	₹50,000
Item 2 Description	Control Panel Kit
Item 2 Quantity	1
Item 2 Unit Price	₹15,500
Item 2 Total	₹15,500
Item 3 Description	Copper Wiring Bundle (100m)
Item 3 Quantity	5
Item 3 Unit Price	₹2,000
Item 3 Total	₹10,000
Item 4 Description	Safety Switch (High Voltage)
Item 4 Quantity	3
Item 4 Unit Price	₹3,500
Item 4 Total	₹10,500
Subtotal	₹86,000
Tax Rate	18%
Tax Amount	₹15,480
Shipping	₹1,500
Total Amount	₹1,02,980
Special Instructions	Please ensure installation manual and quality certification accompany the shipment.
Inferred Fields
Field	Inferred Value
Document Type	Purchase Order
Currency	INR (₹)
Total Items	4
Total Quantity	11 units
Tax Status	Taxable (18% GST)
Payment Terms	Not Specified`;

      const requestData = {
        event_type: "kyc_extraction",
        document_data: documentData
      };
      
      // Store the payload data for display in extracted information
      setPayloadData(prev => ({ ...prev, [docId]: documentData }));
      
      try {
        console.log('Making Purchase Order API call with data:', requestData);
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
          const result = await response.json();
          console.log('Purchase Order API response received:', result);
          dispatch(setExtractedData({ docId, data: result }));
        } else {
          console.error('Purchase Order API call failed:', response.status);
          dispatch(setExtractedData({ 
            docId, 
            data: { 
              statusCode: 200,
              session_id: 'demo-session-' + Date.now(),
              response_data: {
                extracted_kyc_data: documentData,
                timestamp: new Date().toISOString(),
                session_id: 'demo-session-' + Date.now()
              }
            }
          }));
        }
      } catch (error) {
        console.error('Purchase Order API call error:', error);
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: documentData,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    }
  };

  /**
   * API call for Inspection Report extraction
   */
  const makeInspectionReportApiCall = async (docId: string) => {
    if (docId === 'inspection_report') {
      const API_URL = import.meta.env.VITE_API_BASE_URL;
      
      const documentData = `Inspection Report Extracted information 
Explicit Extraction
Field	Extracted Value
Report ID	IR-2025-0234
Inspection Date	17/11/2025
Inspector Name	Mr. Rajesh Kumar
Designation	Senior Quality Auditor
Company	Railway Systems Ltd.
Location	Unit 2, Industrial Area, Pune
Total Items Inspected	18
Items Passed	15
Items Failed	3
Overall Status	Conditionally Approved
Item 1 Number	11201
Item 1 Component Name	Rail Track Sensor Unit
Item 1 Quantity	10
Item 1 Status	Pass
Item 1 Remarks	All units meet quality standards
Item 2 Number	10867
Item 2 Component Name	High Voltage Relay
Item 2 Quantity	5
Item 2 Status	Fail
Item 2 Remarks	3 units showed voltage anomalies
Item 3 Number	11903
Item 3 Component Name	Brake System Module
Item 3 Quantity	3
Item 3 Status	Pass
Item 3 Remarks	Operational and responsive
Item 4 Number	14567
Item 4 Component Name	Overhead Signal Receiver
Item 4 Quantity	8
Item 4 Status	Pass
Item 4 Remarks	Signal integrity verified
Item 5 Number	13759
Item 5 Component Name	Compressor Unit
Item 5 Quantity	2
Item 5 Status	Fail
Item 5 Remarks	Air pressure instability detected
Conclusion	Most components meet expected quality and performance standards. Failed items require immediate attention and rework.
Recommendations	Manufacturer should recalibrate or replace failed units before final assembly.
Inferred Fields
Field	Inferred Value
Document Type	Inspection Report
Inspection Type	Quality and Safety Inspection
Industry	Railway Systems
Pass Rate	83.33%
Failure Rate	16.67%
Requires Rework	Yes`;

      const requestData = {
        event_type: "kyc_extraction",
        document_data: documentData
      };
      
      // Store the payload data for display in extracted information
      setPayloadData(prev => ({ ...prev, [docId]: documentData }));
      
      try {
        console.log('Making Inspection Report API call with data:', requestData);
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
          const result = await response.json();
          console.log('Inspection Report API response received:', result);
          dispatch(setExtractedData({ docId, data: result }));
        } else {
          console.error('Inspection Report API call failed:', response.status);
          dispatch(setExtractedData({ 
            docId, 
            data: { 
              statusCode: 200,
              session_id: 'demo-session-' + Date.now(),
              response_data: {
                extracted_kyc_data: documentData,
                timestamp: new Date().toISOString(),
                session_id: 'demo-session-' + Date.now()
              }
            }
          }));
        }
      } catch (error) {
        console.error('Inspection Report API call error:', error);
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: documentData,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    }
  };

  /**
   * API call for Safety Checklist extraction
   */
  const makeSafetyChecklistApiCall = async (docId: string) => {
    if (docId === 'safety_checklist') {
      const API_URL = import.meta.env.VITE_API_BASE_URL;
      
      const documentData = `Safety Checklist Extracted information 
Explicit Extraction
Field	Extracted Value
Report ID	SC-2025-0133
Date	17/11/2025
Prepared By	A. Sharma
Department	Safety & Audit
Total Checks	30
Compliant	22
Non-Compliant	8
Critical Issues	3
Non-Compliant Item 1 ID	NC-01
Non-Compliant Item 1 Description	Exit signs not visible
Non-Compliant Item 1 Severity	High
Non-Compliant Item 1 Action	Install new signs
Non-Compliant Item 2 ID	NC-03
Non-Compliant Item 2 Description	Fire doors blocked
Non-Compliant Item 2 Severity	Critical
Non-Compliant Item 2 Action	Clear pathways
Non-Compliant Item 3 ID	NC-08
Non-Compliant Item 3 Description	PPE log outdated
Non-Compliant Item 3 Severity	Medium
Non-Compliant Item 3 Action	Update monthly
Action ID 1	ACT-11
Action Task 1	Replace fire extinguisher tags
Action Status 1	Pending
Action Due Date 1	25 Nov
Action ID 2	ACT-18
Action Task 2	Install new CCTV
Action Status 2	In progress
Action Due Date 2	20 Nov
Action ID 3	ACT-22
Action Task 3	Clear emergency exits
Action Status 3	Complete
Action Due Date 3	15 Nov
Recommendation Area 1	Documentation
Recommendation Suggestion 1	Automate checklists via software
Recommendation Area 2	Training
Recommendation Suggestion 2	Monthly fire drills required
Recommendation Area 3	Maintenance
Recommendation Suggestion 3	Quarterly safety audits recommended
Inferred Fields
Field	Inferred Value
Document Type	Safety Compliance Checklist Report
Compliance Rate	73.33%
Non-Compliance Rate	26.67%
Critical Issue Rate	10%
Overall Status	Needs Improvement
Requires Immediate Action	Yes
Pending Actions Count	2
Completed Actions Count	1`;

      const requestData = {
        event_type: "kyc_extraction",
        document_data: documentData
      };
      
      // Store the payload data for display in extracted information
      setPayloadData(prev => ({ ...prev, [docId]: documentData }));
      
      try {
        console.log('Making Safety Checklist API call with data:', requestData);
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
          const result = await response.json();
          console.log('Safety Checklist API response received:', result);
          dispatch(setExtractedData({ docId, data: result }));
        } else {
          console.error('Safety Checklist API call failed:', response.status);
          dispatch(setExtractedData({ 
            docId, 
            data: { 
              statusCode: 200,
              session_id: 'demo-session-' + Date.now(),
              response_data: {
                extracted_kyc_data: documentData,
                timestamp: new Date().toISOString(),
                session_id: 'demo-session-' + Date.now()
              }
            }
          }));
        }
      } catch (error) {
        console.error('Safety Checklist API call error:', error);
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: documentData,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    }
  };

  /**
   * API call for Maintenance Log extraction
   */
  const makeMaintenanceLogApiCall = async (docId: string) => {
    if (docId === 'maintenance_log') {
      const API_URL = import.meta.env.VITE_API_BASE_URL;
      
      const documentData = `Maintenance Log Extracted information 
Explicit Extraction
Field	Extracted Value
Log ID	ML-2025-056
Maintenance Date	17/11/2025
Supervisor	Dr. Swati Joshi
Department	Facility Operations
Location	Central Plant - Block A
Task 1 ID	MT-0921
Task 1 Description	Calibration of Pressure Gauge #3
Task 1 Performed By	Amit Sharma
Task 1 Date Completed	12/11/2025
Task 1 Status	Completed
Task 2 ID	MT-0922
Task 2 Description	Lubrication of Conveyor Belt
Task 2 Performed By	Ravi Kumar
Task 2 Date Completed	13/11/2025
Task 2 Status	Completed
Task 3 ID	MT-0924
Task 3 Description	Overhaul of Hydraulic System
Task 3 Performed By	Pooja Mehta
Task 3 Date Completed	15/11/2025
Task 3 Status	Partially Completed
Task 4 ID	MT-0925
Task 4 Description	Replacement of Cooling Fans
Task 4 Performed By	Sunil Patil
Task 4 Date Completed	16/11/2025
Task 4 Status	Completed
Upcoming Service Equipment 1	Water Pump Unit
Upcoming Service Interval 1	Monthly
Upcoming Service Next Due 1	10/12/2025
Upcoming Service Technician 1	Ravi Kumar
Upcoming Service Equipment 2	Backup Generator
Upcoming Service Interval 2	Quarterly
Upcoming Service Next Due 2	15/01/2026
Upcoming Service Technician 2	Sunil Patil
Upcoming Service Equipment 3	Air Conditioning System
Upcoming Service Interval 3	Bi-Annually
Upcoming Service Next Due 3	20/04/2026
Upcoming Service Technician 3	Amit Sharma
Inferred Fields
Field	Inferred Value
Document Type	Maintenance Log Report
Total Tasks Completed	4
Completed Tasks Count	3
Partially Completed Tasks Count	1
Upcoming Services Count	3
Maintenance Status	Mostly Completed
Requires Follow-up	Yes (1 task partially completed)`;

      const requestData = {
        event_type: "kyc_extraction",
        document_data: documentData
      };
      
      // Store the payload data for display in extracted information
      setPayloadData(prev => ({ ...prev, [docId]: documentData }));
      
      try {
        console.log('Making Maintenance Log API call with data:', requestData);
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
          const result = await response.json();
          console.log('Maintenance Log API response received:', result);
          dispatch(setExtractedData({ docId, data: result }));
        } else {
          console.error('Maintenance Log API call failed:', response.status);
          dispatch(setExtractedData({ 
            docId, 
            data: { 
              statusCode: 200,
              session_id: 'demo-session-' + Date.now(),
              response_data: {
                extracted_kyc_data: documentData,
                timestamp: new Date().toISOString(),
                session_id: 'demo-session-' + Date.now()
              }
            }
          }));
        }
      } catch (error) {
        console.error('Maintenance Log API call error:', error);
        dispatch(setExtractedData({ 
          docId, 
          data: { 
            statusCode: 200,
            session_id: 'demo-session-' + Date.now(),
            response_data: {
              extracted_kyc_data: documentData,
              timestamp: new Date().toISOString(),
              session_id: 'demo-session-' + Date.now()
            }
          }
        }));
      }
    }
  };

  /**
   * Handle extract button click
   */
  const handleExtract = async (docId: string) => {
    setExtractingDocId(docId);
    setShowExtractedInfo(prev => ({ ...prev, [docId]: false }));
    
    // Reset workflow completion state for new extraction
    setWorkflowCompleted(prev => ({ ...prev, [docId]: false }));
    
    // Increment extraction count to force workflow re-render
    setExtractionCount(prev => ({ ...prev, [docId]: (prev[docId] || 0) + 1 }));
    
    // Trigger workflow animation
    setIsWorkflowAnimating(prev => ({ ...prev, [docId]: true }));
    
    // Clear Redux state for fresh extraction
    dispatch(clearExtractedData(docId));
    
    // Automatically switch to workflow tab when starting new extraction
    setActiveTab('workflow');
    
    // Make appropriate API call based on document type
    if (docId === 'purchase_order') {
      console.log('Starting Purchase Order extraction...');
      await makePurchaseOrderApiCall(docId);
      console.log('Purchase Order extraction completed, extractedData state:', extractedData);
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else if (docId === 'inspection_report') {
      console.log('Starting Inspection Report extraction...');
      await makeInspectionReportApiCall(docId);
      console.log('Inspection Report extraction completed, extractedData state:', extractedData);
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else if (docId === 'safety_checklist') {
      console.log('Starting Safety Checklist extraction...');
      await makeSafetyChecklistApiCall(docId);
      console.log('Safety Checklist extraction completed, extractedData state:', extractedData);
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    } else if (docId === 'maintenance_log') {
      console.log('Starting Maintenance Log extraction...');
      await makeMaintenanceLogApiCall(docId);
      console.log('Maintenance Log extraction completed, extractedData state:', extractedData);
      // Add a delay to ensure state is updated and workflow can access the data
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('After delay, extractedData state:', extractedData);
    }
    
    // The workflow completion will be handled by the DocumentWorkflow component callback
  };

  /**
   * Handle workflow completion callback
   */
  const handleWorkflowComplete = async () => {
    if (selectedDocId) {
      setShowExtractedInfo(prev => ({ ...prev, [selectedDocId]: true }));
      setExtractingDocId(null);
      setIsWorkflowAnimating(prev => ({ ...prev, [selectedDocId]: false }));
      setWorkflowCompleted(prev => ({ ...prev, [selectedDocId]: true }));
      // Wait 2.5 seconds (2-3 seconds) after workflow completes to show API response
      await new Promise(resolve => setTimeout(resolve, 2500));
      setActiveTab('extracted');
    }
  };

  /**
   * Prevent access to extracted tab if not available
   */
  const handleTabChange = (tab: 'extracted' | 'workflow') => {
    if (tab === 'extracted' && selectedDocId && !showExtractedInfo[selectedDocId]) {
      return; // Block access to extracted tab
    }
    setActiveTab(tab);
  };

  /**
   * Auto-redirect to workflow tab if extracted tab is accessed before completion
   */
  useEffect(() => {
    if (activeTab === 'extracted' && selectedDocId && !showExtractedInfo[selectedDocId]) {
      setActiveTab('workflow');
    }
  }, [activeTab, selectedDocId, showExtractedInfo]);

  return (
    <>
      <LoginNavbar />
      <div className="container py-6">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-2 -ml-1" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <Link to="/customer/sandbox/manufacturinghome" className="flex items-center gap-2 text-gray-500 no-underline hover:text-gray-700">
                <HomeIcon size={16} className="relative top-[-1px]" />
                Home
              </Link>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-orange-600 font-medium">Intelligent Document Processing</span>
            </li>
          </ol>
        </nav>
        {/* Page Title and Subtitle */}
        <div className="flex items-center gap-6 mb-4 ml-4">
          <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
            <FileText className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
              Intelligent Document Processing
            </h1>
            <p className="text-base text-gray-600">
              Automates extraction and validation of key data from manufacturing documentation using Textract + Claude for hybrid OCR + semantic parsing.
            </p>
          </div>
        </div>
        <div className="container mx-auto py-4 px-4 md:px-6 lg:px-8 min-h-screen">
          {/* Card Selector */}
          <div className="w-full mb-10">
            <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(220px, 1fr))` }}>
              {documentTypes.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => {
                    console.log('Clicking card:', doc.id, 'Current selected:', selectedDocId);
                    setSelectedDocId(doc.id);
                    // Show workflow immediately when document is selected
                    setShowWorkflow(prev => ({ ...prev, [doc.id]: true }));
                    // Reset workflow completion state for new document
                    setWorkflowCompleted(prev => ({ ...prev, [doc.id]: false }));
                    
                    // Reset extracted info state for new document type
                    setShowExtractedInfo(prev => ({ ...prev, [doc.id]: false }));
                    
                    // Clear Redux state for all document types to ensure fresh extraction
                    dispatch(clearExtractedData('purchase_order'));
                    dispatch(clearExtractedData('inspection_report'));
                    dispatch(clearExtractedData('safety_checklist'));
                    dispatch(clearExtractedData('maintenance_log'));
                    
                    // Clear payload data for fresh extraction
                    setPayloadData({});
                    
                    // Reset workflow animation state for new document
                    setIsWorkflowAnimating(prev => ({ ...prev, [doc.id]: false }));
                    
                    // Force active tab to workflow for new document selection
                    setActiveTab('workflow');
                  }}
                  className="cursor-pointer transition-colors duration-200 p-4 rounded-lg bg-white"
                  data-selected={selectedDocId === doc.id}
                  style={{
                    backgroundColor: selectedDocId === doc.id ? 'rgb(255, 251, 245)' : 'white',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)',
                    position: 'relative',
                    border: selectedDocId === doc.id 
                      ? '2px solid #fb923c' 
                      : 'none'
                  }}
                >
                  <div className="flex items-start gap-4">
                    {doc.icon}
                    <div>
                      <h3 className="font-semibold text-base text-gray-800">{doc.name}</h3>
                      <p className="text-sm text-gray-500">{doc.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {selectedDocId && selectedDocData ? (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left: PDF or Image */}
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">{selectedDocData.type}</h2>
                  <div className="w-full h-[700px] rounded-md overflow-hidden bg-white flex flex-col" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                    <div className="flex-1 flex items-center justify-center" style={{ minHeight: 0 }}>
                      {isImage(docUrls[selectedDocId]) ? (
                        <img
                          src={docUrls[selectedDocId]}
                          alt="Document"
                          style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', width: '100%', height: '100%' }}
                        />
                      ) : (
                        <iframe
                          src={getPdfUrl(docUrls[selectedDocId])}
                          title={`${selectedDocData.type} PDF`}
                          width="100%"
                          height="100%"
                          style={{ border: 'none' }}
                          allowFullScreen
                        />
                      )}
                    </div>
                    {/* Extract Button inside the card */}
                    <div className="p-4 border-t border-gray-200 bg-white" style={{ flexShrink: 0 }}>
                      <button
                        onClick={() => handleExtract(selectedDocId)}
                        disabled={extractingDocId === selectedDocId}
                        className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                          extractingDocId === selectedDocId
                            ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                            : 'bg-orange-500 text-white hover:bg-orange-600'
                        }`}
                      >
                        {extractingDocId === selectedDocId ? (
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                            Extracting...
                          </div>
                        ) : (
                          'Extract'
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Tabbed Interface */}
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">Document Analysis</h2>
                  <div className="w-full rounded-md bg-white" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                    {/* Tab Navigation */}
                    <div className="flex border-b border-gray-200 bg-gray-50">
                      <button
                        className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                          activeTab === 'workflow' 
                            ? 'bg-white text-orange-600 border-b-2 border-orange-500' 
                            : 'bg-transparent text-gray-500 hover:text-gray-700'
                        }`}
                        onClick={() => handleTabChange('workflow')}
                      >
                        Processing Workflow
                      </button>
                      <button
                        className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-all duration-200 ${
                          activeTab === 'extracted' 
                            ? 'bg-white text-orange-600 border-b-2 border-orange-500' 
                            : 'bg-transparent text-gray-500 hover:text-gray-700'
                        } ${!showExtractedInfo[selectedDocId] ? 'opacity-50 cursor-not-allowed' : ''}`}
                        onClick={() => handleTabChange('extracted')}
                        disabled={!showExtractedInfo[selectedDocId]}
                      >
                        Extracted Information
                      </button>
                    </div>
                    
                    {/* Tab Content */}
                    <div className="card_body_custom" style={{ position: 'relative', minHeight: 650, height: 650, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: 'white' }}>
                      <div style={{ minHeight: 650, height: 650, maxHeight: 700, overflowY: 'auto' }}>
                        {activeTab === 'extracted' && (
                          <div className="p-6">
                            {!showExtractedInfo[selectedDocId] ? (
                              // Force redirect to workflow tab if extracted info is not available
                              <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                                style={{
                                  minHeight: 650,
                                  height: 650,
                                  color: '#b0b0b0',
                                  fontSize: '0.9rem',
                                  fontWeight: 400,
                                  letterSpacing: '0.01em',
                                  textAlign: 'center',
                                  background: 'inherit',
                                  fontFamily: 'Inter, sans-serif'
                                }}
                              >
                                <span>
                                  Processing not completed yet.
                                </span>
                                <span style={{ lineHeight: '1.2', marginTop: '10px' }}>
                                  Please complete the workflow first.
                                </span>
                                <button
                                  onClick={() => setActiveTab('workflow')}
                                  className="mt-4 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                                >
                                  Go to Workflow
                                </button>
                              </div>
                            ) : (() => {
                              // Use the original payload data that was sent to the API, not the API response
                              const originalPayloadData = payloadData[selectedDocId] || '';
                              const parsed = parseExtractedData(originalPayloadData);
                              // Filter out Special Instructions, Conclusion, and Recommendations fields
                              const filteredExplicit = parsed.explicit.filter(field => {
                                const fieldLower = field.field.toLowerCase();
                                return !fieldLower.includes('special instructions') && 
                                       !fieldLower.includes('conclusion') && 
                                       !fieldLower.includes('recommendations');
                              });
                              
                              return (
                                <>
                                  {filteredExplicit.length > 0 && (
                                    <>
                                      <h3 className="text-lg font-bold mb-4">Explicit Extraction</h3>
                                      <table className="w-full text-sm">
                                        <thead>
                                          <tr className="text-left text-gray-500">
                                            <th className="py-2 text-left">Field</th>
                                            <th className="py-2 text-right">Extracted Value</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {filteredExplicit.map((field, idx) => (
                                            <tr key={idx} className="border-b last:border-b-0">
                                              <td className="py-2 text-gray-700 text-left align-middle">{field.field}</td>
                                              <td className="py-2 font-medium text-gray-900 text-right align-middle">{field.value || <span className="text-gray-400 italic">(not extracted)</span>}</td>
                                            </tr>
                                          ))}
                                        </tbody>
                                      </table>
                                    </>
                                  )}
                                  
                                  {filteredExplicit.length === 0 && (
                                    <div className="text-center py-8 text-gray-500">
                                      No extracted data available
                                    </div>
                                  )}
                                </>
                              );
                            })()}
                          </div>
                        )}
                        
                        {activeTab === 'workflow' && (
                          <div className="p-6">
                            <DocumentWorkflow 
                              key={`${selectedDocId}-${extractionCount[selectedDocId] || 0}`}
                              isVisible={showWorkflow[selectedDocId] || false}
                              documentType={selectedDocData.type}
                              onProcessingComplete={handleWorkflowComplete}
                              isAnimating={isWorkflowAnimating[selectedDocId] || false}
                              resetKey={selectedDocId}
                              isCompleted={workflowCompleted[selectedDocId] || false}
                              extractedData={extractedData[selectedDocId]}
                            />
                          </div>
                        )}
                      </div>  
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <div className="inline-block bg-gray-100 p-5 rounded-full mb-4">
                <FileText className="h-12 w-12 text-gray-300" />
              </div>
              <p className="text-gray-500">Select a document option to begin the extraction process</p>
            </div>
          )}
        </div>
      </div>
      <ManufacturingFooter />
    </>
  );
};

export default ManufacturingDocumentProcessing;

