import React from 'react';
import { Link } from 'react-router-dom';
import { Car, Home } from 'lucide-react';
import GEARVirtualSalesAssistantTool from './GEARVirtualSalesAssistantTool';
import ManufacturingLayout from './ManufacturingLayout';

/**
 * GEAR Virtual Sales Assistant Page Component
 * Wrapper component for the automotive sales assistant chat interface
 */
const GEARVirtualSalesAssistant: React.FC = () => {
  return (
    <ManufacturingLayout>
      <div className="flex-grow container mx-auto px-4 py-4">
        <div className="mx-auto w-full max-w-10xl mt-8">
          <div className="mb-4">
            <div className="w-full">
              <nav className="flex text-sm text-gray-500 mb-2 -mt-6 -ml-5" aria-label="Breadcrumb">
                <ol className="inline-flex items-center space-x-1">
                  <li>
                    <Link to="/customer/sandbox/manufacturinghome" className="flex items-center gap-2 text-gray-500 no-underline hover:text-gray-700">
                      <Home size={16} className="relative top-[-1px]" />
                      <span>Home</span>
                    </Link>
                  </li>
                  <li>
                    <span className="mx-2">/</span>
                    <span className="text-orange-600 font-medium">GEAR Virtual Sales Assistant</span>
                  </li>
                </ol>
              </nav>
              <div className="flex items-center mb-2">
                <div className="ub-feature-icon mr-3">
                  <Car size={30} />
                </div>
                <div>
                  <h2 className="mb-0 text-3xl font-bold">GEAR Virtual Sales Assistant</h2>
                  <p className="text-gray-500" style={{ lineHeight: '1.5' }}>B2C conversational AI for automotive dealerships. Answers product questions using RAG, schedules test drives and service appointments, and handles FAQs on pricing, warranty, service history, and parts availability.</p>
                </div>
              </div>
            </div>
          </div>
          
          <GEARVirtualSalesAssistantTool />
        </div>
      </div>
    </ManufacturingLayout>
  );
};

export default GEARVirtualSalesAssistant;

