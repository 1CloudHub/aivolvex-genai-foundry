import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Loader2, Home, MessageSquare, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import ManufacturingLayout from './ManufacturingLayout';
import { Mic as MicIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import axios from 'axios';

/**
 * Session Manager Class
 * Manages conversation sessions and history
 */
class SessionManager {
  private sessionId: string;
  private conversationHistory: Array<{
    type: 'user' | 'bot';
    content: string;
    timestamp: string;
  }>;

  constructor() {
    this.sessionId = this.generateSessionId();
    this.conversationHistory = [];
  }

  generateSessionId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  addMessage(type: 'user' | 'bot', content: string): void {
    this.conversationHistory.push({
      type: type,
      content: content,
      timestamp: new Date().toISOString()
    });
  }

  getConversationHistory(): Array<{
    type: 'user' | 'bot';
    content: string;
    timestamp: string;
  }> {
    return this.conversationHistory;
  }

  getSessionId(): string {
    return this.sessionId;
  }

  resetSession(): void {
    this.sessionId = this.generateSessionId();
    this.conversationHistory = [];
  }
}

// Voice interaction states
type VoiceState = 'idle' | 'recording' | 'processing' | 'playing';

/**
 * RecordButton Component
 * Handles voice recording button states
 */
interface RecordButtonProps {
  state: VoiceState;
  onRecord: () => void;
  onStop: () => void;
  processingTimeLeft?: number;
}

const RecordButton: React.FC<RecordButtonProps> = ({ state, onRecord, onStop, processingTimeLeft }) => {
  const getButtonConfig = () => {
    switch (state) {
      case 'recording':
        return {
          bg: 'bg-red-500 hover:bg-red-600',
          text: 'Recording...',
          icon: <Square size={32} className="text-white" />,
          pulse: true,
          onClick: onStop
        };
      case 'processing':
        return {
          bg: 'bg-gray-400 cursor-not-allowed',
          text: processingTimeLeft ? `Processing...` : 'Processing...',
          icon: <Loader2 size={32} className="text-white animate-spin" />,
          pulse: false,
          onClick: undefined
        };
      case 'playing':
        return {
          bg: 'bg-gray-400 cursor-not-allowed',
          text: 'Playing...',
          icon: <Mic size={32} className="text-white opacity-50" />,
          pulse: false,
          onClick: undefined
        };
      default:
        return {
          bg: 'bg-[#FF7A00] hover:bg-[#E85D04]',
          text: 'Press to Record',
          icon: <Mic size={32} className="text-white" />,
          pulse: false,
          onClick: onRecord
        };
    }
  };

  const config = getButtonConfig();

  return (
    <div className="flex flex-col items-center space-y-4">
      <button
        onClick={config.onClick}
        disabled={!config.onClick}
        className={`
          w-24 h-24 rounded-full flex items-center justify-center
          transition-all duration-300 transform hover:scale-105
          ${config.bg}
          ${config.pulse ? 'animate-pulse' : ''}
          disabled:hover:scale-100
        `}
      >
        {config.icon}
      </button>
      <p className="text-[#1E3A8A] font-semibold text-xl">{config.text}</p>
    </div>
  );
};

/**
 * WaveformVisualizer Component
 * Visualizes audio waveform during recording/playback
 */
interface WaveformVisualizerProps {
  isPlaying: boolean;
  isRecording: boolean;
}

const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({ isPlaying, isRecording }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const barHeightsRef = useRef<number[]>([]);
  const targetHeightsRef = useRef<number[]>([]);

  useEffect(() => {
    if (!canvasRef.current) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      return;
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;
    const bars = 60;
    const totalWaveformWidth = canvas.width * 0.7;
    const barWidth = totalWaveformWidth / bars;
    const offsetX = (canvas.width - totalWaveformWidth) / 2;
    
    if (barHeightsRef.current.length === 0) {
      barHeightsRef.current = Array(bars).fill(0).map(() => Math.random() * 60 + 10);
      targetHeightsRef.current = Array(bars).fill(0).map(() => Math.random() * 60 + 10);
    }

    const draw = () => {
      if (!ctx) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < bars; i++) {
        let barHeight;
        
        if (isPlaying || isRecording) {
          if (Math.random() < 0.06) {
            targetHeightsRef.current[i] = Math.random() * 80 + 15;
          }
          
          const currentHeight = barHeightsRef.current[i];
          const targetHeight = targetHeightsRef.current[i];
          const difference = targetHeight - currentHeight;
          barHeightsRef.current[i] += difference * 0.2;
          
          barHeight = barHeightsRef.current[i];
        } else {
          barHeight = 15 + Math.sin(i * 2.5) * 8 + Math.cos(i * 1.7) * 12 + Math.sin(i * 0.8) * 6;
          barHeight = Math.abs(barHeight);
        }
        
        const x = offsetX + i * barWidth;
        const y = (canvas.height - barHeight) / 2;
        
        ctx.fillStyle = (isPlaying || isRecording) ? '#FF7A00' : '#9CA3AF';
        
        const barWidthActual = barWidth - 6;
        const cornerRadius = barWidthActual / 2;
        
        ctx.beginPath();
        ctx.roundRect(x, y, barWidthActual, barHeight, cornerRadius);
        ctx.fill();
      }

      time += 0.5;
      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, isRecording]);

  return (
    <div className="w-full mb-8">
      <canvas
        ref={canvasRef}
        width={800}
        height={100}
        className="w-full h-[100px]"
      />
    </div>
  );
};

/**
 * Error Banner Component
 * Displays error messages
 */
interface ErrorBannerProps {
  message: string;
  onClose: () => void;
}

const ErrorBanner: React.FC<ErrorBannerProps> = ({ message, onClose }) => (
  <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
    <div className="flex justify-between items-center">
      <span>{message}</span>
      <button onClick={onClose} className="text-red-500 hover:text-red-700">
        ×
      </button>
    </div>
  </div>
);

/**
 * Factory Voice Assistant Tool Component
 * Voice-enabled SOP and manual retrieval for factory workers
 */
const FactoryVoiceAssistantTool: React.FC = () => {
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [error, setError] = useState<string>('');
  const mediaRecorderRef = useRef<MediaRecorder>();
  const audioChunksRef = useRef<Blob[]>([]);
  const audioElementRef = useRef<HTMLAudioElement>();
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  
  // API related states
  const [isFirstApiCalled, setIsFirstApiCalled] = useState(false);
  const [transcription, setTranscription] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [language, setLanguage] = useState("en");
  const [translationType, setTranslationType] = useState("llm");
  
  // WebSocket related states
  const [connectionId, setConnectionId] = useState<string | null>(null);
  const [streamingMessage, setStreamingMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  const sawTextDeltaRef = useRef(false);
  
  // Processing timer states
  const [processingTimeLeft, setProcessingTimeLeft] = useState(0);
  const processingTimerRef = useRef<number>();
  const processingStartTimeRef = useRef<number>(0);
  const responseReceivedRef = useRef(false);
  
  // Session Manager
  const sessionManagerRef = useRef<SessionManager>(new SessionManager());

  // Example questions for factory workers
  const exampleQuestions = [
    'What are the technical specifications of each Veltro model?',
    'What is the price and availability of spare parts like EV batteries and ADAS modules?',
    'Are there any service bulletins or recalls for specific models?',
    'What is covered under warranty, especially for EV batteries?',
    'What are the labor procedures for ADAS calibration and EV diagnostics?',
    'What is the COE-inclusive price and promotions for each model?',
    'How do I access service history using the VIN?'
  ];

  /**
   * Start processing timer
   */
  const startProcessingTimer = () => {
    responseReceivedRef.current = false;
    processingStartTimeRef.current = Date.now();
    setProcessingTimeLeft(65);
    
    processingTimerRef.current = setInterval(() => {
      const elapsed = Math.floor((Date.now() - processingStartTimeRef.current) / 1000);
      const timeLeft = Math.max(0, 65 - elapsed);
      setProcessingTimeLeft(timeLeft);
      
      if (timeLeft === 0 && !responseReceivedRef.current) {
        console.log("65 seconds timeout reached without response, returning to idle state");
        setVoiceState('idle');
        setError('Request timed out after 65 seconds. Please try again.');
        clearProcessingTimer();
      }
    }, 1000);
  };

  /**
   * Clear processing timer
   */
  const clearProcessingTimer = () => {
    if (processingTimerRef.current) {
      clearInterval(processingTimerRef.current);
      processingTimerRef.current = undefined;
    }
    setProcessingTimeLeft(0);
  };

  /**
   * WebSocket connection function
   */
  const openWebsocketConnection = (): Promise<string> => {
    return new Promise((resolve, reject) => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN && connectionId) {
        console.log("Reusing existing WebSocket connection with ID:", connectionId);
        resolve(connectionId);
        return;
      }

      if (socketRef.current && socketRef.current.readyState !== WebSocket.CLOSED) {
        socketRef.current.close();
      }

      const socket = new WebSocket(
        import.meta.env.VITE_WEBSOCKET_URL_VOICEOPS
      );
      
      let accumulatedMessage = '';
      sawTextDeltaRef.current = false;
      let connectionResolved = false;
      
      socket.onopen = () => {
        console.log('WebSocket Connected for Factory Voice Assistant');
        socket.send(JSON.stringify({ type: "connection_init" }));
      };

      socket.onmessage = (e) => {
        try {
          const messageData = JSON.parse(e.data);
          console.log(messageData, "receivedData_connectid_factory_voice");
          
          if (messageData.connectionid && !connectionResolved) {
            console.log("Connection ID received for Factory Voice Assistant:", messageData.connectionid);
            setConnectionId(messageData.connectionid);
            connectionResolved = true;
            resolve(messageData.connectionid);
          }

          // Handle audio URL from S3
          if (messageData.audio && typeof messageData.audio === 'string' && messageData.audio.includes('s3.amazonaws.com')) {
            console.log("Audio URL received from WebSocket:", messageData.audio);
            responseReceivedRef.current = true;
            clearProcessingTimer();
            setVoiceState('playing');
            
            const audio = new Audio(messageData.audio);
            audioElementRef.current = audio;

            audio.addEventListener("ended", () => {
              console.log("Audio playback ended, setting voice state to 'idle'");
              setVoiceState('idle');
            });

            audio.addEventListener("error", (err) => {
              console.error('Audio playback failed:', err);
              setError('Audio playback failed. Please try again.');
              setVoiceState('idle');
            });

            audio.play().catch(err => {
              console.error('Audio playback failed:', err);
              setError('Audio playback failed. Please try again.');
              setVoiceState('idle');
            });
          }

          // Track if we have seen a text_delta in this stream
          if (messageData.type === "content_block_delta" && messageData.delta?.type === "text_delta") {
            sawTextDeltaRef.current = true;
            accumulatedMessage += messageData.delta.text;
            setStreamingMessage(accumulatedMessage);
            setIsStreaming(true);
          }

          // Handle stream completion
          if (messageData.type === "content_block_stop" || messageData.type === "message_stop") {
            if (sawTextDeltaRef.current) {
              setIsStreaming(false);
              
              if (accumulatedMessage.trim()) {
                setAiResponse(accumulatedMessage);
                sessionManagerRef.current.addMessage('bot', accumulatedMessage);
              }
              setStreamingMessage('');
              
              if (voiceState === 'processing' && !responseReceivedRef.current) {
                console.log("Stream completed with text response, no audio URL");
                responseReceivedRef.current = true;
                clearProcessingTimer();
                setVoiceState('idle');
              }
              
              socket.close();
              setConnectionId(null);
              sawTextDeltaRef.current = false;
            } else {
              accumulatedMessage = '';
              setStreamingMessage('');
            }
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
          if (!connectionResolved) {
            reject(error);
          }
        }
      };

      socket.onclose = () => {
        console.log('WebSocket Disconnected for Factory Voice Assistant');
        setConnectionId(null);
        setIsStreaming(false);
      };

      socket.onerror = (error) => {
        console.error('WebSocket Error for Factory Voice Assistant:', error);
        setIsStreaming(false);
        if (!connectionResolved) {
          reject(error);
        }
      };

      socketRef.current = socket;
      
      setTimeout(() => {
        if (!connectionResolved) {
          reject(new Error('Connection timeout'));
        }
      }, 10000);
    });
  };

  // Initialize WebSocket connection on component mount
  useEffect(() => {
    const initializeWebSocket = async () => {
      try {
        await openWebsocketConnection();
        console.log("WebSocket initialized for Factory Voice Assistant");
      } catch (error) {
        console.error("Failed to initialize WebSocket:", error);
      }
    };

    initializeWebSocket();

    return () => {
      clearProcessingTimer();
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCarouselIndex((prev) => (prev + 1) % exampleQuestions.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  /**
   * Encode WAV file
   */
  const encodeWAV = (samples: Float32Array, sampleRate: number) => {
    const numChannels = 1;
    const bitsPerSample = 16;
    const blockAlign = (numChannels * bitsPerSample) / 8;
    const byteRate = sampleRate * blockAlign;
    const dataSize = (samples.length * numChannels * bitsPerSample) / 8;
    const buffer = new ArrayBuffer(44 + dataSize);
    const view = new DataView(buffer);

    writeString(view, 0, "RIFF");
    view.setUint32(4, 36 + dataSize, true);
    writeString(view, 8, "WAVE");

    writeString(view, 12, "fmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, byteRate, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitsPerSample, true);

    writeString(view, 36, "data");
    view.setUint32(40, dataSize, true);

    floatTo16BitPCM(view, 44, samples);

    return new Blob([view], { type: "audio/wav" });
  };

  const writeString = (view: DataView, offset: number, string: string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  };

  const floatTo16BitPCM = (view: DataView, offset: number, input: Float32Array) => {
    for (let i = 0; i < input.length; i++, offset += 2) {
      const s = Math.max(-1, Math.min(1, input[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
  };

  /**
   * Create Folder - First API Call
   */
  const FirstApiCall = async () => {
    console.log("FOLDER CREATED");
    const formData = new FormData();
    formData.append('session_id', sessionManagerRef.current.getSessionId());
    formData.append('status_flag', 'Start');
    formData.append('language', language);
    formData.append('type', translationType);
    formData.append('box_type', 'manufacturing');
  
    try {
      const response = await axios.post(
        import.meta.env.VITE_API_BASE_URL,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
  
      console.log("Session started with ID:", sessionManagerRef.current.getSessionId());
      return true;
    } catch (error: any) {
      if (error.response) {
        console.error("API error response:", error.response.data);
      } else if (error.request) {
        console.error("No response received:", error.request);
      } else {
        console.error("Error in setting up request:", error.message);
      }
      return false;
    }
  };

  /**
   * Start recording
   */
  const startRecording = async () => {
    console.log(isFirstApiCalled, "start_recording");
    if (!isFirstApiCalled) {
      await FirstApiCall();
      setIsFirstApiCalled(true);
    }

    try {
      setError('');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      const audioChunks: Blob[] = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
        
        const audioContext = new AudioContext();
        const arrayBuffer = await audioBlob.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        const wavBlob = encodeWAV(
          audioBuffer.getChannelData(0),
          audioBuffer.sampleRate
        );
        await uploadAudio(wavBlob);
      };

      mediaRecorder.start();
      setVoiceState('recording');
    } catch (err) {
      setError('Microphone access denied. Please allow microphone access and try again.');
    }
  };

  /**
   * Stop recording
   */
  const stopRecording = () => {
    if (mediaRecorderRef.current && voiceState === 'recording') {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  function base64ToAudioFile(base64String: string) {
    const base64Data = base64String.replace(/^data:audio\/[^;]+;base64,/, '');
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    const blob = new Blob([bytes], { type: 'audio/mp3' });
    const url = URL.createObjectURL(blob);
    setAudioUrl(url);
    return url;
  }

  /**
   * Upload audio to API with WebSocket integration
   */
  const uploadAudio = async (audioBlob: Blob) => {
    if (!audioBlob) return;
    
    console.log("Starting audio upload, setting voice state to 'processing'");
    setVoiceState('processing');
    startProcessingTimer();
    
    const base64Audio = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(audioBlob);
    });
    
    try {
      let currentConnectionId = connectionId;
      if (!currentConnectionId) {
        currentConnectionId = await openWebsocketConnection();
        console.log("WebSocket connection established with ID:", currentConnectionId);
      } else {
        console.log("Using existing WebSocket connection with ID:", currentConnectionId);
      }
      
      const formData = new FormData();
      formData.append('audio', base64Audio);
      formData.append('session_id', sessionManagerRef.current.getSessionId());
      formData.append('box_type', 'manufacturing');
      formData.append('event_type', 'voiceops');
      formData.append('connectionId', currentConnectionId || '');
      formData.append('connection_url', import.meta.env.VITE_WEBSOCKET_URL_VOICEOPS);

      const response = await axios.post( 
        import.meta.env.VITE_API_BASE_URL,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      let transcription = "";

      Object.entries(response.headers).forEach(([key, value]) => {
        if (key.toLowerCase() === "x-transcription") {
          transcription = value;
        }
      });
      
      setTranscription(transcription);
      
      if (transcription) {
        sessionManagerRef.current.addMessage('user', transcription);
      }
      
      console.log("Transcription:", transcription);
      console.log("API response received, waiting for WebSocket response...");
      
    } catch (error: any) {
      console.error("Error uploading audio:", error);
      clearProcessingTimer();
      responseReceivedRef.current = true;
      setVoiceState('idle');
    }
  };

  return (
    <ManufacturingLayout>
      {/* Content Container with proper margins */}
      <div className="flex-1 max-w-7xl mx-auto w-full px-6 lg:px-8 bg-white">
        {/* Breadcrumb - Left Aligned */}
        <div className="pt-6">
          <nav className="flex text-sm text-gray-500 -ml-6" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1">
              <li>
                <Link to="/customer/sandbox/manufacturinghome" className="flex items-center text-gray-500 hover:text-gray-700 no-underline">
                  <Home size={16} className="mr-1" />
                  Home
                </Link>
              </li>
              <li>
                <span className="mx-2">/</span>
                <span className="text-orange-600 font-medium">Factory Voice Assistant</span>
              </li>
            </ol>
          </nav>
        </div>

        {/* Title Section - Left Aligned */}
        <div className="py-6">
          <div className="flex items-start mb-4">
            <div className="flex items-center justify-center w-14 h-14 rounded-full bg-orange-100 mr-4 mt-1">
              <MessageSquare size={24} className="text-orange-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Factory Voice Assistant
              </h1>
              <p className="text-base text-gray-600 max-w-3xl">
                Voice-enabled assistant for technicians to get instant answers from SOPs, maintenance manuals, and troubleshooting guides while keeping hands free.
              </p>
            </div>
          </div>
        </div>

        {/* Main Content Area - Responsive Grid */}
        <div className="pt-4 pb-8 grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch" style={{ marginTop: '-4rem' }}>
          {/* Left: VoiceBot Card */}
          <div className="lg:col-span-7 xl:col-span-8">
            <div className="bg-white rounded-[16px] p-0 h-[75vh] flex flex-col shadow-[0_2px_12px_rgba(0,0,0,0.12)]">
              {/* Card Header - compact and neat */}
              <div className="p-4 border-b flex items-center gap-2">
                <div className="rounded-full bg-[#fbeee6] p-2 flex items-center justify-center" style={{ width: 32, height: 32 }}>
                  <MicIcon className="h-5 w-5 text-primary" />
                </div>
                <h2 className="text-lg font-semibold text-gray-900 mb-0">Factory Voice Assistant</h2>
              </div>
              {/* Card Body */}
              <div className="flex-1 flex flex-col items-center justify-center p-8" style={{marginTop:'-1rem'}}>
                {/* Error Banner */}
                {error && (
                  <ErrorBanner 
                    message={error} 
                    onClose={() => setError('')} 
                  />
                )}
                {/* Waveform Visualizer */}
                <WaveformVisualizer 
                  isPlaying={voiceState === 'playing'}
                  isRecording={voiceState === 'recording'}
                />
                {/* Record Button */}
                <div className="flex justify-center mb-8">
                  <RecordButton
                    state={voiceState}
                    onRecord={startRecording}
                    onStop={stopRecording}
                    processingTimeLeft={processingTimeLeft}
                  />
                </div>
                {/* Instructions */}
                <div className="text-center text-gray-500">
                  <div>
                    {audioUrl && (
                      <audio controls src={audioUrl}>
                        Your browser does not support the audio element.
                      </audio>
                    )}
                  </div>
                  <p className="text-lg mb-2">Click the microphone to start recording your question</p>
                  <p className="text-lg">Click again to stop and get your AI-powered response</p>
                </div>
              </div>
            </div>
          </div>
          {/* Right: What can I ask? Card */}
          <div className="lg:col-span-5 xl:col-span-4">
            <div className="bg-white rounded-[16px] p-0 mb-4 h-[75vh] flex flex-col shadow-[0_2px_12px_rgba(0,0,0,0.12)]">
              <div className="flex items-center gap-2 px-4 pt-3 pb-2 w-full flex-shrink-0">
                <HelpCircle className="h-5 w-5 text-[#e87722]" aria-hidden="true" />
                <span className="font-semibold text-lg text-gray-800">What can I ask?</span>
              </div>
              <div className="w-full px-4 flex-shrink-0" style={{height: '1px', background: '#e5e7eb'}} />
              <div className="flex-1 flex flex-col items-center w-full px-4 py-4" style={{ minHeight: 0 }}>
                {/* Question list */}
                <div 
                  className="flex flex-col items-center justify-center w-full"
                  style={{ 
                    flex: '1 1 auto',
                    width: '100%'
                  }}
                >
                  <div className="w-full">
                    {exampleQuestions.map((q, idx) => {
                      const isActive = carouselIndex === idx;
                      let fontSize = isActive ? '1rem' : '0.9rem';
                      return (
                        <motion.div
                          key={q}
                          initial={false}
                          animate={isActive ? { scale: 1.05, color: '#e87722', fontWeight: 600 } : { scale: 1, color: '#a0aec0', fontWeight: 400 }}
                          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                          className="my-1 text-center"
                          style={{
                            fontSize,
                            background: isActive ? 'rgba(255,255,255,0.95)' : 'none',
                            borderRadius: 8,
                            padding: isActive ? '0.5rem 1rem' : '0.3rem 0.8rem',
                            boxShadow: isActive ? '0 2px 8px rgba(0,0,0,0.04)' : 'none',
                            transition: 'all 0.4s',
                            whiteSpace: 'normal',
                            wordWrap: 'break-word',
                            lineHeight: '1.4',
                            maxWidth: '100%',
                            minWidth: 0,
                          }}
                        >
                          {q}
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ManufacturingLayout>
  );
};

export default FactoryVoiceAssistantTool;

