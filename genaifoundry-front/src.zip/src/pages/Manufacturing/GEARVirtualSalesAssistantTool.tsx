import React, { useState, useRef, useEffect } from 'react';
import { Row, Col, Card, Form, Button } from 'react-bootstrap';
import { Send, Bot, Share, MessageSquare, FileText, Car } from 'lucide-react';
import Markdown from 'react-markdown';
import '../../components/Insurance/custom.scss';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  contextSource?: string;
}

interface Conversation {
  id: string;
  messages: Message[];
}

/**
 * Helper function to process markdown text
 */
const processMarkdownText = (text: string): string => {
  return text.replace(/\\n\\n/g, '\n\n').replace(/\\n/g, '\n');
};

/**
 * Bot typing loader component
 */
const BotTypingLoader: React.FC = () => (
  <span className="streaming-cursor" style={{
    display: 'inline-block',
    width: '2px',
    height: '1.2em',
    backgroundColor: '#1C6E8C',
    marginLeft: '2px',
    animation: 'cursor-blink 1s infinite'
  }}>
    <style>{`
      @keyframes cursor-blink {
        0%, 50% { opacity: 1; }
        51%, 100% { opacity: 0; }
      }
    `}</style>
  </span>
);

/**
 * GEAR Virtual Sales Assistant Tool Component
 * Chat interface for automotive dealership sales assistant
 */
const GEARVirtualSalesAssistantTool: React.FC = () => {
  const emptyConversation: Conversation = { id: 'active-conversation', messages: [] };
  const [conversation, setConversation] = useState<Conversation>(emptyConversation);
  const [inputText, setInputText] = useState('');
  const [connectionId, setConnectionId] = useState<string | null>(null);
  const [streamingMessage, setStreamingMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [activeTab, setActiveTab] = useState<'features' | 'credentials'>('features');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatTranscriptRef = useRef<HTMLDivElement>(null);

  const [chatEnded, setChatEnded] = useState(false);
  const [sessionId, setSessionId] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEndChatLoading, setIsEndChatLoading] = useState(false);
  const [summaryData, setSummaryData] = useState<any>(null);
  const [transcriptData, setTranscriptData] = useState<any>(null);
  const [isSummaryGenerating, setIsSummaryGenerating] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  const [showFaqs, setShowFaqs] = useState(true);
  const sawTextDeltaRef = useRef(false);

  // Automotive-specific FAQ prompts
  // Covers product features, specifications, scheduling, pricing, warranty, and service history
  const faqs = [
    "What safety features does the SUV Elite have?",
    "What are the specifications of the Sedan Pro?",
    "I'd like to schedule a test drive",
    "I need to schedule a service appointment",
    "What are the pricing options for your vehicles?",
    "What warranty coverage is included?",
    "Show me my vehicle's service history"
  ];

  useEffect(() => {
    if (chatTranscriptRef.current) {
      chatTranscriptRef.current.scrollTop = chatTranscriptRef.current.scrollHeight;
    }
  }, [conversation.messages, transcriptData, streamingMessage]);

  /**
   * Opens WebSocket connection for real-time chat
   */
  const openWebsocketConnection = (): Promise<string> => {
    return new Promise((resolve, reject) => {
      // Close existing connection if any
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }

      const socket = new WebSocket(
        import.meta.env.VITE_WEBSOCKET_URL
      );
      
      // Store accumulated message text locally
      let accumulatedMessage = '';
      sawTextDeltaRef.current = false; // reset for each new connection
      
      socket.onopen = () => {
        console.log('WebSocket Connected');
        socket.send(JSON.stringify({ type: "connection_init" }));
      };

      socket.onmessage = (e) => {
        try {
          const messageData = JSON.parse(e.data);
          console.log(messageData, "receivedData_connectid");
          
          // Handle connection ID
          if (messageData.connectionid && !connectionId) {
            console.log("Connection ID received:", messageData.connectionid);
            setConnectionId(messageData.connectionid);
            resolve(messageData.connectionid);
          }

          // Track if we have seen a text_delta in this stream
          if (messageData.type === "content_block_delta" && messageData.delta?.type === "text_delta") {
            sawTextDeltaRef.current = true;
            accumulatedMessage += messageData.delta.text;
            setStreamingMessage(accumulatedMessage);
            setIsStreaming(true);
          }

          // Handle stream completion
          if (messageData.type === "content_block_stop" || messageData.type === "message_stop") {
            if (sawTextDeltaRef.current) {
              // This is the final answer's stop, safe to close
              setIsStreaming(false);
              setIsLoading(false);
              
              if (accumulatedMessage.trim()) {
                setConversation((prev) => ({
                  ...prev,
                  messages: [
                    ...prev.messages,
                    {
                      id: `bot-${Date.now()}`,
                      sender: 'bot',
                      text: accumulatedMessage, 
                      timestamp: new Date().toISOString(),
                    }
                  ]
                }));
              }
              setStreamingMessage('');
              socket.close();
              setConnectionId(null);
              sawTextDeltaRef.current = false; // reset for next stream
            } else {
              // This was just the tool input, do not close yet
              // Wait for the next stream (the answer)
              accumulatedMessage = '';
              setStreamingMessage('');
              // Do not close the socket!
            }
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
          reject(error);
        }
      };

      socket.onclose = () => {
        console.log('WebSocket Disconnected');
        setConnectionId(null);
        setIsLoading(false); 
        setIsStreaming(false); 
      };

      socket.onerror = (error) => {
        console.error('WebSocket Error:', error);
        setIsLoading(false); 
        setIsStreaming(false); 
        reject(error);
      };

      socketRef.current = socket;
      
      // Set timeout for connection
      setTimeout(() => {
        if (!connectionId) {
          reject(new Error('Connection timeout'));
        }
      }, 10000);
    });
  };

  /**
   * Handles form submission for chat messages
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() === '') return;
    
    // Add user message
    const newUserMessage: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: inputText,
      timestamp: new Date().toISOString()
    };
    
    setConversation(prev => ({
      ...prev,
      messages: [...prev.messages, newUserMessage]
    }));
    
    const currentInput = inputText;
    setInputText('');
    setIsLoading(true);
    
    // Hide FAQ only after first send
    if (conversation.messages.length === 0 && showFaqs) {
      setShowFaqs(false);
    }
    
    try {
      // Generate new connection ID for each API call
      const newConnectionId = await openWebsocketConnection();
      console.log("New connection established with ID:", newConnectionId);
      
      // Call the chat API with new connection ID
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      const raw = JSON.stringify({
        event_type: 'gear_tool',
        chat: currentInput,
        session_id: sessionId || '',
        connectionId: newConnectionId
      });

      console.log("API Request:", raw);
      
      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow' as const
      };
      
      const response = await fetch(import.meta.env.VITE_API_BASE_URL, requestOptions);
      const data = await response.json();
      
      if (data.session_id) {
        console.log("Received session ID from API:", data.session_id);
        setSessionId(data.session_id);
      } else {
        console.warn("No session_id received from chat API response:", data);
      }
      
      setIsLoading(false);
      
    } catch (error) {
      console.error("Error in handleSubmit:", error);
      
      // Add error message if WebSocket fails
      const errorMessage: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: 'Sorry, there was a problem connecting to the chat service. Please try again.',
        timestamp: new Date().toISOString(),
      };
      
      setConversation(prev => ({
        ...prev,
        messages: [...prev.messages, errorMessage]
      }));
      
      setIsLoading(false);
      setIsStreaming(false);
      setStreamingMessage('');
    }
  };

  /**
   * Handles FAQ chip click
   */
  const handlePromptChipClick = (text: string) => {
    setInputText(text);
  };

  /**
   * Handles end chat and generates summary
   */
  const handleEndChat = async () => {
    // Capture current sessionId to prevent race conditions
    const currentSessionId = sessionId;
    
    // Validate sessionId exists before proceeding
    if (!currentSessionId) {
      console.error("No session ID available for generating summary");
      alert("Unable to generate summary: No active session found. Please start a new conversation.");
      return;
    }

    console.log("Starting end chat process with session ID:", currentSessionId);
    
    setIsEndChatLoading(true);
    setIsSummaryGenerating(true);
    setChatEnded(true);

    // Close WebSocket connection if open
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.close();
    }

    try {
      console.log("Calling generate_gear_summary with session ID:", currentSessionId);
      const generateResponse = await fetch(import.meta.env.VITE_API_BASE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event_type: 'generate_gear_summary', session_id: currentSessionId }),
      });

      if (!generateResponse.ok) {
        throw new Error(`Generate summary failed with status: ${generateResponse.status}`);
      }

      const pollInterval = setInterval(async () => {
        try {
          console.log("Polling for summary with session ID:", currentSessionId);
          const resp = await fetch(import.meta.env.VITE_API_BASE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ event_type: 'list_gear_summary', session_id: currentSessionId }),
          });

          if (!resp.ok) {
            throw new Error(`List summary failed with status: ${resp.status}`);
          }

          const data = await resp.json();
          console.log("Summary response:", data);
          console.log("Transcript data:", data.transcript);

          if (data?.final_summary) {
            console.log("Summary retrieved successfully");
            clearInterval(pollInterval); // stop polling
            setSummaryData(data.final_summary);
            // Ensure transcript is set even if it's empty or in a different format
            setTranscriptData(data.transcript || []);
            console.log("Transcript data set:", data.transcript || []);
            setIsSummaryGenerating(false);
            setIsEndChatLoading(false);
            // Clear sessionId only after successful retrieval
            setSessionId('');
            // Don't clear conversation immediately - let transcript display first
            // setConversation(emptyConversation);
          } else {
            console.log("Summary not ready yet, continuing to poll...");
          }
        } catch (err) {
          console.error("Polling error:", err);
          clearInterval(pollInterval);
          setIsSummaryGenerating(false);
          setIsEndChatLoading(false);
          alert("Failed to retrieve chat summary. Please try again.");
        }
      }, 5000); // Polling interval to 5 seconds for faster response

      // Add timeout to prevent infinite polling
      setTimeout(() => {
        clearInterval(pollInterval);
        if (isSummaryGenerating) {
          console.error("Summary generation timeout");
          setIsSummaryGenerating(false);
          setIsEndChatLoading(false);
          alert("Summary generation timed out. Please try again.");
        }
      }, 120000); // 2 minute timeout

    } catch (e) {
      console.error("Generate post-chat analysis error:", e);
      setSummaryData(null);
      setTranscriptData(null);
      setIsSummaryGenerating(false);
      setIsEndChatLoading(false);
      alert("Failed to generate chat summary. Please try again.");
    }
  };

  // Clean up WebSocket on component unmount
  useEffect(() => {
    return () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, []);

  return (
    <div>
      <Row>
        <Col lg={8}>
          <Card className="mb-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            {/* Modern Header */}
            <div 
              className="d-flex align-items-center justify-content-between px-4 py-3"
              style={{ 
                backgroundColor: 'white',
                color: 'black',
                fontFamily: 'Inter, sans-serif',
                borderBottom: '1px solid #e9ecef'
              }}
            >
              <div className="d-flex align-items-center">
                <div 
                  className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3"
                >
                  <Bot size={16} className="text-white" />
                </div>
                <div>
                  <div className="d-flex align-items-center">
                    <h5 className="mb-0 fw-bold me-2" style={{ fontSize: '18px', letterSpacing: '-0.5px' }}>
                      GEAR Virtual Sales Assistant
                    </h5>
                  </div>
                </div>
              </div>
            </div>

            {/* Chat Area */}
            <Card.Body className="p-0 d-flex flex-column" style={{ height: '450px', backgroundColor: 'white' }}>
              {/* Messages Container */}
              <div
                className="px-4 py-3 flex-grow-1 position-relative"
                ref={chatTranscriptRef}
                style={{
                  overflowY: 'auto',
                  fontFamily: 'Inter, sans-serif',
                  minHeight: '0'
                }}
              >
                {/* Opening message - always visible during active chat */}
                {(!chatEnded || isSummaryGenerating) && (
                  <div className="d-flex justify-content-start mb-3">
                    <div style={{ maxWidth: '75%' }}>
                      <div 
                        className="text-dark"
                        style={{
                          fontSize: '15px',
                          lineHeight: '1.4',
                          fontWeight: '400'
                        }}
                      >
                        How may I help you with your automotive needs today?
                      </div>
                      
                      <div className="mt-1">
                        <span className="small text-muted" style={{ fontSize: '12px' }}>
                          {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Render conversation messages */}
                {(!chatEnded || isSummaryGenerating) && conversation.messages.map((message) => (
                  <div key={message.id} className={`d-flex ${message.sender === 'user' ? 'justify-content-end' : 'justify-content-start'} mb-3`}>
                    <div style={{ maxWidth: '75%' }}>
                      {/* Message Bubble */}
                      <div 
                        className={message.sender === 'user' ? 'px-4 py-3 text-white' : 'text-dark'}
                        style={{
                          backgroundColor: message.sender === 'user' ? '#e87722' : 'transparent',
                          borderRadius: message.sender === 'user' ? '18px 18px 4px 18px' : '0',
                          fontSize: '15px',
                          lineHeight: '1.4',
                          fontWeight: '400',
                          border: message.sender === 'user' ? 'none' : 'none'
                        }}
                      >
                        {message.sender === 'bot' ? <Markdown>{processMarkdownText(message.text)}</Markdown> : message.text}
                      </div>
                      
                      {/* Generate post-chat analysis button - only for latest bot message */}
                      {message.sender === 'bot' && conversation.messages.indexOf(message) === conversation.messages.length - 1 && !chatEnded && !streamingMessage && (
                        <div className="mt-2">
                          <button
                            className="btn btn-outline-primary btn-sm px-3 py-1"
                            style={{ 
                              borderRadius: '8px',
                              fontSize: '11px',
                              fontWeight: '500',
                              borderColor: '#e87722',
                              color: '#e87722',
                              backgroundColor: 'transparent'
                            }}
                            onClick={handleEndChat}
                            disabled={isEndChatLoading || conversation.messages.length === 0 || !sessionId}
                          >
                            {isEndChatLoading ? (
                              <div className="spinner-border spinner-border-sm me-1" role="status" style={{ width: '10px', height: '10px' }}></div>
                            ) : null}
                            Generate post-chat analysis
                          </button>
                        </div>
                      )}
                      
                      {/* Timestamp */}
                      <div className={`mt-1 ${message.sender === 'user' ? 'text-end' : 'text-start'}`}>
                        <span className="small text-muted" style={{ fontSize: '12px' }}>
                          {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Streaming message */}
                {streamingMessage && isStreaming && (!chatEnded || isSummaryGenerating) && (
                  <div className="d-flex justify-content-start mb-3">
                    <div style={{ maxWidth: '75%' }}>
                      <div 
                        className="text-dark"
                        style={{
                          fontSize: '15px',
                          lineHeight: '1.4',
                          fontWeight: '400'
                        }}
                      >
                        <Markdown>{processMarkdownText(streamingMessage)}</Markdown>
                      </div>
                      
                      <div className="mt-1">
                        <span className="small text-muted" style={{ fontSize: '12px' }}>
                          {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Loading indicator */}
                {isLoading && !isStreaming && (!chatEnded || isSummaryGenerating) && (
                  <div className="d-flex justify-content-start mb-3">
                    <div style={{ maxWidth: '75%' }}>
                      <div 
                        className="text-dark"
                        style={{
                          fontSize: '15px'
                        }}
                      >
                        <BotTypingLoader />
                      </div>
                    </div>
                  </div>
                )}

                {/* Transcript data when chat ended */}
                {chatEnded && transcriptData && Array.isArray(transcriptData) && transcriptData.length > 0 && !isSummaryGenerating && (
                  <>
                    {transcriptData.map((item: any, idx: number) => (
                      <React.Fragment key={idx}>
                        {/* User message */}
                        <div className="d-flex justify-content-end mb-3">
                          <div style={{ maxWidth: '75%' }}>
                            <div 
                              className="px-4 py-3 text-white"
                              style={{
                                backgroundColor: '#e87722',
                                borderRadius: '18px 18px 4px 18px',
                                fontSize: '15px',
                                lineHeight: '1.4',
                                fontWeight: '400'
                              }}
                            >
                              {item.Human}
                            </div>
                            <div className="mt-1 text-end">
                              <span className="small text-muted" style={{ fontSize: '12px' }}>
                                {conversation.messages.length > idx * 2 && conversation.messages[idx * 2].timestamp 
                                  ? new Date(conversation.messages[idx * 2].timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                                  : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        {/* Bot message */}
                        <div className="d-flex justify-content-start mb-3">
                          <div style={{ maxWidth: '75%' }}>
                            <div 
                              className="text-dark"
                              style={{
                                fontSize: '15px',
                                lineHeight: '1.4',
                                fontWeight: '400'
                              }}
                            >
                              <Markdown>{processMarkdownText(item.Bot)}</Markdown>
                            </div>
                            <div className="mt-1">
                              <span className="small text-muted" style={{ fontSize: '12px' }}>
                                {conversation.messages.length > idx * 2 + 1 && conversation.messages[idx * 2 + 1].timestamp 
                                  ? new Date(conversation.messages[idx * 2 + 1].timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                                  : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Quick Reply Suggestions */}
              {conversation.messages.length === 0 && !chatEnded && showFaqs && (
                <div className="px-4 py-2 flex-shrink-0" style={{ borderTop: '1px solid #e9ecef' }}>
                  <div
                    style={{
                      display: 'flex',
                      gap: '8px',
                      overflowX: 'auto',
                      paddingBottom: '8px',
                      WebkitOverflowScrolling: 'touch'
                    }}
                    className="faq-scroll"
                  >
                    {faqs.map((faq, idx) => (
                      <button
                        key={idx}
                        className="btn btn-outline-secondary"
                        style={{
                          borderRadius: '8px',
                          fontSize: '13px',
                          fontWeight: '500',
                          padding: '8px 16px',
                          whiteSpace: 'nowrap',
                          border: '1px solid #e9ecef',
                          color: '#6c757d',
                          backgroundColor: 'white',
                          minWidth: 'fit-content'
                        }}
                        onClick={() => handlePromptChipClick(faq)}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = 'white';
                          e.currentTarget.style.borderColor = '#e87722';
                          e.currentTarget.style.color = '#e87722';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = 'white';
                          e.currentTarget.style.borderColor = '#e9ecef';
                          e.currentTarget.style.color = '#6c757d';
                        }}
                      >
                        {faq}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input Area */}
              <div 
                className="px-4 py-3 flex-shrink-0" 
                style={{ 
                  backgroundColor: 'white',
                  borderTop: '1px solid #e9ecef'
                }}
              >
                {!chatEnded ? (
                  <Form onSubmit={handleSubmit}>
                    <div className="d-flex align-items-center">
                      <div className="flex-grow-1 position-relative">
                        <Form.Control
                          placeholder="Type your message here..."
                          value={inputText}
                          onChange={(e) => setInputText(e.target.value)}
                          disabled={isLoading || isStreaming}
                          style={{
                            borderRadius: '8px',
                            border: '1px solid #e9ecef',
                            padding: '12px 20px',
                            fontSize: '15px',
                            fontFamily: 'Inter, sans-serif',
                            backgroundColor: 'white'
                          }}
                          onFocus={(e) => {
                            e.target.style.borderColor = '#e87722';
                            e.target.style.backgroundColor = 'white';
                          }}
                          onBlur={(e) => {
                            e.target.style.borderColor = '#e9ecef';
                            e.target.style.backgroundColor = 'white';
                          }}
                        />
                      </div>
                      
                      {/* Send Button */}
                      <Button 
                        type="submit" 
                        disabled={isLoading || isStreaming || !inputText.trim()}
                        className="ms-2"
                        style={{
                          borderRadius: '8px',
                          width: '46px',
                          height: '46px',
                          border: 'none',
                          backgroundColor: inputText.trim() ? '#e87722' : '#e9ecef',
                          color: 'white',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          padding: '0'
                        }}
                      >
                        <Send size={19} />
                      </Button>
                    </div>
                  </Form>
                ) : (
                  <Button 
                    variant="primary" 
                    className="w-100"
                    onClick={() => window.location.reload()}
                    disabled={isSummaryGenerating}
                    style={{
                      borderRadius: '8px',
                      backgroundColor: isSummaryGenerating ? '#ccc' : '#e87722',
                      border: 'none',
                      padding: '12px 24px',
                      fontSize: '15px',
                      fontWeight: '500',
                      cursor: isSummaryGenerating ? 'not-allowed' : 'pointer',
                      color: 'white'
                    }}
                  >
                    {isSummaryGenerating ? 'Generating post-chat...' : 'Start a New Chat'}
                  </Button>
                )}
              </div>
            </Card.Body>
          </Card>
          
          {/* WhatsApp Preview Card */}
          <Card className="mt-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header with-separator bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <Share size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>WhatsApp Preview</h5>
              </div>
            </div>
            <Card.Body className="position-relative" style={{ minHeight: 343, height: 343, maxHeight: 343, fontFamily: 'Inter, sans-serif' }}>
              {(!chatEnded || !summaryData) ? (
                <div
                  className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                  style={{
                    minHeight: 268,
                    height: 268,
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    background: 'inherit',
                    fontFamily: 'Inter, sans-serif'
                  }}
                >
                  <span>
                    Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Generate post-chat analysis'</span>
                  </span>
                  <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your personalized summary!
                  </span>
                </div>
              ) : (
                <div className="h-100" style={{ minHeight: 258, height: 258, maxHeight: 258, overflowY: 'auto' }}>
                  <div className="d-flex align-items-start">
                    <div className="me-3">
                      <div className="w-6 h-6 bg-green-500 rounded flex items-center justify-center">
                        <MessageSquare size={16} className="text-white" />
                      </div>  
                    </div>
                    <div>
                      <div className="bg-white p-3 rounded-lg shadow-sm border border-gray-200" style={{ maxWidth: '400px', borderRadius: '18px 18px 18px 4px' }}>
                        <p className="mb-0" style={{ whiteSpace: 'pre-line' }}>{summaryData.whatsapp_content}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
        
        <Col lg={4}>
          {/* Tabbed Interface Card */}
          <Card className="mb-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header with-separator bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <FileText size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>GEAR Virtual Sales Assistant</h5>
              </div>
            </div>
            
            {/* Tab Navigation */}
            <div className="d-flex border-bottom" style={{ backgroundColor: 'white' }}>
              <button
                className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeTab === 'features' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                style={{ 
                  fontSize: '14px',
                  fontFamily: 'Inter, sans-serif',
                  borderBottom: activeTab === 'features' ? '2px solid #e87722' : 'none',
                  transition: 'all 0.2s ease'
                }}
                onClick={() => setActiveTab('features')}
              >
                Features
              </button>
              <button
                className={`flex-grow-1 py-2 px-3 text-center border-0 ${activeTab === 'credentials' ? 'bg-white text-orange-600 fw-semibold' : 'bg-transparent text-muted'}`}
                style={{ 
                  fontSize: '14px',
                  fontFamily: 'Inter, sans-serif',
                  borderBottom: activeTab === 'credentials' ? '2px solid #e87722' : 'none',
                  transition: 'all 0.2s ease'
                }}
                onClick={() => setActiveTab('credentials')}
              >
                Sample Vehicles
              </button>
            </div>
            
            <Card.Body className='card_body_custom' style={{ position: 'relative', minHeight: 220, height: 220, padding: '0% !important', fontFamily: 'Inter, sans-serif', background: 'white' }}>
              <div style={{ minHeight: 220, height: 220, maxHeight: 220, overflowY: 'auto' }}>
                {activeTab === 'features' && (
                  <div className="p-3 rounded mb-3">
                    <ul className="list-unstyled mb-0">
                      <li className="mb-2 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Product & Feature Q&A</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>Answers product questions using RAG technology.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "What safety features does the SUV Elite have?"</span>
                          </div>
                        </div>
                      </li>
                      <li className="mb-2 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Test Drive & Service Scheduling</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>Schedule test drives and service appointments via CRM integration.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "I'd like to schedule a test drive"</span>
                          </div>
                        </div>
                      </li>
                      <li className="mb-2 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Pricing & Warranty</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>Get information on pricing options and warranty coverage.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "What warranty coverage is included?"</span>
                          </div>
                        </div>
                      </li>
                      <li className="mb-2 d-flex align-items-start">
                        <span className="text-success fw-bold me-2 mt-1">&#10003;</span>
                        <div>
                          <div className="fw-semibold" style={{ fontSize: '13px', color: '#2c3e50' }}>Service History & Parts</div>
                          <div className="text-muted small" style={{ fontSize: '11px' }}>Check service history and inquire about parts availability.</div>
                          <div className="mt-1">
                            <span className="text-muted small" style={{ fontSize: '10px' }}>Sample: "Show me my vehicle's service history"</span>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                )}
                
                {activeTab === 'credentials' && (
                  <div className="p-2 rounded mb-3">
                    <div className="mb-2">
                      <div className="d-flex align-items-center mb-1">
                        <Car size={14} className="text-orange-600 me-1" />
                        <span className="fw-semibold" style={{ fontSize: '12px', color: '#2c3e50' }}>Sample VIN & Customer Data</span>
                      </div>
                      <div style={{ maxWidth: '100%', margin: '0 auto', overflowX: 'auto' }}>
                        <div className="bg-white p-2 rounded border" style={{ fontSize: '9px' }}>
                          <div className="mb-1 d-flex" style={{ borderBottom: '1px solid #e9ecef', paddingBottom: '4px' }}>
                            <span className="text-muted fw-semibold" style={{ width: '20%', padding: '2px' }}>VIN</span>
                            <span className="text-muted fw-semibold" style={{ width: '18%', padding: '2px' }}>Name</span>
                            <span className="text-muted fw-semibold" style={{ width: '15%', padding: '2px' }}>Phone</span>
                            <span className="text-muted fw-semibold" style={{ width: '22%', padding: '2px' }}>Email</span>
                            <span className="text-muted fw-semibold" style={{ width: '25%', padding: '2px' }}>Vehicle</span>
                          </div>
                          <div className="mb-1 d-flex" style={{ paddingTop: '2px' }}>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>1HGBH41JXMN109186</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>John Tan</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 9123 4567</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>john.tan@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>Sedan Pro</span>
                          </div>
                          <div className="mb-1 d-flex">
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>5YJSA1E11HF123456</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>Sarah Lim</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 8234 5678</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>sarah.lim@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>SUV Elite</span>
                          </div>
                          <div className="mb-1 d-flex">
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>1FTFW1ET5DFC12345</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>Michael Chen</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 7345 6789</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>michael.chen@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>Truck Max</span>
                          </div>
                          <div className="mb-1 d-flex">
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>WBA3A5C58EF123456</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>Emily Wong</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 6456 7890</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>emily.wong@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>Hatchback Sport</span>
                          </div>
                          <div className="mb-1 d-flex">
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>1G1BE5SM9F7123456</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>David Ng</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 5567 8901</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>david.ng@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>Coupe GT</span>
                          </div>
                          <div className="mb-1 d-flex">
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>1HGBH41JXMN109187</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>Lisa Koh</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 4678 9012</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>lisa.koh@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>Sedan Pro</span>
                          </div>
                          <div className="mb-1 d-flex">
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>5YJSA1E11HF123457</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>Robert Teo</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 3789 0123</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>robert.teo@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>SUV Elite</span>
                          </div>
                          <div className="mb-1 d-flex">
                            <span style={{ color: '#e87722', fontWeight: '600', width: '20%', padding: '2px', fontSize: '8px' }}>1FTFW1ET5DFC12346</span>
                            <span style={{ color: '#2c3e50', width: '18%', padding: '2px', fontSize: '8px' }}>Jennifer Lee</span>
                            <span style={{ color: '#2c3e50', width: '15%', padding: '2px', fontSize: '8px' }}>+65 2890 1234</span>
                            <span style={{ color: '#2c3e50', width: '22%', padding: '2px', fontSize: '8px' }}>jennifer.lee@email.com</span>
                            <span style={{ color: '#e87722', fontWeight: '600', width: '25%', padding: '2px', fontSize: '8px' }}>Truck Max</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-light p-2 rounded" style={{ fontSize: '10px', color: '#6c757d' }}>
                      <span className="fw-semibold">Note:</span> This is a sandbox demo. All data is simulated for demonstration purposes.
                    </div>
                  </div>
                )}
              </div>
            </Card.Body>
          </Card>
          {/* Summary Card */}
          <Card className="mb-4 border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header with-separator bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <FileText size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Summary</h5>
              </div>
            </div>
            <Card.Body className='card_body_custom' style={{ position: 'relative', minHeight: 227, height: 227, fontFamily: 'Inter, sans-serif' }}>
              {(!chatEnded || !summaryData) ? (
                <div
                  className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                  style={{
                    minHeight: 227,
                    height: 227,
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    background: 'inherit',
                    fontFamily: 'Inter, sans-serif'
                  }}
                >
                  <span>
                    Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Generate post-chat analysis'</span>
                  </span>
                  <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your personalized summary!
                  </span>
                </div>
              ) : (
                <div className="bg-light p-3 rounded mb-3" style={{ minHeight: 227, height: 227, maxHeight: 227, overflowY: 'auto' }}>
                  <div className="mb-2"><span className="small mb-0">{summaryData.summary}</span></div>
                </div>
              )}
            </Card.Body>
          </Card>
          {/* Interaction Summary Card */}
          <Card className="border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
            <div className="card-header with-separator bg-white rounded-top-4 fw-bold d-flex align-items-center justify-between" style={{ padding: '1rem 1.5rem' }}>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-2">
                  <MessageSquare size={16} className="text-white" />
                </div>
                <h5 className="mb-0" style={{ fontFamily: 'Inter, sans-serif', fontSize: '16px' }}>Interaction Summary</h5>
              </div>
            </div>
            <Card.Body className='card_body_custom' style={{ position: 'relative', minHeight: 227, height: 227, padding: '0% !important', fontFamily: 'Inter, sans-serif' }}>
              {(!chatEnded || !summaryData) ? (
                <div
                  className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                  style={{
                    minHeight: 227,
                    height: 227,
                    color: '#b0b0b0',
                    fontSize: '0.9rem',
                    fontWeight: 400,
                    letterSpacing: '0.01em',
                    textAlign: 'center',
                    background: 'inherit',
                    fontFamily: 'Inter, sans-serif'
                  }}
                >
                  <span>
                    Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Generate post-chat analysis'</span>
                  </span>
                  <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                    to unlock your personalized summary!
                  </span>
                </div>
              ) : (
                <div className="bg-light p-3 rounded mb-3" style={{ minHeight: 227, height: 227, maxHeight: 227, overflowY: 'auto' }}>
                  {summaryData.Topic && (
                    <div className="mb-2 d-flex justify-content-between">
                      <span className="text-muted small">Topic</span>
                      <span className="fw-bold">{summaryData.Topic}</span>
                    </div>
                  )}
                  <div className="mb-2 d-flex justify-content-between">
                    <span className="text-muted small">Sentiment</span>
                    <span className="fw-bold">{summaryData.sentiment || ''}</span>
                  </div>
                  <div className="mb-2 d-flex justify-content-between">
                    <span className="text-muted small">Escalation Triggered</span>
                    <span className="fw-bold">No</span>
                  </div>
                  <div className="mb-2 d-flex justify-content-between">
                    <span className="text-muted small">Follow-Up Required</span>
                    <span className="fw-bold">Yes – whatsapp</span>
                  </div>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default GEARVirtualSalesAssistantTool;

