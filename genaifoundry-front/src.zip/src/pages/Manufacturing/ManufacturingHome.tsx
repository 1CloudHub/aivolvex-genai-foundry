import React, { useEffect } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Row, Col } from 'antd';
import {
    Car,
    Mic,
    AlertTriangle,
    FileText,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import ManufacturingLayout from './ManufacturingLayout';
import HomeCard from '../../components/ui/HomeCard';

/**
 * Manufacturing Home Component
 * Displays the main dashboard for manufacturing solutions
 */
const ManufacturingHome = () => {
    const navigate = useNavigate();
    const { projectType } = useAppContext();

    useEffect(() => {
        console.log("🔍 Current Project Type from Context:", projectType);
    }, [projectType]);

    // Manufacturing solutions configuration
    const solutions = [
        {
            title: 'GEAR Virtual Sales Assistant',
            area: 'Sales',
            icon: <Car size={24} />,
            description: 'B2C conversational AI for automotive dealerships. Answers product questions using RAG, schedules test drives and service appointments, and integrates with dealer CRM via tool calls.',
            buttonText: 'Try Now',
            tags: ['Sales', 'Customer Service'],
            redirect: '#',
            type: 'component',
            tooltip: {
                icon: '🚗',
                heading: 'GEAR Virtual Sales Assistant',
                subheading: 'B2C Conversational AI for Dealerships',
                points: [
                    'RAG-powered product and feature Q&A',
                    'Schedule test drives and service appointments',
                    'CRM integration via Lambda + API Gateway',
                    'FAQs on pricing, warranty, service history',
                    'Reduces sales cycle friction and improves engagement'
                ]
            }
        },
        {
            title: 'Factory Voice Assistant',
            area: 'Operations',
            icon: <Mic size={24} />,
            description: 'Voice-enabled SOP and manual retrieval for factory workers. Provides hands-free access to procedures, safety protocols, and troubleshooting guides using voice commands and RAG.',
            buttonText: 'Try Now',
            tags: ['Operations', 'Safety'],
            redirect: '#',
            type: 'component',
            tooltip: {
                icon: '🎤',
                heading: 'Factory Voice Assistant',
                subheading: 'Voicebot + RAG for Factory Workers',
                points: [
                    'Voice-activated SOP and manual retrieval',
                    'Contextual responses for specific equipment',
                    'Integration with equipment logs and safety checklists',
                    'Offline/edge-compatible for factory environments',
                    'Boosts safety and reduces technician downtime'
                ]
            }
        },
        {
            title: 'Intelligent Document Processing',
            area: 'Documentation',
            icon: <FileText size={24} />,
            description: 'Extracts and validates structured data from manufacturing documents including Purchase Orders, Inspection Reports, Safety Checklists, and Maintenance Logs using Textract + Claude.',
            buttonText: 'Try Now',
            tags: ['Documentation', 'Automation'],
            redirect: '#',
            type: 'component',
            tooltip: {
                icon: '📄',
                heading: 'Intelligent Document Processing',
                subheading: 'Automated Data Extraction & Validation',
                points: [
                    'POs: Extract supplier info, quantities, unit costs',
                    'Inspection Reports: Capture measurements and test results',
                    'Safety Checklists: Identify missing compliance fields',
                    'Maintenance Logs: Record task completions and intervals',
                    'MES/ERP integration with anomaly highlighting'
                ]
            }
        },
        {
            title: 'Anomaly Detection & Root Cause',
            area: 'Quality Control',
            icon: <AlertTriangle size={24} />,
            description: 'Detects irregularities in machine sensor data and identifies root causes. Uses multivariate anomaly detection to analyze temperature, vibration, RPM, and pressure data with RCA summaries.',
            buttonText: 'Try Now',
            tags: ['Quality Control', 'Analytics'],
            redirect: '#',
            type: 'component',
            tooltip: {
                icon: '⚠️',
                heading: 'Anomaly Detection & Root Cause Analysis',
                subheading: 'IoT Sensor Data Analysis with RCA',
                points: [
                    'Real-time data from IoT sensors via AWS IoT Core/Kinesis',
                    'Multivariate anomaly detection with explanations',
                    'Contextual analysis using machine type and maintenance logs',
                    'RCA output with issue classification (bearing wear, leaks, etc.)',
                    'Enables proactive maintenance and prevents breakdowns'
                ]
            }
        },
    ];

    /**
     * Navigation handler for Manufacturing solutions
     * Routes to appropriate component based on solution title
     */
    const handleManufacturingNavigation = (solution: any) => {
        switch (solution.title) {
            case "GEAR Virtual Sales Assistant":
                navigate('/customer/sandbox/manufacturing/gear-sales-assistant');
                break;
            case "Factory Voice Assistant":
                navigate('/customer/sandbox/manufacturing/factory-voice-assistant');
                break;
            case "Anomaly Detection & Root Cause":
                navigate('/customer/sandbox/manufacturing/anomaly-detection');
                break;
            case "Intelligent Document Processing":
                navigate('/customer/sandbox/manufacturing/document-ai');
                break;
            default:
                // Handle default case or external links
                break;
        }
    };

    return (
        <ManufacturingLayout>
            {/* Spacing below navbar */}
            <div className="flex-grow px-15 mx-auto py-3 bg-gray-50">
                {/* Header Section */}
                <div className="text-center">
                    <div className="flex flex-col items-center justify-center mt-8 mb-2">
                        <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                            <span style={{ color: '#e87722' }}>GenAI</span>
                            <span style={{ color: '#181f5a' }}> Sandbox</span>
                        </h1>
                    </div>
                    <div className="mb-8">
                        <span className="text-lg text-gray-700">
                            Explore AI-powered tools designed to transform manufacturing operations and enhance productivity.
                        </span>
                    </div>
                </div>

                {/* Solution Cards Section */}
                <div className="max-w-7xl mx-auto px-4">
                    <Row
                        gutter={[16, 16]}
                        justify="center"
                        className="p-4"
                        style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                    >
                        {solutions.map((solution, index) => (
                            <Col 
                                key={index} 
                                xs={24}
                                sm={12}
                                md={6}
                                lg={6}
                                xl={6}
                                style={{ 
                                    marginBottom: "16px"
                                }}
                            >
                                <HomeCard
                                    solution={solution}
                                    cardHeight="h-[360px]"
                                    buttonHeight="32px"
                                    onNavigate={handleManufacturingNavigation}
                                />
                            </Col>
                        ))}
                    </Row>
                </div>
            </div>
        </ManufacturingLayout>
    );
};

export default ManufacturingHome;

