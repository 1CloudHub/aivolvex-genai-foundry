import React from 'react';
import { Link } from 'react-router-dom';
import { Server, DollarSign, CheckCircle, Clock, AlertTriangle, TrendingUp } from 'lucide-react';

export default function DevOpsDashboard() {
  const stats = {
    totalCredits: 2450,
    pendingApprovals: 3,
    approvedEvents: 8,
    monthlySpend: 1250
  };

  const pendingApprovals = [
    { id: '2', eventName: 'Insurance AI Workshop', requestedAmount: 750, requestedBy: 'Sarah Marketing' },
    { id: '4', eventName: 'Healthcare AI Summit', requestedAmount: 900, requestedBy: 'Sarah Marketing' },
    { id: '5', eventName: 'Manufacturing AI Demo', requestedAmount: 650, requestedBy: 'Sarah Marketing' }
  ];

  const recentActivity = [
    { action: 'Approved', event: 'GenAI Banking Summit', amount: 850, date: '2025-01-15' },
    { action: 'Rejected', event: 'Small Business AI', amount: 1200, date: '2025-01-14' },
    { action: 'Approved', event: 'Retail AI Conference', amount: 720, date: '2025-01-12' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">DevOps Dashboard</h1>
        <p className="text-gray-600 mt-2">Monitor AWS credits and infrastructure approvals</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8 text-green-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Credits</p>
              <p className="text-2xl font-bold text-gray-900">${stats.totalCredits}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Clock className="h-8 w-8 text-orange-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Pending Approvals</p>
              <p className="text-2xl font-bold text-gray-900">{stats.pendingApprovals}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-blue-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Approved Events</p>
              <p className="text-2xl font-bold text-gray-900">{stats.approvedEvents}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-purple-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Monthly Spend</p>
              <p className="text-2xl font-bold text-gray-900">${stats.monthlySpend}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Pending Approvals */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900 flex items-center">
            <AlertTriangle className="h-5 w-5 text-orange-500 mr-2" />
            Pending Credit Approvals
          </h2>
          <Link to="/events" className="text-orange-600 hover:text-orange-700 text-sm font-medium">
            View All Events
          </Link>
        </div>
        
        <div className="divide-y divide-gray-200">
          {pendingApprovals.map((approval) => (
            <div key={approval.id} className="p-6 hover:bg-gray-50 transition-colors duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{approval.eventName}</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Requested by {approval.requestedBy} • ${approval.requestedAmount} credits
                  </p>
                </div>
                <Link
                  to={`/events/${approval.id}/credit-check`}
                  className="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors duration-200"
                >
                  Review
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Recent Activity</h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {recentActivity.map((activity, index) => (
            <div key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {activity.action === 'Approved' ? (
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 text-red-500 mr-3" />
                  )}
                  <div>
                    <p className="text-sm font-medium text-gray-900">
                      {activity.action} {activity.event}
                    </p>
                    <p className="text-sm text-gray-600">${activity.amount} credits</p>
                  </div>
                </div>
                <span className="text-sm text-gray-500">
                  {new Date(activity.date).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Infrastructure Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <Server className="h-5 w-5 text-blue-500 mr-2" />
            Resource Utilization
          </h3>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">EC2 Instances</span>
                <span className="font-medium">12/20</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '60%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Storage (GB)</span>
                <span className="font-medium">450/1000</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '45%' }}></div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Cost Breakdown</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Compute</span>
              <span className="font-medium">$850</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Storage</span>
              <span className="font-medium">$250</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Networking</span>
              <span className="font-medium">$150</span>
            </div>
            <div className="flex justify-between pt-3 border-t border-gray-200">
              <span className="font-medium text-gray-900">Total</span>
              <span className="font-bold text-gray-900">${stats.monthlySpend}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}