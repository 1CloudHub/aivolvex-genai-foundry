import React from 'react';
import { Link } from 'react-router-dom';
import { Users, UserCheck, Mail, TrendingUp, Calendar, Target } from 'lucide-react';
import { Breadcrumb, BreadcrumbList, BreadcrumbItem, BreadcrumbPage, BreadcrumbHome, BreadcrumbLink, BreadcrumbSeparator } from '../../components/ui/breadcrumb';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import 'antd/dist/reset.css';
import 'react-datepicker/dist/react-datepicker.css';
import '../../styles/datepicker-theme.css';
import { format } from 'date-fns';

const statsByMonth: Record<string, { totalCustomers: number; qualifiedLeads: number; emailsSent: number; conversionRate: number }> = {
  '2025-01': { totalCustomers: 120, qualifiedLeads: 60, emailsSent: 30, conversionRate: 65 },
  '2025-02': { totalCustomers: 156, qualifiedLeads: 89, emailsSent: 45, conversionRate: 72 },
  '2025-03': { totalCustomers: 180, qualifiedLeads: 100, emailsSent: 55, conversionRate: 75 },
  '2025-07': { totalCustomers: 200, qualifiedLeads: 110, emailsSent: 60, conversionRate: 80 },
};

const eventCategoriesByMonth: Record<string, { name: string; value: number; color: string }[]> = {
  '2025-01': [
    { name: 'Conference', value: 20, color: '#3366CC' },
    { name: 'Workshop', value: 25, color: '#ec580c' },
    { name: 'Webinar', value: 18, color: '#34a853' },
    { name: 'Summit', value: 12, color: '#a142f4' },
  ],
  '2025-02': [
    { name: 'Conference', value: 30, color: '#3366CC' },
    { name: 'Workshop', value: 40, color: '#ec580c' },
    { name: 'Webinar', value: 28, color: '#34a853' },
    { name: 'Summit', value: 22, color: '#a142f4' },
  ],
  '2025-03': [
    { name: 'Conference', value: 25, color: '#3366CC' },
    { name: 'Workshop', value: 35, color: '#ec580c' },
    { name: 'Webinar', value: 20, color: '#34a853' },
    { name: 'Summit', value: 15, color: '#a142f4' },
  ],
  '2025-07': [
    { name: 'Conference', value: 40, color: '#3366CC' },
    { name: 'Workshop', value: 50, color: '#ec580c' },
    { name: 'Webinar', value: 30, color: '#34a853' },
    { name: 'Summit', value: 18, color: '#a142f4' },
  ],
};

const registrationDataByMonth: Record<string, { name: string; value: number; color: string }[]> = {
  '2025-01': [
    { name: 'Summit', value: 30, color: '#4285F4' },
    { name: 'Workshop', value: 60, color: '#EA4335' },
    { name: 'Conference', value: 40, color: '#3366CC' },
  ],
  '2025-02': [
    { name: 'Summit', value: 60, color: '#4285F4' },
    { name: 'Workshop', value: 120, color: '#EA4335' },
    { name: 'Conference', value: 80, color: '#3366CC' },
  ],
  '2025-03': [
    { name: 'Summit', value: 50, color: '#4285F4' },
    { name: 'Workshop', value: 90, color: '#EA4335' },
    { name: 'Conference', value: 70, color: '#3366CC' },
  ],
  '2025-07': [
    { name: 'Summit', value: 80, color: '#4285F4' },
    { name: 'Workshop', value: 150, color: '#EA4335' },
    { name: 'Conference', value: 130, color: '#3366CC' },
  ],
};

export default function SalesDashboard() {
  const now = new Date();
  const [selectedDate, setSelectedDate] = React.useState(now);
  const [selectedMonth, setSelectedMonth] = React.useState(format(now, 'yyyy-MM'));

  React.useEffect(() => {
    setSelectedMonth(format(selectedDate, 'yyyy-MM'));
  }, [selectedDate]);

  const stats = statsByMonth[selectedMonth] || { totalCustomers: 0, qualifiedLeads: 0, emailsSent: 0, conversionRate: 0 };
  const eventCategories = eventCategoriesByMonth[selectedMonth] || [];
  const registrationData = registrationDataByMonth[selectedMonth] || [];

  const recentLeads = [
    { id: '1', name: 'John Smith', company: 'TechBank Corp', status: 'qualified', lastContact: '2025-01-15' },
    { id: '2', name: 'Sarah Johnson', company: 'InsureCo', status: 'contacted', lastContact: '2025-01-14' },
    { id: '3', name: 'Mike Chen', company: 'RetailPlus', status: 'new', lastContact: '2025-01-13' },
    { id: '4', name: 'Lisa Wong', company: 'HealthTech', status: 'qualified', lastContact: '2025-01-12' }
    
  ];

  const upcomingFollowUps = [
    { customer: 'John Smith', company: 'TechBank Corp', date: '2025-01-20', type: 'Demo Call' },
    { customer: 'Lisa Wong', company: 'HealthTech', date: '2025-01-22', type: 'Follow-up Email' },
    { customer: 'David Brown', company: 'LogiCorp', date: '2025-01-25', type: 'Proposal Review' }
  ];

  const leadsByStatus = [
    { name: 'Qualified', value: 40, color: '#34a853' },
    { name: 'Contacted', value: 25, color: '#3366CC' },
    { name: 'New', value: 15, color: '#ec580c' },
    { name: 'Lost', value: 9, color: '#a142f4' },
  ];

  const leadsBySource = [
    { name: 'Referral', value: 30, color: '#4285F4' },
    { name: 'Website', value: 40, color: '#EA4335' },
    { name: 'Event', value: 19, color: '#34a853' },
    { name: 'Email', value: 20, color: '#fbbc05' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Row: Breadcrumb/Title left, Date Filter right */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2 mt-2">
        <div>
          <Breadcrumb>
            <BreadcrumbList className="flex items-center text-base font-semibold gap-0 align-middle">
              <BreadcrumbItem>
                <BreadcrumbLink to="/">
                  <BreadcrumbHome />
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator>
                <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
              </BreadcrumbSeparator>
              <BreadcrumbItem>
                <BreadcrumbPage className="text-orange-600 font-semibold">Dashboard</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          <h1 className="text-3xl font-medium text-gray-900 mt-2">Dashboard</h1>
        </div>
        <div className="flex items-center gap-2 mt-4 md:mt-0 justify-end md:justify-start ml-2">
          <DatePicker
            picker="month"
            value={dayjs(selectedDate)}
            onChange={date => { if (date) setSelectedDate(date.toDate()); }}
            allowClear={false}
            format="MMM YYYY"
            suffixIcon={
              <svg width={18} height={18} stroke="#ec580c" fill="none" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
            }
            className="bg-white rounded-lg shadow-sm border"
            style={{
              height: 40,
              minWidth: 100,
              fontWeight: 600,
              fontSize: 16,
              textAlign: 'center',
              color: '#1e293b',
              paddingLeft: 16,
              paddingRight: 16,
              background: 'white',
            }}
            inputReadOnly
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Customers</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalCustomers}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <UserCheck className="h-8 w-8 text-green-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Upcoming events</p>
              <p className="text-2xl font-bold text-gray-900">{stats.qualifiedLeads}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Mail className="h-8 w-8 text-orange-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Emails Sent</p>
              <p className="text-2xl font-bold text-gray-900">{stats.emailsSent}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <TrendingUp className="h-8 w-8 text-purple-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Account launch Rate</p>
              <p className="text-2xl font-bold text-gray-900">{stats.conversionRate}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid (replicated from MarketingDashboard) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        {/* Events by Category Bar Chart */}
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <h3 className="text-md font-semibold mb-4">Events by Category</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={eventCategories}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value">
                {eventCategories.map((entry, index) => (
                  <Cell key={`cell-bar-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        {/* Registrations by Event Donut Chart */}
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <h3 className="text-md font-semibold mb-4">Registrations by Event</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={registrationData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                fill="#8884d8"
                label
              >
                {registrationData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Legend />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Leads */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900">Recent Leads</h2>
          <Link to="/reports/customers" className="text-orange-600 hover:text-orange-700 text-sm font-medium">
            View All Customers
          </Link>
        </div>
        
        <div className="divide-y divide-gray-200">
          {recentLeads.map((lead) => (
            <div key={lead.id} className="p-6 hover:bg-gray-50 transition-colors duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{lead.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {lead.company} • Last contact: {new Date(lead.lastContact).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    lead.status === 'qualified' ? 'bg-green-100 text-green-800' :
                    lead.status === 'contacted' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
                  </span>
                  {/* <Link
                    to={`/attendees/${lead.id}/status`}
                    className="text-orange-600 hover:text-orange-700 text-sm font-medium"
                  >
                    View Details
                  </Link> */}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming Follow-ups */}

      {/* AntD DatePicker: Only change selected month and year color in calendar popup */}
      <style>{`
        .ant-picker-panel .ant-picker-month-panel .ant-picker-cell.ant-picker-cell-selected .ant-picker-cell-inner {
          background: #ec580c !important;
          color: #fff !important;
        }
        /* Year selection override for AntD v5 (with dev-only class) */
        :where(.css-dev-only-do-not-override-pjilya).ant-picker-dropdown .ant-picker-cell-in-view.ant-picker-cell-selected:not(.ant-picker-cell-disabled) .ant-picker-cell-inner,
        :where(.css-dev-only-do-not-override-pjilya).ant-picker-dropdown .ant-picker-cell-in-view.ant-picker-cell-range-start:not(.ant-picker-cell-disabled) .ant-picker-cell-inner,
        :where(.css-dev-only-do-not-override-pjilya).ant-picker-dropdown .ant-picker-cell-in-view.ant-picker-cell-range-end:not(.ant-picker-cell-disabled) .ant-picker-cell-inner {
          color: #fff !important;
          background: #ec580c !important;
        }
      `}</style>
    </div>
  );
}