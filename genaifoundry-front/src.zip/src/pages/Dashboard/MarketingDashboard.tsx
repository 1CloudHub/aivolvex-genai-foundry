import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Users, CheckCircle, Clock, Plus, BarChart3 } from 'lucide-react';
import { Breadcrumb, BreadcrumbList, BreadcrumbItem, BreadcrumbPage, BreadcrumbHome, BreadcrumbLink, BreadcrumbSeparator } from '../../components/ui/breadcrumb';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import 'antd/dist/reset.css';
import { format } from 'date-fns';
import '../../styles/datepicker-theme.css';

const months = [
  { value: '2025-01', label: 'January 2025' },
  { value: '2025-02', label: 'February 2025' },
  { value: '2025-03', label: 'March 2025' },
];

const statsByMonth: Record<string, { totalEvents: number; upcomingEvents: number; totalRegistrations: number; completedEvents: number }> = {
  '2025-01': { totalEvents: 10, upcomingEvents: 2, totalRegistrations: 200, completedEvents: 5 },
  '2025-02': { totalEvents: 12, upcomingEvents: 3, totalRegistrations: 245, completedEvents: 7 },
  '2025-03': { totalEvents: 15, upcomingEvents: 4, totalRegistrations: 300, completedEvents: 9 },
  '2025-07': { totalEvents: 18, upcomingEvents: 5, totalRegistrations: 350, completedEvents: 12 },
};

const eventCategoriesByMonth: Record<string, { name: string; value: number; color: string }[]> = {
  '2025-01': [
    { name: 'Conference', value: 10, color: '#3366CC' },
    { name: 'Workshop', value: 15, color: '#ec580c' },
    { name: 'Webinar', value: 8, color: '#34a853' },
    { name: 'Summit', value: 5, color: '#a142f4' },
  ],
  '2025-02': [
    { name: 'Conference', value: 30, color: '#3366CC' },
    { name: 'Workshop', value: 40, color: '#ec580c' },
    { name: 'Webinar', value: 28, color: '#34a853' },
    { name: 'Summit', value: 22, color: '#a142f4' },
  ],
  '2025-03': [
    { name: 'Conference', value: 20, color: '#3366CC' },
    { name: 'Workshop', value: 25, color: '#ec580c' },
    { name: 'Webinar', value: 18, color: '#34a853' },
    { name: 'Summit', value: 12, color: '#a142f4' },
  ],
  '2025-07': [
    { name: 'Conference', value: 35, color: '#3366CC' },
    { name: 'Workshop', value: 50, color: '#ec580c' },
    { name: 'Webinar', value: 30, color: '#34a853' },
    { name: 'Summit', value: 20, color: '#a142f4' },
  ],
};

const registrationDataByMonth: Record<string, { name: string; value: number; color: string }[]> = {
  '2025-01': [
    { name: 'Summit', value: 20, color: '#4285F4' },
    { name: 'Workshop', value: 50, color: '#EA4335' },
    { name: 'Conference', value: 30, color: '#3366CC' },
  ],
  '2025-02': [
    { name: 'Summit', value: 60, color: '#4285F4' },
    { name: 'Workshop', value: 120, color: '#EA4335' },
    { name: 'Conference', value: 80, color: '#3366CC' },
  ],
  '2025-03': [
    { name: 'Summit', value: 40, color: '#4285F4' },
    { name: 'Workshop', value: 90, color: '#EA4335' },
    { name: 'Conference', value: 60, color: '#3366CC' },
  ],
  '2025-07': [
    { name: 'Summit', value: 70, color: '#4285F4' },
    { name: 'Workshop', value: 150, color: '#EA4335' },
    { name: 'Conference', value: 130, color: '#3366CC' },
  ],
};

export default function MarketingDashboard() {
  const now = new Date();
  const [selectedDate, setSelectedDate] = React.useState(now);
  const [selectedMonth, setSelectedMonth] = React.useState(format(now, 'yyyy-MM'));

  React.useEffect(() => {
    setSelectedMonth(format(selectedDate, 'yyyy-MM'));
  }, [selectedDate]);

  const stats = statsByMonth[selectedMonth] || { totalEvents: 0, upcomingEvents: 0, totalRegistrations: 0, completedEvents: 0 };
  const eventCategories = eventCategoriesByMonth[selectedMonth] || [];
  const registrationData = registrationDataByMonth[selectedMonth] || [];

  const recentEvents = [
    { id: '1', name: 'GenAI for Banking Summit', date: '2025-02-15', registrations: 45, status: 'upcoming' },
    { id: '2', name: 'Insurance AI Workshop', date: '2025-01-28', registrations: 32, status: 'Live' },
    { id: '3', name: 'Retail AI Conference', date: '2025-01-20', registrations: 67, status: 'completed' },
    { id: '4', name: 'Healthcare Tech Symposium', date: '2025-03-10', registrations: 80, status: 'upcoming' },
  ];

  return (
    <div className="space-y-6">
      {/* Breadcrumb and Title mimic EventDashboard */}
      <div className="mb-2">
        <Breadcrumb>
          <BreadcrumbList className="flex items-center text-base font-semibold gap-0 align-middle">
            <BreadcrumbItem>
              <BreadcrumbLink to="/">
                <BreadcrumbHome />
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbPage className="text-orange-600 font-semibold">Dashboard</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 mt-2">
        <h1 className="text-3xl font-medium text-gray-900">Dashboard</h1>
        <div className="flex items-center gap-2 mt-4 md:mt-0">
          <DatePicker
            picker="month"
            value={dayjs(selectedDate)}
            onChange={date => { if (date) setSelectedDate(date.toDate()); }}
            allowClear={false}
            format="MMM YYYY"
            suffixIcon={
              <svg width={18} height={18} stroke="#ec580c" fill="none" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
            }
            className="bg-white rounded-lg shadow-sm border"
            style={{
              height: 40,
              minWidth: 100,
              fontWeight: 600,
              fontSize: 16,
              textAlign: 'center',
              color: '#1e293b',
              paddingLeft: 16,
              paddingRight: 16,
              background: 'white',
            }}
            inputReadOnly
          />
        </div>
      </div>
      {/* Show message if no data for this month */}
      {!statsByMonth[selectedMonth] && (
        <div className="text-center text-gray-500 my-8">No data available for this month.</div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Calendar className="h-8 w-8 text-blue-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Events</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalEvents}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Clock className="h-8 w-8 text-orange-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Upcoming Events</p>
              <p className="text-2xl font-bold text-gray-900">{stats.upcomingEvents}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-green-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Registrations</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalRegistrations}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-purple-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Completed events</p>
              <p className="text-2xl font-bold text-gray-900">{stats.completedEvents}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        {/* Events by Category Bar Chart */}
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <h3 className="text-md font-semibold mb-4">Events by Category</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={eventCategories}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value">
                {eventCategories.map((entry: { name: string; value: number; color: string }, index: number) => (
                  <Cell key={`cell-bar-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        {/* Registrations by Event Donut Chart */}
        <div className="bg-white rounded-lg shadow-sm p-6 border">
          <h3 className="text-md font-semibold mb-4">Registrations by Event</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={registrationData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                fill="#8884d8"
                label
              >
                {registrationData.map((entry: { name: string; value: number; color: string }, index: number) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Legend />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Events (not filtered) */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900">Recent Events</h2>
          <Link to="/events" className="text-orange-600 hover:text-orange-700 text-sm font-medium">
            View All
          </Link>
        </div>
        <div className="divide-y divide-gray-200">
          {recentEvents.map((event) => (
            <div key={event.id} className="p-6 hover:bg-gray-50 transition-colors duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{event.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {new Date(event.date).toLocaleDateString()} • {event.registrations} registrations
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    event.status === 'upcoming' ? 'bg-blue-100 text-blue-800' :
                    event.status === 'Live' ? 'bg-green-100 text-green-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
 
      {/* AntD DatePicker: Only change selected month and year color in calendar popup */}
      <style>{`
        .ant-picker-panel .ant-picker-month-panel .ant-picker-cell.ant-picker-cell-selected .ant-picker-cell-inner {
          background: #ec580c !important;
          color: #fff !important;
        }
        /* Year selection override for AntD v5 (with dev-only class) */
        :where(.css-dev-only-do-not-override-pjilya).ant-picker-dropdown .ant-picker-cell-in-view.ant-picker-cell-selected:not(.ant-picker-cell-disabled) .ant-picker-cell-inner,
        :where(.css-dev-only-do-not-override-pjilya).ant-picker-dropdown .ant-picker-cell-in-view.ant-picker-cell-range-start:not(.ant-picker-cell-disabled) .ant-picker-cell-inner,
        :where(.css-dev-only-do-not-override-pjilya).ant-picker-dropdown .ant-picker-cell-in-view.ant-picker-cell-range-end:not(.ant-picker-cell-disabled) .ant-picker-cell-inner {
          color: #fff !important;
          background: #ec580c !important;
        }
      `}</style>
    </div>
  );
}