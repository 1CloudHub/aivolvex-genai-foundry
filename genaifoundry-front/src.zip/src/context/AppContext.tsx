import React, { createContext, useContext, useState, ReactNode } from 'react';

type ProjectType = 'insurance' | 'banking' | 'retail' | 'healthcare' | null;

interface AppContextType {
  projectType: ProjectType;
  setProjectType: (type: ProjectType) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  // Load initial value from localStorage
  const [projectType, setProjectTypeState] = useState<ProjectType>(
    () => (localStorage.getItem('projectType') as ProjectType) || null
  );

  // Function to update state and localStorage
  const setProjectType = (type: ProjectType) => {
    setProjectTypeState(type);
    if (type) {
      localStorage.setItem('projectType', type);
    } else {
      localStorage.removeItem('projectType');
    }
  };

  return (
    <AppContext.Provider value={{ projectType, setProjectType }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};
