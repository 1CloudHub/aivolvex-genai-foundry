import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAppContext } from './AppContext';

export type UserRole = 'marketing' | 'devops' | 'sales' | 'customer';

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demonstration
const mockUsers: Record<string, User> = {
  'marketing@genai.com': {
    id: '1',
    name: 'Sarah Marketing',
    email: 'marketing@genai.com',
    role: 'marketing'
  },
  'devops@genai.com': {
    id: '2',
    name: 'Mike DevOps',
    email: 'devops@genai.com',
    role: 'devops'
  },
  'sales@genai.com': {
    id: '3',
    name: 'Jenny Sales',
    email: 'sales@genai.com',
    role: 'sales'
  },
  'demo@insurance.com': {
    id: '5',
    name: 'Clyde',
    email: 'demo@insurance.com',
    role: 'customer'
  },
  'demo@banking.com': {
    id: '6',
    name: 'Venessa',
    email: 'demo@banking.com',
    role: 'customer'
  },
  'demo@retail.com': {
    id: '7',
    name: 'John Retail',
    email: 'demo@retail.com',
    role: 'customer'
  },
  'demo@healthcare.com': {
    id: '8',
    name: 'Dr. Sarah Healthcare',
    email: 'demo@healthcare.com',
    role: 'customer'
  }
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { setProjectType } = useAppContext(); // 🔥 Access AppContext here

  useEffect(() => {
    // Check for stored user on mount
    const storedUser = localStorage.getItem('genai-user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    const mockUser = mockUsers[email];
    if (
      (mockUser && mockUser.role === 'customer' && email === 'demo@insurance.com' && password === 'InsuranceDemo2025!') ||
      (mockUser && mockUser.role === 'customer' && email === 'demo@banking.com' && password === 'BankingDemo@2025!') ||
      (mockUser && mockUser.role === 'customer' && email === 'demo@retail.com' && password === 'RetailDemo@2025!') ||
      (mockUser && mockUser.role === 'customer' && email === 'demo@healthcare.com' && password === 'HealthcareDemo@2025!') ||
      (mockUser && mockUser.role === 'customer' && email !== 'demo@insurance.com' && email !== 'demo@banking.com' && email !== 'demo@retail.com' && email !== 'demo@healthcare.com' && password === 'GenAI2025!') ||
      (mockUser && mockUser.role !== 'customer' && password === 'password')
    ) {
      setUser(mockUser);
      localStorage.setItem('genai-user', JSON.stringify(mockUser));

      // 🔥 Set projectType dynamically
      if (email === 'demo@insurance.com') {
        setProjectType('insurance');
      } else if (email === 'demo@banking.com') {
        setProjectType('banking');
      } else if (email === 'demo@retail.com') {
        setProjectType('retail');
      } else if (email === 'demo@healthcare.com') {
        setProjectType('healthcare');
      } else {
        setProjectType(null);
      }

      console.log('Project Type set to:', email); // ✅ Debugging log
      setIsLoading(false);
      return true;
    }

    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('genai-user');

    //Clear projectType on logout
    setProjectType(null);
    console.log('Project Type cleared on logout'); //  Debugging log
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

