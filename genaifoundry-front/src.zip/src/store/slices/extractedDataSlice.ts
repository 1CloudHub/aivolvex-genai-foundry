import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface ExtractedDataState {
  [docId: string]: {
    statusCode: number;
    session_id: string;
    response_data: {
      extracted_kyc_data: string;
      timestamp: string;
      session_id: string;
    };
  } | null;
}

const initialState: ExtractedDataState = {};

const extractedDataSlice = createSlice({
  name: 'extractedData',
  initialState,
  reducers: {
    setExtractedData: (state, action: PayloadAction<{ docId: string; data: any }>) => {
      const { docId, data } = action.payload;
      state[docId] = data;
    },
    clearExtractedData: (state, action: PayloadAction<string>) => {
      const docId = action.payload;
      state[docId] = null;
    },
    clearAllExtractedData: (state) => {
      Object.keys(state).forEach(key => {
        state[key] = null;
      });
    },
  },
});

export const { setExtractedData, clearExtractedData, clearAllExtractedData } = extractedDataSlice.actions;
export default extractedDataSlice.reducer;
