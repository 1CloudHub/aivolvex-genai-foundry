import { configureStore } from '@reduxjs/toolkit';
import extractedDataReducer from './slices/extractedDataSlice';

export const store = configureStore({
  reducer: {
    extractedData: extractedDataReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
