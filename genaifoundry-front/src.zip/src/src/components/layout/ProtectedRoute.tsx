import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth, UserRole } from '../../context/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
  redirectTo?: string;
}

export default function ProtectedRoute({ 
  children, 
  allowedRoles = [], 
  redirectTo = '/login' 
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to={redirectTo} replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    // Redirect to appropriate home page based on role
    let homePage = user.role === 'customer' ? '/customer/sandbox' : '/events';
    
    if (user.role === 'customer' && user.email === 'demo@insurance.com') {
      homePage = '/customer/sandbox/insurancehome';
    } else if (user.role === 'customer' && user.email === 'demo@banking.com') {
      homePage = '/customer/sandbox/bankinghome';
    } else if (user.role === 'customer' && user.email === 'demo@retail.com') {
      homePage = '/customer/sandbox/retailhome';
    } else if (user.role === 'customer' && user.email === 'demo@healthcare.com') {
      homePage = '/customer/sandbox/healthcarehome';
    } else if (user.role === 'customer' && user.email === 'demo@manufacturing.com') {
      homePage = '/customer/sandbox/manufacturinghome';
    }
    return <Navigate to={homePage} replace />;
  }

  return <>{children}</>;
}