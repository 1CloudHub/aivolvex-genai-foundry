import React from 'react';
import { CheckCircle, Mail, Calendar, User, Building, Rocket } from 'lucide-react';

interface EmailConfirmationProps {
  customerData: {
    name: string;
    email: string;
    company: string;
    eventName: string;
    eventDate: string;
  };
  onClose: () => void;
}

export default function EmailConfirmation({ customerData, onClose }: EmailConfirmationProps) {
  const [launching, setLaunching] = React.useState(false);

  const handleLaunch = () => {
    setLaunching(true);
    setTimeout(() => setLaunching(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Email Header */}
        <div className="bg-orange-500 text-white p-6 rounded-t-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-white bg-opacity-20 rounded-full p-2">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Registration Confirmed!</h2>
                <p className="text-orange-100">Welcome to GenAI Sandbox</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-orange-200 transition-colors duration-200"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Email Body */}
        <div className="p-8">
          <div className="text-center mb-8">
            <div className="mx-auto flex items-center justify-center h-16 w-16 bg-green-100 rounded-full mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              Thank you for registering, {customerData.name}!
            </h3>
            <p className="text-gray-600">
              Your registration has been successfully processed. You can now access your personalized sandbox environment.
            </p>
          </div>

          {/* Account Credentials */}
          <div className="bg-gray-50 rounded-lg p-6 mb-6 border border-gray-200">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Your Account Credentials</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Login URL:</span>
                <a
                  href="/customer/login"
                  className="font-mono text-sm text-orange-600 hover:underline break-all"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {`${window.location.origin}/customer/login`}
                </a>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Username:</span>
                <span className="font-mono text-sm bg-gray-200 text-gray-800 px-2 py-1 rounded">
                  {customerData.email}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Temporary Password:</span>
                <span className="font-mono text-sm bg-gray-200 text-gray-800 px-2 py-1 rounded">
                  GenAI2025!
                </span>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-4">
              Please save these credentials. You will be prompted to change your password upon first login.
            </p>
          </div>

          {/* Event Details Card */}
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Event Information</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-orange-500" />
                <div>
                  <p className="text-sm text-gray-500">Event</p>
                  <p className="font-medium text-gray-900">{customerData.eventName}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-orange-500" />
                <div>
                  <p className="text-sm text-gray-500">Date</p>
                  <p className="font-medium text-gray-900">{new Date(customerData.eventDate).toLocaleDateString()}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <User className="h-5 w-5 text-orange-500" />
                <div>
                  <p className="text-sm text-gray-500">Attendee</p>
                  <p className="font-medium text-gray-900">{customerData.name}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Building className="h-5 w-5 text-orange-500" />
                <div>
                  <p className="text-sm text-gray-500">Company</p>
                  <p className="font-medium text-gray-900">{customerData.company}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Static instruction and Launch button as CTA */}
          <div className="text-center my-8">
            <p className="mb-4 text-lg text-gray-700 font-medium">
              Press the <span className="font-semibold text-green-600">Launch</span> button below to activate your AWS account.
            </p>
            <button
              onClick={handleLaunch}
              className="px-6 py-3 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors duration-200 flex items-center text-lg font-semibold shadow mx-auto"
              disabled={launching}
            >
              {launching ? (
                <span className="flex items-center animate-bounce">
                  <Rocket className="h-6 w-6 mr-2 text-white animate-spin" />
                  Launching...
                </span>
              ) : (
                <>
                  <Rocket className="h-6 w-6 mr-2" />
                  Launch
                </>
              )}
            </button>
          </div>

          {/* Contact Information */}
          <div className="text-center">
            <p className="text-gray-600 mb-4">
              Questions? Contact our team at{' '}
              <a href="mailto:support@genai-sandbox.com" className="text-orange-600 hover:text-orange-700">
                support@genai-sandbox.com
              </a>
            </p>
            <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
              <span>GenAI Sandbox Team</span>
              <span>•</span>
              <span>Transforming Business with AI</span>
            </div>
          </div>
        </div>

        {/* Email Footer */}
        <div className="bg-gray-50 px-8 py-4 rounded-b-lg border-t border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <img src="/banner/1chblack (1).jpg" alt="1CH Logo" className="h-8 w-auto rounded" />
            </div>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}