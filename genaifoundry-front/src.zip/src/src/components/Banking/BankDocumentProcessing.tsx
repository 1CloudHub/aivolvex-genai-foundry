import { useState } from 'react';
// Removed unused UI imports
import { 
  FileText,

  Home as HomeIcon,
  Info
} from 'lucide-react';
// Removed unused utility import
import { useNavigate } from 'react-router-dom';
import LoginNavbar from '../layout/LoginNavbar';
import Footer from '../Banking/BankingFooter';

interface DocumentType {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

interface ExtractedField {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'error';
  message?: string;
}

interface ProcessedDocument {
  id: string;
  name: string;
  type: string;
  status: 'processing' | 'completed' | 'failed';
  confidence: number;
  fields: ExtractedField[];
  uploadTime: Date;
}

const documentTypes: DocumentType[] = [
  {
    id: 'pan',
    name: 'NRIC',
    description: 'Clear image of your NRIC card',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
      <path d="M14 2v6h6"/>
      <path d="M16 13H8"/>
      <path d="M16 17H8"/>
      <path d="M10 9H8"/>
    </svg>
  </div>
  },
  {
    id: 'bank_statement',
    name: 'Bank Statement',
    description: 'Last 3 months statement (PDF format)',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
        <path d="M14 2v6h6"/>
        <path d="M16 13H8"/>
        <path d="M16 17H8"/>
        <path d="M10 9H8"/>
      </svg>
    </div>
  },
  {
    id: 'salary_slip',
    name: 'Salary Slip',
    description: 'Upload your latest salary slip',
    icon: <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
      <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
        <path d="M14 2v6h6"/>
        <path d="M16 13H8"/>
        <path d="M16 17H8"/>
        <path d="M10 9H8"/>
      </svg>
    </div>
  },

];

// Mock processed document data
const mockDocuments: Record<string, ProcessedDocument> = {
  pan: {
    id: 'pan-001',
    name: 'sg-nric+1.jpg',
    type: 'NRIC',
    status: 'completed',
    confidence: 88,
    fields: [
      { name: 'Identity Card Number', value: '123456789', status: 'success' },
      { name: 'Name', value: 'MARIE JUMIO', status: 'success' },
      { name: 'Race', value: 'CHINESE', status: 'success' },
      { name: 'Sex', value: 'F', status: 'success' },
      { name: 'Date of Birth', value: '1975-01-01', status: 'success' },
      { name: 'Country of Birth', value: 'SINGAPORE', status: 'success' }
    ],
    uploadTime: new Date()
  },
  bank_statement: {
    id: 'statement-001',
    name: 'Bank_Statement_Jan_Mar_2025.pdf',
    type: 'Bank Statement',
    status: 'completed',
    confidence: 95,
    fields: [
      { name: 'Account Holder Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Bank Name & Branch', value: 'State Bank of India, Bangalore Main Branch', status: 'success' },
      { name: 'Statement Period', value: 'Jan 2025 - Mar 2025', status: 'success' },
      { name: 'Monthly Salary Credits', value: '₹85,000', status: 'success' },
      { name: 'EMI/Loan Debits', value: '₹28,500', status: 'success' },
      { name: 'Utility/Recurring Payments', value: '₹5,000', status: 'success' },
      { name: 'Minimum Balance Trends', value: '₹25,000 - ₹72,456', status: 'success' },
      { name: 'NSF/Bounce Charges', value: '₹0', status: 'success' },
      { name: 'Cash Deposits/Transfers', value: '₹50,000', status: 'success' },
      { name: 'End-of-Month Balances', value: '₹72,456', status: 'success' }
    ],
    uploadTime: new Date()
  },
  salary_slip: {
    id: 'salary-slip-001',
    name: 'Salary_Slip_Mar_2025.pdf',
    type: 'Salary Slip',
    status: 'completed',
    confidence: 93,
    fields: [
      { name: 'Employee Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Designation', value: 'Senior Software Engineer', status: 'success' },
      { name: 'Gross Monthly Income', value: '₹90,000', status: 'success' },
      { name: 'Deductions', value: '₹8,000', status: 'success' },
      { name: 'Net Take-Home Pay', value: '₹82,000', status: 'success' },
      { name: 'Pay Period', value: 'Mar 2025', status: 'success' }
    ],
    uploadTime: new Date()
  },
  insurance_pdf: {
    id: 'insurance-pdf-001',
    name: 'Insurance sandbox doc4.pdf',
    type: 'Insurance Discharge Summary',
    status: 'completed',
    confidence: 80,
    fields: [
      { name: 'patient_name', value: 'John Doe', status: 'success' },
      { name: 'hospital_name', value: 'General Hospital', status: 'success' },
      { name: 'admission_date', value: 'May 10, 2024', status: 'success' },
      { name: 'discharge_date', value: 'May 20, 2024', status: 'success' },
      { name: 'primary_diagnosis', value: 'Acute appendicitis', status: 'success' },
      { name: 'procedure_performed', value: 'Appendectomy performed on May 11, 2024', status: 'success' },
      { name: 'discharge_condition', value: 'Stable', status: 'success' },
    ],
    uploadTime: new Date()
  }
};

const docUrls: Record<string, string> = {
  pan: '/Documents/sg-nric 1.jpg',
  bank_statement: '/Documents/bank statement blog image.webp',
  // salary_slip: '/Documents/salaryslip.pdf#toolbar=0',
  salary_slip: '/Documents/salaryslip.png',
  insurance_pdf: '/Insurance/Insurance sandbox doc4.pdf'
};

const getPdfUrl = (url: string) => {
  if (url.endsWith('.pdf')) {
    return `${url}#toolbar=0&navpanes=0&scrollbar=0&view=FitH`;
  }
  return url;
};

const bankExplicitFields = [
  { field: 'Account Holder Name', value: 'Mr. Toby Grant', note: 'Top-left' },
  { field: 'Address', value: '27 Argyll Road, London W8 7DA', note: 'Can be cross-validated with NRIC/ID' },
  { field: 'Bank Name', value: 'HSBC UK', note: 'Useful for validating account legitimacy' },
  { field: 'Account Number (IBAN)', value: 'GB24BHBK408913829263', note: 'Redact/mask if needed' },
  { field: 'Statement Period', value: '25 Nov to 2 Dec 2023', note: 'Date context for transaction activity' },
  { field: 'Opening Balance', value: '£0.57', note: 'Useful to assess liquidity at start' },
  { field: 'Closing Balance', value: '£2,139.27', note: 'Strong end-of-period balance' },
  { field: 'Total Payments In', value: '£3,142.37', note: 'Used to calculate average monthly income (if full period shown)' },
  { field: 'Total Payments Out', value: '£1,003.10', note: 'Used to assess spending behavior' },
];

const bankInferredFields = [
  { field: 'Monthly Income Estimate', value: 'Approx. £2,200–£3,100 (from 3 credits)', note: 'Combine: £2,212.14 (Transfer), £425.23 (Deposit), £500 (Cheque)' },
  { field: 'Regular Inflow Pattern', value: 'High confidence: Income inferred from "Transfer" or "Deposit"', note: 'Indicates applicant is receiving income (possibly salary or sales proceeds)' },
  { field: 'Transaction Type Diversity', value: 'BP, Uber, Mastercard, Costa', note: 'Validates real spending behavior' },
  { field: 'Loan EMIs?', value: 'None visible', note: 'No recurring EMI-like deduction → may be new borrower' },
  { field: 'Cash Flow Stability', value: 'Strong positive balance throughout', note: 'Healthy liquidity profile' },
  { field: 'Active Account Usage', value: 'Yes', note: 'High volume of small transactions indicates active usage (e.g., BP, Costa, Uber)' },
];

const salaryIdentityFields = [
  { field: 'Employee Name', value: 'John Stiles' },
  { field: 'Employee Address', value: '101 Main Street, Anytown, USA 12345' },
  { field: 'Employer Name', value: 'Any Company Corp.' },
  { field: 'Employer Address', value: '475 Any Avenue, Anytown, USA 10101' },
  { field: 'Social Security Number (demo use)', value: '987-65-4321' },
  { field: 'Taxable Marital Status', value: 'Married' },
  { field: 'Pay Period Ending', value: '07/18/2008' },
  { field: 'Pay Date', value: '07/25/2008' },
];

const salaryEarningsFields = [
  { field: 'Total Earnings', value: '$452.43' },
  { field: 'Breakdown', value: 'Regular, Overtime, Holiday, Tuition-based earnings' },
];

const salaryDeductionsFields = [
  { field: 'Statutory Deductions', value: '$91.19' },
  { field: 'Other Deductions', value: '$83.85' },
  { field: 'Total Deductions', value: '$175.04' },
];

const salaryAdjustmentsFields = [
  { field: 'Life Insurance Reimbursement', value: '+$13.50' },
];

const salaryNetSummaryFields = [
  { field: 'Net Pay', value: '$291.90' },
  { field: 'Federal Taxable Wages', value: '$386.15' },
];

const salaryInferredFields = [
  { field: 'Estimated Monthly Income', value: '~$1,300', note: 'Extrapolated from gross pay' },
  { field: 'Employment Type', value: 'Hourly', note: 'Based on rate/hour pattern' },
  { field: 'Employer Stability', value: 'Trusted', note: '401(k), Stock Plan, Insurance present' },
  { field: 'Existing Liability', value: 'Yes – Loan deduction ($30)', note: 'Signals repayment history' },
  { field: 'Net Pay Viability', value: 'Moderate', note: '~$1,100/month net estimated' },
  { field: 'Expense Pressure', value: 'Medium', note: '35–40% of income deducted' },
];

const Documents = () => {
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [extractingDocId, setExtractingDocId] = useState<string | null>(null);
  // Removed unused extractedData state
  const [showExtractedInfo, setShowExtractedInfo] = useState<{[key: string]: boolean}>({});
  const navigate = useNavigate();
  const selectedDocData = selectedDocId ? mockDocuments[selectedDocId] : null;

  // Helper to check if the selected doc is an image
  const isImage = (url: string) => /\.(jpg|jpeg|png|webp|gif)$/i.test(url);

  // RiskLens API call function using the same API as Risk.tsx
  const makeDummyApiCall = (docId: string) => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    // Build request body similar to Risk.tsx
    const payload = {
      event_type: 'risk_sandbox',
      applicant_profile: {
        name: 'Aaron Goh',
        age: 39,
        occupation: 'Self-Employed (Event Logistics Support)',
        credit_score: 1660
      },
      financials: {
        monthly_income: 5800,
        existing_emis: 950,
        net_pay: 4850
      },
      loan_details: {
        loan_type: 'Secured Personal Loan',
        loan_purpose: 'Short-term cash flow for upcoming event',
        requested_amount: 6000,
        tenure_months: 3,
        interest_rate: 2.5
      },
      collateral: {
        type: 'Vehicle',
        description: '2016 Toyota Altis (full ownership, maintained)',
        market_value: 14500,
        conditionVehicle: 'Good',
        ownership_proof: 'Yes'
      },
      agent_comments: 'Known customer. Has taken one short-term loan before and repaid early. Vehicle appraised by branch staff, and event work invoice shown as partial proof of upcoming income.',
      document_type: docId // Add document type to payload
    };
    
    // Non-blocking API call
    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(error => {
      console.log('RiskLens call made (non-blocking):', payload, error);
    });
  };

  // Handle extract button click
  const handleExtract = (docId: string) => {
    setExtractingDocId(docId);
    setShowExtractedInfo(prev => ({ ...prev, [docId]: false }));
    
    // Make dummy API call
    makeDummyApiCall(docId);
    
    // Show extracted info after 5-6 seconds
    setTimeout(() => {
      setShowExtractedInfo(prev => ({ ...prev, [docId]: true }));
      setExtractingDocId(null);
    }, 5500); // 5.5 seconds
  };

  return (
    <>
      <LoginNavbar />
      <div className="container py-6">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-2 -ml-1" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <button 
                type="button" 
                onClick={() => navigate('/customer/sandbox/bankinghome')} 
                className="flex items-center gap-2 text-orange-600 no-underline"
                style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
              >
                <HomeIcon size={16} className="relative top-[-1px]" />
                Home
              </button>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-gray-500">Document Processing Assistant</span>
            </li>
          </ol>
        </nav>
        {/* Page Title and Subtitle */}
        <div className="flex items-center gap-6 mb-4 ml-4">
          <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
            <FileText className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
            Document Processing Assistant
            </h1>
            <p className="text-base text-gray-600">
              Upload and analyze financial documents with AI-powered extraction of key information.
            </p>
          </div>
        </div>
        <div className="container mx-auto py-4 px-4 md:px-6 lg:px-8 min-h-screen">
          {/* Card Selector */}
          <div className="w-full mb-10">
            <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(220px, 1fr))` }}>
              {documentTypes.map((doc) => (
                   <div
                     key={doc.id}
                onClick={() => {
                  console.log('Clicking card:', doc.id, 'Current selected:', selectedDocId);
                  setSelectedDocId(doc.id);
                }}
                   className="cursor-pointer transition-colors duration-200 p-4 rounded-lg bg-white"
                   data-selected={selectedDocId === doc.id}
                   style={{
                     backgroundColor: selectedDocId === doc.id ? 'rgb(255, 251, 245)' : 'white',
                     boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)',
                     position: 'relative',
                     border: selectedDocId === doc.id 
                       ? '2px solid #fb923c' 
                       : 'none'
                   }}
                >
               <div className="flex items-start gap-4">
                 {doc.icon}
                 <div>
                   <h3 className="font-semibold text-base text-gray-800">{doc.name}</h3>
                   <p className="text-sm text-gray-500">{doc.description}</p>
                 </div>
               </div>
                </div>
              ))}
                   </div>
                 </div>

        {selectedDocId && selectedDocData ? (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left: PDF or Image */}
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-4">{selectedDocData.type}</h2>
                <div className="w-full h-[700px] rounded-lg overflow-hidden bg-white flex flex-col" style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
                  <div className="flex-1 flex items-center justify-center" style={{ minHeight: 0 }}>
                    {isImage(docUrls[selectedDocId]) ? (
                      <img
                        src={docUrls[selectedDocId]}
                        alt="Document"
                        style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', width: '100%', height: '100%' }}
                      />
                    ) : (
                      <iframe
                        src={getPdfUrl(docUrls[selectedDocId])}
                        title="Document"
                        width="100%"
                        height="100%"
                        style={{ border: 'none' }}
                        allowFullScreen
                      />
                    )}
                  </div>
                  {/* Extract Button inside the card */}
                  <div className="p-4 border-t border-gray-200 bg-white" style={{ flexShrink: 0 }}>
                    <button
                      onClick={() => handleExtract(selectedDocId)}
                      disabled={extractingDocId === selectedDocId}
                      className={`w-full py-3 px-4 rounded-lg text-sm font-medium transition-colors duration-200 ${
                        extractingDocId === selectedDocId
                          ? 'bg-orange-100 text-orange-600 cursor-not-allowed'
                          : 'bg-orange-500 text-white hover:bg-orange-600'
                      }`}
                    >
                      {extractingDocId === selectedDocId ? (
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-4 h-4 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
                          Extracting...
                        </div>
                      ) : (
                        'Extract'
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column */}
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Extracted Information</h2>
                <div className="w-full rounded-lg bg-white p-6"
                style={{ 
                  height: selectedDocId === 'insurance_pdf' ? '700px' : '700px', 
                  overflowY: 'auto',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)',
                  border: 'none'
                }}
              >
                {!showExtractedInfo[selectedDocId] ? (
                  // Placeholder content similar to the Summary card
                  <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
                    style={{
                      minHeight: 600,
                      height: 600,
                      color: '#b0b0b0',
                      fontSize: '0.9rem',
                      fontWeight: 400,
                      letterSpacing: '0.01em',
                      textAlign: 'center',
                      background: 'inherit',
                      fontFamily: 'Inter, sans-serif'
                    }}
                  >
                    <span>
                      Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
                    </span>
                    <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
                      to begin document processing!
                    </span>
                  </div>
                ) : (
                  <>
                    {selectedDocId === 'bank_statement' ? (
                      <>
                        {/* Explicit Extraction Table */}
                        <h3 className="text-lg font-bold mb-2">Explicit Extraction</h3>
                        <table className="w-full mb-6 text-sm">
                        
                          <thead>
                            <tr className="text-left text-gray-500">

                              <th className="py-2 text-left">Field</th>
                              <th className="py-2 text-right">Extracted Value</th>
                              <th className="py-2"></th>
                            </tr>
                          </thead>
                          <tbody>
                            {bankExplicitFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                                <td className="py-2">
                                  <span className="relative group cursor-pointer">
                                    {/* <span className="flex items-center justify-center w-6 h-6  bg-white">
                                      <Info className="h-4 w-4 text-orange-500" />
                                    </span> */}
                                    <span
                                      className="absolute right-8 top-1/2 -translate-y-1/2 z-20 invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all duration-200 bg-white text-gray-900 text-xs rounded-lg px-4 py-3 min-w-[220px] max-w-[320px] whitespace-normal shadow-xl border-l-4 border-orange-400 flex flex-col items-start"
                                      style={{ boxShadow: '0 4px 24px 0 rgba(16,30,54,.12)' }}
                                    >
                                      <span className="text-sm text-gray-700">{row.note}</span>
                                    </span>
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {/* Inferred Fields Table */}
                        <h3 className="text-lg font-bold mb-2">Inferred Fields</h3>
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Field</th>
                              <th className="py-2 text-right">Inferred Value</th>
                              <th className="py-2"></th>
                            </tr>
                          </thead>
                          <tbody>
                            {bankInferredFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                                <td className="py-2 text-left align-middle">
                                  <span className="relative group cursor-pointer">
                                    <span className="flex items-center justify-center w-6 h-6  bg-white">
                                      <Info className="h-4 w-4 text-orange-500" />
                                    </span>
                                    <span
                                      className="absolute right-8 top-1/2 -translate-y-1/2 z-20 invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all duration-200 bg-white text-gray-900 text-xs rounded-lg px-4 py-3 min-w-[220px] max-w-[320px] whitespace-normal shadow-xl border-l-4 border-orange-400 flex flex-col items-start"
                                      style={{ boxShadow: '0 4px 24px 0 rgba(16,30,54,.12)' }}
                                    >
                                      <span className="text-sm text-gray-700">{row.note}</span>
                                    </span>
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </>
                    ) : selectedDocId === 'salary_slip' ? (
                      <>
                        {/* Identity & Employer Details */}
                        <h3 className="text-lg font-bold mb-2">Explicit Extraction</h3>
                        <table className="w-full mb-6 text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Field</th>
                              <th className="py-2 text-right">Value</th>
                            </tr>
                          </thead>
                          <tbody>
                            {salaryIdentityFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {/* Earnings Summary */}
                        <h3 className="text-lg font-bold mb-2">Earnings Summary (This Period)</h3>
                        <table className="w-full mb-6 text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Field</th>
                              <th className="py-2 text-right">Value</th>
                            </tr>
                          </thead>
                          <tbody>
                            {salaryEarningsFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {/* Deductions Summary */}
                        <h3 className="text-lg font-bold mb-2">Deductions Summary (This Period)</h3>
                        <table className="w-full mb-6 text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Type</th>
                              <th className="py-2 text-right">Total Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            {salaryDeductionsFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {/* Adjustments */}
                        <h3 className="text-lg font-bold mb-2">Adjustments</h3>
                        <table className="w-full mb-6 text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Description</th>
                              <th className="py-2 text-right">Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            {salaryAdjustmentsFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {/* Net Summary */}
                        <h3 className="text-lg font-bold mb-2">Net Summary</h3>
                        <table className="w-full mb-6 text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Field</th>
                              <th className="py-2 text-right">Value</th>
                            </tr>
                          </thead>
                          <tbody>
                            {salaryNetSummaryFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{row.value}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {/* Inferred Fields */}
                        <h3 className="text-lg font-bold mb-2">Inferred Fields</h3>
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Field</th>
                              <th className="py-2 text-right">Inferred Value</th>
                            </tr>
                          </thead>
                          <tbody>
                            {salaryInferredFields.map((row) => (
                              <tr key={row.field} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{row.field}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">
                                  <div className="flex items-center justify-end gap-2">
                                    <span>{row.value}</span>
                                    <span className="relative group cursor-pointer">
                                      <span className="flex items-center justify-center w-6 h-6 bg-white">
                                        <Info className="h-4 w-4 text-orange-500" />
                                      </span>
                                      <span
                                        className="absolute right-8 top-1/2 -translate-y-1/2 z-20 invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all duration-200 bg-white text-gray-900 text-xs rounded-lg px-4 py-3 min-w-[220px] max-w-[320px] whitespace-normal shadow-xl border-l-4 border-orange-400 flex flex-col items-start"
                                        style={{ boxShadow: '0 4px 24px 0 rgba(16,30,54,.12)' }}
                                      >
                                        <span className="text-sm text-gray-700">{row.note}</span>
                                      </span>
                                    </span>
                              </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </>
                    ) : selectedDocId === 'insurance_pdf' ? (
                      <>
                        <div className="text-lg font-bold mb-2">Fields to Extract</div>
                        <table className="w-full mb-6 text-sm">
                          <thead>
                            <tr className="text-left text-gray-500">
                              <th className="py-2 text-left">Field</th>
                              <th className="py-2 text-right">Extracted Value</th>
                            </tr>
                          </thead>
                          <tbody>
                            {selectedDocData.fields.map((field) => (
                              <tr key={field.name} className="border-b last:border-b-0">
                                <td className="py-2 text-gray-700 text-left align-middle">{field.name}</td>
                                <td className="py-2 font-medium text-gray-900 text-right align-middle">{field.value || <span className="text-gray-400 italic">(not extracted)</span>}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </>
                    ) : (
                      <>
                      <div className="text-lg font-bold mb-2">Explicit Extraction</div>
                      <table className="w-full mb-6 text-sm">
                          
                        <thead>
                          <tr className="text-left text-gray-500">
                            <th className="py-2 text-left">Field</th>
                            <th className="py-2 text-right">Extracted Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          {selectedDocData.fields.map((field) => (
                         
                               <tr key={field.name} className="border-b last:border-b-0">
                              <td className="py-2 text-gray-700 text-left align-middle">{field.name}</td>
                              <td className="py-2 font-medium text-gray-900 text-right align-middle">{field.value}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      </>
                    )}
                  </>
                )}
                </div>
              </div>
            </div>
            <div className="flex justify-center mt-10">
              {/* <Button onClick={() => navigate('/risk')} className="w-96 max-w-full">
                    Proceed to RiskLens
                  </Button> */}
                </div>
          </>
        ) : (
          <div className="text-center py-16">
            <div className="inline-block bg-gray-100 p-5 rounded-full mb-4">
              <FileText className="h-12 w-12 text-gray-300" />
            </div>
            <p className="text-gray-500">Select a document option to begin the extraction process</p>
              </div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Documents;