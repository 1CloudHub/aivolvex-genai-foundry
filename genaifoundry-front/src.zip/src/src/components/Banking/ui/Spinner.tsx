import React from 'react';

interface SpinnerProps {
  label?: string;
  size?: number;
  className?: string;
}

const Spinner: React.FC<SpinnerProps> = ({ label = 'Loading...', size = 40, className = '' }) => (
  <div className={`flex flex-col items-center justify-center ${className}`} aria-busy="true" aria-live="polite">
    <svg
      className="animate-spin"
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label={label}
      tabIndex={0}
      role="status"
    >
      <path
        d="M20 4
          a 16 16 0 0 1 0 32"
        stroke="#e87722"
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
    {label && (
      <span className="text-[#e87722] font-semibold text-lg text-center mt-4">{label}</span>
    )}
  </div>
);

export default Spinner; 