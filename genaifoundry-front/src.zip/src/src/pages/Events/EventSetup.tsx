import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, MapPin, DollarSign, ArrowLeft } from 'lucide-react';
import { useNotification } from '../../hooks/useNotification';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbSeparator,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbHome,
} from '../../components/ui/breadcrumb';

export default function EventSetup() {
  const navigate = useNavigate();
  const { showNotification } = useNotification();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    date: '',
    time: '',
    location: '',
    estimatedCosts: '',
    targetIndustries: [] as string[]
  });
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const industries = [
    'Banking & Finance',
    'Insurance',
    'Retail & E-commerce',
    'Healthcare',
    'Manufacturing',
    'Logistics & Supply Chain',
    'Media & Entertainment',
    'Government & Public Sector'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Basic validation
    if (!formData.name || !formData.date || !formData.location) {
      setErrorMessage('Please fill in all required fields: Event Name, Event Date, and Location.');
      setTimeout(() => setErrorMessage(''), 3000); // Hide error after 3 seconds
      return;
    }
    
    // Set loading state
    setIsSubmitting(true);
    
    // Generate a unique event ID
    const eventId = 'event_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    
    // Prepare API request data
    const apiData = {
      "event_type": "ins_event_data",
      "data": {
        "eventid": eventId,
        "eventname": formData.name,
        "eventdesc": formData.description || "No description provided", // Provide default if empty
        "eventdate": formData.date,
        "eventtime": formData.time || "00:00:00",
        "eventlocation": formData.location
      }
    };

    try {
      const myHeaders = new Headers();
      myHeaders.append("Content-Type", "application/json");
      
      const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: JSON.stringify(apiData),
        redirect: "follow" as RequestRedirect
      };
      
      const response = await fetch(import.meta.env.VITE_EVENT_API_URL, requestOptions);
      const result = await response.text();
      
      console.log('API Response:', result);
      console.log('Creating event:', formData);
      
      showNotification('success', 'Event has been created successfully');
      setTimeout(() => {
        navigate('/events', { state: { refresh: true } });
      }, 100); // Short delay to allow notification to show on /events
      
    } catch (error) {
      console.error('API Error:', error);
      setErrorMessage('Failed to create event. Please try again.');
      setTimeout(() => setErrorMessage(''), 3000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleIndustryChange = (industry: string) => {
    setFormData(prev => ({
      ...prev,
      targetIndustries: prev.targetIndustries.includes(industry)
        ? prev.targetIndustries.filter(i => i !== industry)
        : [...prev.targetIndustries, industry]
    }));
  };

  return (
    <div className="min-h-screen w-full px-4 sm:px-8 lg:px-12 bg-gray-50 flex flex-col">
      <div className="mb-2">
      <div className="mb-2">
          <Breadcrumb>
            <BreadcrumbList className="flex items-center text-base font-semibold gap-0">
              <BreadcrumbItem>
                <BreadcrumbLink to="/">
                  <BreadcrumbHome />
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator>
                <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
              </BreadcrumbSeparator>
              <BreadcrumbItem>
                <BreadcrumbLink to="/events" className="text-gray-700 hover:text-orange-600 font-semibold">Events</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator>
                <span className="mx-0.5 text-gray-400 text-lg font-bold">/</span>
              </BreadcrumbSeparator>
              <BreadcrumbItem>
                <BreadcrumbPage className="text-orange-600 font-semibold">Create Event</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </div>
        <h1 className="text-3xl font-medium text-gray-900 mb-4">Create New Event</h1>
        {/* <p className="text-gray-600 mt-2">Set up a new GenAI Sandbox demonstration event</p> */}

      </div>

      <form onSubmit={handleSubmit} className="space-y-8 mt-0">
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-xl font-medium text-gray-900 mb-6">Event Details</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Event Name *
              </label>
              <input
                type="text"
                id="name"
                required
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="e.g., GenAI for Banking Summit 2025"
              />
            </div>

            <div className="md:col-span-2">
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                id="description"
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="Describe the event and its objectives..."
              />
            </div>

            <div>
              <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="h-4 w-4 inline mr-1" />
                Event Date *
              </label>
              <input
                type="date"
                id="date"
                required
                min={new Date().toISOString().split('T')[0]}
                value={formData.date}
                onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>

            <div>
              <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-2">
                Time
              </label>
              <input
                type="time"
                id="time"
                value={formData.time}
                onChange={(e) => setFormData(prev => ({ ...prev, time: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>

            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                <MapPin className="h-4 w-4 inline mr-1" />
                Location *
              </label>
              <input
                type="text"
                id="location"
                required
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                placeholder="e.g., San Francisco, CA"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={() => navigate('/events')}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors duration-200"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className={`px-6 py-2 rounded-md transition-colors duration-200 ${
              isSubmitting 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-orange-500 hover:bg-orange-600 text-white'
            }`}
          >
            {isSubmitting ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Creating Event...
              </div>
            ) : (
              'Create Event'
            )}
          </button>
        </div>
      </form>

      {errorMessage && (
        <div className="mt-4 text-red-500">
          {errorMessage}
        </div>
      )}
    </div>
  );
}