import React, { useState, useEffect, useRef } from 'react';
import { Home as HomeIcon, AlertTriangle, FileText, Play, Pause, Activity, Thermometer, Gauge, Zap, TrendingUp, Info } from 'lucide-react';
import { Link } from 'react-router-dom';
import ManufacturingLayout from './ManufacturingLayout';
import ReactApexChart from 'react-apexcharts';

/**
 * Sensor Data Interface
 */
interface SensorData {
  timestamp: string;
  temperature: number;
  vibration: number;
  pressure: number;
  rpm: number;
  powerLoad: number;
}

/**
 * Anomaly Detection & Root Cause Analysis Component
 * Simplified, clean interface for monitoring machine health
 */
const AnomalyDetectionRCA = () => {
  const [machineStatus] = useState<'normal' | 'warning' | 'anomaly'>('anomaly');
  const [lastScanTime, setLastScanTime] = useState<string>(new Date().toLocaleString());
  const [sensorData, setSensorData] = useState<SensorData[]>([]);
  const [isStreaming, setIsStreaming] = useState<boolean>(true);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [hasRunAnalysis, setHasRunAnalysis] = useState<boolean>(false);
  const intervalRef = useRef<number | null>(null);

  /**
   * Generate mock sensor data
   */
  const generateMockSensorData = (): SensorData => {
    const baseTemp = 55;
    const baseVibration = 5;
    const basePressure = 4.5;
    const baseRPM = 2400;
    const basePower = 65;

    const temp = baseTemp + Math.random() * 40 + (machineStatus === 'anomaly' ? 20 : 0);
    const vibration = baseVibration + Math.random() * 7 + (machineStatus === 'anomaly' ? 5 : 0);
    const pressure = basePressure + Math.random() * 1.5;
    const rpm = baseRPM + (Math.random() - 0.5) * 100;
    const power = basePower + Math.random() * 15 + (machineStatus === 'anomaly' ? 6 : 0);

    return {
      timestamp: new Date().toLocaleTimeString(),
      temperature: Math.round(temp * 10) / 10,
      vibration: Math.round(vibration * 10) / 10,
      pressure: Math.round(pressure * 10) / 10,
      rpm: Math.round(rpm),
      powerLoad: Math.round(power * 10) / 10
    };
  };

  /**
   * Initialize sensor data stream
   */
  useEffect(() => {
    const initialData: SensorData[] = [];
    for (let i = 0; i < 20; i++) {
      initialData.push(generateMockSensorData());
    }
    setSensorData(initialData);

    if (isStreaming) {
      intervalRef.current = setInterval(() => {
        setSensorData(prev => {
          const newData = [...prev, generateMockSensorData()];
          return newData.slice(-50);
        });
        setLastScanTime(new Date().toLocaleString());
      }, 2000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isStreaming, machineStatus]);

  /**
   * Handle analysis trigger
   */
  const handleRunAnalysis = () => {
    setIsAnalyzing(true);
    setHasRunAnalysis(true);
    // Show loader for 3-5 seconds (using 4 seconds as middle ground)
    setTimeout(() => {
      setIsAnalyzing(false);
    }, 4000);
  };

  /**
   * Get current sensor readings
   */
  const currentReading = sensorData.length > 0 ? sensorData[sensorData.length - 1] : null;

  /**
   * Chart configuration for sensor trends
   */
  const chartOptions = {
    chart: {
      type: 'line' as const,
      height: 250,
      toolbar: { show: false },
      zoom: { enabled: false }
    },
    colors: ['#e87722', '#dc2626', '#3b82f6', '#10b981', '#f59e0b'],
    stroke: {
      curve: 'smooth' as const,
      width: 2
    },
    xaxis: {
      categories: sensorData.length > 0 ? sensorData.slice(-20).map((_, i) => `T${i + 1}`) : [],
      labels: { style: { fontSize: '10px' } }
    },
    legend: {
      position: 'top' as const,
      fontSize: '12px'
    },
    tooltip: {
      shared: true
    }
  };

  const chartSeries = [
    {
      name: 'Temperature (°C)',
      data: sensorData.length > 0 ? sensorData.slice(-20).map(d => d.temperature) : []
    },
    {
      name: 'Vibration (mm/s)',
      data: sensorData.length > 0 ? sensorData.slice(-20).map(d => d.vibration) : []
    }
  ];


  /**
   * Sensor metric card component
   */
  const SensorMetricCard = ({ icon: Icon, label, value, unit, normalRange, isAnomaly }: {
    icon: React.ElementType;
    label: string;
    value: number;
    unit: string;
    normalRange: string;
    isAnomaly: boolean;
  }) => (
    <div className={`bg-white p-4 ${isAnomaly ? 'bg-red-50' : ''}`} style={isAnomaly ? { borderRadius: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: '2px solid #fecaca' } : { borderRadius: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Icon className={`h-5 w-5 ${isAnomaly ? 'text-red-600' : 'text-gray-600'}`} />
          <span className="text-sm font-medium text-gray-700">{label}</span>
        </div>
        {isAnomaly && (
          <span className="text-xs font-semibold text-red-600 bg-red-100 px-2 py-1 rounded">ALERT</span>
        )}
      </div>
      <div className="flex items-baseline gap-2">
        <span className={`text-2xl font-bold ${isAnomaly ? 'text-red-600' : 'text-gray-900'}`}>
          {value.toFixed(1)}
        </span>
        <span className="text-sm text-gray-500">{unit}</span>
      </div>
      <div className="mt-2 text-xs text-gray-500">
        Normal: {normalRange}
      </div>
    </div>
  );

  return (
    <ManufacturingLayout>
      <div className="flex-grow container mx-auto px-4 py-4">
        <div className="mx-auto w-full max-w-10xl mt-8">
          <div className="mb-4">
            <div className="w-full">
              <nav className="flex text-sm text-gray-500 mb-2 -mt-6 -ml-5" aria-label="Breadcrumb">
                <ol className="inline-flex items-center space-x-1">
                  <li>
                    <Link to="/customer/sandbox/manufacturinghome" className="flex items-center gap-2 text-gray-500 no-underline hover:text-gray-700">
                      <HomeIcon size={16} className="relative top-[-1px]" />
                      <span>Home</span>
                    </Link>
                  </li>
                  <li>
                    <span className="mx-2">/</span>
                    <span className="text-orange-600 font-medium">Anomaly Detection & Root Cause</span>
                  </li>
                </ol>
              </nav>
              <div className="flex items-center mb-2">
                <div className="ub-feature-icon mr-3">
                  <AlertTriangle size={30} />
                </div>
                <div>
                  <h2 className="mb-0 text-3xl font-bold">Anomaly Detection & Root Cause Analysis</h2>
                  <p className="text-gray-500" style={{ lineHeight: '1.5' }}>AI-powered monitoring that detects machine anomalies and explains root causes in real-time</p>
                </div>
              </div>
            </div>
          </div>

          {/* Machine Status Card */}
          <div className="bg-white p-4 mb-6" style={{ borderRadius: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6 flex-wrap">
                <div>
                  <span className="text-xs text-gray-500">Machine ID</span>
                  <p className="text-sm font-semibold text-gray-900">CNC-MX450</p>
                </div>
                <div>
                  <span className="text-xs text-gray-500">Last Scan</span>
                  <p className="text-sm font-medium text-gray-900">{lastScanTime}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunAnalysis}
                  disabled={isAnalyzing}
                  className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isAnalyzing ? 'Analyzing...' : 'Run Analysis'}
                </button>
                <button
                  onClick={() => setIsStreaming(!isStreaming)}
                  className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium"
                >
                  {isStreaming ? <Pause size={18} /> : <Play size={18} />}
                  {isStreaming ? 'Pause' : 'Resume'}
                </button>
              </div>
            </div>
          </div>

          {/* Current Sensor Readings - Key Metrics */}
          {currentReading && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="h-5 w-5 text-gray-600" />
              <h2 className="text-lg font-semibold text-gray-900">Current Sensor Readings</h2>
              <Info className="h-4 w-4 text-gray-400" />
              <span className="text-xs text-gray-500">Real-time data from IoT sensors</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <SensorMetricCard
                icon={Thermometer}
                label="Temperature"
                value={currentReading.temperature}
                unit="°C"
                normalRange="40-75°C"
                isAnomaly={currentReading.temperature > 75}
              />
              <SensorMetricCard
                icon={Gauge}
                label="Vibration"
                value={currentReading.vibration}
                unit="mm/s"
                normalRange="2-8 mm/s"
                isAnomaly={currentReading.vibration > 8}
              />
              <SensorMetricCard
                icon={Activity}
                label="Pressure"
                value={currentReading.pressure}
                unit="bar"
                normalRange="3.5-5.5 bar"
                isAnomaly={currentReading.pressure < 3.5 || currentReading.pressure > 5.5}
              />
              <SensorMetricCard
                icon={TrendingUp}
                label="RPM"
                value={currentReading.rpm}
                unit="rpm"
                normalRange="2300-2500 rpm"
                isAnomaly={currentReading.rpm < 2300 || currentReading.rpm > 2500}
              />
              <SensorMetricCard
                icon={Zap}
                label="Power Load"
                value={currentReading.powerLoad}
                unit="%"
                normalRange="50-80%"
                isAnomaly={currentReading.powerLoad > 80}
              />
            </div>
          </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Anomaly Detection Results */}
            <div 
              className="bg-white p-6 relative" 
              style={{ 
                borderRadius: '16px', 
                boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', 
                border: 'none',
                transition: 'all 0.3s ease'
              }}
            >
              <div className="flex items-center gap-2 mb-4">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <h2 className="text-lg font-semibold text-gray-900">Detected Anomalies</h2>
                <Info className="h-4 w-4 text-gray-400" />
                <span className="text-xs text-gray-500">AI-detected issues with confidence scores</span>
              </div>
              {(!hasRunAnalysis || isAnalyzing) && (
                <div 
                  className="relative rounded-[16px] pointer-events-none z-10 flex items-center justify-center"
                  style={{
                    backgroundColor: 'white',
                    height: '300px'
                  }}
                >
                  {isAnalyzing ? (
                    <div className="text-center">
                      <div className="mb-2" style={{ fontSize: '15px', color: '#e87722', fontStyle: 'italic' }}>
                        <span>Generating insights</span>
                        <span style={{ display: 'inline-flex', gap: '2px', marginLeft: '4px' }}>
                          <span style={{ 
                            width: '4px', 
                            height: '4px', 
                            borderRadius: '50%', 
                            backgroundColor: '#e87722',
                            animation: 'wave 1.5s infinite',
                            animationDelay: '0s'
                          }}></span>
                          <span style={{ 
                            width: '4px', 
                            height: '4px', 
                            borderRadius: '50%', 
                            backgroundColor: '#e87722',
                            animation: 'wave 1.5s infinite',
                            animationDelay: '0.3s'
                          }}></span>
                          <span style={{ 
                            width: '4px', 
                            height: '4px', 
                            borderRadius: '50%', 
                            backgroundColor: '#e87722',
                            animation: 'wave 1.5s infinite',
                            animationDelay: '0.6s'
                          }}></span>
                        </span>
                        <style>{`
                          @keyframes wave {
                            0%, 60%, 100% { 
                              transform: translateY(0px);
                              opacity: 0.4;
                            }
                            30% { 
                              transform: translateY(-8px);
                              opacity: 1;
                            }
                          }
                        `}</style>
                      </div>
                      <div className="text-xs text-gray-500">Analyzing sensor data...</div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="text-gray-500" style={{ fontSize: '15px' }}>
                        Click "Run Analysis" button to view results
                      </div>
                    </div>
                  )}
                </div>
              )}
              {hasRunAnalysis && !isAnalyzing && (
                <div className="space-y-3" style={{ height: '300px', overflowY: 'auto', scrollbarWidth: 'thin', scrollbarColor: '#cbd5e1 #f1f5f9' }}>
                  <div className="border-2 border-red-200 bg-red-50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-red-900">Temperature Anomaly</span>
                      <span className="text-xs font-medium bg-red-200 text-red-800 px-2 py-1 rounded">94% Confidence</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm mb-2">
                      <div>
                        <span className="text-gray-600">Current:</span>
                        <span className="ml-2 font-semibold text-red-600">96°C</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Normal Range:</span>
                        <span className="ml-2">40-75°C</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-700">Exceeded thermal limit during idle operation</p>
                  </div>
                  <div className="border-2 border-red-200 bg-red-50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-red-900">Vibration Anomaly</span>
                      <span className="text-xs font-medium bg-red-200 text-red-800 px-2 py-1 rounded">87% Confidence</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm mb-2">
                      <div>
                        <span className="text-gray-600">Current:</span>
                        <span className="ml-2 font-semibold text-red-600">12.3 mm/s</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Normal Range:</span>
                        <span className="ml-2">2-8 mm/s</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-700">Unbalanced rotation detected - possible bearing wear</p>
                  </div>
                </div>
              )}
            </div>

            {/* Sensor Trend Visualization */}
            <div className="bg-white p-6" style={{ borderRadius: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-5 w-5 text-gray-600" />
                <h2 className="text-lg font-semibold text-gray-900">Sensor Trends</h2>
                <Info className="h-4 w-4 text-gray-400" />
                <span className="text-xs text-gray-500">Temperature and vibration correlation over time</span>
              </div>
              {sensorData.length > 0 && (
                <ReactApexChart
                  options={chartOptions}
                  series={chartSeries}
                  type="line"
                  height={250}
                />
              )}
            </div>
          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-6">
            {/* Machine Information */}
            <div className="bg-white p-4" style={{ borderRadius: '16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', border: 'none' }}>
              <div className="flex items-center gap-2 mb-3">
                <Info className="h-4 w-4 text-gray-600" />
                <h2 className="text-base font-semibold text-gray-900">Machine Info</h2>
              </div>
              <div className="space-y-2.5">
                <div>
                  <span className="text-xs text-gray-500">Machine Type</span>
                  <p className="text-sm font-medium text-gray-900 mt-0.5">CNC Lathe MX450</p>
                </div>
                <div>
                  <span className="text-xs text-gray-500">Last Maintenance</span>
                  <p className="text-sm font-medium text-gray-900 mt-0.5">14 days ago</p>
                </div>
                <div>
                  <span className="text-xs text-gray-500">Operational Mode</span>
                  <p className="text-sm font-medium text-gray-900 mt-0.5">Precision Cutting</p>
                </div>
                <div>
                  <span className="text-xs text-gray-500">Ambient Temperature</span>
                  <p className="text-sm font-medium text-gray-900 mt-0.5">38°C</p>
                </div>
                <div className="pt-2 border-t border-gray-200">
                  <span className="text-xs text-gray-500">Maintenance Notes</span>
                  <p className="text-xs text-gray-700 mt-0.5 italic">Minor bearing noise observed during last inspection</p>
                </div>
              </div>
            </div>

            {/* AI-Powered Diagnostic Analysis */}
            <div 
              className="bg-white p-4 relative" 
              style={{ 
                borderRadius: '16px', 
                boxShadow: '0 2px 8px rgba(0,0,0,0.06), 0 1.5px 4px rgba(0,0,0,0.04)', 
                border: 'none',
                transition: 'all 0.3s ease'
              }}
            >
              <div className="flex items-center gap-2 mb-3">
                <FileText className="h-4 w-4 text-blue-600" />
                <h2 className="text-base font-semibold text-gray-900">AI-Powered Diagnostic Analysis</h2>
              </div>
              {(!hasRunAnalysis || isAnalyzing) && (
                <div 
                  className="relative rounded-[16px] pointer-events-none z-10 flex items-center justify-center"
                  style={{
                    backgroundColor: 'white',
                    minHeight: '280px',
                    height: '280px'
                  }}
                >
                  {isAnalyzing ? (
                    <div className="text-center">
                      <div className="mb-2" style={{ fontSize: '15px', color: '#e87722', fontStyle: 'italic' }}>
                        <span>Generating insights</span>
                        <span style={{ display: 'inline-flex', gap: '2px', marginLeft: '4px' }}>
                          <span style={{ 
                            width: '4px', 
                            height: '4px', 
                            borderRadius: '50%', 
                            backgroundColor: '#e87722',
                            animation: 'wave 1.5s infinite',
                            animationDelay: '0s'
                          }}></span>
                          <span style={{ 
                            width: '4px', 
                            height: '4px', 
                            borderRadius: '50%', 
                            backgroundColor: '#e87722',
                            animation: 'wave 1.5s infinite',
                            animationDelay: '0.3s'
                          }}></span>
                          <span style={{ 
                            width: '4px', 
                            height: '4px', 
                            borderRadius: '50%', 
                            backgroundColor: '#e87722',
                            animation: 'wave 1.5s infinite',
                            animationDelay: '0.6s'
                          }}></span>
                        </span>
                        <style>{`
                          @keyframes wave {
                            0%, 60%, 100% { 
                              transform: translateY(0px);
                              opacity: 0.4;
                            }
                            30% { 
                              transform: translateY(-8px);
                              opacity: 1;
                            }
                          }
                        `}</style>
                      </div>
                      <div className="text-xs text-gray-500">Generating diagnostic analysis...</div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="text-gray-500" style={{ fontSize: '15px' }}>
                        Click "Run Analysis" button to view results
                      </div>
                    </div>
                  )}
                </div>
              )}
              {hasRunAnalysis && !isAnalyzing && (
                <div className="max-h-[280px] overflow-y-auto space-y-2 pr-2" style={{ scrollbarWidth: 'thin', scrollbarColor: '#cbd5e1 #f1f5f9' }}>
                  <div className="bg-blue-50 border-l-4 border-blue-500 p-2 rounded">
                    <h3 className="text-xs font-semibold text-blue-900 mb-0.5">Detected Issue</h3>
                    <p className="text-xs text-blue-800 font-medium">Bearing Wear Likely</p>
                  </div>
                  <div>
                    <h3 className="text-xs font-semibold text-gray-900 mb-0.5">Root Cause</h3>
                    <p className="text-xs text-gray-700 leading-relaxed">
                      Elevated vibration amplitude with simultaneous thermal spike suggests possible bearing degradation. 
                      The correlation between increased vibration and temperature indicates mechanical stress.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-xs font-semibold text-gray-900 mb-0.5">Supporting Evidence</h3>
                    <p className="text-xs text-gray-700 leading-relaxed">
                      Increased power draw (+6%) and maintenance log from 2 weeks ago indicates prior lubrication issue. 
                      Historical data shows similar patterns before previous bearing failures.
                    </p>
                  </div>
                  <div className="bg-orange-50 border-l-4 border-orange-500 p-2 rounded">
                    <h3 className="text-xs font-semibold text-orange-900 mb-0.5">Recommended Action</h3>
                    <p className="text-xs text-orange-800 font-medium">
                      Schedule bearing inspection and lubrication within next 24 hours
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
          </div>
        </div>
      </div>
    </ManufacturingLayout>
  );
};

export default AnomalyDetectionRCA;
