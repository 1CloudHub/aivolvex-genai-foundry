import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
  Button,
  Badge,
  Separator,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/ui/index';
import {
  Mic,
  User,
  Home,
  DollarSign,
  Calendar,
  Building,
  Users,
  FileText,
  Play,
  Pause,
  Square,
  RotateCcw,
} from 'lucide-react';
import { cn } from '../lib/utils';
import './FieldAudio.css';

// Add static audio data for three languages
const audioSamples = [
  {
    id: 'hindi',
    title: 'Field Visit',
    language: 'Hindi',
    badgeColor: 'bg-yellow-100 text-yellow-800',
    url: 'https://union-bank-demo.s3.ap-south-1.amazonaws.com/sandbox-audio/hindi_audio.wav',
    profile: {
      name: 'Raj Kumar Singh',
      familyMembers: 3,
      loanAmount: 600000,
      purpose: 'Home Loan',
      monthlyIncome: 97000,
      monthlyExpenses: 28500,
      existingLoans: [] as { lender: string; amount: number; emi: number }[],
      language: 'Hindi',
      confidence: 90
    },
    transcript: `
[Field Officer]: शुभ अपराह्न सुश्री. राजकुमार। मैं ABC बैंक से। आज मिलने के लिए समय देने के लिए धन्यवाद।
[Customer]: शुभ अपराह्न । कृपया अंदर आइए और बैठिए।
[Field Officer]: धन्यवाद। आपके लोन आवेदन को पूरा करने के लिए मुझे कुछ जानकारी चाहिए। क्या अभी समय ठीक है?
[Customer]: हां बिल्कुल, शुरू कीजिए।
[Field Officer]: सबसे पहले आपके परिवार की जानकारी से शुरू करते हैं। आपके परिवार में कितने सदस्य हैं?
[Customer]: हम तीन लोग हैं — मैं, मेरी पत्नी और मेरी बेटी जो पहली कक्षा में है।
[Field Officer]: ठीक है। लोन का उद्देश्य क्या है — आप इसे किस लिए उपयोग करना चाहते हैं?
[Customer]: हम अवाड़ी में एक छोटा घर खरीदना चाहते हैं। संपत्ति देख ली है, डाउन पेमेंट और निर्माण के कुछ खर्चों के लिए लोन चाहिए।
[Field Officer]: समझ गया। आप कितनी राशि के लिए आवेदन कर रहे हैं?
[Customer]: ₹6,00,000
[Field Officer]: ठीक है। आपकी आय और खर्चों के अनुसार, आप कितनी EMI भर सकते हैं?
[Customer]: मैंने बजट किया है। ₹18,000 से ₹20,000 प्रति माह दे सकता हूँ।
[Field Officer]: अच्छा। क्या आपके पास Five Star से कोई चल रही लोन है?
[Customer]: नहीं, यह मेरी पहली लोन होगी आपकी कंपनी से।
[Field Officer]: किसी और बैंक या NBFC से कोई लोन?
[Customer]: नहीं, मैंने कभी लोन नहीं लिया है।
[Field Officer]: आप कहाँ काम करते हैं?
[Customer]: मैं AWS में सीनियर टेक्नीशियन हूँ, पिछले छह वर्षों से।
[Field Officer]: आपकी मासिक सैलरी कितनी है?
[Customer]: ₹85,000
[Field Officer]: क्या आपकी पत्नी भी काम करती हैं?
[Customer]: हां, पार्ट टाइम। एक प्राइवेट स्कूल में पढ़ाती हैं।
[Field Officer]: उनकी आय कितनी है?
[Customer]: ₹12,000 प्रति माह।
[Field Officer]: तो कुल पारिवारिक मासिक आय ₹97,000 है?
[Customer]: हां।
[Field Officer]: आपके मासिक घरेलू खर्च कितने हैं?
[Customer]: लगभग ₹28,500। इसमें किराया, राशन, स्कूल फीस, यूटिलिटी और ट्रांसपोर्ट शामिल हैं।
[Field Officer]: समझ गया। इस लोन के लिए एक को-एप्लिकेंट या गारंटर चाहिए। क्या आपके पास कोई है?
[Customer]: हां, मेरा छोटा भाई अनिल कुमार सिंह। वह हमारे साथ रहता है और गारंटर बनने को तैयार है।
[Field Officer]: वह कहाँ काम करता है?
[Customer]: रिलायंट लॉजिस्टिक्स में वेयरहाउस सुपरवाइजर है, पाडी के पास।
[Field Officer]: उसकी सैलरी कितनी है?
[Customer]: ₹30,000.
[Field Officer]: क्या उसने सहमति दे दी है?
[Customer]: हां, हम बात कर चुके हैं और वह तैयार है।
[Field Officer]: बहुत अच्छा। क्या आपके पास EB कार्ड और लेटेस्ट हाउस टैक्स रिसीट है?
[Customer]: हां, दोनों मेरे पास हैं। दिखाऊं?
[Field Officer]: हां, कृपया।
[Field Officer]: धन्यवाद श्री राजकुमार। सारी जानकारी नोट कर ली गई है। हम आपका आवेदन प्रोसेस करेंगे और आगे की प्रक्रिया के लिए संपर्क करेंगे। एक टीम सदस्य प्रॉपर्टी वेरिफिकेशन के लिए आ सकता है।
[Customer]: ठीक है सर, धन्यवाद।
[Field Officer]: यह मेरी खुशी है। संपर्क में रहूँगा। आपका दिन शुभ हो।
`,
    summary: `राजकुमार सिंह अवाड़ी में घर खरीदने के लिए ₹6,00,000 का होम लोन चाहते हैं। वे AWS में सीनियर टेक्नीशियन हैं और ₹85,000 कमाते हैं। उनकी पत्नी ₹12,000 कमा रही हैं। कुल घरेलू आय ₹97,000 और खर्च ₹28,500 है। उनके पास कोई मौजूदा लोन नहीं है। उनका भाई अनिल कुमार सिंह ₹30,000 आय के साथ गारंटर बनने को तैयार है। सभी दस्तावेज उपलब्ध हैं। उनका प्रोफाइल होम लोन के लिए उपयुक्त है।`,
    qa: [
      { question: 'क्या एजेंट ने ग्राहक का अभिवादन किया?', answer: 'हाँ, एजेंट ने विनम्रतापूर्वक अभिवादन किया।' },
      { question: 'क्या ग्राहक की आवश्यकता को सही से समझा गया?', answer: 'हाँ, एजेंट ने लोन का उद्देश्य स्पष्ट रूप से समझा।' },
      { question: 'क्या एजेंट ने ग्राहक की बात काटी?', answer: 'नहीं, बातचीत पूरी तरह व्यवस्थित रही।' },
      { question: 'क्या समाधान सही जानकारी के साथ दिया गया?', answer: 'हाँ, प्रक्रिया और अगले कदम स्पष्ट रूप से बताए गए।' },
      { question: 'क्या अनावश्यक रूप से किसी उच्च स्तर पर भेजा गया?', answer: 'नहीं, कोई आवश्यकता नहीं पड़ी।' },
      { question: 'क्या एजेंट ने अगले चरणों के बारे में बताया?', answer: 'हाँ, दस्तावेज़ और वेरिफिकेशन प्रक्रिया समझाई गई।' },
      { question: 'क्या ग्राहक बातचीत से संतुष्ट था?', answer: 'हाँ, ग्राहक ने धन्यवाद दिया और संतोष जताया।' },
      { question: 'क्या एजेंट ने बातचीत को पेशेवर तरीके से समाप्त किया?', answer: 'हाँ, बातचीत को सम्मानपूर्वक समाप्त किया गया।' },
    ]
  },
  {
    id: 'tamil',
    title: 'Field Visit',
    language: 'Tamil',
    badgeColor: 'bg-pink-100 text-pink-800',
    url: 'https://union-bank-demo.s3.ap-south-1.amazonaws.com/sandbox-audio/tamil_sandbox.wav',
    profile: {
      name: 'Raj Kumar Singh',
      familyMembers: 3,
      loanAmount: 600000,
      purpose: 'Home Loan',
      monthlyIncome: 97000,
      monthlyExpenses: 28500,
      existingLoans: [] as { lender: string; amount: number; emi: number }[],
      language: 'Tamil',
      confidence: 90
    },
    transcript: `
[Field Officer]: மதியம் வணக்கம் திருமதி. ராஜ்குமார. நான் ABC வங்கியிலிருந்து பேசுகிறேன். இன்று சந்திக்க நேரம் ஒதுக்கியதற்கு நன்றி.
[Customer]: மதியம் வணக்கம் . உள்ளே வாருங்கள், தயவு செய்து அமருங்கள்.
[Field Officer]: நன்றி. உங்கள் கடன் விண்ணப்பத்தை முடிக்க சில விவரங்கள் தேவை. இது அதிக நேரம் ஆகாது — இப்போது பேசலாமா?
[Customer]: ஆம் சார், சொல்லுங்கள். தொடங்கலாம்.
[Field Officer]: சரி, முதலில் உங்கள் குடும்ப விவரங்களைத் தொடங்கலாம். உங்கள் வீட்டில் எத்தனை பேர் இருக்கின்றனர்?
[Customer]: நாங்கள் மூன்று பேர் — நான், என் மனைவி மற்றும் என் மகள் (அவள் முதல் வகுப்பில் படிக்கிறாள்).
[Field Officer]: சரி. கடன் எதற்காக வேண்டும் — நீங்கள் அதை எதற்காக பயன்படுத்த திட்டமிட்டுள்ளீர்கள்?
[Customer]: அவாடியில் ஒரு சிறிய வீடு வாங்குவதற்காக. ஒரு சொத்தை தேர்ந்தெடுத்துள்ளோம், முன்பணம் செலுத்தவும் கட்டுமான செலவுகளின் ஒரு பகுதியை ஏற்படுத்தவும் கடன் தேவை.
[Field Officer]: புரிந்தது. கடன் தொகை எவ்வளவு வேண்டுமென்று நீங்கள் விண்ணப்பிக்கிறீர்கள்?
[Customer]: ₹6,00,000.
[Field Officer]: சரி. உங்கள் வருமானம் மற்றும் செலவுகளைப் பார்த்தால், மாதத் தவணையாக நீங்கள் எவ்வளவு செலுத்த முடியுமென நினைக்கிறீர்கள்?
[Customer]: நான் கொஞ்சம் கணக்குப் பார்த்தேன். ₹18,000 முதல் ₹20,000 வரை செலுத்த முடியுமென நினைக்கிறேன்.
[Field Officer]: நல்லது. இப்போது, Five Star வங்கியில் ஏற்கனவே ஏதும் கடன் இருக்கிறதா?
[Customer]: இல்லை, இது உங்கள் வங்கியில் என்னுடைய முதல் கடனாகும்.
[Field Officer]: வேறு ஏதாவது வங்கி அல்லது நிதி நிறுவனம் (NBFC) மூலம் ஏதேனும் கடன்கள் உள்ளதா?
[Customer]: இல்லை, இதுவரை எந்தவொரு கடனும் எடுத்ததில்லை.
[Field Officer]: சரி. உங்கள் வேலை பற்றிச் சொல்ல முடியுமா — எங்கு வேலை செய்கிறீர்கள்?
[Customer]: நான் AWS-ல் வேலை செய்கிறேன். கடந்த ஆறு வருடங்களாக மூத்த தொழில்நுட்பராக பணியாற்றி வருகிறேன்.
[Field Officer]: அருமை. உங்கள் மாத சம்பளம் எவ்வளவு?
[Customer]: ₹85,000.
[Field Officer]: உங்கள் மனைவியும் வேலை செய்கிறாரா?
[Customer]: ஆம், பகுதி நேரமாக. எங்கள் பகுதியில் உள்ள தனியார் பள்ளியில் ஆசிரியையாக இருக்கிறார்.
[Field Officer]: அவர் சம்பளம் எவ்வளவு?
[Customer]: மாதம் சுமார் ₹12,000 சம்பாதிக்கிறார்.
[Field Officer]: எனவே, மொத்த குடும்ப வருமானம் மாதம் சுமார் ₹97,000 என்பதா?
[Customer]: ஆமாம், சரிதான்.
[Field Officer]: உங்கள் குடும்ப செலவுகள் மாதம் எவ்வளவு ஆகின்றன?
[Customer]: சுமார் ₹28,500. இதில் வீட்டு வாடகை, மளிகை செலவுகள், குழந்தையின் பள்ளிக் கட்டணம், உபயோகப்படுத்தும் சேவைகள் மற்றும் போக்குவரத்து ஆகியவை அடங்கும்.
[Field Officer]: புரிந்தது. இந்தக் கடனுக்கு, ஒரு இணை விண்ணப்பதாரர் அல்லது உத்தரவாததாரர் தேவைப்படும். உங்களுக்குப் பொருத்தமானவர் யாராவது உள்ளாரா?
[Customer]: ஆம், என் இளைய சகோதரர் அனில் குமார் சிங். நம்முடன் தங்கியிருக்கிறார். உத்தரவாதம் வழங்க தயாராக உள்ளார்.
[Field Officer]: அவர் எங்கு வேலை செய்கிறார்?
[Customer]: Reliant Logistics-இல், பாடி அருகே கிடங்குத் தோழராக (warehouse supervisor) பணியாற்றுகிறார்.
[Field Officer]: அவரது மாத சம்பளம் எவ்வளவு?
[Customer]: ₹30,000.
[Field Officer]: சிறப்பு. அவர் உத்தரவாததாரராக ஒப்புக்கொண்டாரா?
[Customer]: ஆம், நாங்கள் விவாதித்தோம், அவர் ஒப்புக்கொண்டுள்ளார்.
[Field Officer]: அருமை. இப்போது சரிபார்ப்பதற்காக, உங்கள் EB அட்டை மற்றும் சமீபத்திய வீட்டுவரி ரசீது போன்ற அசல் ஆவணங்கள் உள்ளனவா?
[Customer]: ஆம், இரண்டும் என்னிடம் இருக்கின்றன. நீங்கள் பார்க்க விரும்புகிறீர்களா?
[Field Officer]: ஆம் தயவு செய்து.
[Field Officer]: நன்றி திரு. ராஜ்குமார். உங்கள் அனைத்து விவரங்களையும் பதிவு செய்துள்ளேன். உங்கள் விண்ணப்பத்தை செயல்படுத்துகிறோம், அடுத்த நடவடிக்கைகள் தொடங்கும்போது தொடர்பு கொள்வோம். எங்கள் குழுவில் ஒருவர் சொத்து சரிபார்ப்பு நோக்கமாக வரலாம்.
[Customer]: சரி சார், வந்ததற்கும் உதவியதற்கும் நன்றி.
[Field Officer]: இது எனது மகிழ்ச்சி. மீண்டும் தொடர்பு கொள்கிறேன். நல்ல நாளாகட்டும்!
`,
    summary: `ராஜ்குமார் சிங் அவர்கள் அவாடியில் வீடு வாங்க ₹6,00,000 கடனுக்காக விண்ணப்பிக்கிறார். குடும்ப வருமானம் ₹97,000 மற்றும் செலவு ₹28,500. இவர் AWS-ல் மூத்த தொழில்நுட்பராக பணியாற்றுகிறார்; மனைவியும் பகுதி நேர வேலை செய்கிறார். எந்தவொரு பழைய கடனும் இல்லை. தம்பி அனில் குமார் சிங் ₹30,000 சம்பளத்துடன் உத்தரவாததாரராக ஒப்புக்கொண்டுள்ளார். ஆவணங்கள் தயாராக உள்ளன. அவரது சுயவிவரம் வீட்டு கடனுக்கு தகுந்தது.`,
    qa: [
      { question: 'வழங்குபவர் வாடிக்கையாளரை மரியாதையுடன் வாழ்த்தினாரா?', answer: 'ஆம், மரியாதையுடன் "காலை வணக்கம்" தெரிவித்தார்.' },
      { question: 'வாடிக்கையாளர் தேவைகள் தெளிவாக புரிந்துகொள்ளப்பட்டதா?', answer: 'ஆம், வீட்டு கடனுக்கான நோக்கம் தெளிவாகப் புரிந்துகொள்ளப்பட்டது.' },
      { question: 'வழங்குபவர் வாடிக்கையாளரை இடையூறு செய்தாரா?', answer: 'இல்லை, முழுமையாக பதிலளிக்கச் சமயம் அளித்தார்.' },
      { question: 'தரப்பட்ட தீர்வு சரியானதா?', answer: 'ஆம், கடன் செயல்முறை மற்றும் அடுத்த கட்ட நடவடிக்கைகள் தெளிவாகக் கூறப்பட்டன.' },
      { question: 'தேவையில்லாமல் அதிகரிப்பு (escalation) செய்தாரா?', answer: 'இல்லை, தேவையற்ற எதுவும் ஏற்படவில்லை.' },
      { question: 'அடுத்த நடவடிக்கைகள் கூறப்பட்டதா?', answer: 'ஆம், ஆவணச் சரிபார்ப்பு மற்றும் சொத்து பரிசோதனை பற்றிக் கூறினார்.' },
      { question: 'வாடிக்கையாளர் உரையின் இறுதியில் திருப்தியாக இருந்தாரா?', answer: 'ஆம், நன்றி தெரிவித்தார் மற்றும் திருப்தியுடன் இருந்தார்.' },
      { question: 'வழங்குபவர் உரையை தொழில்முறை முறையில் முடித்தாரா?', answer: 'ஆம், நன்றியுடன் மரியாதையாக உரையை முடித்தார்.' },
    ]
  },
  {
    id: 'english',
    title: 'Field Visit',
    language: 'English',
    badgeColor: 'bg-blue-100 text-blue-800',
    url: 'https://union-bank-demo.s3.ap-south-1.amazonaws.com/sandbox-audio/english_audio.wav',
    profile: {
      name: 'Raj Kumar Singh',
      familyMembers: 3,
      loanAmount: 600000,
      purpose: 'Home Loan',
      monthlyIncome: 97000,
      monthlyExpenses: 28500,
      existingLoans: [] as { lender: string; amount: number; emi: number }[],
      language: 'English',
      confidence: 90
    },
    transcript: `
[Field Officer]:Good afternoon, Mr. Raj Kumar. I'm from ABC Bank. Thanks for taking the time to meet today.
[Customer]:Good afternoon. Please come in and have a seat.
[Field Officer]:Thank you. I'll just need a few details to complete your loan application. This won't take long — is now a good time?
[Customer]:Yes, sure. Let's go ahead.
[Field Officer]:Alright, let's start with your family details. How many people are there in your household?
[Customer]:We are three — me, my wife, and our daughter who's in Class 1.
[Field Officer]:Okay. And the purpose of the loan — what are you planning to use it for?
[Customer]:It's for purchasing a small house in Avadi. We've identified a property and would like to make the down payment and cover part of the construction costs.
[Field Officer]:Got it. And how much loan amount are you applying for?
[Customer]:₹6,00,000.
[Field Officer]:Noted. Based on your income and expenses, how much would you be comfortable paying monthly as EMI?
[Customer]:I've done a bit of budgeting. I can manage between ₹18,000 and ₹20,000 per month.
[Field Officer]:Alright, good. Now, do you have any ongoing loans with Five Star?
[Customer]:No, this will be my first loan with your company.
[Field Officer]:Any loans from any other bank or NBFC?
[Customer]:No, I've never taken a loan before.
[Field Officer]:Okay. Can you tell me about your employment — where do you work?
[Customer]:I'm working in AWS. I've been there for six years now as a Senior Technician.
[Field Officer]:Great. And your monthly salary?
[Customer]:It's ₹85,000.
[Field Officer]:Is your wife working as well?
[Customer]:Yes, part-time. She teaches at a private school here in our locality.
[Field Officer]:And her income?
[Customer]:She earns about ₹12,000 a month.
[Field Officer]:So total monthly household income is around ₹97,000?
[Customer]:That's right.
[Field Officer]:And what would you say your monthly household expenses are?
[Customer]:Approximately ₹28,500. That includes rent, groceries, child's school fees, utilities, and transport.
[Field Officer]:Understood. For this loan, we require either a co-applicant or a guarantor. Do you have someone who could support you?
[Customer]:Yes, my younger brother, Anil Kumar Singh. He lives with us and is willing to sign as a guarantor.
[Field Officer]:Where does he work?
[Customer]:He works as a warehouse supervisor at Reliant Logistics, near Padi.
[Field Officer]:And what is his monthly salary?
[Customer]:₹30,000.
[Field Officer]:Perfect. Has he confirmed he's willing to be a guarantor?
[Customer]:Yes, we've discussed it and he's ready to sign.
[Field Officer]:Excellent. Now just to check, do you have original documents like your EB card and latest house tax receipt?
[Customer]:Yes, I have both here. Would you like to see them?
[Field Officer]:Yes, please. 
[Field Officer]:Thank you, Mr. Raj Kumar. I've captured all the details. We'll process your application and get back to you once we initiate the next steps. Someone from our team may come for property verification too.
[Customer]:Alright, sir. Thank you for coming and helping me through this.
[Field Officer]:It's my pleasure. I'll be in touch. Have a great day
`,
    summary: `Raj Kumar is applying for a ₹6,00,000 home loan to purchase and construct a house in Avadi. He lives with his wife and daughter. His monthly salary is ₹85,000, and his wife contributes ₹12,000, totaling a household income of ₹97,000. Their monthly expenses are ₹28,500. He has no prior loans and is currently employed as a Senior Technician at AWS. His brother, Anil Kumar Singh, earning ₹30,000 per month, will be the guarantor. He has all necessary documents ready, and the profile is considered suitable for a housing loan with strong repayment capacity.`,
    qa: [
      { question: 'Did the agent greet the customer?', answer: 'Yes, the agent greeted the customer professionally.' },
      { question: 'Was the customer issue clearly understood?', answer: 'Yes, the agent clearly understood the loan purpose and requirements.' },
      { question: 'Did the agent interrupt the customer?', answer: 'No interruptions; the agent allowed full responses.' },
      { question: 'Was the resolution provided accurate?', answer: 'Yes, the loan application process and next steps were clearly explained.' },
      { question: 'Did the agent escalate unnecessarily?', answer: 'No escalation occurred.' },
      { question: 'Did the agent provide next steps?', answer: 'Yes, explained document collection and property verification process.' },
      { question: 'Was the customer satisfied by the end of the call?', answer: 'Yes, the customer expressed gratitude and comfort.' },
      { question: 'Did the agent close the call professionally?', answer: 'Yes, the agent closed the meeting on a polite and professional note.' },
    ]
  }
];

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
};

const getAnswerBadgeColor = (answer: string) => {
  const lowerAnswer = answer.toLowerCase();
  if (lowerAnswer.includes('good') || lowerAnswer.includes('politely') || lowerAnswer.includes('clearly') || lowerAnswer.includes('correct')) {
    return 'bg-green-50 text-green-800 border-green-200';
  }
  if (lowerAnswer.includes('bad') || lowerAnswer.includes('rude') || lowerAnswer.includes('incorrect')) {
    return 'bg-red-50 text-red-800 border-red-200';
  }
  return 'bg-blue-50 text-blue-800 border-blue-200';
};

const FieldAudio = () => {
  // No audio selected by default
  const [selectedAudio, setSelectedAudio] = useState<null | typeof audioSamples[0]>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState<'transcript' | 'summary' | 'qa' | string>('');
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [hasPlayed, setHasPlayed] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const navigate = useNavigate();
  const [isSendingCrm, setIsSendingCrm] = useState(false);
  const [showCrmNotification, setShowCrmNotification] = useState(false);

  // Format time as mm:ss
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Handle audio time updates
  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };
  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  // When audio ends
  const handleAudioEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const handleSendToCrm = () => {
    setIsSendingCrm(true);
    setTimeout(() => {
      setIsSendingCrm(false);
      setShowCrmNotification(true);
      setTimeout(() => setShowCrmNotification(false), 3000);
    }, 2000 + Math.random() * 1000); // 2-3 seconds
  };

  return (
    <div className="container py-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 mb-6">
        <button type="button" onClick={() => navigate('/')} className="flex items-center font-semibold " style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}>
          <Home className="h-5 w-5  mr-1" />
          <span className="text-gray-600">Home</span>
        </button>
        <span className="text-gray-400">/</span>
        <span style={{ fontWeight: 600, color:'#e87722' }}>VoiceIQ</span>
      </div>
      {/* Page Title and Subtitle */}
      <div className="flex items-center gap-6 mb-8">
        <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
          <Mic className="h-8 w-8 text-primary" />
        </div>
        <div>
          <h1 className="text-4xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
            VoiceIQ
          </h1>
          <p className="text-lg text-gray-600">
            Analyze field officer recordings to auto-generate customer profiles and insights.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Audio Samples Panel */}
        <div className="lg:col-span-3 flex flex-col gap-3">
          {/* Smaller Audio Samples Card */}
          <Card className="w-full" style={{ maxWidth: 370, margin: '0 auto', padding: 0,height: '25rem' }}>
            <CardHeader className="pb-2 pt-5 px-6 mb-4">
              <CardTitle className="text-2xl font-bold mb-0">Audio Samples</CardTitle>
              <CardDescription className="text-base text-gray-500">Select and play a field visit recording</CardDescription>
            </CardHeader>
            <CardContent className="pt-2 pb-4 px-4">
              <div className="space-y-4">
                {audioSamples.map((sample) => (
                  <div
                    key={sample.id}
                    className={cn(
                      'flex items-center gap-3 p-3 rounded-lg border-2 transition-all cursor-pointer min-h-[48px]',
                      selectedAudio?.id === sample.id ? 'border-[#e87722] bg-[#fff7f0] shadow' : 'border-gray-200 bg-white hover:border-[#e87722]/60'
                    )}
                    onClick={() => {
                      setSelectedAudio(sample);
                      setIsPlaying(false);
                      setCurrentTime(0);
                      setDuration(0);
                      setHasPlayed(true);
                      setActiveTab('transcript');
                      if (audioRef.current) {
                        audioRef.current.pause();
                        audioRef.current.currentTime = 0;
                      }
                    }}
                  >
                    <div className={cn('px-2 py-0.5 rounded-full text-xs font-semibold', sample.badgeColor)}>
                      {sample.language}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-base">{sample.title}</div>
                    </div>
                  </div>
                ))}
                {/* Audio element (hidden) */}
                <audio
                  ref={audioRef}
                  src={selectedAudio?.url || ''}
                  onEnded={handleAudioEnded}
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  style={{ display: 'none' }}
                />
              </div>
            </CardContent>
          </Card>
          {/* Play Controls Card - always visible, disabled if no audio selected */}
          <Card className="w-full" style={{ maxWidth: 370, margin: '0 auto', padding: 0 }}>
            <CardContent className="flex flex-col items-center justify-center py-5">
              <div className="flex flex-col items-center gap-2 w-full">
                <div className="flex items-center gap-4 justify-center">
                  {/* Stop Button (left) */}
                  <button
                    className={cn(
                      'audio-play-btn flex items-center justify-center rounded-full shadow-lg transition-all',
                      selectedAudio ? 'bg-[#e87722] hover:bg-[#ff9a4d] text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    )}
                    style={{ width: 48, height: 48, fontSize: 22, outline: 'none', border: 'none', position: 'relative' }}
                    disabled={!selectedAudio}
                    onClick={() => {
                      if (!selectedAudio) return;
                      if (audioRef.current) {
                        audioRef.current.pause();
                        audioRef.current.currentTime = 0;
                        setIsPlaying(false);
                        setCurrentTime(0);
                      }
                    }}
                  >
                    <span className="sr-only">Stop</span>
                    <Square className="h-7 w-7" />
                  </button>
                  {/* Play/Pause Button (center) */}
                  <button
                    className={cn(
                      'audio-play-btn flex items-center justify-center rounded-full shadow-lg transition-all',
                      isPlaying ? 'audio-play-btn-animate' : '',
                      selectedAudio ? 'bg-[#e87722] hover:bg-[#ff9a4d] text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    )}
                    style={{ width: 64, height: 64, fontSize: 28, outline: 'none', border: 'none', position: 'relative' }}
                    disabled={!selectedAudio}
                    onClick={() => {
                      if (!selectedAudio) return;
                      if (audioRef.current) {
                        if (isPlaying) {
                          audioRef.current.pause();
                        } else {
                          audioRef.current.play();
                          setActiveTab('transcript');
                          setHasPlayed(true);
                        }
                      }
                      setIsPlaying(!isPlaying);
                    }}
                  >
                    <span className="sr-only">{isPlaying ? 'Pause' : 'Play'}</span>
                    {isPlaying ? (
                      <Pause className="h-8 w-8" />
                    ) : (
                      <Play className="h-8 w-8" />
                    )}
                    {/* Animated ring */}
                    {isPlaying && <span className="audio-play-btn-ring" />}
                  </button>
                  {/* Reload/Restart Button (right) */}
                  <button
                    className={cn(
                      'audio-play-btn flex items-center justify-center rounded-full shadow-lg transition-all',
                      selectedAudio ? 'bg-[#e87722] hover:bg-[#ff9a4d] text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    )}
                    style={{ width: 48, height: 48, fontSize: 22, outline: 'none', border: 'none', position: 'relative' }}
                    disabled={!selectedAudio}
                    onClick={() => {
                      if (!selectedAudio) return;
                      if (audioRef.current) {
                        audioRef.current.currentTime = 0;
                        audioRef.current.play();
                        setIsPlaying(true);
                        setActiveTab('transcript');
                        setHasPlayed(true);
                      }
                    }}
                  >
                    <span className="sr-only">Restart</span>
                    <RotateCcw className="h-7 w-7" />
                  </button>
                </div>
                <div className="text-sm font-mono text-gray-700 min-w-[70px] text-center mt-2">
                  {selectedAudio ? `${formatTime(currentTime)} / ${formatTime(duration)}` : '--:-- / --:--'}
                </div>
                {/* <div className="text-xs text-gray-500 text-center min-h-[18px]">
                  {selectedAudio ? selectedAudio.language : 'Select an audio sample'}
                </div> */}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Transcription Panel */}
        <div className="lg:col-span-5">
          <Card className="h-full" style={{ height: '34.5rem' }}>
            <CardHeader className={selectedAudio && hasPlayed ? "border-b" : ""}>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Audio Analysis</CardTitle>
                  <CardDescription>
                    Transcription and extracted information
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {selectedAudio && hasPlayed ? (
                <Tabs
                  value={activeTab}
                  onValueChange={setActiveTab}
                  className="h-full"
                >
                  <TabsList className="w-full justify-start rounded-none border-b">
                    <TabsTrigger value="transcript">Transcript</TabsTrigger>
                    <TabsTrigger value="summary">Summary</TabsTrigger>
                    <TabsTrigger value="qa">Q&A</TabsTrigger>
                  </TabsList>
                  <div className="p-4 overflow-y-auto" style={{ maxHeight: '22rem' }}>
                    <TabsContent value="transcript" className="m-0">
                      <div className="font-mono text-sm whitespace-pre-wrap space-y-2">
                        {selectedAudio.transcript
                          .split('\n')
                          .filter(line => line.trim())
                          .map((line, idx) => (
                            <div key={idx}>{line}</div>
                          ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="summary" className="m-0">
                      <div className="space-y-4">
                        <p className="text-sm">
                          {selectedAudio.summary}
                        </p>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-green-50 text-green-800">
                            {selectedAudio.profile.purpose}
                          </Badge>
                          <Badge variant="outline" className="bg-green-50 text-green-800">
                            {selectedAudio.language}
                          </Badge>
                        </div>
                      </div>
                    </TabsContent>
                    <TabsContent value="qa" className="m-0">
                      <div className="space-y-4">
                        <div className="space-y-3">
                          {selectedAudio.qa.map((qa, index) => (
                            <div key={index} className="p-4 border rounded-lg bg-gray-50/50">
                              <div className="flex items-start gap-3">
                                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mt-0.5">
                                  <span className="text-xs font-medium text-primary">
                                    {index + 1}
                                  </span>
                                </div>
                                <div className="flex-1 space-y-2">
                                  <p className="text-sm font-medium text-gray-900">
                                    {qa.question}
                                  </p>
                                  <div className="flex items-center gap-2">
                                    <Badge 
                                      variant="outline" 
                                      className={`text-xs ${getAnswerBadgeColor(qa.answer)}`}
                                    >
                                      {qa.answer}
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </TabsContent>
                  </div>
                </Tabs>
              ) : (
                <div className="text-center py-12" style={{ marginTop: '6.5rem' }}>
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Press play to view analysis and profile</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Profile Builder Panel */}
        <div className="lg:col-span-4">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Customer Profile</CardTitle>
              <CardDescription>
                Auto-generated from voice analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              {selectedAudio && hasPlayed ? (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium">{selectedAudio.profile.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          Family Size: {selectedAudio.profile.familyMembers}
                        </p>
                      </div>
                    </div>
                    <Separator />
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Loan Request</span>
                        </div>
                        <span className="text-sm font-medium">
                          {formatCurrency(selectedAudio.profile.loanAmount)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <Building className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Purpose</span>
                        </div>
                        <span className="text-sm font-medium">
                          {selectedAudio.profile.purpose}
                        </span>
                      </div>  
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Monthly Income</span>
                        </div>
                        <span className="text-sm font-medium">
                          {formatCurrency(selectedAudio.profile.monthlyIncome)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <Home className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Monthly Expenses</span>
                        </div>
                        <span className="text-sm font-medium">
                          {formatCurrency(selectedAudio.profile.monthlyExpenses)}
                        </span>
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <h4 className="text-sm font-medium mb-3">Existing Obligations</h4>
                      {selectedAudio.profile.existingLoans.length > 0 ? (
                        selectedAudio.profile.existingLoans.map((loan, index) => (
                          <div
                            key={index}
                            className="p-3 bg-muted rounded-lg mb-2"
                          >
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">{loan.lender}</span>
                              <span className="text-sm font-medium">
                                {formatCurrency(loan.amount)}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-xs text-muted-foreground">
                                Monthly EMI
                              </span>
                              <span className="text-xs font-medium">
                                {formatCurrency(loan.emi)}
                              </span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
                          <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                          <span className="text-xs text-blue-700 font-medium">No existing loans or obligations</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12" style={{ marginTop: '6.5rem' }}>
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Press play to view analysis and profile</p>
                </div>
              )}
            </CardContent>
            <CardFooter className={selectedAudio && hasPlayed ? "border-t p-4" : "p-4"}>
              <div className="w-full space-y-3">
                <div className="flex justify-between" style={{ marginTop: '1.5rem' }}>
                  {selectedAudio && hasPlayed && (
                    <>
                      <Button
                        className="d-flex align-items-center gap-2 px-4 py-2 rounded-pill fw-bold border-0 text-white"
                        style={{ background: '#e87722' }}
                        onClick={handleSendToCrm}
                        disabled={isSendingCrm}
                      >
                        {isSendingCrm ? (
                          <>
                            <svg className="animate-spin mr-2" width="18" height="18" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="white" strokeWidth="4" />
                              <path className="opacity-75" fill="#fff" d="M4 12a8 8 0 018-8v8z" />
                            </svg>
                            Sending...
                          </>
                        ) : (
                          <>
                            <svg width="18" height="18" fill="white" viewBox="0 0 24 24" className="me-1"><path d="M2 21l21-9-21-9v7l15 2-15 2z"/></svg>
                            Send to CRM
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={() => navigate('/documents')}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Proceed to DocIQ
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
      {showCrmNotification && (
        <div
          className="fixed top-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 px-7 py-5 rounded-3xl bg-white border shadow-lg animate-fade-in-out"
          style={{ borderColor: '#e87722', boxShadow: '0 8px 32px 0 #e8772222', animation: 'fade-in-out 3s', minWidth: 420, maxWidth: '90vw' }}
        >
          <svg width="36" height="36" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#fff7f0" stroke="#e87722" strokeWidth="2"/><path d="M9.5 12.5l2 2 4-4" stroke="#e87722" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          <div>
            <div className="fw-bold" style={{ color: '#e87722', fontSize: '1.18rem', letterSpacing: 0.2 }}>All details sent to CRM successfully!</div>
            <div style={{ color: '#4B5563', fontWeight: 500, fontSize: '1rem', marginTop: 2 }}>Your application data has been securely pushed to the CRM system.</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FieldAudio;
        
