import React, { useState } from 'react';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import {
    Mic ,
    Edit3 ,
    BarChart2 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    Shield,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../../components/layout/LoginNavbar';
import Footer from '../../components/Mainbox/Footer';

const GenAISandboxHome = () => {
    const { Title, Text } = Typography;
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');

const solutions = [

//   {
//     title: "BankAssist Suite",
//     area: "Banking",
//     icon: <Edit3 size={24} />,
//     description: "Extension of AI-powered tools showcasing GenAI use cases for banking operations.",
//     buttonText: "Get Assistance",
//     tags: ["Bank Assistance"],
//     redirect:"/customer/sandbox/bankhome",
//     type: "component",
//     tooltip: {
//       icon: "🏦",
//       heading: "BankAssist Suite",
//       subheading: "GenAI Toolkit for Banking Operations",
//       points: [
//        "Answer customer queries via conversational assistant",
// "Analyze call center audio for insights and compliance",
// "Compare documents for faster review and risk checks"     
//       ]
//     }
//   },

//   {
//     title: "Microfinance Suite",
//     area: "Microfinance",
//     icon: <Sparkles size={24} />,
//     description: "AI-powered tools for microfinance institutions to streamline loan processing, risk assessment, and customer engagement.",
//     buttonText: "Explore Microfinance",
//     tags: ["Microfinance"],
//     redirect: "microfinance",
//     type: "component",
//     tooltip: {
//       icon: "💰",
//       heading: "Microfinance Suite",
//       subheading: "AI for Microfinance Operations",
//       points: [
//         "Automate loan application and approval workflows",
//         "Assess borrower risk using AI-driven analytics",
//         "Enhance customer outreach and engagement"
//       ]
//     }
//   },
//     {
//         title: "VideoInsight Studio",
//         area: "Media",
//         icon: <Mic size={24} />,
//         description: "Upload videos to receive chapter summaries, transcripts, and highlight reels.",
//         buttonText: "Analyze Media",
//         tags: ["Media AI"],
//         redirect: "media",
//         type: "component",
//         tooltip: {
//           icon: "🎥",
//           heading: "VideoInsight Studio",
//           subheading: "Automated Media Analysis & Summarization",
//           points: [
//            "Upload videos to get chapter summaries and transcripts",
//     "Generate short highlight reels for faster content review",
//     "Ideal for training, compliance, or media production workflows"
//           ]
//         }
//       },
//     {
//     title: "PolicyPal Assistant",
//     area: "Insurance",
//     icon: <MessageSquare size={24} />,
//     description: "Conversational assistant for insurance agents to query policy documents via RAG.",
//     buttonText: "Start Conversation",
//     tags: ["Multilingual", "AI + NLP"],
//     redirect: "insurance",
//     type: "component",
//     tooltip: {
// icon: "📦",
//       heading: "PolicyPal Assistant",
//       subheading: "Conversational AI for Insurance",
//       points: [
//         "Assist insurance agents in real-time",
//         "Retrieve policy details instantly",
//         "Supports multilingual queries"
//       ]
//     }
//   },
//   {
//     title: "FreightLens",
//     area: "Logistics",
//     icon: <FileSearch size={24} />,
//     description: "Intelligent Document Processing for extracting structured data from logistics documents",
//     buttonText: "Process Documents",
//     tags: ["OCR + NLP"],
//     redirect: "logistics",
//     type: "component",
//     tooltip: {
//       icon: "📄",
//       heading: "FreightLens",
//       subheading: "Intelligent Extraction for Logistics Docs",
//       points: [
//       "Auto-extract key fields from Bills of Lading, Invoices, Packing Lists, and Airway Bills",
// "Reduce manual effort in freight document processing",
// "Speed up shipment validation and customs workflows"
//       ]
//     }
//   },
//   {
//     title: "Product Vision Search",
//     area: "Retail",
//     icon: <BarChart2 size={24} />,
//     description: "Visual search capability to upload product images and receive relevant matches from the catalog.",
//     buttonText: "Search Products",
//     tags: ["ML + Analytics"],
//     redirect: "retailproducts",
//     type: "component",
//     tooltip: {
//       icon: "🛍️",
//       heading: "Product Vision Search",
//       subheading: "AI-Powered Visual Product Discovery",
//       points: [
//         "Instantly match uploaded product images with catalog items",
// "Enhance customer experience with visual similarity search",
// "Improve product discoverability in e-commerce platforms"
//       ]
//     }
//   },
  {
    title: "Insurance",
    area: "Insurance",
    icon: <Shield size={24} />, // Using Shield icon for insurance
    description: "Explore AI-powered insurance tools for claims, policy management, and customer support.",
    buttonText: "Explore Insurance",
    tags: ["Insurance AI"],
    redirect: "/customer/sandbox/insurancehome",
    type: "component",
    tooltip: {
      icon: "🛡️",
      heading: "Insurance Suite",
      subheading: "AI for Insurance Operations",
      points: [
        "Automate claims processing and policy management",
        "Enhance customer support with AI chatbots",
        "Analyze risk and detect fraud using AI analytics"
      ]
    }
  },
  {
    title: "Banking",
    area: "Banking",
    icon: <BarChart2 size={24} />, // Using BarChart2 icon for banking
    description: "Comprehensive banking solutions with AI-powered analytics, risk assessment, and customer insights.",
    buttonText: "Explore Banking",
    tags: ["Banking AI"],
    redirect: "/customer/sandbox/bankinghome",
    type: "component",
    tooltip: {
      icon: "🏦",
      heading: "Banking Suite",
      subheading: "AI-Powered Banking Solutions",
      points: [
        "Advanced analytics for financial data insights",
        "Risk assessment and fraud detection systems",
        "Customer behavior analysis and personalized services"
      ]
    }
  },
//   {
//     title: "Retail",
//     area: "Retail",
//     icon: <BarChart2 size={24} />, // You can change to a shopping icon if available
//     description: "Discover AI-driven retail tools for product search, customer engagement, and inventory insights.",
//     buttonText: "Explore Retail",
//     tags: ["Retail AI"],
//     redirect: "/customer/sandbox/retailhome",
//     type: "component",
//     tooltip: {
//       icon: "🛍️",
//       heading: "Retail Suite",
//       subheading: "AI for Retail Operations",
//       points: [
//         "Visual product search and recommendations",
//         "Customer engagement with AI chatbots",
//         "Inventory and sales analytics"
//       ]
//     }
//   },
];

    // const handleSolutionClick = (solution) => {
    //     if (solution.type === 'external') {
    //         window.open(solution.redirect, '_blank');
    //     } else if (solution.type === 'component') {
    //         navigate(`/industryusecases/${solution.redirect}`);
    //     } else {
    //         navigate(`/industryusecases/${solution.redirect}`);
    //     }
    // };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {/* Login Navbar */}
            <LoginNavbar />
            {/* Spacing below navbar */}
            <div className="flex-grow px-15 mx-auto py-12">
                {/* Header Section - Matching the image */}
                <div className="text-center">
                    <div className="flex flex-col items-center justify-center mt-8 mb-2">
                        <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                            <span style={{ color: '#e87722' }}>GenAI</span>
                            <span style={{ color: '#181f5a' }}> Sandbox</span>
                        </h1>
                    </div>
                    <div className="mb-8">
                        <span className="text-lg text-gray-700">
                            Explore AI-powered tools designed to transform business unit operations across industries.
                        </span>
                    </div>
                </div>

                {/* Solution Cards Section - Styled to match the image with reduced height and increased width appearance */}
                <Row
                        gutter={[16, 16]}
                        justify="center"
                        className="p-4"
                        style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                    >
                        {solutions.map((solution, index) => (
                      
                            <Col key={index} xs={24} sm={12} md={8} lg={7} xl={6}>
    <Card
        className="relative w-full h-[340px] border-2 border-transparent rounded-lg shadow-md
            hover:shadow-lg transition-all duration-300 ease-in-out
            hover:!border-[#e87822] flex flex-col"
        bodyStyle={{ 
            height: "100%",
            display: 'flex', 
            flexDirection: 'column',
            overflow: 'hidden',
        }}
    >
        <div className="absolute -top-2 -left-4 bg-[#e87722] text-white text-xs font-bold px-3 py-1 rounded-full shadow-md z-10">
            {solution.area}
        </div>

        <div className="absolute top-2 right-2 z-10">
            
    
<Tooltip
  placement="topRight"
  color="white" 
  overlayInnerStyle={{
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    borderRadius: '10px',
    padding: '0', 
    maxWidth: '250px',
  }}
  title={
    <div className="p-[1px]">
  
      <div className="flex bg-[#f9fafb] rounded-md border-l-[4px] border-[#e87722] p-4">
        <div className="flex flex-col">
          <div className="font-bold text-[#181f5a] text-sm mb-1">
            {solution.tooltip.icon} {solution.tooltip.heading}
          </div>
          <div className="text-black text-xs font-semibold mb-2">
            {solution.tooltip.subheading}
          </div>
          <ul className="list-disc pl-5 space-y-1 text-xs text-gray-700">
            {solution.tooltip.points.map((point, idx) => (
              <li key={idx}>{point}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  }
>
  <Info className="text-[#e87722] hover:cursor-pointer" size={16} />
</Tooltip>


        </div>

        <div className="flex flex-col h-full mt-3">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-[#e8782222] mb-3">
                {React.cloneElement(solution.icon, {
                    size: 24,
                    className: "text-[#e87722]",
                })}
            </div>

            <div className="mb-2 min-h-[24px] flex gap-2 flex-wrap">
                {solution.tags?.map((tag, index) => (
                    <span key={index} className="inline-block bg-[#e8782222] text-[#e87722] text-xs font-medium px-2.5 py-0.5 rounded-md">
                        {tag}
                    </span>
                ))}
            </div>

            {/* Title */}
            <Title level={5} className="!text-xl !font-bold !mb-2 !text-gray-900" style={{ height: '48px' }}>
                {solution.title}
            </Title>

            {/* Description */}
            <div className="flex-grow mb-4 mt-1 min-h-[72px] overflow-hidden">
                <Text className="text-gray-600 !text-xs leading-relaxed h-full">
                    {solution.description}
                </Text>
            </div>

            {/* Button */}
            {solution.type === 'external' ? (
                <a
                    href={solution.redirect}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </a>
            ) : solution.title === "PolicyPal Assistant" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/insurance')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "FreightLens" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/logistics')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Product Vision Search" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/retailproducts')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "VideoInsight Studio" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/media')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "BankAssist Suite" ? (
                <button
                    onClick={() => navigate(solution.redirect)}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Microfinance Suite" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/microfinance')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Insurance" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/insurancehome')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Banking" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/bankinghome')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Retail" ? (
                <button
                    onClick={() => navigate('retailhome')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </button>
            ) : (
                <Link
                    to={`/industryusecases/${solution.redirect}`}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '36px' }}
                >
                    {solution.buttonText}
                </Link>
            )}
        </div>
    </Card>
</Col>
))}
                    </Row>
                </div>
                <Footer />
            </div>

    );
};

export default GenAISandboxHome;