// Mock data for the GenAI Banking Sandbox

// Conversation Assistant - Message Types
export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

// Document Processing - Document Types
export interface DocumentField {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'error';
  message?: string;
}

export interface Document {
  id: string;
  name: string;
  type: 'aadhaar' | 'pan' | 'bank_statement';
  status: 'processing' | 'completed' | 'failed';
  confidence: number;
  fields: DocumentField[];
  uploadTime: Date;
}

// Risk Assessment - Profile Data
export interface RiskFactor {
  name: string;
  severity: 'low' | 'medium' | 'high';
  description: string;
}

export interface RiskProfile {
  id: string;
  applicantName: string;
  age: number;
  occupation: string;
  employer: string;
  incomeMonthly: number;
  creditScore: number;
  existingObligations: number;
  loanAmount: number;
  loanTenure: number;
  interestRate: number;
  loanType: string;
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high';
  riskFactors: RiskFactor[];
  recommendations: string[];
}

// Document Generator - Form Data
export interface DocumentForm {
  applicantName: string;
  applicantAddress: string;
  loanType: string;
  loanAmount: number;
  interestRate: number;
  tenure: number;
  emi: number;
  sanctionDate: string;
  validityDate: string;
}

// Helper functions for the mock data
export const calculateEMI = (principal: number, rate: number, tenure: number) => {
  // Convert interest rate from annual to monthly percentage
  const monthlyRate = rate / 12 / 100;
  // Convert tenure from years to months
  const tenureMonths = tenure * 12;
  
  // EMI formula: P * r * (1+r)^n / ((1+r)^n - 1)
  const emi = principal * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths) / 
              (Math.pow(1 + monthlyRate, tenureMonths) - 1);
  
  return Math.round(emi);
};

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
};