import React from 'react';
import ReactDOM from 'react-dom';
import { X, User, Building, Mail, Phone, Calendar, Users, Briefcase, BarChart2, CheckCircle, XCircle, CreditCard } from 'lucide-react';
import type { Customer } from '../../CustomerTypes';
import { useAuth } from '../../context/AuthContext';

interface CustomerDetailsModalProps {
    customer: Customer;
    onClose: () => void;
}

const DetailItem = ({ icon: Icon, label, value }: { icon: React.ElementType, label: string, value: React.ReactNode }) => (
    <div className="flex items-start space-x-3">
        <Icon className="h-5 w-5 text-orange-500 mt-1 flex-shrink-0" />
        <div>
            <p className="text-sm font-medium text-gray-500">{label}</p>
            <p className="text-base text-gray-900">{value}</p>
        </div>
    </div>
);

export default function CustomerDetailsModal({ customer, onClose }: CustomerDetailsModalProps) {
    if (!customer) return null;
    const { user } = useAuth();

    const modalContent = (
        <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-white/80 animate-fade-in"
            onClick={onClose}
        >
            <div
                className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto transform transition-transform duration-300 scale-95 hover:scale-100 p-4"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
                    <h2 className="text-xl font-bold text-gray-900">Customer Details</h2>
                    <button
                        onClick={onClose}
                        className="p-1 rounded-full text-gray-400 hover:bg-gray-200 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-orange-500"
                    >
                        <X className="h-6 w-6" />
                    </button>
                </div>

                <div className="p-6 space-y-6">
                    {/* Personal & Company Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <DetailItem icon={User} label="Name" value={customer.name} />
                        <DetailItem icon={Briefcase} label="Job Title" value={customer.jobTitle} />
                        <DetailItem icon={Mail} label="Email" value={customer.email} />
                        <DetailItem icon={Phone} label="Phone" value={customer.phone || 'N/A'} />
                        <DetailItem icon={Building} label="Company" value={customer.company} />
                        <DetailItem icon={BarChart2} label="Industry" value={customer.industry} />
                    </div>

                    {/* Event & Status */}
                    <div className="border-t border-gray-200 pt-6 space-y-4">
                        <DetailItem icon={Calendar} label="Event" value={customer.eventName} />
                        <DetailItem icon={Users} label="Sales Qualified" value={customer.salesQualified ? 'Yes' : 'No'} />
                        {/* Sales-only details */}
                        {user?.role === 'sales' && (
                          <>
                            <DetailItem
                              icon={Mail}
                              label="Mail Sent"
                              value={customer.mailSent ? (
                                <span className="inline-flex items-center text-green-700 font-semibold"><CheckCircle className="h-4 w-4 mr-1 text-green-500" />Sent</span>
                              ) : (
                                <span className="inline-flex items-center text-red-700 font-semibold"><XCircle className="h-4 w-4 mr-1 text-red-500" />Not Sent</span>
                              )}
                            />
                            <DetailItem
                              icon={CreditCard}
                              label="Account Deployed"
                              value={customer.acctLaunched ? (
                                <span className="inline-flex items-center text-blue-700 font-semibold"><CheckCircle className="h-4 w-4 mr-1 text-blue-500" />Deployed</span>
                              ) : (
                                <span className="inline-flex items-center text-gray-700 font-semibold"><XCircle className="h-4 w-4 mr-1 text-gray-400" />Not Deployed</span>
                              )}
                            />
                          </>
                        )}
                    </div>

                    {/* Interests */}
                    <div className="border-t border-gray-200 pt-6">
                        <h3 className="text-lg font-semibold text-gray-900 mb-3">Interests</h3>
                        <div className="flex flex-wrap gap-2">
                            {customer.interests.length > 0 ? customer.interests.map((interest) => (
                                <span key={interest} className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm">
                                    {interest}
                                </span>
                            )) : <p className="text-sm text-gray-500">No interests specified.</p>}
                        </div>
                    </div>
                </div>

                <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-3 flex justify-end">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
    );

    return ReactDOM.createPortal(modalContent, document.body);
} 