import React, { useState, useEffect, useRef } from 'react';
import { FileText, Cpu, Brain } from 'lucide-react';
import Markdown from 'react-markdown';
import { useAppSelector } from '../../store/hooks';

interface DocumentWorkflowProps {
  isVisible: boolean;
  documentType?: string;
  onProcessingComplete?: () => void; // Callback when processing is complete
  isAnimating?: boolean; // Control when animation starts
  resetKey?: string | number; // Key to reset workflow state when document changes
  isCompleted?: boolean; // External completion state from parent component
  extractedData?: any; // API response data from parent component
}

/**
 * Document Workflow Component with real-time processing animations
 * Shows each step processing sequentially with smooth transitions
 */
const DocumentWorkflow: React.FC<DocumentWorkflowProps> = ({ 
  isVisible, 
  documentType = 'NRIC',
  onProcessingComplete,
  isAnimating = false,
  resetKey,
  isCompleted: externalIsCompleted = false,
  extractedData
}) => {
  // Debug logging for props
  console.log('DocumentWorkflow: Component rendered with props:', {
    isVisible,
    documentType,
    onProcessingComplete: !!onProcessingComplete,
    isAnimating,
    resetKey,
    externalIsCompleted,
    hasExtractedData: !!extractedData
  });
  const [currentStep, setCurrentStep] = useState(0);
  const [stepStatuses, setStepStatuses] = useState(['pending', 'pending', 'pending']);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [hasCompletedOnce, setHasCompletedOnce] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  
  // Redux state
  const reduxExtractedData = useAppSelector((state) => state.extractedData);
  
  // Ref to track current extractedData value for use in async functions
  const extractedDataRef = useRef(extractedData);
  
  // Update ref when extractedData changes
  useEffect(() => {
    extractedDataRef.current = extractedData;
  }, [extractedData]);

  // Start animation immediately when isAnimating becomes true
  useEffect(() => {
    if (isAnimating && !hasStarted && !isProcessing && !hasCompletedOnce && !isCompleted) {
      console.log(`Starting workflow processing for ${documentType}...`);
      setHasStarted(true);
          setIsProcessing(true);
          setIsCompleted(false);
          startProcessing();
    } else if (isAnimating && (hasStarted || isProcessing || hasCompletedOnce || isCompleted)) {
      console.log(`DocumentWorkflow: Skipping workflow start - already started, processing, or completed`);
    }
  }, [isAnimating, hasStarted, hasCompletedOnce, documentType, isProcessing, isCompleted]);
  
  // Monitor extractedData changes
  useEffect(() => {
    if (extractedData) {
      console.log('DocumentWorkflow: extractedData changed:', {
        hasData: !!extractedData,
        type: typeof extractedData,
        length: typeof extractedData === 'string' ? extractedData.length : 'N/A',
        content: typeof extractedData === 'string' ? extractedData.substring(0, 100) + '...' : extractedData
      });
    }
  }, [extractedData]);
  
  // Prevent workflow from restarting when extractedData changes
  useEffect(() => {
    if (extractedData && isProcessing && !isCompleted) {
      console.log('DocumentWorkflow: extractedData received while processing, continuing workflow...');
    }
  }, [extractedData, isProcessing, isCompleted]);

  // Auto-scroll to first step when workflow becomes visible
  useEffect(() => {
    if (isVisible && isAnimating && !isCompleted) {
      // Scroll to the first step when workflow starts
      setTimeout(() => {
        const firstStepElement = document.querySelector('[data-step="1"]');
        if (firstStepElement) {
          firstStepElement.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest'
          });
        }
      }, 200);
    }
  }, [isVisible, isAnimating, isCompleted]);

  // Initialize with static workflow when component mounts
  useEffect(() => {
    if (!hasCompletedOnce) {
      setCurrentStep(0);
      setStepStatuses(['pending', 'pending', 'pending']);
      setIsProcessing(false);
      setIsCompleted(false);
    }
  }, [hasCompletedOnce]);

  // Reset workflow state when resetKey changes (new document selected)
  useEffect(() => {
    if (resetKey !== undefined) {
      setCurrentStep(0);
      setStepStatuses(['pending', 'pending', 'pending']);
      setIsProcessing(false);
      setIsCompleted(false);
      setHasCompletedOnce(false);
      setHasStarted(false);
    }
  }, [resetKey]);

  // Show completed state when workflow has been completed before and component is visible
  useEffect(() => {
    if (hasCompletedOnce && !isAnimating && isVisible) {
      setStepStatuses(['completed', 'completed', 'completed']);
      setCurrentStep(3);
      setIsCompleted(true);
      setIsProcessing(false);
    }
  }, [hasCompletedOnce, isAnimating, isVisible]);

  // Use external completion state from parent component
  useEffect(() => {
    if (externalIsCompleted && isVisible) {
      setStepStatuses(['completed', 'completed', 'completed']);
      setCurrentStep(3);
      setIsCompleted(true);
      setIsProcessing(false);
      setHasCompletedOnce(true);
    }
  }, [externalIsCompleted, isVisible]);

  // Debug logging for extracted data - now using Redux
  useEffect(() => {
    if (extractedData) {
      console.log('DocumentWorkflow received extractedData:', extractedData);
      console.log('DocumentWorkflow documentType:', documentType);
      console.log('Extracted data available:', extractedData.response_data?.extracted_kyc_data);
      // Data is now managed by Redux, no need for localStorage
    }
  }, [extractedData, documentType]);

  // Data is now managed by Redux, no need for localStorage loading

  // Data cleanup is now handled by Redux, no localStorage cleanup needed



  // Auto-scroll function to scroll to the current step
  const scrollToCurrentStep = (stepNumber: number) => {
    setTimeout(() => {
      const stepElement = document.querySelector(`[data-step="${stepNumber}"]`);
      if (stepElement) {
        stepElement.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
          inline: 'nearest'
        });
      }
    }, 100); // Small delay to ensure DOM is updated
  };



  const startProcessing = async () => {
    // Prevent multiple executions
    if (isCompleted || hasCompletedOnce || hasStarted) {
      console.log('DocumentWorkflow: startProcessing called but already completed or started, skipping...');
      return;
    }
    
    console.log('DocumentWorkflow: startProcessing started');
    
    // Step 1: Document Upload (immediate)
    setStepStatuses(['processing', 'pending', 'pending']);
    await new Promise(resolve => setTimeout(resolve, 800));
    setStepStatuses(['completed', 'pending', 'pending']);
    setCurrentStep(1);
    
    // Auto-scroll to current step
    scrollToCurrentStep(1);

    // Step 2: Textract Extraction
    setStepStatuses(['completed', 'processing', 'pending']);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setStepStatuses(['completed', 'completed', 'pending']);
    setCurrentStep(2);
    
    // Auto-scroll to current step
    scrollToCurrentStep(2);

    // Step 3: Bedrock Processing
    setStepStatuses(['completed', 'completed', 'processing']);
    
    // Auto-scroll to current step (LLM Processing)
    scrollToCurrentStep(3);
    
    // Wait for API response data to be available for extraction documents
    if (documentType === 'NRIC' || documentType === 'Bank Statement' || documentType === 'Salary Slip' || documentType === 'Discharge Summary' || documentType === 'Invoice' || documentType === 'Three-Way Comparison' || documentType === 'Blood Biomarker Report' || documentType === 'CMS-1500 Claim Form' || documentType === 'Prescription' || documentType === 'Radiology Report') {
      console.log(`Waiting for API response for ${documentType}...`);
      
      // Wait for extractedData to be available with a maximum timeout
      let attempts = 0;
      const maxWaitTime = 14000; // 14 seconds maximum wait
      const checkInterval = 500; // Check every 500ms
      
      console.log('DocumentWorkflow: Starting to wait for extractedData...');
      console.log('DocumentWorkflow: Current extractedData value:', extractedData);
      console.log('DocumentWorkflow: Current extractedDataRef value:', extractedDataRef.current);
      
      while (attempts < (maxWaitTime / checkInterval)) {
        // PRIORITY: Check extractedData prop first (this is the most reliable)
        // Use ref to get current value instead of captured closure value
        const currentExtractedData = extractedDataRef.current;
        if (currentExtractedData && 
            currentExtractedData.response_data && 
            currentExtractedData.response_data.extracted_kyc_data && 
            currentExtractedData.response_data.extracted_kyc_data.trim().length > 0) {
          console.log('DocumentWorkflow: API response received via extractedData prop, proceeding to completion');
          break;
        }
        
        // Also check if extractedData has any truthy value (not just empty strings)
        if (currentExtractedData && currentExtractedData !== '' && currentExtractedData !== false && currentExtractedData !== null && currentExtractedData !== true) {
          console.log('DocumentWorkflow: API response received via extractedData prop (truthy value), proceeding to completion');
          break;
        }
        
        // Check Redux state as fallback
        const docIdMap: { [key: string]: string } = {
          'NRIC': 'nric',
          'Bank Statement': 'bank_statement',
          'Salary Slip': 'salary_slip',
          'Discharge Summary': 'discharge_summary',
          'Invoice': 'invoice',
          'Three-Way Comparison': 'threeway',
          'Blood Biomarker Report': 'blood_biomarker',
          'CMS-1500 Claim Form': 'cms_1500',
          'Prescription': 'prescription',
          'Radiology Report': 'radiology_report'
        };
        
        const docId = docIdMap[documentType];
        console.log('DocumentWorkflow: Checking Redux state for docId:', docId);
        console.log('DocumentWorkflow: Full Redux state:', reduxExtractedData);
        if (docId && reduxExtractedData[docId]) {
          const reduxData = reduxExtractedData[docId];
          console.log('DocumentWorkflow: Found data in Redux:', reduxData);
          if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
            console.log('DocumentWorkflow: Found valid data in Redux, proceeding to completion');
            break;
      }
    } else {
          console.log('DocumentWorkflow: No data found in Redux for docId:', docId);
        }
        
        // Also check if the workflow has been externally completed
        if (externalIsCompleted) {
          console.log('DocumentWorkflow: External completion detected, proceeding to completion');
          break;
        }
        
        await new Promise(resolve => setTimeout(resolve, checkInterval));
        attempts++;
        console.log(`DocumentWorkflow: Waiting for API response... attempt ${attempts} (${(attempts * checkInterval / 1000).toFixed(1)}s)`);
        console.log('DocumentWorkflow: Current extractedData:', extractedData);
        console.log('DocumentWorkflow: Current extractedDataRef:', extractedDataRef.current);
        console.log('DocumentWorkflow: Current Redux state:', reduxExtractedData);
      }
      
      if (attempts >= (maxWaitTime / checkInterval)) {
        console.log('DocumentWorkflow: Maximum wait time reached, proceeding with workflow completion');
      } else {
        // API response was received, show completed status for LLM Processing step
        console.log('DocumentWorkflow: API response received, showing completed status for LLM Processing');
    setStepStatuses(['completed', 'completed', 'completed']);
    setCurrentStep(3);
    
        // Wait 2-3 seconds to show the completed status
        await new Promise(resolve => setTimeout(resolve, 2500));
      }
    } else {
      // For non-extraction documents, proceed normally
      await new Promise(resolve => setTimeout(resolve, 1200));
    }
    
    // Set completion state
    setIsCompleted(true);
    setIsProcessing(false);
    setHasCompletedOnce(true);
    
    console.log('DocumentWorkflow: Workflow completed, about to trigger callback');
    
    // Trigger callback immediately for extraction documents, or after delay for others
    if (documentType === 'NRIC' || documentType === 'Bank Statement' || documentType === 'Salary Slip' || documentType === 'Discharge Summary' || documentType === 'Invoice' || documentType === 'Three-Way Comparison' || documentType === 'Blood Biomarker Report' || documentType === 'CMS-1500 Claim Form' || documentType === 'Prescription' || documentType === 'Radiology Report') {
      // For extraction documents, trigger callback immediately
      console.log('DocumentWorkflow: Triggering onProcessingComplete callback immediately for extraction document');
            if (onProcessingComplete) {
              onProcessingComplete();
      } else {
        console.warn('DocumentWorkflow: onProcessingComplete callback is not provided');
      }
    } else {
      // For other documents, wait 3 seconds
      console.log('DocumentWorkflow: Triggering onProcessingComplete callback after 3 seconds for non-extraction document');
      setTimeout(() => {
        if (onProcessingComplete) {
          onProcessingComplete();
        } else {
          console.warn('DocumentWorkflow: onProcessingComplete callback is not provided');
        }
      }, 3000);
    }
  };

  // Create workflow steps array that's reactive to stepStatuses
  const workflowSteps = React.useMemo(() => [
    {
      id: 1,
      title: 'Document Upload',
      description: `${documentType} uploaded and prepared for processing`,
      icon: <FileText className="h-6 w-6 text-blue-500" />,
      status: stepStatuses[0]
    },
    {
      id: 2,
      title: 'OCR Extraction',
      description: 'AWS Textract extracts raw text and data from the document',
      icon: <Cpu className="h-6 w-6 text-green-500" />,
      status: stepStatuses[1],
      features: [
        'Optical Character Recognition (OCR)',
        'Form data extraction',
        'Table structure detection',
        'Key-value pair identification'
      ]
    },
    {
      id: 3,
      title: 'LLM Processing',
      description: 'Amazon Bedrock filters and structures extracted information',
      icon: <Brain className="h-6 w-6 text-purple-500" />,
      status: stepStatuses[2],
      features: (documentType === 'NRIC' || documentType === 'Invoice' || documentType === 'Three-Way Comparison' || documentType === 'Blood Biomarker Report' || documentType === 'CMS-1500 Claim Form' || documentType === 'Prescription' || documentType === 'Radiology Report') && extractedData ? [] : [
        'Intelligent data classification',
        'KYC verification and validation',
        'Data quality assessment',
        'Confidence scoring'
      ]
    }
  ], [stepStatuses, documentType]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800 border border-green-200 animate-pulse">
            <svg className="w-3 h-3 text-green-600 mr-1" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            Completed
          </span>
        );
      case 'processing':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200">
            <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
            Processing...
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-600 border border-gray-200">
            Pending
          </span>
        );
    }
  };

  const getIconContainer = (step: any, index: number) => {
    const isActive = step.status === 'processing';
    const isCompleted = step.status === 'completed';
    const isPending = step.status === 'pending';

    return (
      <div className="relative flex-shrink-0 mr-6">
        <div className={`w-16 h-16 rounded-full border-2 flex items-center justify-center shadow-sm transition-all duration-500 ${
          isCompleted ? 'bg-green-100 border-green-300' :
          isActive ? 'bg-blue-100 border-blue-300 animate-pulse' :
          'bg-gray-200 border-gray-300'
        }`}>
          {step.icon}
        </div>
        {/* Processing indicator ring */}
        {isActive && (
          <div className="absolute inset-0 w-16 h-16 rounded-full border-2 border-blue-400 border-t-transparent animate-spin"></div>
        )}
        {/* Success checkmark for completed steps */}
        {isCompleted && (
          <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
            <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M5 13l4 4L19 7"></path>
            </svg>
          </div>
        )}
      </div>
    );
  };



  return (
    <div className="w-full bg-white p-6 rounded-lg"
      style={{ fontFamily: 'Inter, sans-serif' }}
    >
      {/* Show initial message or workflow content */}
      {!isAnimating && !hasCompletedOnce && !externalIsCompleted ? (
        /* Initial Message - Show when workflow hasn't started */
        <div className="w-100 h-100 d-flex flex-column justify-content-center align-items-center"
          style={{
            minHeight: 500,
            height: 500,
            color: '#b0b0b0',
            fontSize: '0.9rem',
            fontWeight: 400,
            letterSpacing: '0.01em',
            textAlign: 'center',
            background: 'inherit',
            fontFamily: 'Inter, sans-serif'
          }}
        >
          <span>
            Click <span className="fw-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
          </span>
          <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
            to begin document processing!
          </span>
        </div>
      ) : (
        <>
          {/* Header - Only show when workflow is active or completed */}
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-2">AI Processing Workflow</h3>
            <p className="text-gray-600">Real-time processing pipeline using AWS AI services</p>
          </div>

          {/* Completion Message */}
          {isCompleted && (
            <div className="mb-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg text-center animate-in slide-in-from-top-2 duration-500">
              <div className="flex items-center justify-center mb-4">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center animate-bounce">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
              </div>
              <h4 className="text-xl font-bold text-green-800 mb-2">Processing Complete!</h4>
              <p className="text-green-700">All document processing steps have been completed successfully.</p>
              {/* <div className="mt-4 flex items-center justify-center gap-2 text-sm text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>Navigating to extracted information...</span>
              </div> */}
            </div>
          )}

          {/* Vertical Workflow Steps - Show only when processing or completed */}
          <div className="space-y-16">
            {workflowSteps.map((step, index) => (
              <div key={step.id} className="flex items-start relative" data-step={step.id}>
                {/* Left: Circular Icon with Animation */}
                {getIconContainer(step, index)}

                {/* Right: Content Card */}
                <div className={`flex-1 bg-white rounded-lg border p-6 shadow-sm transition-all duration-500 ${
                  step.status === 'processing' ? 'border-blue-200 bg-blue-50' :
                  step.status === 'completed' ? 'border-green-200 bg-green-50' :
                  'border-gray-200'
                }`}>
                  {/* Title and Status */}
                  <div className="flex items-center justify-between mb-3">
                    <h4 className={`text-lg font-bold transition-colors duration-300 ${
                      step.status === 'processing' ? 'text-blue-800' :
                      step.status === 'completed' ? 'text-green-800' :
                      'text-gray-800'
                    }`}>
                      {step.title}
                    </h4>
                    {getStatusBadge(step.status)}
                  </div>
                  
                  {/* Description */}
                  <p className={`text-sm mb-4 transition-colors duration-300 ${
                    step.status === 'processing' ? 'text-blue-700' :
                    step.status === 'completed' ? 'text-green-700' :
                    'text-gray-600'
                  }`}>
                    {step.description}
                  </p>
                  
                  {/* Features Box (only for Textract and Bedrock) */}
                  {step.features && (
                    <div className={`p-4 rounded-lg transition-all duration-500 ${
                      step.id === 2 
                        ? step.status === 'processing' ? 'bg-blue-100 border border-blue-200' :
                          step.status === 'completed' ? 'bg-green-50 border border-green-200' :
                          'bg-gray-50 border border-gray-200'
                        : step.status === 'processing' ? 'bg-purple-100 border border-purple-200' :
                          step.status === 'completed' ? 'bg-purple-50 border border-purple-200' :
                          'bg-gray-50 border border-gray-200'
                    }`}>
                      <h5 className={`text-sm font-medium mb-2 transition-colors duration-300 ${
                        step.id === 2 
                          ? step.status === 'processing' ? 'text-blue-700' : 'text-green-700'
                          : step.status === 'processing' ? 'text-purple-700' : 'text-purple-700'
                      }`}>
                        {step.id === 2 ? 'Textract Features:' : 'Bedrock Processing:'}
                      </h5>
                      {/* Show features for all steps */}
                      <ul className="space-y-1">
                        {step.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-start text-sm">
                            <span className={`w-1.5 h-1.5 rounded-full mt-2 mr-2 flex-shrink-0 transition-colors duration-300 ${
                              step.id === 2 
                                ? step.status === 'processing' ? 'bg-blue-600' : 'bg-green-600'
                                : step.status === 'processing' ? 'bg-purple-600' : 'bg-purple-600'
                            }`}></span>
                            <span className={`transition-colors duration-300 ${
                              step.id === 2 
                                ? step.status === 'processing' ? 'text-blue-700' : 'text-green-700'
                                : step.status === 'processing' ? 'text-purple-700' : 'text-purple-700'
                            }`}>
                              {feature}
                            </span>
                          </li>
                          ))}
                        </ul>
                      
                      {/* Show API response for Bedrock Processing when available */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'NRIC' && (
                        <div className="mt-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                          <h6 className="text-sm font-medium text-purple-800 mb-3">Extraction Results</h6>
                          
                          {/* Extracted KYC Data - Single Clean Display */}
                          {(() => {
                            // Try to get data from props first, then from Redux
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data && extractedData.response_data.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['nric'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-purple-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-purple-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                          
                          {/* Completion Status - Removed for cleaner UI */}
                        </div>
                      )}

                      {/* Show Bank Statement extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Bank Statement' && (
                        <div className="mt-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <h6 className="text-sm font-medium text-blue-800 mb-3">Bank Statement Extraction Results</h6>
                          
                          {/* Extracted Bank Statement Data */}
                          {(() => {
                            // Try to get data from props first, then from Redux
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data && extractedData.response_data.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['bank_statement'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-blue-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-blue-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show Salary Slip extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Salary Slip' && (
                        <div className="mt-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <h6 className="text-sm font-medium text-green-800 mb-3">Salary Slip Extraction Results</h6>
                          
                          {/* Extracted Salary Slip Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data && extractedData.response_data.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['salary_slip'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-green-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-green-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show Discharge Summary extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Discharge Summary' && (
                        <div className="mt-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                          <h6 className="text-sm font-medium text-purple-800 mb-3">Discharge Summary Extraction Results</h6>
                          
                          {/* Extracted Discharge Summary Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data && extractedData.response_data.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['discharge_summary'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-purple-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-purple-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show Invoice extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Invoice' && (
                        <div className="mt-3 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                          <h6 className="text-sm font-medium text-orange-800 mb-3">Invoice Extraction Results</h6>
                          
                          {/* Extracted Invoice Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data && extractedData.response_data.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['invoice'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-orange-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-orange-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show Three-Way Comparison extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Three-Way Comparison' && (
                        <div className="mt-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <h6 className="text-sm font-medium text-blue-800 mb-3">Three-Way Comparison Results</h6>
                          
                          {/* Extracted Three-Way Comparison Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data && extractedData.response_data.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['threeway'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-blue-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-blue-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show Blood Biomarker Report extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Blood Biomarker Report' && (
                        <div className="mt-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <h6 className="text-sm font-medium text-green-800 mb-3">Blood Biomarker Report Results</h6>
                          
                          {/* Extracted Blood Biomarker Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data?.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['blood_biomarker'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-green-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-green-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show CMS-1500 Claim Form extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'CMS-1500 Claim Form' && (
                        <div className="mt-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <h6 className="text-sm font-medium text-blue-800 mb-3">CMS-1500 Claim Form Results</h6>
                          
                          {/* Extracted CMS-1500 Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data?.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['cms_1500'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-blue-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-blue-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show Prescription extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Prescription' && (
                        <div className="mt-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <h6 className="text-sm font-medium text-green-800 mb-3">Prescription Results</h6>
                          
                          {/* Extracted Prescription Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data?.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['prescription'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-green-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-green-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}

                      {/* Show Radiology Report extraction results */}
                      {step.id === 3 && (step.status === 'processing' || step.status === 'completed') && documentType === 'Radiology Report' && (
                        <div className="mt-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                          <h6 className="text-sm font-medium text-purple-800 mb-3">Radiology Report Results</h6>
                          
                          {/* Extracted Radiology Report Data */}
                          {(() => {
                            // Try to get data from props first, then from localStorage
                            let displayData = null;
                            
                            if (extractedData && extractedData !== true && extractedData.response_data?.extracted_kyc_data) {
                              displayData = extractedData.response_data.extracted_kyc_data;
                            } else {
                              // Try Redux as fallback
                              const reduxData = reduxExtractedData['radiology_report'];
                              if (reduxData && reduxData.response_data && reduxData.response_data.extracted_kyc_data) {
                                displayData = reduxData.response_data.extracted_kyc_data;
                              }
                            }
                            
                            if (displayData) {
                              return (
                                <div className="mb-3">
                                  <div className="p-3 bg-white rounded border border-purple-200 max-h-48 overflow-y-auto">
                                    <div className="text-xs text-purple-800 font-sans leading-relaxed prose prose-sm max-w-none [&>h1]:text-sm [&>h2]:text-xs [&>h3]:text-xs [&>h4]:text-xs [&>h5]:text-xs [&>h6]:text-xs [&>h1]:font-semibold [&>h2]:font-medium [&>h3]:font-medium [&>h4]:font-medium [&>h5]:font-medium [&>h6]:font-medium [&>h1]:mb-2 [&>h2]:mb-1.5 [&>h3]:mb-1 [&>h4]:mb-1 [&>h5]:mb-1 [&>h6]:mb-1">
                                      <Markdown>{displayData}</Markdown>
                                    </div>
                                  </div>
                                </div>
                              );
                            } else {
                              return (
                                <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                  <div className="flex items-center justify-center">
                                    <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-2"></div>
                                    <div className="text-xs text-blue-700">
                                      Processing extraction results...
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                          })()}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Connector Line - positioned relative to the step container */}
                {index < workflowSteps.length - 1 && (
                  <div className="absolute w-0.5 transition-all duration-1000" 
                       style={{ 
                         top: '4rem',
                         left: '32px',
                         height: '22rem',
                         transform: 'translateX(-50%)',
                         background: isCompleted 
                           ? '#10b981' 
                           : step.status === 'completed' && workflowSteps[index + 1]?.status === 'processing' 
                             ? 'linear-gradient(to bottom, #10b981, #3b82f6)' 
                             : step.status === 'completed' 
                               ? '#10b981' 
                               : '#d1d5db'
                       }}></div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default DocumentWorkflow;
