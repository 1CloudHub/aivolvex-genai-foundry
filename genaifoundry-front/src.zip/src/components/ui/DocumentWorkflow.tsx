import React from 'react';
import { FileText, Cpu, Brain } from 'lucide-react';

interface DocumentWorkflowProps {
  isVisible: boolean;
  documentType?: string;
}

/**
 * Document Workflow Component matching the exact design from the image
 * Features light grey circular icons with blue icons inside and clean vertical layout
 */
const DocumentWorkflow: React.FC<DocumentWorkflowProps> = ({ 
  isVisible, 
  documentType = 'NRIC' 
}) => {
  if (!isVisible) {
    return (
      <div className="w-full h-full flex flex-col justify-center items-center"
        style={{
          minHeight: 500,
          height: 500,
          color: '#b0b0b0',
          fontSize: '0.9rem',
          fontWeight: 400,
          letterSpacing: '0.01em',
          textAlign: 'center',
          background: 'inherit',
          fontFamily: 'Inter, sans-serif'
        }}
      >
        <span>
          Click <span className="font-bold" style={{ color: '#b0b0b0', fontWeight: 500, fontFamily: 'Inter, sans-serif' }}>'Extract'</span>
        </span>
        <span style={{ lineHeight: '1.2', marginTop: '-2px' }}>
          to begin document processing!
        </span>
      </div>
    );
  }

  const workflowSteps = [
    {
      id: 1,
      title: 'Document Upload',
      description: `${documentType} uploaded and prepared for processing`,
      icon: <FileText className="h-6 w-6 text-blue-500" />,
      status: 'Completed'
    },
    {
      id: 2,
      title: 'Textract Extraction',
      description: 'AWS Textract extracts raw text and data from the document',
      icon: <Cpu className="h-6 w-6 text-green-500" />,
      status: 'Completed',
      features: [
        'Optical Character Recognition (OCR)',
        'Form data extraction',
        'Table structure detection',
        'Key-value pair identification'
      ]
    },
    {
      id: 3,
      title: 'Bedrock Processing',
      description: 'Amazon Bedrock filters and structures extracted information',
      icon: <Brain className="h-6 w-6 text-purple-500" />,
      status: 'Completed',
      features: [
        'Intelligent data classification'
      ]
    }
  ];

  return (
    <div className="w-full bg-white p-6 rounded-lg"
      style={{ fontFamily: 'Inter, sans-serif' }}
    >
      {/* Header */}
      <div className="mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">AI Processing Workflow</h3>
        <p className="text-gray-600">Real-time processing pipeline using AWS AI services</p>
      </div>

      {/* Vertical Workflow Steps */}
      <div className="space-y-12">
        {workflowSteps.map((step, index) => (
          <div key={step.id} className="flex items-start">
            {/* Left: Circular Icon */}
            <div className="relative flex-shrink-0 mr-6">
              <div className="w-16 h-16 rounded-full bg-gray-200 border-2 border-blue-100 flex items-center justify-center shadow-sm">
                {step.icon}
              </div>
              
              {/* Connector Line */}
              {index < workflowSteps.length - 1 && (
                <div className="absolute w-0.5 bg-gray-300" 
                     style={{ 
                       top: '100%',
                       height: '45px',
                       left: '50%',
                       transform: 'translateX(-50%)'
                     }}></div>
              )}
            </div>

            {/* Right: Content Card */}
            <div className="flex-1 bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              {/* Title and Status */}
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-lg font-bold text-gray-800">{step.title}</h4>
                <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800 border border-green-200">
                  {step.status}
                </span>
              </div>
              
              {/* Description */}
              <p className="text-gray-600 text-sm mb-4">{step.description}</p>
              
              {/* Features Box (only for Textract and Bedrock) */}
              {step.features && (
                <div className={`p-4 rounded-lg ${
                  step.id === 2 
                    ? 'bg-green-50 border border-green-200' 
                    : 'bg-purple-50 border border-purple-200'
                }`}>
                  <h5 className={`text-sm font-medium mb-2 ${
                    step.id === 2 ? 'text-green-700' : 'text-purple-700'
                  }`}>
                    {step.id === 2 ? 'Textract Features:' : 'Bedrock Processing:'}
                  </h5>
                  <ul className="space-y-1">
                    {step.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start text-sm">
                        <span className={`w-1.5 h-1.5 rounded-full mt-2 mr-2 flex-shrink-0 ${
                          step.id === 2 ? 'bg-green-600' : 'bg-purple-600'
                        }`}></span>
                        <span className={`${
                          step.id === 2 ? 'text-green-700' : 'text-purple-700'
                        }`}>
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DocumentWorkflow;
