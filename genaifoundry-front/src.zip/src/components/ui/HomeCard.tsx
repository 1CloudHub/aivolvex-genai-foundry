import React from 'react';
import { Card, Typography, Tooltip } from 'antd';
import { Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

const { Title, Text } = Typography;

// Define the solution item interface
interface SolutionItem {
  title: string;
  area: string;
  icon: React.ReactElement;
  description: string;
  buttonText: string;
  tags?: string[];
  redirect: string;
  type: string;
  tooltip: {
    icon: string;
    heading: string;
    subheading: string;
    points: string[];
  };
}

// Define the component props
interface HomeCardProps {
  solution: SolutionItem;
  cardHeight?: string;
  buttonHeight?: string;
  onNavigate: (solution: SolutionItem) => void;
}

/**
 * Reusable HomeCard component for displaying solution cards
 * Used in both Banking and Insurance home pages
 */
const HomeCard: React.FC<HomeCardProps> = ({ 
  solution, 
  cardHeight = "h-[340px]", 
  buttonHeight = "36px",
  onNavigate 
}) => {
  const navigate = useNavigate();

  // Handle button click with navigation logic
  const handleButtonClick = () => {
    // Check if this is the disabled Gen BI card
    if (solution.title === 'Gen BI with QuickSight + Q') {
      return; // Don't navigate for disabled cards
    }
    onNavigate(solution);
  };

  // Check if card should be disabled
  const isDisabled = solution.title === 'Gen BI with QuickSight + Q';

  return (
    <Card
      className={`relative w-full ${cardHeight} border-2 border-transparent rounded-lg shadow-md
        hover:shadow-lg transition-all duration-300 ease-in-out
        hover:!border-[#e87822] flex flex-col ${isDisabled ? 'opacity-50 grayscale' : ''}`}
      bodyStyle={{ 
        height: "100%",
        display: 'flex', 
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Tooltip Info Icon */}
      <div className="absolute top-2 right-2 z-10">
        <Tooltip
          placement="topRight"
          color="white" 
          overlayInnerStyle={{
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
            borderRadius: '10px',
            padding: '0', 
            maxWidth: '250px',
          }}
          title={
            <div className="p-[1px]">
              <div className="flex bg-[#f9fafb] rounded-md border-l-[4px] border-[#e87722] p-4">
                <div className="flex flex-col">
                  <div className="font-bold text-[#181f5a] text-sm mb-1">
                    {solution.tooltip.icon} {solution.tooltip.heading}
                  </div>
                  <div className="text-black text-xs font-semibold mb-2">
                    {solution.tooltip.subheading}
                  </div>
                  <ul className="list-disc pl-5 space-y-1 text-xs text-gray-700">
                    {solution.tooltip.points.map((point, idx) => (
                      <li key={idx}>{point}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          }
        >
          <Info className="text-[#e87722] hover:cursor-pointer" size={16} />
        </Tooltip>
      </div>

      {/* Card Content */}
      <div className="flex flex-col h-full justify-between">
        {/* Top Section: Icon and Tags */}
        <div className="flex-shrink-0">
          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#e8782222] mb-2">
            {React.cloneElement(solution.icon, {
              size: 20,
              className: "text-[#e87722]",
            })}
          </div>

          <div className="mb-2 min-h-[20px] flex gap-1 flex-wrap">
            {solution.tags?.map((tag, index) => (
              <span key={index} className="inline-block bg-[#e8782222] text-[#e87722] text-xs font-medium px-2 py-0.5 rounded-md">
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Middle Section: Title and Description */}
        <div className="flex-grow flex flex-col min-h-0">
          <Title level={5} className="!text-lg !font-bold !mb-2 !text-gray-900">
            {solution.title}
          </Title>

          <div className="flex-grow overflow-y-auto min-h-0">
            <Text className="text-gray-600 !text-xs leading-relaxed">
              {solution.description}
              {isDisabled && <span className="text-gray-400"> (Coming Soon)</span>}
            </Text>
          </div>
        </div>

        {/* Bottom Section: Button */}
        <div className="flex-shrink-0 mt-3">
          <button
            onClick={handleButtonClick}
            disabled={isDisabled}
            aria-disabled={isDisabled}
            className={`text-center !w-full !px-4 !py-2 !rounded-md !text-xs !font-medium
              focus:!outline-none !focus:ring-2 !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline
              ${isDisabled 
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                : '!bg-[#e87722] !text-white hover:!bg-[#d0691d] focus:!ring-[#e87722]'
              }`}
            style={{ height: buttonHeight, textDecoration: 'none' }}
          >
            {solution.buttonText}
          </button>
        </div>
      </div>
    </Card>
  );
};

export default HomeCard;
