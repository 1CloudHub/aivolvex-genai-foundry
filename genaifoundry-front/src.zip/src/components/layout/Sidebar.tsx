import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { 
  Cloud, 
  Calendar, 
  Users, 
  BarChart3,
  Home,
  ChevronLeft,
  ChevronRight,
  Briefcase,
  BarChart,
  User as UserIcon
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export default function Sidebar({ collapsed, setCollapsed }: SidebarProps) {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) return null;

  const getNavLinks = () => {
    switch (user.role) {
      case 'marketing':
        return [
          { path: '/dashboard', label: 'Dashboard', icon: Home },
          { path: '/events', label: 'Events', icon: Calendar },
        ];
      case 'devops':
        return [
          { path: '/dashboard', label: 'Dashboard', icon: Home },
          { path: '/events', label: 'Events', icon: Calendar },
        ];
      case 'sales':
        return [
          { path: '/dashboard', label: 'Dashboard', icon: Home },
          { path: '/events', label: 'Events', icon: Calendar },
        ];
      case 'customer':
        return [
          { path: '/customer/sandbox', label: 'My Sandbox', icon: Cloud }
        ];
      default:
        return [];
    }
  };

  const navLinks = getNavLinks();

  const isActive = (path: string) => {
    // Highlight 'Events' tab for /events, /reports/customers, /customers/new, and any /customers/* route
    if (
      path === '/events' && (
        location.pathname.startsWith('/reports/customers') ||
        location.pathname.startsWith('/customers')
      )
    ) {
      return true;
    }
    return location.pathname.startsWith(path);
  };

  // Sidebar is fixed to the left, below the header (4rem)
  return (
    <motion.aside
      initial={{ x: -300 }}
      animate={{
        x: 0,
        width: collapsed ? 64 : 256
      }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="backdrop-blur-lg shadow-md border-r border-gray-200 h-[calc(100vh-4rem)] fixed left-0 top-16 flex flex-col z-40 "
      style={{}}
    >

      {/* Navigation */}
      <nav className="mt-8 px-2 flex-1">
        <ul className="space-y-2">
          {navLinks.map((link, idx) => {
            const IconComponent = link.icon;
            const active = isActive(link.path);
            return (
              <li key={link.path}>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.07 }}
                >
                  <Link
                    to={link.path}
                    className={`w-full flex ${collapsed ? 'items-center justify-center px-0' : 'items-center space-x-4 px-4'} py-3 rounded-xl text-left transition-all relative group ${
                      active
                        ? 'font-semibold shadow'
                        : 'text-gray-700 hover:text-orange-600 hover:bg-orange-50'
                    }`}
                    title={collapsed ? link.label : undefined}
                    style={active ? { background: '#ec580c', color: '#fff' } : {}}
                  >
                    <IconComponent className="w-5 h-5" style={active ? { color: '#fff' } : {}} />
                    <AnimatePresence>
                      {!collapsed && (
                        <motion.span
                          initial={{ opacity: 0, width: 0 }}
                          animate={{ opacity: 1, width: 'auto' }}
                          exit={{ opacity: 0, width: 0 }}
                          className="font-medium"
                          style={active ? { color: '#fff' } : {}}
                        >
                          {link.label}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </Link>
                </motion.div>
              </li>
            );
          })}
        </ul>
      </nav>
      {/* User Department Info at the bottom */}
      {/* Removed: No logged-in user detail at the bottom */}
    </motion.aside>
  );
}