import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import oneChBlackLogo from '../../../public/banner/1chblack.jpg';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when changing routes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Digital RM', path: '/chat' },
    { name: 'DocIQ', path: '/documents' },
    { name: 'RiskLens', path: '/risk' },
    { name: 'SanctionPad', path: '/generate' }
  ];

  return (
    <header 
      className={`sticky top-0 z-50 w-full transition-all duration-200 border-b border-gray-200 ${isScrolled ? 'bg-primary shadow-md' : 'bg-primary'}`}
      style={{ backgroundColor: '#ffffff', boxShadow: '0 2px 4px #0000000d', color: '#000000 !important', left: 0, right: 0 }}
    >
      <div className="w-full h-16 flex items-center justify-between">
        <div className="flex items-center gap-2 pl-6">
          <Link 
            to="/" 
            className="flex items-center gap-2"
          >
            <img 
              src={oneChBlackLogo} 
              alt="1CloudHub Logo" 
              className="h-8 object-contain"
            />
          </Link>
        </div>
        
        
        
        {/* Mobile menu button */}
        <button
          type="button"
          className="md:hidden p-2 rounded-full hover:bg-gray-100 focus:outline-none mr-6"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? (
            <X className="h-6 w-6" style={{ color: '#e87722' }} />
          ) : (
            <Menu className="h-6 w-6" style={{ color: '#e87722' }} />
          )}
        </button>
      </div>
      
      {/* Mobile navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-primary-800">
          <div className="container py-3 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block px-3 py-2 rounded-md text-base font-medium hover:text-dark transition-colors ${location.pathname === link.path && 'fw-bold'}`}
                style={location.pathname === link.path
                  ? { color: '#e87722', borderBottom: '3px solid #e87722', borderRadius: 0, background: 'none', outline: 'none', boxShadow: 'none' }
                  : { color: '#e87722' }}
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}
      
      {/* Page title bar */}
      <div className="bg-white border-b border-border" style={{ marginTop: '-1.5rem' }}>
        <div className="container py-4">
          {/* <h1 className="text-lg font-medium text-foreground">{pageTitle}</h1> */}
        </div>
      </div>
    </header>
  );
};

export default Header;