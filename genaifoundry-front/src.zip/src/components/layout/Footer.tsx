import { Link } from 'react-router-dom';
import { Separator } from '../../components/ui/separator';
import { ExternalLink } from 'lucide-react';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="w-full bg-gray-100 py-6 md:py-8">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-2">
            <h3 className="text-base font-semibold text-foreground">1Cloudhub AI Sandbox</h3>
            <p className="text-sm text-muted-foreground">
              Explore AI-powered tools designed to transform microfinance experiences
            </p>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-base font-semibold text-foreground">Quick Links</h3>
            <ul className="space-y-1">
              <li>
                <Link to="/chat" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Digital RM
                </Link>
              </li>
              <li>
                <Link to="/fieldaudio" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                VoiceIQ
                </Link>
              </li>
              <li>
                <Link to="/documents" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  DocIQ
                </Link>
              </li>
              <li>
                <Link to="/risk" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  RiskLens
                </Link>
              </li>
              <li>
                <Link to="/generate" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  SanctionPad
                </Link>
              </li>
            </ul>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-base font-semibold text-foreground">Resources</h3>
            <ul className="space-y-1">
              <li>
                <a 
                  href="https://www.1cloudhub.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center"
                >
                  1CloudHub
                  <ExternalLink className="ml-1 h-3 w-3" />
                </a>
              </li>
              <li>
                
              </li>
            </ul>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground text-center md:text-left">
            © {year} 1Cloudhub Gen AI Banking Sandbox. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground text-center md:text-right">
            <strong>Disclaimer:</strong> This is a demo sandbox environment. No real banking transactions are processed.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;