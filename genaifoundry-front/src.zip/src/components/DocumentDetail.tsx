import { Separator } from '@/components/ui/index';
import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react';
import { ProcessedDocument, ExtractedField } from '@/data/documentData';
import { cn } from '@/lib/utils';

const getStatusIcon = (status: ExtractedField['status']) => {
  switch (status) {
    case 'success':
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    case 'warning':
      return <AlertTriangle className="h-4 w-4 text-amber-500" />;
    case 'error':
      return <XCircle className="h-4 w-4 text-red-500" />;
    default:
      return null;
  }
};

export function DocumentDetail({ doc }: { doc: ProcessedDocument }) {
  return (
    <div className="bg-white rounded-2xl shadow-sm p-8 max-w-xl w-full">
      <div className="mb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-1">{doc.type}</h2>
          <div className="text-sm text-gray-500">Uploaded: {doc.uploadTime.toLocaleTimeString()}</div>
        </div>
      </div>
      <Separator className="my-4" />
      <div className="flex items-center justify-between text-base font-medium mb-2">
        <span>Document Name</span>
        <span className="text-gray-700 font-semibold">{doc.name}</span>
      </div>
      <Separator className="mb-4" />
      <div>
        <h3 className="text-lg font-semibold mb-3 text-gray-800">Extracted Information</h3>
        <div className="space-y-4">
          {doc.fields.map((field, index) => (
            <div key={index} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
              <div className="flex items-center gap-2">
                {getStatusIcon(field.status)}
                <span className="text-base text-gray-700">{field.name}</span>
              </div>
              <div className="text-right">
                <span className="text-base font-semibold text-gray-900">{field.value}</span>
                {field.message && (
                  <p className={cn(
                    "text-xs mt-0.5",
                    field.status === 'warning' ? "text-amber-600" :
                    field.status === 'error' ? "text-red-600" : ""
                  )}>
                    {field.message}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
} 