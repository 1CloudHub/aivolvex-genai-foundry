export type ScenarioKey = 'sme-loan' | 'credit-card' | 'complaint';

export interface ChatMessage {
  text: string;
  sender: 'agent' | 'customer';
  timestamp?: string;
  type?: 'question' | 'statement' | 'issue';
}

export interface ScenarioConfig {
  key: ScenarioKey;
  label: string;
  showCopilot: boolean;
  triggerPatterns?: RegExp[];
}

export interface CopilotData {
  suggestions: string[];
  policyRef: string;
  compliance: string[]; // List of compliance reminders, highlight if present
}

export interface AnalyticsData {
  topic: string;
  confidence: number; // 0-1
  complianceStatus: 'ok' | 'warn';
}

export interface ScenarioData {
  label: string;
  chat: ChatMessage[];
  copilot: CopilotData[];
  analytics: AnalyticsData[];
} 