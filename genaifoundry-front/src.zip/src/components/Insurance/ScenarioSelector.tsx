import React from 'react';
import { Row, Col, Card } from 'react-bootstrap';
import { CreditCard, Building2, MessageCircleWarning } from 'lucide-react';

type ScenarioKey = 'sme-loan' | 'credit-card' | 'complaint';

interface ScenarioSelectorProps {
  onSelect: (key: ScenarioKey) => void;
  selectedScenario: ScenarioKey | null;
}

interface ScenarioConfig {
  key: ScenarioKey;
  label: string;
  icon: React.ReactNode;
  description: string;
  tags: string[];
  showCopilot: boolean;
  triggerPatterns?: RegExp[];
}

const scenarioOptions: ScenarioConfig[] = [
  { 
    key: 'sme-loan', 
    label: 'SME Loan Inquiry',
    icon: <Building2 size={20} color="#f37021" />, 
    description: 'Assist agents in handling SME loan queries by identifying business types, checking alternate documentation paths, and responding with policy-based eligibility insights.',
    tags: ['Business Banking', 'Loans', 'SME'],
    showCopilot: true,
    triggerPatterns: [/loan/i, /business/i]
  },
  { 
    key: 'credit-card', 
    label: 'Credit Card Limit Increase',
    icon: <CreditCard size={20} color="#f37021" />, 
    description: 'Simulate how Copilot supports agents in limit increase discussions by validating credit criteria, income documentation needs, and card-specific income thresholds.',
    tags: ['Credit Cards', 'Retail', 'Upgrade'],
    showCopilot: true,
    triggerPatterns: [/credit.*card/i, /limit/i]
  },
  { 
    key: 'complaint', 
    label: 'Complaint Handling',
    icon: <MessageCircleWarning size={20} color="#f37021" />, 
    description: 'Guide complaint resolution with AI-assisted responses on payment delays, trace initiation using transaction references, and late fee waivers based on billing policy.',
    tags: ['Support', 'Compliance', 'Resolution'],
    showCopilot: false
  }
];

const ScenarioSelector: React.FC<ScenarioSelectorProps> = ({ onSelect, selectedScenario }) => {
  return (
    <>
      <Row className="g-4 justify-content-center">
        {scenarioOptions.map((scenario) => (
          <Col xl={4} lg={4} md={6} sm={12} key={scenario.key}>
            <Card 
              className={`h-100 ub-card cursor-pointer ${selectedScenario === scenario.key ? 'selected-card' : ''}`}
            
              onClick={() => onSelect(scenario.key)}
            >
              <Card.Body className="d-flex flex-column  text-start">
               <div
  className="d-flex align-items-center gap-2 mb-3"
>
  <div
    
  
  >
    {scenario.icon}
  </div>

  <Card.Title
    className="mb-0"
    style={{
      fontSize: '1.25rem',
      fontWeight: '700',
      color: '#2C3E50',
      lineHeight: '1.3'
    }}
  >
    {scenario.label}
  </Card.Title>
</div>

                <Card.Text className="mb-3 " style={{
                  color: '#6c757d',
                  fontSize: '0.9rem',
                  lineHeight: '1.5'
                }}>
                  {scenario.description}
                </Card.Text>
                <div className="mb-3 d-flex flex-wrap gap-1">
                  {scenario.tags.map((tag, index) => (
                    <span key={index} className="feature-tag" style={{
                      background: 'rgba(243, 112, 33, 0.08)',
                      color: '#f37021',
                      padding: '4px 10px',
                      borderRadius: '16px',
                      fontSize: '0.8rem',
                      fontWeight: '500'
                    }}>
                      {tag}
                    </span>
                  ))}
                </div>
                
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      <style>{`
        .hover-card {
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }

        .hover-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
        }

        .selected-card {
          border: 2px solid #f37021 !important;
          box-shadow: 0 8px 30px rgba(243, 112, 33, 0.15) !important;
        }

        .feature-tag {
          transition: all 0.3s ease;
        }

        .feature-tag:hover {
          background: rgba(243, 112, 33, 0.15) !important;
          transform: translateY(-1px);
        }

        .feature-icon-wrapper {
          transition: all 0.3s ease;
        }

        .hover-card:hover .feature-icon-wrapper {
          transform: scale(1.05);
        }

        .cursor-pointer {
          cursor: pointer;
        }

        @media (max-width: 768px) {
          .hover-card {
            transform: none !important;
          }
        }
      `}</style>
    </>
  );
};

export default ScenarioSelector;

export const getScenarioConfig = (key: ScenarioKey) => {
  return scenarioOptions.find(option => option.key === key)!;
};
