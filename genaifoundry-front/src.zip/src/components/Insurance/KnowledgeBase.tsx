import { memo } from "react";
import { Avatar } from "antd";
import { mockKBListData } from "./mockdata";

const KnowledgeBase = () => {
  const KBListData = mockKBListData;
  return (
    <div className="post-call-transcript">
      <div className="d-flex justify-content-start mt-2">
        <div>
          <Avatar className="pca-chatbot-ai" size="large">
            AA
          </Avatar>
        </div>
        <div className="pca-ai-message">
          <div>
            <b>Incoming Call: </b> Lim Mei Ling
          </div>
          <div>
            <b>Phone Number: </b>+6591234567
          </div>
          <div>
            <b>Location: </b> Singapore
          </div>
          <div>
            <b>Account Number: </b>SGP-98234761
          </div>
          <div>
            <b>Current Plan: </b> Not Enrolled
          </div>
          <div>
            <b>Joined Date: </b> March 15 2023
          </div>
          <div>
            <b>Recent Tickets: </b> Credit Card Enquiry (Resolved)
          </div>
        </div>
      </div>
  
      {KBListData.map((msg, index) => (
        msg.type === "ans" && (
          <div key={index} className="d-flex justify-content-start mt-2">
            <Avatar className="pca-chatbot-ai" size="large">
              AA
            </Avatar>
            <div className="pca-ai-message1">
              <span style={{ fontSize: '12px' }}>
                {msg.message}
              </span>
            </div>
          </div>
        )
      ))}
    </div>
  );
};

export default memo(KnowledgeBase);
