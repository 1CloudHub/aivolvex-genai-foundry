import React from 'react';
import { ScenarioKey } from './types';

const avatarBot = '/assets/images/agent-avatar.svg';
const avatarCustomer = '/assets/images/customer-avatar.svg';

const previousTranscripts: Record<ScenarioKey, { sender: 'bot' | 'customer'; text: string }[]> = {
  'sme-loan': [
    { sender: 'customer', text: 'Hi, I want to know more about SME loans.' },
    { sender: 'bot', text: "Sure, I'd be happy to help. May I know what type of business you're in?"},
    { sender: 'customer', text: "It's a small retail shop." },
    { sender: 'bot', text: 'Thanks for sharing. Retail shops are eligible under our SME loan program. Would you like to know about eligibility or documentation?' },
    { sender: 'customer', text: 'Can I apply if my business is less than 1 year old?' },
    { sender: 'bot', text: 'Generally, 2 years is required, but with ITRs and GST filings, we may consider your application. Do you have those documents?' },
    { sender: 'customer', text: "Yes, I can share last year's ITR and GST returns."},
    { sender: 'bot', text: 'Great. That helps. We can proceed via the alternate documentation route.' },
    { sender: 'customer', text: 'How long does it usually take to get the loan approved?' },
    { sender: 'bot', text: "It typically takes 5–7 working days after all documents are submitted and verified. I'll guide you through the process to ensure it's smooth." },
  ],
  'credit-card': [
    { sender: 'customer', text: "Hi, I'd like to request an increase to my credit card limit." },
    { sender: 'bot', text: "Sure, I can help with that. May I know if you've had any changes in income or credit usage recently?" },
    { sender: 'customer', text: "No, nothing's changed. I just want a higher limit for emergencies." },
    { sender: 'bot', text: 'Understood. Just to inform you, limit increases are assessed based on your recent usage, payment history, and internal credit score. Have you submitted any income proof recently?' },
    { sender: 'customer', text: "No, I haven't submitted income proof." },
    { sender: 'bot', text: "Thanks. We'll need your latest income document—like a payslip or ITR—to proceed with a manual review. Would you be able to share that?" },
    { sender: 'customer', text: 'Yes, I can share my latest payslip.' },
    { sender: 'bot', text: "Perfect. Once your payslip is submitted, it usually takes 3–5 working days for review. You'll get notified once a decision is made." },
    { sender: 'customer', text: 'Is there a minimum salary required to be eligible?' },
    { sender: 'bot', text: "Good question. For standard cards, the minimum monthly income is around PHP 25,000. It's higher for premium cards. I'll help verify this based on your card type." },
  ],
  'complaint': [
    { sender: 'customer', text: 'I want to file a complaint about a failed transaction.' },
    { sender: 'bot', text: "I'm sorry to hear that. Can you share the transaction ID?" },
    { sender: 'customer', text: 'TXN123456' },
    { sender: 'bot', text: 'Thank you. When did this transaction occur?' },
    { sender: 'customer', text: 'Yesterday evening.' },
    { sender: 'bot', text: 'We have registered your complaint and will update you soon.' },
    { sender: 'customer', text: 'How will I be notified?' },
    { sender: 'bot', text: 'You will receive an SMS and email once the issue is resolved.' },
  ],
};

interface Props {
  scenario: ScenarioKey;
  embedded?: boolean;
}

const PreviousHistory: React.FC<Props> = ({ scenario, embedded }) => {
  const transcript = previousTranscripts[scenario];

  if (embedded) {
    return (
      <section style={{ fontFamily: 'Inter, sans-serif' }}>
        <div className="bg-light rounded p-3" style={{ minHeight: 200, maxHeight: 280, overflowY: 'auto' }}>
          {transcript.map((msg, idx) => (
            <div key={idx} className={`d-flex mb-3 ${msg.sender === 'bot' ? 'flex-row-reverse' : 'flex-row'}`}> 
              <div className="d-flex flex-column align-items-center" style={{ minWidth: 40 }}>
                {msg.sender === 'bot' ? (
                  <span style={{ width: 40, height: 40, background: '#002856', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%', border: '2px solid #e9ecef' }}>
                    B
                  </span>
                ) : (
                  <span style={{ width: 40, height: 40, background: '#f37021', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%', border: '2px solid #e9ecef' }}>
                    C
                  </span>
                )}
              </div>
              <div>
                <div
                  className={`px-3 py-2 rounded-3 mb-1 fw-medium`}
                  style={msg.sender === 'bot' ? { background: '#002856', color: '#fff' } : { background: '#fff', color: '#222', border: '1px solid #e9ecef' }}
                >
                  {msg.text}
                </div>
                <div className="small text-muted text-end" style={{ fontSize: 12 }}>
                  {msg.sender === 'bot' ? 'Bot' : 'Customer'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  return (
    <div className="card shadow-sm border-0 rounded-4 mb-4" 
      style={{ 
        fontFamily: 'Inter, sans-serif', 
        height: '25rem',
        width: '48rem',
        minWidth: '48rem',
        flex: '0 0 48rem'
      }}>
      <div className="card-header bg-white rounded-top-4 fw-bold" style={{ color: '#1C6E8C', fontSize: 20 }}>
        Previous History
      </div>
      <div className="card-body bg-light" style={{ minHeight: 200, maxHeight: 'calc(25rem - 3.5rem)', overflowY: 'auto' }}>
        {transcript.map((msg, idx) => (
          <div key={idx} className={`d-flex mb-3 ${msg.sender === 'bot' ? 'flex-row-reverse' : 'flex-row'}`}> 
            <div className="d-flex flex-column align-items-center" style={{ minWidth: 40 }}>
              {msg.sender === 'bot' ? (
                <span style={{ width: 40, height: 40, background: '#002856', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%', border: '2px solid #e9ecef' }}>
                  B
                </span>
              ) : (
                <span style={{ width: 40, height: 40, background: '#f37021', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%', border: '2px solid #e9ecef' }}>
                  C
                </span>
              )}
            </div>
            <div>
              <div
                className={`px-3 py-2 rounded-3 mb-1 fw-medium`}
                style={msg.sender === 'bot' ? { background: '#002856', color: '#fff' } : { background: '#fff', color: '#222', border: '1px solid #e9ecef' }}
              >
                {msg.text}
              </div>
              <div className="small text-muted text-end" style={{ fontSize: 12 }}>
                {msg.sender === 'bot' ? 'Bot' : 'Customer'}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PreviousHistory; 