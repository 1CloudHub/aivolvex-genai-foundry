import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Home, CheckSquare, Lock, Users, FileText, AlertTriangle, TrendingUp } from 'lucide-react';
import LoginNavbar from '../layout/LoginNavbar';
import InsuranceFooter from './InsuranceFooter';

// API Types
interface UnderwritingResponse {
  eligibility_status: string;
  eligibility_summary: string;
  final_recommendation: string;
  recommendation_reasoning: string;
  premium_loading_percent: number;
  exclusions: string[];
  waiting_periods: {
    general: string;
    [key: string]: string; // Allow for condition-specific periods as direct properties
  };
  risk_score: number;
  risk_tier: string;
  risk_summary: string;
  risk_reasoning: string;
  plan_fit_score: number;
  plan_fit_reasoning: string;
  agent_assist_flags: string[];
  rule_trace: string[];
  underwriter_rationale: string;
}

// Types for form data
interface MediPlusSecureData {
  full_name: string;
  age: string;
  gender: string;
  occupation: string;
  annual_income: string;
  smoker_status: string;
  pre_existing_conditions: string;
  ongoing_medications: string;
  height_cm: string;
  weight_kg: string;
  alcohol_consumption: string;
  selected_plan: string;
  agent_comments: string;
}

interface LifeSecureTermData {
  full_name: string;
  age: string;
  gender: string;
  occupation: string;
  annual_income: string;
  smoker_status: string;
  alcohol_consumption: string;
  pre_existing_conditions: string;
  ongoing_medications: string;
  height_cm: string;
  weight_kg: string;
  coverage_amount: string;
  term_duration: string;
  family_medical_history: string;
  agent_comments: string;
}

const UnderwritingDecisionSupport: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'mediplus' | 'lifesecure'>('mediplus');
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Separate state for each tab
  const [mediPlusResults, setMediPlusResults] = useState<{
    hasResults: boolean;
    apiResponse: UnderwritingResponse | null;
    error: string | null;
  }>({
    hasResults: false,
    apiResponse: null,
    error: null
  });
  
  const [lifeSecureResults, setLifeSecureResults] = useState<{
    hasResults: boolean;
    apiResponse: UnderwritingResponse | null;
    error: string | null;
  }>({
    hasResults: false,
    apiResponse: null,
    error: null
  });
  
  // Helper to get current tab's results
  const getCurrentResults = () => {
    return activeTab === 'mediplus' ? mediPlusResults : lifeSecureResults;
  };
  
  // Helper to set current tab's results
  const setCurrentResults = (results: {
    hasResults: boolean;
    apiResponse: UnderwritingResponse | null;
    error: string | null;
  }) => {
    if (activeTab === 'mediplus') {
      setMediPlusResults(results);
    } else {
      setLifeSecureResults(results);
    }
  };

  // Form data states with default values for MediPlus Secure
  const [mediPlusData, setMediPlusData] = useState<MediPlusSecureData>({
    full_name: 'Tan Wei Ming',
    age: '42',
    gender: 'Male',
    occupation: 'Logistics Supervisor',
    annual_income: '72000',
    smoker_status: 'Smoker',
    pre_existing_conditions: 'Hypertension, Type 2 Diabetes (on oral meds)',
    ongoing_medications: 'Amlodipine, Metformin',
    height_cm: '170',
    weight_kg: '92',
    alcohol_consumption: 'Occasionally',
    selected_plan: 'Standard', // Default plan - field removed from form
    agent_comments: 'Applicant reports well-controlled BP and sugar levels, no recent hospitalisations.'
  });

  const [lifeSecureData, setLifeSecureData] = useState<LifeSecureTermData>({
    full_name: 'Jennifer Loh Mei Ling',
    age: '35',
    gender: 'Female',
    occupation: 'Restaurant Manager',
    annual_income: '55000',
    smoker_status: 'Smoker',
    alcohol_consumption: 'Regularly',
    pre_existing_conditions: 'Asthma (stable)',
    ongoing_medications: 'Salbutamol inhaler, Fluticasone',
    height_cm: '160',
    weight_kg: '68',
    coverage_amount: '400000',
    term_duration: '25',
    family_medical_history: 'Lung cancer (Mother at 55)',
    agent_comments: 'Smoker with respiratory condition, family history of lung cancer'
  });

  // Validation states
  const [mediPlusErrors, setMediPlusErrors] = useState<Record<string, string>>({});
  const [lifeSecureErrors, setLifeSecureErrors] = useState<Record<string, string>>({});

  // Helper function to provide default values for API response
  const getDefaultResponse = (): UnderwritingResponse => ({
    eligibility_status: "Pending Assessment",
    eligibility_summary: "Assessment in progress",
    final_recommendation: "Under Review",
    recommendation_reasoning: "Application is being evaluated",
    premium_loading_percent: 0,
    exclusions: [],
    waiting_periods: {
      general: "30 days"
    },
    risk_score: 0,
    risk_tier: "Low",
    risk_summary: "Assessment pending",
    risk_reasoning: "Initial evaluation in progress",
    plan_fit_score: 0,
    plan_fit_reasoning: "Plan compatibility being assessed",
    agent_assist_flags: [],
    rule_trace: [],
    underwriter_rationale: "Assessment in progress"
  });

  // Helper function to sanitize API response with default values
  const sanitizeAPIResponse = (response: any): UnderwritingResponse => {
    const defaultResponse = getDefaultResponse();
    
    return {
      eligibility_status: response.eligibility_status || defaultResponse.eligibility_status,
      eligibility_summary: response.eligibility_summary || defaultResponse.eligibility_summary,
      final_recommendation: response.final_recommendation || defaultResponse.final_recommendation,
      recommendation_reasoning: response.recommendation_reasoning || response.final_recommendation_reasoning || defaultResponse.recommendation_reasoning,
      premium_loading_percent: response.premium_loading_percent ?? defaultResponse.premium_loading_percent,
      exclusions: Array.isArray(response.exclusions) ? response.exclusions : defaultResponse.exclusions,
      waiting_periods: {
        general: response.waiting_periods?.general || defaultResponse.waiting_periods.general,
        ...Object.fromEntries(
          Object.entries(response.waiting_periods || {}).filter(([key]) => key !== 'general')
        )
      },
      risk_score: response.risk_score ?? defaultResponse.risk_score,
      risk_tier: response.risk_tier || defaultResponse.risk_tier,
      risk_summary: response.risk_summary || defaultResponse.risk_summary,
      risk_reasoning: response.risk_reasoning || defaultResponse.risk_reasoning,
      plan_fit_score: response.plan_fit_score ?? defaultResponse.plan_fit_score,
      plan_fit_reasoning: response.plan_fit_reasoning || defaultResponse.plan_fit_reasoning,
      agent_assist_flags: Array.isArray(response.agent_assist_flags) ? response.agent_assist_flags : defaultResponse.agent_assist_flags,
      rule_trace: Array.isArray(response.rule_trace) ? response.rule_trace : defaultResponse.rule_trace,
      underwriter_rationale: response.underwriter_rationale || defaultResponse.underwriter_rationale
    };
  };

  // API call function for both MediPlus and LifeSecure
  const callUnderwritingAPI = async (formData: MediPlusSecureData | LifeSecureTermData, eventType: 'mediplus_assess' | 'lifesecure_assess'): Promise<UnderwritingResponse> => {
    const API_URL = import.meta.env.VITE_API_BASE_URL;
    
    // Parse form data for API
    const preExistingConditions = formData.pre_existing_conditions
      ? formData.pre_existing_conditions.split(',').map(condition => condition.trim()).filter(Boolean)
      : [];

    const ongoingMedications = formData.ongoing_medications
      ? formData.ongoing_medications.split(',').map(medication => medication.trim()).filter(Boolean)
      : [];

    // Base applicant data
    const applicantData: any = {
      full_name: formData.full_name,
      age: parseInt(formData.age) || 0,
      gender: formData.gender,
      occupation: formData.occupation,
      annual_income: parseInt(formData.annual_income) || 0,
      smoker_status: formData.smoker_status,
      pre_existing_conditions: preExistingConditions,
      ongoing_medications: ongoingMedications,
      height_cm: parseInt(formData.height_cm) || 0,
      weight_kg: parseInt(formData.weight_kg) || 0,
      alcohol_consumption: formData.alcohol_consumption,
      agent_comments: formData.agent_comments || ''
    };

    // Add product-specific fields
    if (eventType === 'mediplus_assess') {
      const mediPlusData = formData as MediPlusSecureData;
      applicantData.selected_plan = mediPlusData.selected_plan;
    } else if (eventType === 'lifesecure_assess') {
      const lifeSecureData = formData as LifeSecureTermData;
      applicantData.coverage_amount = parseInt(lifeSecureData.coverage_amount) || 0;
      applicantData.term_duration = parseInt(lifeSecureData.term_duration) || 0;
      applicantData.family_medical_history = lifeSecureData.family_medical_history;
    }

    const requestData = {
      event_type: eventType,
      applicant_data: applicantData
    };

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    const rawResponse = await response.json();
    return sanitizeAPIResponse(rawResponse);
  };

  // Validation functions
  const validateMediPlusForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!mediPlusData.full_name.trim()) errors.full_name = 'Full name is required';
    if (!mediPlusData.age.trim()) errors.age = 'Age is required';
    if (!mediPlusData.gender.trim()) errors.gender = 'Gender is required';
    if (!mediPlusData.occupation.trim()) errors.occupation = 'Occupation is required';
    if (!mediPlusData.annual_income.trim()) errors.annual_income = 'Annual income is required';
    if (!mediPlusData.smoker_status.trim()) errors.smoker_status = 'Smoker status is required';
    if (!mediPlusData.pre_existing_conditions.trim()) errors.pre_existing_conditions = 'Pre-existing conditions field is required';
    if (!mediPlusData.ongoing_medications.trim()) errors.ongoing_medications = 'Ongoing medications field is required';
    if (!mediPlusData.height_cm.trim()) errors.height_cm = 'Height is required';
    if (!mediPlusData.weight_kg.trim()) errors.weight_kg = 'Weight is required';
    if (!mediPlusData.alcohol_consumption.trim()) errors.alcohol_consumption = 'Alcohol consumption is required';
    if (!mediPlusData.agent_comments.trim()) errors.agent_comments = 'Agent comments are required';
    
    setMediPlusErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const validateLifeSecureForm = (): boolean => {
    const errors: Record<string, string> = {};
    
    if (!lifeSecureData.full_name.trim()) errors.full_name = 'Full name is required';
    if (!lifeSecureData.age.trim()) errors.age = 'Age is required';
    if (!lifeSecureData.gender.trim()) errors.gender = 'Gender is required';
    if (!lifeSecureData.occupation.trim()) errors.occupation = 'Occupation is required';
    if (!lifeSecureData.annual_income.trim()) errors.annual_income = 'Annual income is required';
    if (!lifeSecureData.smoker_status.trim()) errors.smoker_status = 'Smoker status is required';
    if (!lifeSecureData.alcohol_consumption.trim()) errors.alcohol_consumption = 'Alcohol consumption is required';
    if (!lifeSecureData.pre_existing_conditions.trim()) errors.pre_existing_conditions = 'Pre-existing conditions field is required';
    if (!lifeSecureData.ongoing_medications.trim()) errors.ongoing_medications = 'Ongoing medications field is required';
    if (!lifeSecureData.height_cm.trim()) errors.height_cm = 'Height is required';
    if (!lifeSecureData.weight_kg.trim()) errors.weight_kg = 'Weight is required';
    if (!lifeSecureData.coverage_amount.trim()) errors.coverage_amount = 'Coverage amount is required';
    if (!lifeSecureData.term_duration.trim()) errors.term_duration = 'Term duration is required';
    if (!lifeSecureData.family_medical_history.trim()) errors.family_medical_history = 'Family medical history is required';
    if (!lifeSecureData.agent_comments.trim()) errors.agent_comments = 'Agent comments are required';
    
    setLifeSecureErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle form submission
  const handleAssessRisk = async () => {
    // Validate form before submission
    const isValid = activeTab === 'mediplus' ? validateMediPlusForm() : validateLifeSecureForm();
    
    if (!isValid) {
      return; // Stop submission if validation fails
    }
    
    setIsProcessing(true);
    setCurrentResults({ ...getCurrentResults(), error: null });
    
    try {
      const currentFormData = activeTab === 'mediplus' ? mediPlusData : lifeSecureData;
      const eventType = activeTab === 'mediplus' ? 'mediplus_assess' : 'lifesecure_assess';
      
      const response = await callUnderwritingAPI(currentFormData, eventType);
      setCurrentResults({
        hasResults: true,
        apiResponse: response,
        error: null
      });
    } catch (err: any) {
      const errorMessage = err.message.includes('API request failed') 
        ? 'Unable to connect to the assessment service. Please try again later.'
        : err.message.includes('NetworkError')
        ? 'Network connection error. Please check your internet connection.'
        : 'An unexpected error occurred. Please try again.';
      
      setCurrentResults({
        hasResults: false,
        apiResponse: null,
        error: errorMessage
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle input changes for MediPlus Secure
  const handleMediPlusChange = (field: keyof MediPlusSecureData, value: string) => {
    setMediPlusData(prev => ({ ...prev, [field]: value }));
    // Clear error for this field when user starts typing
    if (mediPlusErrors[field]) {
      setMediPlusErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  // Handle input changes for LifeSecure Term
  const handleLifeSecureChange = (field: keyof LifeSecureTermData, value: string) => {
    setLifeSecureData(prev => ({ ...prev, [field]: value }));
    // Clear error for this field when user starts typing
    if (lifeSecureErrors[field]) {
      setLifeSecureErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  // Switch tabs without resetting results
  const handleTabChange = (tab: 'mediplus' | 'lifesecure') => {
    setActiveTab(tab);
  };

  // Locked Output Card Component
  const LockedOutputCard: React.FC<{ title: string; icon: React.ReactNode; description: string }> = ({ 
    title, 
    icon, 
    description 
  }) => (
    <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="text-gray-400">{icon}</div>
          <h3 className="text-lg font-semibold text-gray-400">{title}</h3>
        </div>
        <Lock size={20} className="text-gray-400" />
      </div>
      <p className="text-sm text-gray-400 mb-4">{description}</p>
      <div className="text-center">
        <p className="text-sm text-gray-500">Click 'Assess Risk' to view analysis</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <LoginNavbar />
      
      {/* Content Container with proper margins */}
      <div className="flex-1 max-w-7xl mx-auto w-full px-6 lg:px-8">
        {/* Breadcrumb - Left Aligned */}
        <div className="pt-6 -ml-6">
          <nav className="flex text-sm text-gray-500" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1">
              <li>
                <Link to="/customer/sandbox/insurancehome" className="flex items-center gap-2 text-gray-500 no-underline hover:text-gray-700">
                  <Home size={16} className="relative top-[-1px]" />
                  Home
                </Link>
              </li>
              <li>
                <span className="mx-2">/</span>
                <span className="text-orange-600 font-medium">RiskLens</span>
              </li>
            </ol>
          </nav>
        </div>

        {/* Title Section - Left Aligned */}
        <div className="py-6">
          <div className="flex items-start -mb-9">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-orange-100 mr-4 mt-1">
              <CheckSquare size={28} className="text-orange-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-3">
                RiskLens
              </h1>
              <p className="text-base text-gray-600 max-w-3xl">
                Collects applicant profile details and compares them against internal underwriting manuals to generate eligibility status, exclusions, loadings, and risk recommendations.
              </p>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 py-6">
          {/* Tabs */}
          <div className="mb-6">
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex space-x-8">
                <button
                  onClick={() => handleTabChange('mediplus')}
                  className={`py-3 px-2 border-b-2 font-medium text-base ${
                    activeTab === 'mediplus'
                      ? 'border-orange-500 text-orange-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  MediPlus Secure
                </button>
                <button
                  onClick={() => handleTabChange('lifesecure')}
                  className={`py-3 px-2 border-b-2 font-medium text-base ${
                    activeTab === 'lifesecure'
                      ? 'border-orange-500 text-orange-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  LifeSecure Term
                </button>
              </nav>
            </div>
          </div>

          {/* Main Layout Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
            {/* Left Side - Input Form */}
                          <div className="lg:col-span-4 bg-white rounded-lg overflow-hidden max-h-[915px] min-h-[700px] flex flex-col underwriting-output-card mr-2">
              {/* Header */}
              <div className="bg-white-50 px-4 py-3 border-b border-gray-200 flex-shrink-0">
                <h2 className="text-xl font-semibold text-gray-900 flex items-center">
                  <div className="w-7 h-7 bg-orange-500 rounded-full flex items-center justify-center mr-3">
                    <Users size={16} className="text-white" />
                  </div>
                  Applicant Information
                </h2>
                <p className="text-sm text-gray-600 mt-1">Please fill in all required fields for risk assessment</p>
              </div>

              {/* Scrollable Form Content */}
              <div className="flex-1 overflow-y-auto p-4">
                {/* Form Fields */}
                <div className="space-y-4">
                {activeTab === 'mediplus' ? (
                  // MediPlus Secure Form
                  <div className="grid grid-cols-1 gap-4">
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Full Name
                          </label>
                          <input
                            type="text"
                            value={mediPlusData.full_name}
                            onChange={(e) => handleMediPlusChange('full_name', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.full_name ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Full name"
                          />
                          {mediPlusErrors.full_name && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.full_name}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Age
                          </label>
                          <input
                            type="number"
                            value={mediPlusData.age}
                            onChange={(e) => handleMediPlusChange('age', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.age ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Age"
                          />
                          {mediPlusErrors.age && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.age}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Gender
                          </label>
                          <select
                            value={mediPlusData.gender}
                            onChange={(e) => handleMediPlusChange('gender', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.gender ? 'border-red-500' : 'border-gray-300'
                        }`}
                          >
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                          </select>
                          {mediPlusErrors.gender && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.gender}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Occupation
                          </label>
                          <input
                            type="text"
                            value={mediPlusData.occupation}
                            onChange={(e) => handleMediPlusChange('occupation', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.occupation ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Occupation"
                          />
                          {mediPlusErrors.occupation && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.occupation}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Annual Income (SGD)
                          </label>
                          <input
                            type="number"
                            value={mediPlusData.annual_income}
                            onChange={(e) => handleMediPlusChange('annual_income', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.annual_income ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Annual income"
                          />
                          {mediPlusErrors.annual_income && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.annual_income}</p>
                          )}
                        </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                        Smoker Status
                      </label>
                      <select
                        value={mediPlusData.smoker_status}
                        onChange={(e) => handleMediPlusChange('smoker_status', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.smoker_status ? 'border-red-500' : 'border-gray-300'
                        }`}
                      >
                        
                        <option value="Non-Smoker">Non-Smoker</option>
                        <option value="Smoker">Smoker</option>
                        <option value="Ex-Smoker">Ex-Smoker</option>
                      </select>
                      {mediPlusErrors.smoker_status && (
                        <p className="text-red-500 text-sm mt-1">{mediPlusErrors.smoker_status}</p>
                      )}
                      </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Height (cm)
                          </label>
                          <input
                            type="number"
                            value={mediPlusData.height_cm}
                            onChange={(e) => handleMediPlusChange('height_cm', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.height_cm ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Height in cm"
                          />
                          {mediPlusErrors.height_cm && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.height_cm}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Weight (kg)
                          </label>
                          <input
                            type="number"
                            value={mediPlusData.weight_kg}
                            onChange={(e) => handleMediPlusChange('weight_kg', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.weight_kg ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Weight in kg"
                          />
                          {mediPlusErrors.weight_kg && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.weight_kg}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Alcohol Consumption
                          </label>
                          <select
                            value={mediPlusData.alcohol_consumption}
                            onChange={(e) => handleMediPlusChange('alcohol_consumption', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.alcohol_consumption ? 'border-red-500' : 'border-gray-300'
                        }`}
                          >
                            
                            <option value="Never">Never</option>
                            <option value="Occasionally">Occasionally</option>
                            <option value="Regularly">Regularly</option>
                            <option value="Heavily">Heavily</option>
                          </select>
                          {mediPlusErrors.alcohol_consumption && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.alcohol_consumption}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Pre-existing Conditions
                          </label>
                          <textarea
                            value={mediPlusData.pre_existing_conditions}
                            onChange={(e) => handleMediPlusChange('pre_existing_conditions', e.target.value)}
                            rows={3}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.pre_existing_conditions ? 'border-red-500' : 'border-gray-300'
                        }`}
                            placeholder="List any pre-existing medical conditions"
                          />
                          {mediPlusErrors.pre_existing_conditions && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.pre_existing_conditions}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Ongoing Medications
                          </label>
                          <textarea
                            value={mediPlusData.ongoing_medications}
                            onChange={(e) => handleMediPlusChange('ongoing_medications', e.target.value)}
                            rows={3}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.ongoing_medications ? 'border-red-500' : 'border-gray-300'
                        }`}
                            placeholder="List any ongoing medications"
                          />
                          {mediPlusErrors.ongoing_medications && (
                            <p className="text-red-500 text-sm mt-1">{mediPlusErrors.ongoing_medications}</p>
                          )}
                        </div>
                      <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                          Agent Comments
                        </label>
                        <textarea
                          value={mediPlusData.agent_comments}
                          onChange={(e) => handleMediPlusChange('agent_comments', e.target.value)}
                          rows={3}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          mediPlusErrors.agent_comments ? 'border-red-500' : 'border-gray-300'
                        }`}
                          placeholder="Additional comments or observations"
                        />
                        {mediPlusErrors.agent_comments && (
                          <p className="text-red-500 text-sm mt-1">{mediPlusErrors.agent_comments}</p>
                        )}
                      </div>
                    </div>
                ) : (
                  // LifeSecure Term Form
                  <div className="grid grid-cols-1 gap-4">
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Full Name
                          </label>
                          <input
                            type="text"
                            value={lifeSecureData.full_name}
                            onChange={(e) => handleLifeSecureChange('full_name', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.full_name ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Full name"
                          />
                          {lifeSecureErrors.full_name && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.full_name}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Age
                          </label>
                          <input
                            type="number"
                            value={lifeSecureData.age}
                            onChange={(e) => handleLifeSecureChange('age', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.age ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Age"
                          />
                          {lifeSecureErrors.age && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.age}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Gender
                          </label>
                          <select
                            value={lifeSecureData.gender}
                            onChange={(e) => handleLifeSecureChange('gender', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.gender ? 'border-red-500' : 'border-gray-300'
                        }`}
                          >
                            
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                          </select>
                          {lifeSecureErrors.gender && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.gender}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Occupation
                          </label>
                          <input
                            type="text"
                            value={lifeSecureData.occupation}
                            onChange={(e) => handleLifeSecureChange('occupation', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.occupation ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Occupation"
                          />
                          {lifeSecureErrors.occupation && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.occupation}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Annual Income (SGD)
                          </label>
                          <input
                            type="number"
                            value={lifeSecureData.annual_income}
                            onChange={(e) => handleLifeSecureChange('annual_income', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.annual_income ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Annual income"
                          />
                          {lifeSecureErrors.annual_income && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.annual_income}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                        Requested Coverage
                          </label>
                          <input
                            type="number"
                            value={lifeSecureData.coverage_amount}
                            onChange={(e) => handleLifeSecureChange('coverage_amount', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.coverage_amount ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Coverage amount"
                          />
                          {lifeSecureErrors.coverage_amount && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.coverage_amount}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Term Duration (years)
                          </label>
                          <input
                            type="number"
                            value={lifeSecureData.term_duration}
                            onChange={(e) => handleLifeSecureChange('term_duration', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.term_duration ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Term duration in years"
                          />
                          {lifeSecureErrors.term_duration && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.term_duration}</p>
                          )}
                        </div>
                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                        Smoker Status
                      </label>
                      <select
                        value={lifeSecureData.smoker_status}
                        onChange={(e) => handleLifeSecureChange('smoker_status', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.smoker_status ? 'border-red-500' : 'border-gray-300'
                        }`}
                      >
                        
                        <option value="Non-Smoker">Non-Smoker</option>
                        <option value="Smoker">Smoker</option>
                        <option value="Ex-Smoker">Ex-Smoker</option>
                      </select>
                      {lifeSecureErrors.smoker_status && (
                        <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.smoker_status}</p>
                      )}
                      </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Height (cm)
                          </label>
                          <input
                            type="number"
                            value={lifeSecureData.height_cm}
                            onChange={(e) => handleLifeSecureChange('height_cm', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.height_cm ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Height in cm"
                          />
                          {lifeSecureErrors.height_cm && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.height_cm}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Weight (kg)
                          </label>
                          <input
                            type="number"
                            value={lifeSecureData.weight_kg}
                            onChange={(e) => handleLifeSecureChange('weight_kg', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.weight_kg ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Weight in kg"
                          />
                          {lifeSecureErrors.weight_kg && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.weight_kg}</p>
                          )}
                        </div>
                        <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">
                            Alcohol Consumption
                          </label>
                          <select
                            value={lifeSecureData.alcohol_consumption}
                            onChange={(e) => handleLifeSecureChange('alcohol_consumption', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                          lifeSecureErrors.alcohol_consumption ? 'border-red-500' : 'border-gray-300'
                        }`}
                          >
                      
                            <option value="Never">Never</option>
                            <option value="Occasionally">Occasionally</option>
                            <option value="Regularly">Regularly</option>
                            <option value="Heavily">Heavily</option>
                          </select>
                          {lifeSecureErrors.alcohol_consumption && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.alcohol_consumption}</p>
                          )}
                        </div>
                        <div>
                        <label className="block text-base font-medium text-gray-700 mb-1">
                            Pre-existing Conditions
                          </label>
                          <textarea
                            value={lifeSecureData.pre_existing_conditions}
                            onChange={(e) => handleLifeSecureChange('pre_existing_conditions', e.target.value)}
                            rows={3}
                          className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                            lifeSecureErrors.pre_existing_conditions ? 'border-red-500' : 'border-gray-300'
                          }`}
                            placeholder="List any pre-existing medical conditions"
                          />
                          {lifeSecureErrors.pre_existing_conditions && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.pre_existing_conditions}</p>
                          )}
                        </div>
                        <div>
                        <label className="block text-base font-medium text-gray-700 mb-1">
                            Ongoing Medications
                          </label>
                          <textarea
                            value={lifeSecureData.ongoing_medications}
                            onChange={(e) => handleLifeSecureChange('ongoing_medications', e.target.value)}
                            rows={3}
                          className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                            lifeSecureErrors.ongoing_medications ? 'border-red-500' : 'border-gray-300'
                          }`}
                            placeholder="List any ongoing medications"
                          />
                          {lifeSecureErrors.ongoing_medications && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.ongoing_medications}</p>
                          )}
                        </div>
                        <div>
                        <label className="block text-base font-medium text-gray-700 mb-1">
                            Family Medical History
                          </label>
                          <textarea
                            value={lifeSecureData.family_medical_history}
                            onChange={(e) => handleLifeSecureChange('family_medical_history', e.target.value)}
                            rows={3}
                          className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                            lifeSecureErrors.family_medical_history ? 'border-red-500' : 'border-gray-300'
                          }`}
                            placeholder="Describe relevant family medical history"
                          />
                          {lifeSecureErrors.family_medical_history && (
                            <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.family_medical_history}</p>
                          )}
                        </div>
                      <div>
                        <label className="block text-base font-medium text-gray-700 mb-1">
                          Agent Comments
                        </label>
                        <textarea
                          value={lifeSecureData.agent_comments}
                          onChange={(e) => handleLifeSecureChange('agent_comments', e.target.value)}
                          rows={3}
                          className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent text-base ${
                            lifeSecureErrors.agent_comments ? 'border-red-500' : 'border-gray-300'
                          }`}
                          placeholder="Additional comments or observations"
                        />
                        {lifeSecureErrors.agent_comments && (
                          <p className="text-red-500 text-sm mt-1">{lifeSecureErrors.agent_comments}</p>
                        )}
                      </div>
                    </div>
                )}

                </div>
              </div>

              {/* Fixed Submit Button Section */}
              <div className="border-t border-gray-200 bg-gray-50 p-4 flex-shrink-0">
                  <button
                    onClick={handleAssessRisk}
                    disabled={isProcessing}
                  className="w-full bg-orange-500 text-white py-3 px-4 rounded-md font-medium hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-base"
                  >
                    {isProcessing ? 'Assessing Risk...' : 'Assess Risk'}
                  </button>
                
                                  {/* Error Display */}
                  {getCurrentResults().error && (
                    <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-md">
                      <div className="flex items-center space-x-2">
                        <AlertTriangle size={16} className="text-red-600" />
                        <span className="text-sm text-red-700 font-medium">Error</span>
                </div>
                      <p className="text-sm text-red-600 mt-1">{getCurrentResults().error}</p>
                </div>
                  )}
              </div>
            </div>

            {/* Right Side - Output Cards Grid */}
            <div className="lg:col-span-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Top Left - Assessment Summary */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-64 underwriting-output-card">
              {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                <>
                    <div className="p-3 underwriting-card-header bg-white" style={{ borderBottom: '1px solid #e5e7eb' }}>
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <FileText size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Assessment Summary</h3>
                      </div>
                    </div>
                    <div className="flex-1 p-4">
                      {/* Risk Scores Display */}
                      <div className="grid grid-cols-2 gap-3">
  {/* Risk Score Card */}
  <div className="border-l-4 border-[#F3722C] rounded-[12px] bg-white py-1.5 px-2.5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] flex flex-col items-center justify-center min-h-[65px]">
    <div className="text-base font-extrabold text-orange-600 mb-1">{getCurrentResults().apiResponse!.risk_score}</div>
    <div className="inline-block bg-yellow-100 text-orange-700 px-2 py-0.5 rounded-full text-xs font-semibold mb-1">
      {getCurrentResults().apiResponse!.risk_tier} Risk
    </div>
    <div className="text-gray-600 text-xs">Risk Score</div>
  </div>
  {/* Recommendation Card */}
  <div className="border-l-4 border-[#F3722C] rounded-[12px] bg-white py-1.5 px-2.5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] flex flex-col items-center justify-center min-h-[65px]">
    <div className="text-sm font-bold text-green-800 mb-1 text-center" style={{lineHeight:1.1}}>{getCurrentResults().apiResponse!.final_recommendation}</div>
    <div className="text-green-600 font-bold uppercase tracking-tight text-xs">Recommendation</div>
  </div>
  {/* Premium Loading Card */}
  <div className="border-l-4 border-[#F3722C] rounded-[12px] bg-white py-1.5 px-2.5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] flex flex-col items-center justify-center min-h-[65px]">
    <div className="text-base font-extrabold text-blue-600 mb-1">{getCurrentResults().apiResponse!.premium_loading_percent}%</div>
    <div className="text-blue-600 font-bold uppercase tracking-tight text-xs">Premium Loading</div>
  </div>
  {/* Plan Fit Score Card */}
  <div className="border-l-4 border-[#F3722C] rounded-[12px] bg-white py-1.5 px-2.5 shadow-[0_2px_8px_rgba(0,0,0,0.06)] flex flex-col items-center justify-center min-h-[65px]">
    <div className="text-base font-extrabold text-purple-600 mb-1">{getCurrentResults().apiResponse!.plan_fit_score}%</div>
    <div className="text-purple-600 font-bold uppercase tracking-tight text-xs">Plan Fit Score</div>
  </div>
</div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 underwriting-card-header bg-white" style={{ borderBottom: '1px solid #e5e7eb' }}>
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <FileText size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Assessment Summary</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                  </>
                )}
                  </div>

              {/* Top Right - Risk Assessment */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-64 underwriting-output-card">
                {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <TrendingUp size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Risk Assessment</h3>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                      <div className="font-medium text-gray-800 text-base mb-2">{getCurrentResults().apiResponse!.risk_tier} Risk (Score: {getCurrentResults().apiResponse!.risk_score}/100)</div>
                      <p className="text-sm text-gray-700 mb-2">
                        <strong>Summary:</strong> {getCurrentResults().apiResponse!.risk_summary}
                      </p>
                      <p className="text-sm text-gray-700">
                        <strong>Risk Reasoning:</strong> {getCurrentResults().apiResponse!.risk_reasoning}
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <TrendingUp size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Risk Assessment</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                  </>
                )}
                    </div>

              {/* Middle Left - Eligibility & Recommendation */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-80 underwriting-output-card">
                {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <CheckSquare size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Eligibility & Final Recommendation</h3>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                      <div className="flex items-center space-x-2 mb-2">
                        <div className="w-3 h-3 bg-green-500 rounded"></div>
                        <span className="font-medium text-green-700 text-base">{getCurrentResults().apiResponse!.eligibility_status}</span>
                      </div>
                      <p className="text-sm text-gray-600 mb-3 leading-relaxed">
                        {getCurrentResults().apiResponse!.eligibility_summary}
                      </p>
                      <div className="bg-green-50 border border-green-200 rounded p-2">
                        <div className="font-medium text-green-800 text-base mb-1">{getCurrentResults().apiResponse!.final_recommendation}</div>
                        <p className="text-sm text-green-700">
                          {getCurrentResults().apiResponse!.recommendation_reasoning}
                            </p>
                          </div>
                        </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <CheckSquare size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Eligibility & Final Recommendation</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                  </>
                )}
                  </div>

              {/* Middle Right - Premium Loading & Waiting Periods */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-80 underwriting-output-card">
                {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <TrendingUp size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Premium Loading & Waiting Periods</h3>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                      <div className="bg-gray-50 border border-gray-200 rounded p-2 mb-3">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-base font-medium text-gray-700">Premium Loading</span>
                          <span className="text-lg font-bold text-gray-900">{getCurrentResults().apiResponse!.premium_loading_percent}%</span>
                          </div>
                        <p className="text-sm text-gray-600">
                          Premium adjustment based on risk assessment and underwriting guidelines.
                          </p>
                        </div>
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-gray-700 mb-2">Waiting Periods</div>
                        <div className="flex justify-between items-center py-2 px-2 bg-gray-50 rounded text-sm">
                          <span>General</span>
                          <span className="font-bold">{getCurrentResults().apiResponse!.waiting_periods.general}</span>
                      </div>
                        {Object.entries(getCurrentResults().apiResponse!.waiting_periods)
                          .filter(([key]) => key !== 'general')
                          .map(([condition, period]) => (
                          <div key={condition} className="flex justify-between items-center py-2 px-2 bg-gray-50 rounded text-sm">
                            <span className="capitalize">{condition}</span>
                            <span className="font-bold text-gray-900">{period}</span>
                          </div>
                        ))}
                    </div>
                  </div>
                </>
              ) : (
                <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <TrendingUp size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Premium Loading & Waiting Periods</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                </>
              )}
          </div>

              {/* Bottom Left - Agent Action Items */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-72 underwriting-output-card">
            {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <Users size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Agent Action Items</h3>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                      <div className="space-y-3">
                        {getCurrentResults().apiResponse!.agent_assist_flags.map((flag: string, index: number) => (
                          <div key={index} className="flex items-start space-x-2 p-2 bg-gray-50 rounded">
                            <div className="w-2 h-2 bg-black rounded-full mt-1.5"></div>
                        <div>
                              <p className="text-sm text-gray-600 font-medium mb-1">{flag}</p>
                              <p className="text-sm text-gray-600">Action required based on underwriting assessment.</p>
                          </div>
                        </div>
                        ))}
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <Users size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Agent Action Items</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                  </>
                )}
                </div>

              {/* Bottom Right - Exclusions & Confidence */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-72 underwriting-output-card">
                {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <AlertTriangle size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Exclusions & Confidence</h3>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                      {/* Exclusions Section */}
                      <div className="mb-4">
                        <div className="bg-red-50 border border-red-200 rounded p-2">
                          <div className="flex items-center space-x-2">
                      <AlertTriangle size={16} className="text-red-600" />
                            <span className="font-medium text-red-700 text-sm">
                              {getCurrentResults().apiResponse!.exclusions.length > 0 ? `${getCurrentResults().apiResponse!.exclusions.length} Exclusions Applied` : 'No Exclusions Applied'}
                            </span>
                    </div>
                          <p className="text-sm text-red-600 mt-1">
                            {getCurrentResults().apiResponse!.exclusions.length > 0 
                              ? getCurrentResults().apiResponse!.exclusions.join(', ')
                              : 'All pre-existing conditions have been assessed and accepted under conditional approval terms.'
                            }
                          </p>
                  </div>
                </div>

                      {/* Confidence Section */}
                      <div>
                        <div className="text-sm font-medium text-gray-700 mb-2">Assessment Confidence</div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-gray-600">Plan Fit Score</span>
                          <span className="text-base font-bold text-green-600">{getCurrentResults().apiResponse!.plan_fit_score}%</span>
                      </div>
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
                          <div className="bg-green-500 h-2 rounded-full" style={{ width: `${getCurrentResults().apiResponse!.plan_fit_score}%` }}></div>
                    </div>
                        <p className="text-sm text-gray-600 mb-2">{getCurrentResults().apiResponse!.plan_fit_reasoning}</p>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <AlertTriangle size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Exclusions & Confidence</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                  </>
                )}
                  </div>
                </div>

            {/* Full Width Bottom Cards */}
            <div className="lg:col-span-12 grid grid-cols-1 lg:grid-cols-2 gap-7 mt-2">
              {/* Underwriter Rationale */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-64 underwriting-output-card">
                {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <FileText size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Underwriter Rationale</h3>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                      <div className="bg-gray-50 rounded p-3">
                        <p className="text-sm text-gray-700 leading-relaxed">
                          {getCurrentResults().apiResponse!.underwriter_rationale}
                    </p>
                  </div>
                </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <FileText size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Underwriter Rationale</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                  </>
                )}
                    </div>

              {/* Rule Evaluation Table */}
              <div className="bg-white rounded-lg flex flex-col overflow-hidden h-64 underwriting-output-card">
                {getCurrentResults().hasResults && getCurrentResults().apiResponse ? (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <CheckSquare size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900 mb-0">Rule Evaluation Table</h3>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3">
                  <div className="space-y-2">
                        {getCurrentResults().apiResponse!.rule_trace.map((rule: string, index: number) => {
                          // Detect the icon at the start of the rule text
                          const hasCheckIcon = rule.includes('✓') || rule.includes('☑') || rule.includes('✅');
                          const hasWarningIcon = rule.includes('⚠') || rule.includes('△') || rule.includes('▲');
                          
                          return (
                            <div key={index} className={`flex items-center p-2 rounded ${
                              hasCheckIcon ? 'bg-green-50' : hasWarningIcon ? 'bg-yellow-50' : 'bg-gray-50'
                            }`}>
                              <span className={`text-sm ${
                                hasCheckIcon ? 'text-green-800' : hasWarningIcon ? 'text-yellow-800' : 'text-gray-800'
                              }`}>{rule}</span>
                            </div>
                          );
                        })}
                </div>
              </div>
                  </>
                ) : (
                  <>
                    <div className="p-3 underwriting-card-header bg-white">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center">
                          <CheckSquare size={16} className="text-white" />
                        </div>
                        <h3 className="text-base font-bold text-gray-900">Rule Evaluation Table</h3>
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-sm text-gray-400">to unlock your underwriting risk!</p>
                      </div>
                    </div>
                  </>
            )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <InsuranceFooter />
    </div>
  );
};

export default UnderwritingDecisionSupport; 