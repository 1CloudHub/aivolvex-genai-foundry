import { memo } from "react";
import Insights from "./Insights";
import PostCallAI from "./PostCallAI";
import SentimentChart from "./SentimentCallChart";
import CallSummary from "./CallSummary";
import QAPoints from "./QAPoints";
import PCATranscript from "./PCATranscript";
import KnowledgeBase from "./KnowledgeBase";
import { Link, useParams } from "react-router-dom";
import { mockPostCallRecords } from "./mockdata";
import "./postcallanalysis.scss";
import { Bot, Home, FileText, User, BarChart3, MessageSquare, TrendingUp, CheckSquare } from "lucide-react";
import Card from "react-bootstrap/Card";
import LoginNavbar from '../layout/LoginNavbar';
import InsuranceFooter from './InsuranceFooter';

const PostCallAnalysis = () => {
  const { sessionId } = useParams();
  const postcallrecords = mockPostCallRecords;

  return (
    <>
      <LoginNavbar />
      <div className="container px-0" style={{ minHeight: '100vh' }}>
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-1 mt-2 -ml-6 pt-2 ps-0" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <Link to="/customer/sandbox/insurancehome" className="flex items-center gap-2 text-orange-600 no-underline">
                <Home size={16} className="relative top-[-1px]" />
                Home
              </Link>
            </li>
            <li>
              <span className="mx-2">/</span>
              <Link to="/customer/sandbox/insurance/cci-dashboard" className="text-orange-600 no-underline">
                Contact Centre Intelligence
              </Link>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-gray-500">Post Call Analysis</span>
            </li>
          </ol>
        </nav>
        {/* Header and Scenario Selector */}
        <div className="row align-items-center mb-4 px-0">
          <div className="col-12 col-md-7 d-flex align-items-center mb-3 mb-md-0">
            <div className="me-3 flex-shrink-0">
              <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#fff4ed', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Bot size={30} color="#f37021" />
              </div>
            </div>
            <div>

              <h2 className="fw-bold mb-1" style={{ color: '#000' }}>Post Call Analysis</h2>
              <div className="text-muted" style={{ fontSize: 17 }}>An analytics dashboard offering deep insights into customer sentiment, agent performance, and call quality.</div>
            </div>
          </div>
          <div className="col-12 col-md-5 d-flex justify-content-md-end align-items-center">
            {/* ScenarioSelector will be rendered inside ChatCopilot, so leave space here for alignment */}
          </div>
        </div>
        {/* Main Content Card */}
        <div className="row justify-content-center">
          <div className="col-12">
            <div className="postcall-grid">
              <div className="insights">
                <Card className="card-insurance">
                  <Card.Header className="card-header-insurance postcall-separator">
                    <div className="d-flex align-items-center mt-2">
                      <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                        <FileText size={16} className="text-white" />
                      </div>
                      Generative AI Insights
                    </div>
                  </Card.Header>
                  <Card.Body className="card-body-insurance">
                    <div className="card-content-area">
                      <Insights />
                    </div>
                  </Card.Body>
                </Card>
              </div>
              <div className="ai">
                <Card className="card-insurance">
                  <Card.Header className="card-header-insurance postcall-separator">
                    <div className="d-flex align-items-center mt-2">
                      <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                        <User size={16} className="text-white" />
                      </div>
                      Customer Details
                    </div>
                  </Card.Header>
                  <Card.Body className="card-body-insurance">
                    <div className="card-content-area">
                      <PostCallAI />
                    </div>
                  </Card.Body>
                </Card>
              </div>
              <div className="summary">
                <Card className="card-insurance">
                  <Card.Header className="card-header-insurance postcall-separator">
                    <div className="d-flex align-items-center mt-2">
                      <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                        <BarChart3 size={16} className="text-white" />
                      </div>
                      Call Analytics Summary
                    </div>
                  </Card.Header>
                  <Card.Body className="card-body-insurance">
                    <div className="card-content-area">
                      <CallSummary postcallrecords={postcallrecords} />
                    </div>
                  </Card.Body>
                </Card>
              </div>
              <div className="kb">
                <Card className="card-insurance">
                  <Card.Header className="card-header-insurance postcall-separator">
                    <div className="d-flex align-items-center mt-2">
                      <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                        <MessageSquare size={16} className="text-white" />
                      </div>
                      Knowledge Base Centre - Agent Assist
                    </div>
                  </Card.Header>
                  <Card.Body className="card-body-insurance">
                    <div className="card-content-area">
                      <KnowledgeBase />
                    </div>
                  </Card.Body>
                </Card>
              </div>
              <div className="sentiment">
                <Card className="card-insurance">
                  <Card.Header className="card-header-insurance postcall-separator">
                    <div className="d-flex align-items-center mt-2">
                      <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                        <TrendingUp size={16} className="text-white" />
                      </div>
                      Sentiment Scale
                    </div>
                  </Card.Header>
                  <Card.Body className="card-body-insurance">
                    <SentimentChart />
                  </Card.Body>
                </Card>
              </div>
              <div className="qa">
                <Card className="card-insurance">
                  <Card.Header className="card-header-insurance postcall-separator">
                    <div className="d-flex align-items-center mt-2">
                      <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                        <CheckSquare size={16} className="text-white" />
                      </div>
                      QA Check
                    </div>
                  </Card.Header>
                  <Card.Body className="card-body-insurance">
                    <QAPoints />
                  </Card.Body>
                </Card>
              </div>
            </div>
            {/* Add full-width transcript card at the bottom */}
            <div className="w-100 pca-card">
              <Card className="card-insurance">
                <Card.Header className="card-header-insurance postcall-separator">
                  <div className="d-flex align-items-center mt-2">
                    <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                      <FileText size={16} className="text-white" />
                    </div>
                    Transcript
                  </div>
                </Card.Header>
                <Card.Body className="card-body-insurance">
                  <div className="card-content-area">
                    <PCATranscript />
                  </div>
                </Card.Body>
              </Card>
            </div>
          </div>
        </div>
      </div>
      <InsuranceFooter />
    </>
  );
};

export default memo(PostCallAnalysis);
