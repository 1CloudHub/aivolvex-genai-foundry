import { ScenarioKey, ScenarioData } from './types';

export const scenarios: Record<ScenarioKey, ScenarioData> = {
  'sme-loan': {
    label: 'SME Loan Inquiry',
    chat: [
      { sender: 'customer', text: 'Hi, I want to know more about SME loans.' },
      { sender: 'agent', text: "Sure, I'd be happy to help. May I know what type of business you're in?" },
      { sender: 'customer', text: "It's a small retail shop." },
      { sender: 'agent', text: 'Thanks for sharing. Retail shops are eligible under our SME loan program. Would you like to know about eligibility or documentation?' },
      { sender: 'customer', text: 'Can I apply if my business is less than 1 year old?' },
      { sender: 'agent', text: 'Generally, 2 years is required, but with ITRs and GST filings, we may consider your application. Do you have those documents?' },
      { sender: 'customer', text: "Yes, I can share last year's ITR and GST returns." },
      { sender: 'agent', text: 'Great. That helps. We can proceed via the alternate documentation route.' },
      { sender: 'customer', text: 'How long does it usually take to get the loan approved?' },
      { sender: 'agent', text: "It typically takes 5–7 working days after all documents are submitted and verified. I'll guide you through the process to ensure it's smooth." },
    ],
    copilot: [
      { suggestions: ['Ask about business type'], policyRef: 'SME Lending Policy → Section 2.1.1\nRetail businesses, including standalone shops, are eligible under the "Commercial Enterprises – Trading" category for SME loans.', compliance: [] },
      { suggestions: ['Acknowledge retail business eligibility'], policyRef: 'SME Lending Policy → Section 2.1.1', compliance: [] },
      { suggestions: ['Retail businesses, including standalone shops, are eligible under the “Commercial Enterprises – Trading” category for SME loans.'], policyRef: 'SME Lending Policy → Section 2.1.1', compliance: [] },
      { suggestions: ['Explain minimum business vintage and alternate criteria'], policyRef: 'SME Lending Policy → Section 3.3\nMinimum business vintage is 2 years. However, applicants with less than 2 years may qualify if supported by audited ITRs, GST filings, or collateral.', compliance: [] },
      { suggestions: ['Minimum business vintage is 2 years. However, applicants with less than 2 years may qualify if supported by audited ITRs, GST filings, or collateral.'], policyRef: 'SME Lending Policy → Section 3.3', compliance: [] },
      { suggestions: ['Acknowledge alternate documentation route'], policyRef: 'SME Lending Policy → Section 4.2.2\nApplicants with adequate turnover and financial records may qualify under alternate evaluation.', compliance: [] },
      { suggestions: ['Applicants with adequate turnover and financial records may qualify under alternate evaluation'], policyRef: 'SME Lending Policy → Section 4.2.2', compliance: [] },
      { suggestions: ['Guide customer through process'], policyRef: 'SME Lending Policy → Section 5.4', compliance: [] },
    ],
    analytics: [
      { topic: 'SME Loan Inquiry', confidence: 0.92, complianceStatus: 'ok' },
      { topic: 'Business Type', confidence: 0.88, complianceStatus: 'ok' },
      { topic: 'Eligibility', confidence: 0.90, complianceStatus: 'warn' },
      { topic: 'Documentation', confidence: 0.93, complianceStatus: 'ok' },
      { topic: 'Processing Time', confidence: 0.95, complianceStatus: 'ok' },
    ],
  },
  'credit-card': {
    label: 'Credit Card Limit Increase',
    chat: [
      { sender: 'customer', text: "Hi, I’d like to request an increase to my credit card limit." },
      { sender: 'agent', text: "Sure, I can help with that. May I know if you’ve had any changes in income or credit usage recently?" },
      { sender: 'customer', text: "No, nothing’s changed. I just want a higher limit for emergencies." },
      { sender: 'agent', text: "Understood. Just to inform you, limit increases are assessed based on your recent usage, payment history, and internal credit score. Have you submitted any income proof recently?" },
      { sender: 'customer', text: "No, I haven’t submitted income proof." },
      { sender: 'agent', text: "Thanks. We’ll need your latest income document—like a payslip or ITR—to proceed with a manual review. Would you be able to share that?" },
      { sender: 'customer', text: "Yes, I can share my latest payslip." },
      { sender: 'agent', text: "Perfect. Once your payslip is submitted, it usually takes 3–5 working days for review. You’ll get notified once a decision is made." },
      { sender: 'customer', text: "Is there a minimum salary required to be eligible?" },
      { sender: 'agent', text: "Good question. For standard cards, the minimum monthly income is around PHP 25,000. It’s higher for premium cards. I’ll help verify this based on your card type." }
    ],
    copilot: [
      { suggestions: ['Ask about changes in income or credit usage'], policyRef: 'Credit Card Policy → Section 6.2.1\nLimit increase requests are evaluated based on recent income proof, card usage history, repayment behavior, and internal credit scoring thresholds.', compliance: [] },
      { suggestions: ['Explain evaluation criteria for limit increase'], policyRef: 'Credit Card Policy → Section 6.2.1', compliance: [] },
      { suggestions: ['Limit increase requests are evaluated based on recent income proof, card usage history, repayment behavior, and internal credit scoring thresholds.'], policyRef: 'Credit Card Policy → Section 6.2.1', compliance: [] },
      { suggestions: ['Request latest income document'], policyRef: 'Credit Card Policy → Section 6.2.3', compliance: [] },
      { suggestions: ['Income documentation (e.g., latest payslip or ITR) is mandatory for manual limit enhancement requests unless eligible for auto-review based on transaction patterns.'], policyRef: 'Credit Card Policy → Section 6.2.3', compliance: [] },
      { suggestions: ['Explain minimum salary requirements'], policyRef: 'Credit Card Policy → Section 6.1.2\nMinimum monthly income required for limit enhancement varies by card tier—typically PHP 25,000 for standard cards and PHP 40,000 for premium cards.', compliance: [] },
      { suggestions: ['Once documentation is submitted, standard processing takes 3–5 working days. Applicants will be notified via SMS and email.'], policyRef: 'Credit Card Policy → Section 7.1', compliance: [] },
    ],
    analytics: [
      { topic: 'Limit Increase Request', confidence: 0.91, complianceStatus: 'ok' },
      { topic: 'Evaluation Criteria', confidence: 0.89, complianceStatus: 'ok' },
      { topic: 'Income Proof', confidence: 0.87, complianceStatus: 'warn' },
      { topic: 'Processing Time', confidence: 0.94, complianceStatus: 'ok' },
      { topic: 'Eligibility', confidence: 0.95, complianceStatus: 'ok' },
    ],
  },
  'complaint': {
    label: 'Complaint Handling: Payment Not Reflected',
  chat: [
    { sender: 'customer', text: 'Hi, I made a payment three days ago, but it’s still not showing on my credit card statement.' },
    { sender: 'agent', text: 'Sorry to hear that. Can you confirm how you made the payment—through mobile banking, over the counter, or via a third-party app?' },
    { sender: 'customer', text: 'I paid through a mobile banking app.' },
    { sender: 'agent', text: 'Thanks. Mobile banking payments usually reflect within 24 to 48 hours. Since it’s been over three days, I’ll help escalate this for review.' },
    { sender: 'customer', text: 'Okay, is there any way to track the payment?' },
    { sender: 'agent', text: 'Yes, please share the transaction reference number so I can raise a trace request. We’ll get an update within 2–3 working days.' },
    { sender: 'customer', text: 'Got it. One more thing—will I be charged late fees while this is being sorted?' },
    { sender: 'agent', text: 'If your payment date is within the billing cycle and you’ve got a valid transaction reference, we’ll request a waiver for any late fees once it’s verified.' },
  ],
    copilot: [
      { suggestions: ['Empathize with customer', 'Ask for transaction details'], policyRef: 'Customer Service Policy – Clause 3.1', compliance: [] },
      { suggestions: ['Request transaction date/amount', 'Log complaint'], policyRef: 'Customer Service Policy – Clause 3.2', compliance: [] },
      { suggestions: ['Mobile banking payments are usually processed within 24–48 hours. Delays beyond this period may occur due to transaction batching or interbank settlement lags.'],
        policyRef: 'Payment Processing Guidelines → Section 3.2.1',
        compliance: []
      },
      { suggestions: ['Request transaction ID', 'Confirm details'], policyRef: 'Customer Service Policy – Clause 3.3', compliance: [] },
      {
        suggestions: ['Customers can provide the transaction reference number to initiate a trace. Investigation timelines are typically 2–3 working days.'],
        policyRef: 'Payment Investigation Policy → Section 4.1',
        compliance: []
      },
      {
        suggestions: ['If the payment date falls within the billing cycle and the customer has a valid reference, late payment fees may be waived subject to internal verification.'],
        policyRef: 'Billing Policy → Section 5.4',
        compliance: []
      },
    ],
    analytics: [
      { topic: 'Complaint', confidence: 0.93, complianceStatus: 'ok' },
      { topic: 'Transaction Details', confidence: 0.90, complianceStatus: 'ok' },
      { topic: 'Escalation', confidence: 0.85, complianceStatus: 'warn' },
      { topic: 'Resolution', confidence: 0.96, complianceStatus: 'ok' },
    ],
  },
}; 