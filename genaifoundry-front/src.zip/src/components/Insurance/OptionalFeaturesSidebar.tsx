import React from 'react';
import { ScenarioKey } from './types';

const scenarioFeatures: Record<ScenarioKey, { label: string; enabled: boolean }[]> = {
  'sme-loan': [
    { label: 'CRM Integration', enabled: true },
    { label: 'Escalation Trigger', enabled: false },
    { label: 'Customer Sentiment Overlay', enabled: true },
    { label: 'Customer Info Panel', enabled: true },
    { label: 'RM Integration', enabled: false },
  ],
  'credit-card': [
    { label: 'CRM Integration', enabled: true },
    { label: 'Escalation Trigger', enabled: true },
    { label: 'Customer Sentiment Overlay', enabled: false },
    { label: 'Customer Info Panel', enabled: true },
    { label: 'RM Integration', enabled: false },
  ],
  'complaint': [
    { label: 'CRM Integration', enabled: true },
    { label: 'Escalation Trigger', enabled: true },
    { label: 'Customer Sentiment Overlay', enabled: true },
    { label: 'Customer Info Panel', enabled: false },
    { label: 'RM Integration', enabled: false },
  ],
};

interface Props {
  scenario: ScenarioKey;
}

const OptionalFeaturesSidebar: React.FC<Props> = ({ scenario }) => (
  <div className="card shadow-sm mb-3" style={{ background: '#fff', opacity: 1, height: '18rem' }}>
     <div className="card-header bg-white rounded-top-4 fw-bold d-flex align-items-center" style={{ color: '#000', fontSize: 18 }}>
        {/* <i className="bi bi-person-circle me-2" style={{ fontSize: 22, color: '#000' }}></i> */}
      Optional Features
      </div>
    <div className="card-body">
      <ul className="list-unstyled mb-0">
        {scenarioFeatures[scenario].map((f, i) => (
          <li key={i} className="mb-3 d-flex align-items-center small">
            {f.enabled ? (
              <span className="me-2" style={{ color: '#28a745', fontWeight: 700 }}>&#10003;</span>
            ) : (
              <span className="me-2" style={{ color: '#dc3545', fontWeight: 700 }}>&#10007;</span>
            )}
            <span style={{ color: '#000000' }}>{f.label}</span>
          </li>
        ))}
      </ul>
    </div>
  </div>
);

export default OptionalFeaturesSidebar; 