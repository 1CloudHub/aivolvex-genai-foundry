export interface Message {
    id: string;
    sender: 'user' | 'bot';
    text: string;
    timestamp: string;
    contextSource?: string;
  }
  
  export interface Conversation {
    id: string;
    messages: Message[];
  }
  
  export interface PromptChip {
    id: string;
    text: string;
  }
  
  export interface AnalyticsData {
    topTopic: string;
    sentiment: 'positive' | 'neutral' | 'negative';
    followUpSent: boolean;
  }
  
  export const promptChips: PromptChip[] = [
    { id: 'auto-loan', text: "What's the auto loan interest rate?" },
    { id: 'credit-card', text: "How do I apply for a credit card?" },
    { id: 'account-balance', text: "How do I check my account balance?" }
  ];
  
  export const sampleConversation: Conversation = {
    id: 'sample-conversation',
    messages: [
      {
        id: '1',
        sender: 'user',
        text: "What's the current interest rate for auto loans?",
        timestamp: '2025-04-05T09:30:00Z'
      },
      {
        id: '2',
        sender: 'bot',
        text: "UnionBank's current auto loan interest rates start at 7.9% per annum for brand new vehicles with our promotional offer, and 9.5% for our standard auto loan. The rate may vary based on your credit profile, loan term, and the type of vehicle. Would you like me to help you with an auto loan application or provide more details about our auto loan features?",
        timestamp: '2025-04-05T09:30:10Z',
        contextSource: 'Auto Loan Rate Sheet (April 2025)'
      },
      {
        id: '3',
        sender: 'user',
        text: "What documents do I need to apply for an auto loan?",
        timestamp: '2025-04-05T09:31:05Z'
      },
      {
        id: '4',
        sender: 'bot',
        text: "For a UnionBank auto loan application, you'll need the following documents:\n\n1. Valid government-issued ID (e.g., passport, driver's license)\n2. Proof of income:\n   - For employed: Certificate of Employment, latest 3 months' pay slips, and latest ITR\n   - For self-employed: Business registration documents and latest ITR\n3. Proof of billing/address (utility bill not older than 3 months)\n4. Vehicle quotation from an accredited dealer\n5. Downpayment proof (if already paid)\n\nWould you like me to assist you with starting your application online?",
        timestamp: '2025-04-05T09:31:15Z',
        contextSource: 'Auto Loan Requirements Guide'
      }
    ]
  };
  
  export const whatsAppPreview = {
    phoneNumber: '+63 912 345 6789',
    message: "Thank you for your inquiry about UnionBank's auto loan requirements. Here's a summary of what you'll need:\n\n• Government ID\n• Income documents (employment certificate, pay slips, ITR)\n• Proof of billing\n• Vehicle quotation\n• Downpayment proof (if applicable)\n\nClick here to start your application: https://www.unionbankph.com/auto-loan-apply\n\nNeed more help? Reply to this message or call our hotline at (02) 8841-8600."
  };