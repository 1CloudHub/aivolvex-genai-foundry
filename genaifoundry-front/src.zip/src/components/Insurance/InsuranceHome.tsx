import React, { useState } from 'react';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import {
    Mic ,
    Edit3 ,
    BarChart2 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    FileText,
    Home,
    ClipboardCheck,
    PieChart,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../layout/LoginNavbar';
import InsuranceFooter from './InsuranceFooter';

const GenAISandboxHome = () => {
    const { Title, Text } = Typography;
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');

const solutions = [
  {
    title: 'Virtual Insurance Assistant',
    area: 'Banking',
    icon: <MessageSquare size={24} />,
    description: 'Helps users discover relevant insurance products, view active policies, track and file claims, and schedule a human agent callback using RAG and tool calling.',
    buttonText: 'Try Now',
    tags: ['Customer Service', 'Sales'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '💬',
      heading: 'Virtual Insurance Assistant',
      subheading: 'AI Chatbot for Insurance',
      points: [
        'Discover insurance products',
        'View active policies',
        'Track and file claims',
        'Schedule agent callback',
        'Uses RAG and tool calling'
      ]
    }
  },
  // {
  //   title: 'Voicebot with RAG Support',
  //   area: 'Contact Center',
  //   icon: <Sparkles size={24} />,
  //   description: 'Handles first-line customer queries via voice by retrieving answers from internal documents such as policy terms, claims procedures, and SOPs.',
  //   buttonText: 'Explore',
  //   tags: ['Contact Center', 'SME'],
  //   redirect: '#',
  //   type: 'component',
  //   tooltip: {
  //     icon: '🗣️',
  //     heading: 'Voicebot with RAG',
  //     subheading: 'Voice AI for Insurance',
  //     points: [
  //       'Handles first-line queries via voice',
  //       'Retrieves answers from policy documents',
  //       'Supports claims procedures and SOPs'
  //     ]
  //   }
  // },
  {
    title: 'Document Processing Assistant',
    area: 'Contact Center',
    icon: <FileText size={24} />,
    description: 'Extracts and infers structured data from key insurance documents like NRICs, payslips, bank statements, and medical reports for use in claims or underwriting workflows.',
    buttonText: 'Try Now',
    tags: ['Contact Center', 'QA', 'Training'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📄',
      heading: 'Document Processing Assistant',
      subheading: 'AI Document Extraction',
      points: [
        'Extracts data from NRICs, payslips, bank statements, medical reports',
        'Supports claims and underwriting workflows'
      ]
    }
  },
  {
    title: 'Underwriting Decision Support Assistant',
    area: 'Legal',
    icon: <ClipboardCheck size={24} />,
    description: 'Collects applicant profile details and compares them against internal underwriting manuals to generate eligibility status, exclusions, loadings, and risk recommendations.',
    buttonText: 'Explore',
    tags: ['Legal', 'Compliance', 'Credit Ops'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📋',
      heading: 'Underwriting Decision Support',
      subheading: 'AI for Underwriting',
      points: [
        'Collects applicant profile details',
        'Compares with underwriting manuals',
        'Generates eligibility, exclusions, loadings, risk recommendations'
      ]
    }
  },
  {
    title: 'Contact Centre Intelligence Dashboard',
    area: 'Legal',
    icon: <BarChart2 size={24} />,
    description: 'Analyzes call recordings and transcripts to generate AI-powered summaries, issue tagging, agent QA scoring, sentiment tracking, and performance dashboards.',
    buttonText: 'Explore',
    tags: ['Legal', 'Compliance', 'Credit Ops'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📊',
      heading: 'Contact Centre Intelligence',
      subheading: 'AI Analytics for Contact Centers',
      points: [
        'Analyzes call recordings and transcripts',
        'AI-powered summaries and issue tagging',
        'Agent QA scoring and sentiment tracking',
        'Performance dashboards'
      ]
    }
  },

];

    

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {/* Login Navbar */}
            <LoginNavbar />
            {/* mm */}

            {/* Spacing below navbar */}
            <div className="flex-grow px-15 mx-auto py-3">
                {/* Header Section - Matching the image */}
                <div className="text-center">
                    <div className="flex flex-col items-center justify-center mt-8 mb-2">
                        <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                            <span style={{ color: '#e87722' }}>GenAI</span>
                            <span style={{ color: '#181f5a' }}> Sandbox</span>
                        </h1>
                    </div>
                    <div className="mb-8">
                        <span className="text-lg text-gray-700">
                            Explore AI-powered tools designed to transform business unit operations across industries.
                        </span>
                    </div>
                </div>

                {/* Solution Cards Section - Styled to match the image with reduced height and increased width appearance */}
                <Row
                        gutter={[16, 16]}
                        justify="center"
                        className="p-4"
                        style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                    >
                        {solutions.map((solution, index) => (
                      
                            <Col key={index} style={{ flex: "0 0 calc(20% - 16px)" }}>
    <Card
        className="relative w-full h-[360px] border-2 border-transparent rounded-lg shadow-md
            hover:shadow-lg transition-all duration-300 ease-in-out
            hover:!border-[#e87822] flex flex-col"
        bodyStyle={{ 
            height: "100%",
            display: 'flex', 
            flexDirection: 'column',
            overflow: 'hidden',
        }}
    >


        <div className="absolute top-2 right-2 z-10">
            
    
<Tooltip
  placement="topRight"
  color="white" 
  overlayInnerStyle={{
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    borderRadius: '10px',
    padding: '0', 
    maxWidth: '250px',
  }}
  title={
    <div className="p-[1px]">
  
      <div className="flex bg-[#f9fafb] rounded-md border-l-[4px] border-[#e87722] p-4">
        <div className="flex flex-col">
          <div className="font-bold text-[#181f5a] text-sm mb-1">
            {solution.tooltip.icon} {solution.tooltip.heading}
          </div>
          <div className="text-black text-xs font-semibold mb-2">
            {solution.tooltip.subheading}
          </div>
          <ul className="list-disc pl-5 space-y-1 text-xs text-gray-700">
            {solution.tooltip.points.map((point, idx) => (
              <li key={idx}>{point}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  }
>
  <Info className="text-[#e87722] hover:cursor-pointer" size={16} />
</Tooltip>


        </div>

        <div className="flex flex-col h-full mt-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#e8782222] mb-2">
                {React.cloneElement(solution.icon, {
                    size: 20,
                    className: "text-[#e87722]",
                })}
            </div>

            <div className="mb-3 min-h-[20px] flex gap-1 flex-wrap">
                {solution.tags?.map((tag, index) => (
                    <span key={index} className="inline-block bg-[#e8782222] text-[#e87722] text-xs font-medium px-2 py-0.5 rounded-md">
                        {tag}
                    </span>
                ))}
            </div>

            {/* Title */}
            <Title level={5} className="!text-lg !font-bold !mb-4 !text-gray-900" style={{ height: '40px', lineHeight: '1.2' }}>
                {solution.title}
            </Title>

            {/* Description */}
            <div 
                className="flex-grow mb-4 min-h-[100px] max-h-[100px]"
            >
                <Text className="text-gray-600 !text-xs leading-relaxed">
                    {solution.description}
                </Text>
            </div>

            {/* Button - Always at bottom */}
            <div className="mt-auto">
            {solution.title === "Virtual Insurance Assistant" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/insurance/virtual-assistant')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '32px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Voicebot with RAG Support" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/insurance/voicebot-rag-support')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '32px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Document Processing Assistant" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/insurance/document-processing')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '32px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Underwriting Decision Support Assistant" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/underwriting-decision-support')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '32px' }}
                >
                    {solution.buttonText}
                </button>
            ) : solution.title === "Contact Centre Intelligence Dashboard" ? (
                <button
                    onClick={() => navigate('/customer/sandbox/insurance/cci-dashboard')}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '32px' }}
                >
                    {solution.buttonText}
                </button>
            ) : (
                <Link
                    to={`/industryusecases/${solution.redirect}`}
                    className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                        hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                        !focus:ring-opacity-50 !transition-colors !duration-200"
                    style={{ height: '32px' }}
                >
                    {solution.buttonText}
                </Link>
            )}
            </div>
        </div>
    </Card>
</Col>
))}
                    </Row>
                </div>
                <InsuranceFooter />

            </div>

    );
};

export default GenAISandboxHome;