import React, { useEffect, useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import {
    Mic ,
    Edit3 ,
    BarChart2 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    FileText,
    Home,
    ClipboardCheck,
    PieChart,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../layout/LoginNavbar';
import InsuranceFooter from './InsuranceFooter';
import HomeCard from '../ui/HomeCard';

const GenAISandboxHome = () => {
    const navigate = useNavigate();
    const { projectType } = useAppContext();
    const [currentView, setCurrentView] = useState('home');

    useEffect(() => {
        console.log("🔍 Current Project Type from Context:", projectType);
    }, [projectType]);

const solutions = [
  {
    title: 'Virtual Insurance Assistant',
    area: 'Banking',
    icon: <MessageSquare size={24} />,
    description: 'Helps users discover relevant insurance products, view active policies, track and file claims, and schedule a human agent callback using RAG and tool calling.',
    buttonText: 'Try Now',
    tags: ['Customer Service', 'Sales'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'Virtual Insurance Assistant',
      subheading: 'AI Chatbot for Insurance',
      points: [
        'Discover insurance products',
        'View active policies',
        'Track and file claims',
        'Schedule agent callback',
        'Uses RAG and tool calling'
      ]
    }
  },
  {
    title: 'Voicebot with RAG Support',
    area: 'Contact Center',
    icon: <Sparkles size={24} />,
    description: 'Handles first-line customer queries via voice by retrieving answers from internal documents such as policy terms, claims procedures, and SOPs.',
    buttonText: 'Explore',
    tags: ['Contact Center', 'SME'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🗣️',
      heading: 'Voicebot with RAG',
      subheading: 'Voice AI for Insurance',
      points: [
        'Handles first-line queries via voice',
        'Retrieves answers from policy documents',
        'Supports claims procedures and SOPs'
      ]
    }
  },
  {
    title: 'Document Processing Assistant',
    area: 'Contact Center',
    icon: <FileText size={24} />,
    description: 'Extracts and infers structured data from key insurance documents like NRICs, payslips, bank statements, and medical reports for use in claims or underwriting workflows.',
    buttonText: 'Try Now',
    tags: ['Contact Center', 'QA', 'Training'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'Document Processing Assistant',
      subheading: 'AI Document Extraction',
      points: [
        'Extracts data from NRICs, payslips, bank statements, medical reports',
        'Supports claims and underwriting workflows'
      ]
    }
  },
  {
    title: 'Underwriting Decision Support Assistant',
    area: 'Legal',
    icon: <ClipboardCheck size={24} />,
    description: 'Collects applicant profile details and compares them against internal underwriting manuals to generate eligibility status, exclusions, loadings, and risk recommendations.',
    buttonText: 'Explore',
    tags: ['Legal', 'Compliance', 'Credit Ops'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'Underwriting Decision Support',
      subheading: 'AI for Underwriting',
      points: [
        'Collects applicant profile details',
        'Compares with underwriting manuals',
        'Generates eligibility, exclusions, loadings, risk recommendations'
      ]
    }
  },
  {
    title: 'Contact Centre Intelligence',
    area: 'Legal',
    icon: <BarChart2 size={24} />,
    description: 'Analyzes call recordings and transcripts to generate AI-powered summaries, issue tagging, agent QA scoring, sentiment tracking, and performance dashboards.',
    buttonText: 'Explore',
    tags: ['Legal', 'Compliance', 'Credit Ops'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'Contact Centre Intelligence',
      subheading: 'AI Analytics for Contact Centers',
      points: [
        'Analyzes call recordings and transcripts',
        'AI-powered summaries and issue tagging',
        'Agent QA scoring and sentiment tracking',
        'Performance dashboards and insights'
      ]
    }
  },
];

// Navigation handler for Insurance solutions
const handleInsuranceNavigation = (solution: any) => {
  switch (solution.title) {
    case "Virtual Insurance Assistant":
      navigate('/customer/sandbox/insurance/virtual-assistant');
      break;
    case "Voicebot with RAG Support":
      navigate('/customer/sandbox/insurance/voicebot-rag-support');
      break;
    case "Document Processing Assistant":
      navigate('/customer/sandbox/insurance/document-processing');
      break;
    case "Underwriting Decision Support Assistant":
      navigate('/customer/sandbox/underwriting-decision-support');
      break;
    case "Contact Centre Intelligence":
      navigate('/customer/sandbox/insurance/cci-dashboard');
      break;
    default:
      // Handle default case or external links
      break;
  }
};

return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Login Navbar */}
        <LoginNavbar />

        {/* Spacing below navbar */}
        <div className="flex-grow px-15 mx-auto py-3">
            {/* Header Section */}
            <div className="text-center">
                <div className="flex flex-col items-center justify-center mt-8 mb-2">
                    <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                        <span style={{ color: '#e87722' }}>GenAI</span>
                        <span style={{ color: '#181f5a' }}> Sandbox</span>
                    </h1>
                </div>
                <div className="mb-8">
                    <span className="text-lg text-gray-700">
                        Explore AI-powered tools designed to transform business unit operations across industries.
                    </span>
                </div>
            </div>

            {/* Solution Cards Section */}
            <div className="max-w-7xl mx-auto px-4">
                <Row
                    gutter={[16, 16]}
                    justify="center"
                    className="p-4"
                    style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                >
                    {solutions.map((solution, index) => (
                        <Col 
                            key={index} 
                            xs={24}
                            sm={24}
                            md={8}
                            lg={8}
                            xl={8}
                            style={{ 
                                marginBottom: "16px"
                            }}
                        >
                            <HomeCard
                                solution={solution}
                                cardHeight="h-[360px]"
                                buttonHeight="32px"
                                onNavigate={handleInsuranceNavigation}
                            />
                        </Col>
                    ))}
                </Row>
            </div>
        </div>
        <InsuranceFooter />
    </div>
);

};

export default GenAISandboxHome;