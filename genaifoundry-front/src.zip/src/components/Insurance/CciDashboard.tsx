import { Dot, Eye, MapPin, MessageSquareText, SquareUser, User, TrendingUp } from 'lucide-react'
import {  Row, Col, Table, Tag, Space } from 'antd'
import { Card } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import Sentimentchart from './SentimentChartInsurance';
import Knowledgechart from './KnowledgeChart';
import Total from './Total';
import Callchart from './CallChart';
// import { Link } from 'react-router-dom';
// import { useState } from 'react';

function CCIDashboard() {

  const navigate = useNavigate();
  const [historytdetails] = useState([{
    'dateandtime': '29 Apr 08:04:AM',
    'Name': 'Tan Wei Ming',
    'Number': '+6591234567',
    'Type': 'New',
    'Opportunity': 'Positive',
    'session_id': '5RWLIPMY'
  },
  {
    'dateandtime': '29 Apr 07:55:AM',
    'Name': 'Lim Mei Ling',
    'Number': '+6598765432',
    'Type': 'New',
    'Opportunity': 'Positive',
    'session_id': 'I0JJMOF0'
  },
  {
    'dateandtime': '23 Apr 12:01:PM',
    'Name': 'Goh Ah Keng',
    'Number': '+6592345678',
    'Type': 'New',
    'Opportunity': 'Positive',
    'session_id': 'sKG2R0Wj'
  }]);

  const [sentimentdetails ] = useState({'negative': 3 ,'neutral' : 21, 'positive' : 35, 'total' : 59});
  const [WeeklyKB] = useState({"Sunday": 1, "Monday": 3, "Tuesday": 6, "Wednesday": 5, "Thursday": 4, "Friday": 3, "Saturday": 2});
  const [calldetails] = useState({"Monday": 5, "Tuesday": 3, "Wednesday": 7, "Thursday": 2, "Friday": 6, "Saturday": 4});
  const [callcountdetails] = useState({new : 6, exist: 5});



  const columns = [
    {
      title: "Date & Time",
      dataIndex: "dateandtime",
      key: "dateandtime"
    },
    {
      title: "Number",
      dataIndex: "Number",
      key: "Number",
    },
    {
      title: "Type",
      dataIndex: "Type",
      key: "Type"
    },

    {
      title: "Opportunity",
      key: "Opportunity",
      align: "center" as const,
      dataIndex: "Opportunity",
      render: (opportunity: any) => (
        <Tag
          color={opportunity === "No" ? "red" : "green"}
          className="tag-dashboard"
        >
          {opportunity.toUpperCase()}
        </Tag>
      ),
    },
    {
      title: "Action",
      key: "action",
      align: "center" as const,
      render: (_: any, record: any) => (
        <Space size="middle">
          <span style={{ cursor: 'pointer' }} onClick={() => navigate(`/customer/sandbox/insurance/post-call-analysis/${record.session_id}`)}>
            <Eye style={{ color: '#4b5563', opacity: 1, width: '16px', height: '16px' }} />
          </span>
        </Space>
      ),
    },
  ];

  return (
    <>
      <Row className="px-4">
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} className="p-[12px]">
          <Card className="dashboard-card-table">
            <Card.Header className="bg-white cci-separator">
              <div className="d-flex align-items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                  <User size={16} className="text-white" />
                </div>
                <h5 className="mb-0 dashboard-card-title" style={{ color: '#000' }}>Agent Profile</h5>
              </div>
            </Card.Header>
            <Card.Body>
              <div className="pt-2 ps-4">
                <Row className="p-1 " gutter={[16, 16]}>
                  <Col span={12} className="p-2">
                    <div className="d-flex justify-content-start ps-2">
                      <div className="d-flex align-items-center px-1">
                        <User />
                      </div>
                      <div className=" px-1">
                        <div className="d-flex align-items-center">Name </div>
                        <div className="d-flex align-items-center profile-name">
                          <p>Tan Wei Ming</p>
                        </div>
                      </div>
                    </div>
                  </Col>
                  <Col span={12} className="p-2">
                    <div className="d-flex justify-content-start ps-2">
                      <div className="d-flex align-items-center px-1">
                        <SquareUser />
                      </div>
                      <div className=" px-1">
                        <div className="d-flex align-items-center">Role </div>
                        <div className="d-flex align-items-center text-capitalize profile-name">
                          <p>Senior Insurance Officer</p>
                        </div>
                      </div>
                    </div>
                  </Col>
                </Row>
                <Row className="p-1 " gutter={[16, 16]}>
                  <Col span={12} className="p-2">
                    <div className="d-flex justify-content-start ps-2">
                      <div className="d-flex align-items-center px-1">
                        <MessageSquareText />
                      </div>
                      <div className=" px-1">
                        <div className="d-flex align-items-center">Number</div>
                        <div className="d-flex align-items-center profile-name">
                          +6591234567
                        </div>
                      </div>
                    </div>
                  </Col>
                  <Col span={12} className="p-2">
                    <div className="d-flex justify-content-start ps-2">
                      <div className="d-flex align-items-center px-1">
                        <MapPin />
                      </div>
                      <div className=" px-1">
                        <div className="d-flex align-items-center">location</div>
                        <div className="d-flex align-items-center profile-name">
                          Singapore
                        </div>
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} className="p-[12px]">
          <Card className="dashboard-card-table">
            <Card.Header className="bg-white cci-separator">
              <div className="d-flex align-items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                  <MessageSquareText size={16} className="text-white" />
                </div>
                <h5 className="mb-0 dashboard-card-tabltitle" style={{ color: '#000' }}>Last Call History</h5>
              </div>
            </Card.Header>
            <Card.Body>
              <div className="px-2">
                <Table
                  columns={columns}
                  dataSource={historytdetails}
                  pagination={false}
                  className="dashboard-table"
                />
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row className="px-4">
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} className="p-[12px]">
          <Card className="dashboard-sec-card">
            <Card.Header className="bg-white cci-separator">
                <div className="d-flex align-items-center">
                  <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                    <TrendingUp size={16} className="text-white" />
                  </div>
                  <h5 className="mb-0 dashboard-card-tabltitle" style={{ color: '#000' }}>Sentiment</h5>
              </div>
            </Card.Header>
            <Card.Body>
              <Row>
                <Col
                  xxl={13}
                  xl={13}
                  lg={13}
                  md={24}
                  sm={24}
                  xs={24}
                  className="px-4 spacing !h-[150px]"
                >
                  <div className="d-flex justify-content-around call-card-mid">
                    <div className="d-flex justify-content-center">
                      <div className="px-2">
                        <Dot className='neutral-text'/>
                      </div>
                      <div className="px-2 call-text">Neutral Calls</div>
                    </div>
                    <div className="call-text-no">
                      55
                    </div>
                  </div>
                  <div className="d-flex justify-content-around call-card-pos">
                    <div className="d-flex justify-content-center">
                      <div className="px-2">
                        <Dot className="pos-text" />
                      </div>
                      <div className="px-2 call-text">Positive Calls</div>
                    </div>
                    <div className="call-text-no">1</div>
                  </div>
                  <div className="d-flex justify-content-around call-card-neg">
                    <div className="d-flex justify-content-center">
                      <div className="px-2">
                        <Dot className="neg-text" />
                      </div>
                      <div className="px-2 call-text">Negative Calls</div>
                    </div>
                    <div className="call-text-no">3</div>
                  </div>
                </Col>
                <Col xxl={11} xl={11} lg={11} md={24} sm={24} xs={24} className='!h-[150px]'>
                  <div className="d-flex justify-content-center">
                    <Sentimentchart sentimentdetails={sentimentdetails} />
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>

        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} className="p-[12px]">
          <Card className="dashboard-sec-card">
            <Card.Header className="bg-white cci-separator">
              <div className="d-flex align-items-center">
                <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                  <MessageSquareText size={16} className="text-white" />
                </div>
                <h5 className="mb-0 dashboard-card-tabltitle" style={{ color: '#000' }}>Knowledge Base Usage</h5>
              </div>
            </Card.Header>
            <Card.Body>
              <Knowledgechart WeeklyKB={WeeklyKB} />
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row className="px-4">
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} className="p-[12px]">
          <Card className="dashboard-sec-card">
            <Card.Header className="bg-white cci-separator">
                              <div className="d-flex align-items-center">
                  <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                    <MessageSquareText size={16} className="text-white" />
                  </div>
                  <h5 className="mb-0 dashboard-card-tabltitle" style={{ color: '#000' }}>Today New Existing Calls</h5>
                </div>
            </Card.Header>
            <Card.Body>
              <Row>
                <Col
                  xxl={13}
                  xl={13}
                  lg={13}
                  md={24}
                  sm={24}
                  xs={24}
                  className="p-1"
                >
                  <div className="px-4">
                    <div className="d-flex justify-content-around call-card-mid">
                      <div className="d-flex justify-content-center">
                        <div className="px-2">
                          <Dot className="neutral-text" />
                        </div>
                        <div className="px-2 call-text">Total Calls</div>
                      </div>
                      <div className="call-text-no">11</div>
                    </div>
                    <div className="d-flex justify-content-around call-card-new">
                      <div className="d-flex justify-content-center">
                        <div className="px-2">
                          <Dot className="new-text" />
                        </div>
                        <div className="px-2 call-text">New Calls</div>
                      </div>
                      <div className="call-text-no">6</div>
                    </div>
                    <div className="d-flex justify-content-around call-card-exs">
                      <div className="d-flex justify-content-center">
                        <div className="px-2">
                          <Dot className="exs-text" />
                        </div>
                        <div className="px-2 call-text">Existing Calls</div>
                      </div>
                      <div className="call-text-no">5</div>
                    </div>
                  </div>
                </Col>
                <Col xxl={11} xl={11} lg={11} md={24} sm={24} xs={24}>
                  <div className="p-1">
                    <Callchart callcountdetails={callcountdetails} />
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>
        <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} className="p-[12px]">
          <Card className="dashboard-sec-card">
            <Card.Header className="bg-white cci-separator">
                              <div className="d-flex align-items-center">
                  <div className="w-6 h-6 bg-orange-500 rounded flex items-center justify-center me-3">
                    <TrendingUp size={16} className="text-white" />
                  </div>
                  <h5 className="mb-0 dashboard-card-tabltitle" style={{ color: '#000' }}>Call by Week</h5>
                </div>
            </Card.Header>
            <Card.Body>
              <Total calldetails={calldetails} />
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </>
  )
}

export default CCIDashboard
