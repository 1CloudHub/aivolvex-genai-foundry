// src/pages/PostCall/mockdata.ts

export const mockPostCallRecords = {
    summary: "The customer contacted the contact centre to enquire about available life insurance policies. The agent provided detailed information about the 'Family Protection Plan', including coverage benefits, contribution options, and eligibility criteria. The customer expressed interest and requested a follow-up with a licensed advisor to proceed with enrollment.",
    title: "Life Insurance Policy Enquiry",
    product: "Family Protection Plan",
    issue_resolved: "Information Provided",
    callback: "Yes – Scheduled with Advisor",
    customer_name: "Tan Wei Ming",
    phone_number: "+6591234567",
    account_number: "SGP-98234761",
    current_plan: "Not Enrolled",
    joined_date: "March 15 2023",
    recent_tickets: "Health Plan Enquiry (Resolved)",
    action_items: "Schedule advisor callback and email policy brochure",
    stream_output_s3path: "",
  };
  
  export const mockQaCheck = "Completed";
  export const mockQaCheckStatus = [
    ["Professional Greeting", "Yes"],
    ["Accuracy of Information", "Yes"],
    ["Customer Verification", "No"],
    ["Empathy Displayed", "Yes"],
    ["Communication Clarity", "Yes"],
    ["Efficient Query Resolution", "Yes"],
    ["Compliance with Procedures", "Yes"],
    ["Effective Call Management", "Yes"],
    ["Appropriate Upselling Cross Selling", "Yes"],
    ["Professional Closure and Follow Up", "Yes"],
  ];
  
  export const mockCallSummaryRecords = [
    {
      opportunity_status: "positive",
      opportunity_tag: "Policy Interest Captured",
      transcript: "I'm looking for a life insurance plan for my family. Can you tell me what options are available?",
    },
    {
      opportunity_status: "negative",
      opportunity_tag: "Missed Compliance Check",
      transcript: "The agent did not perform the mandatory KYC verification before sharing policy details.",
    },
  ];
  
  export const mockChatMessages = [
    { type: "agent", message: "Hi, how can I help you today?" },
    { type: "ans", message: "Hello! My internet has been really slow today. Can you please help me out?" },
  ];
  
  export const mockTranscript = [
    {
      speaker: "SPEAKER_00", // Client
      transcript: "Hi, I was looking to understand your life insurance options. Can someone help me with that?",
      Opportunity_status: "positive",
      sentiment_status: "Neutral",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01", // Agent
      transcript: "Absolutely, I’d be happy to assist you. Are you looking for individual coverage or a family protection plan?",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "I’m mainly interested in something that would cover my family in case something happens to me.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01",
      transcript: "Understood. In that case, the Family Protection Plan would be ideal. It includes coverage up to SGD 1,000,000 and other great benefits.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "That sounds good. What would the monthly contributions look like?",
      Opportunity_status: "positive",
      sentiment_status: "Neutral",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01",
      transcript: "Contributions start from SGD 150 per month depending on your age and coverage amount. I can send a brochure with full details.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "Yes, please do. Also, can someone reach out to help me enroll?",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01",
      transcript: "Certainly. I’ll schedule a callback with one of our licensed advisors. Is tomorrow morning okay?",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "Perfect. Thanks for your help.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
  ];
   
  
  export const mockKBListData = [
    { type: "agent", message: "please tell me more about the Ultra Plan" },
  {
    type: "ans",
    message: "The Family Protection Plan includes the following features: - Coverage: Up to SGD 1,000,000 - Contribution: Starting from SGD 150/month - Eligibility: Individuals aged 18 to 60 - Benefits: Comprehensive coverage, Maturity payout, Death and disability benefit, Family support fund, Hassle-free claims process, Dedicated advisor support"
  }
  ];
  
  export const mockCallHistoryData = [
    {
      title: "Tan Wei Ming",
      phone_number: "+6591234567",
      created_at: "2024-06-01T10:00:00Z",
      session_id: "session1",
    },
    {
      title: "Lim Mei Ling",
      phone_number: "+6598765432",
      created_at: "2024-06-02T11:30:00Z",
      session_id: "session2",
    },
  ];
  
  export const mockSummaryDetails = [
    {
      title: "Internet Upgrade Call",
      summary: "Customer called to upgrade their internet plan. Agent provided details and processed the upgrade.",
      sentiment_status: "Positive",
      sentiment: "The customer was satisfied with the service.",
      opportunity_status: "Upgrade Offered",
      opportunity: "Agent offered an upgrade to the Ultra Plan.",
      qa_check: JSON.stringify({
        "Professional Greeting": "Yes",
        "Accuracy of Information": "Yes",
        "Customer Verification": "No",
        "Empathy Displayed": "Yes",
        "Communication Clarity": "Yes",
        "Efficient Query Resolution": "Yes",
        "Compliance with Procedures": "Yes",
        "Effective Call Management": "Yes",
        "Appropriate Upselling Cross Selling": "Yes",
        "Professional Closure and Follow Up": "Yes"
      })
    }
  ];
  
  export const mockSentimentChartData = [
    {
      name: "Agent",
      data: [0, 0, 3, 3, 4, 4, 4, 3, 3, 4, 4, 3], // generally calm, supportive, and professional
    },
    {
      name: "Client",
      data: [-2, 0, 2, 3, 3, 4, 4, 3, 3, 3, 2, 2], // starts neutral, gets more engaged, ends calm
    },
  ];
  
  export const mockXAxisData = [
    "00:00:01.000",
    "00:00:02.000",
    "00:00:03.000",
    "00:00:04.000",
    "00:00:05.000",
    "00:00:06.000",
    "00:00:07.000",
    "00:00:08.000",
    "00:00:09.000",
    "00:00:10.000",
    "00:00:11.000",
    "00:00:12.000",
  ]; 