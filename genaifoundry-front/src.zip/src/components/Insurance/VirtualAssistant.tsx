import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Home } from 'lucide-react';
import ConversationalAssistantTool from './VirtualAssistantTool';
import LoginNavbar from '../layout/LoginNavbar';
import InsuranceFooter from './InsuranceFooter';

const ConversationalAssistantPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <LoginNavbar />
      <div className="flex-grow container mx-auto px-4 py-4">
        <div className="mx-auto w-full max-w-10xl mt-8">
          <div className="mb-4">
            <div className="w-full">
              <nav className="flex text-sm text-gray-500 mb-2 -mt-6 -ml-5" aria-label="Breadcrumb">
                <ol className="inline-flex items-center space-x-1">
                  <li>
                    <Link to="/customer/sandbox/insurancehome" className="flex items-center gap-2 text-orange-600 no-underline">
                      <Home size={16} className="relative top-[-1px]" />
                      <span>Home</span>
                    </Link>
                  </li>
                  <li>
                    <span className="mx-2">/</span>
                    <span className="text-gray-500">Virtual Insurance Assistant</span>
                  </li>
                </ol>
              </nav>
              <div className="flex items-center mb-2">
                <div className="ub-feature-icon mr-3">
                  <MessageSquare size={30} />
                </div>
                <div>
                  <h2 className="mb-0 text-3xl font-bold">Virtual Insurance Assistant</h2>
                  <p className="text-gray-500">Enables users to discover insurance products, manage policies, file claims, and schedule agent callbacks using RAG and tool-based automation</p>
                </div>
              </div>
            </div>
          </div>
          
          <ConversationalAssistantTool />
        </div>
      </div>
      <InsuranceFooter />
    </div>
  );
};

export default ConversationalAssistantPage;