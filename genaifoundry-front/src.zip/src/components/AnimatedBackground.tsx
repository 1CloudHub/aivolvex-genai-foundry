import React from 'react';
import { motion } from 'framer-motion';

// Generate random values for each particle
const getRandom = (min: number, max: number) => Math.random() * (max - min) + min;

const particles = Array.from({ length: 20 }, (_, i) => {
  const left = getRandom(0, 100);
  const top = getRandom(0, 100);
  const x = getRandom(-60, 60);
  const y = getRandom(-60, 60);
  const scale1 = getRandom(0.8, 1.2);
  const scale2 = getRandom(1.3, 1.7);
  const duration = getRandom(3, 6);
  const size = getRandom(32, 72); // px (increased size)
  return (
    <motion.div
      key={i}
      className="absolute bg-[#F97316] rounded-full opacity-40 pointer-events-none"
      style={{
        left: `${left}%`,
        top: `${top}%`,
        width: `${size}px`,
        height: `${size}px`,
      }}
      animate={{
        x: [0, x],
        y: [0, y],
        scale: [scale1, scale2, scale1],
      }}
      transition={{
        duration,
        repeat: Infinity,
        repeatType: 'reverse',
        ease: 'easeInOut',
      }}
    />
  );
});

/**
 * Animated background with orange circles and fade effect for login screens.
 * Absolutely positioned, non-interactive, and sits behind content.
 */
export default function AnimatedBackground() {
  return (
    <div
      className="fixed inset-0 w-full h-full -z-10 overflow-hidden pointer-events-none"
      aria-hidden="true"
    >
      {particles}
      {/* Subtle radial fade overlay */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          background:
            'radial-gradient(ellipse at 60% 40%, rgba(255, 186, 120, 0.08) 0%, transparent 70%)',
        }}
    />
    </div>
  );
} 