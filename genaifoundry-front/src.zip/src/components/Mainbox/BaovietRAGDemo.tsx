import React, { useState, useRef, useEffect } from 'react';
import { Button, Input, Typography, Card, Avatar, Spin, message, Divider, Row, Col } from 'antd';
import { UserOutlined, SendOutlined, InfoCircleOutlined, ClockCircleOutlined, CheckCircleOutlined, MessageOutlined, HomeOutlined } from '@ant-design/icons';
import { FileText, Sparkles, UserSearch, Shield, Zap, BookOpen, Bot, PackageSearch, User } from 'lucide-react';
import { Breadcrumb } from "antd";
// import Navbar from './Navbar';
// import Footer from './Footer';
import { Tooltip } from "antd";
import { Info } from 'lucide-react';
import LoginNavbar from '../layout/LoginNavbar';
import Footer from '../Mainbox/Footer'
import { useNavigate } from 'react-router-dom';

const { Title, Text } = Typography;
const { TextArea } = Input;

// Mock knowledge base data - in a real app this would come from your API
const mockKnowledgeBase = [
  {
    id: 'doc-001',
    title: 'Health Insurance',
    category: 'Health',
    src: '/MainboxDoc/Health_Insurance.pdf',
    lastUpdated: '2024-06-01',
    snippet: 'Comprehensive guide to health insurance policies.'
  },
  {
    id: 'doc-003',
    title: 'Vehicle Insurance',
    category: 'Automotive',
    src: '/MainboxDoc/Vehicle_Insurance.pdf',
    lastUpdated: '2024-05-15',
    snippet: 'Covers all aspects of vehicle insurance.'
  },
  {
    id: 'doc-002',
    title: 'Home Insurance',
    category: 'Property',
    src: '/MainboxDoc/Home_Insurance.pdf',
    lastUpdated: '2024-04-20',
    snippet: 'Protect your home with our insurance plans.'
  }
];

const BaovietRAGDemo = () => {
    const [loading, setLoading] = useState(false);
    const [messageInput, setMessageInput] = useState('');
    const [streamingText, setStreamingText] = useState('');
    const [isStreaming, setIsStreaming] = useState(false);

    const [conversation, setConversation] = useState([
        {
            id: 1,
            sender: 'bot',
            text: 'Xin chào! Tôi là Trợ lý PolicyPal. Tôi có thể giúp gì cho bạn về bảo hiểm hôm nay?',
            timestamp: new Date()
        }
    ]);
    const [activeDocuments, setActiveDocuments] = useState(mockKnowledgeBase);

    const chatContainerRef = useRef<HTMLDivElement | null>(null);
    const messagesEndRef = useRef<HTMLDivElement | null>(null);
    const hasScrolledRef = useRef(false); // to track if scroll has already happened

    const scrollToBottom = () => {
    if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
    };

    useEffect(() => {
    if (!hasScrolledRef.current && conversation.length === 1) {
        // first message, skip scrolling
        return;
    }

    scrollToBottom();
    hasScrolledRef.current = true;
    }, [conversation]);

    const navigate = useNavigate();

    const fetchAIResponse = async (query: string) => {
        try {
            const response = await fetch('https://pl8rboai9k.execute-api.us-east-1.amazonaws.com/prod/upload', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: query
                })
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            
            let responseBody;
            if (typeof data.body === 'string') {
                try {
                    responseBody = JSON.parse(data.body);
                } catch (e) {
                    responseBody = data.body;
                }
            } else {
                responseBody = data.body;
            }

            // In a real app, you would update activeDocuments with the actual documents referenced
            // For now we'll just rotate through our mock documents
            setActiveDocuments(prev => {
                const newDocs = [...mockKnowledgeBase];
                return newDocs.sort(() => 0.5 - Math.random()).slice(0, 3);
            });

            return {
                text: responseBody.response || responseBody.body?.response || "I couldn't find an answer to that question."
            };
        } catch (error) {
            console.error('Error fetching AI response:', error);
            return {
                text: "Sorry, I'm having trouble connecting to the knowledge base. Please try again later."
            };
        }
    };

   const handleSendMessage = async () => {
    if (!messageInput.trim()) {
        message.warning('Please enter a message');
        return;
    }

    const userMessage = {
        id: conversation.length + 1,
        sender: 'user',
        text: messageInput,
        timestamp: new Date()
    };

    setConversation(prev => [...prev, userMessage]);
    setMessageInput('');
    setLoading(true);
    setIsStreaming(true);
    setStreamingText('');

    try {
        const aiResponse = await fetchAIResponse(messageInput);
        const fullText = aiResponse.text;

        let currentText = '';
        let index = 0;

        const interval = setInterval(() => {
            if (index < fullText.length) {
                currentText += fullText[index];
                setStreamingText(currentText);
                index++;
            } else {
                clearInterval(interval);
                const botMessage = {
                    id: conversation.length + 2,
                    sender: 'bot',
                    text: fullText,
                    timestamp: new Date()
                };
                setConversation(prev => [...prev, botMessage]);
                setStreamingText('');
                setIsStreaming(false);
            }
        }, 30); // Adjust speed here
    } catch (error) {
        console.error('Error handling message:', error);
        message.error('Failed to get response from AI');
        setIsStreaming(false);
    } finally {
        setLoading(false);
    }
};


    return (
        <>
        <LoginNavbar />
        {/* <Navbar/> */}
        <div className="min-h-screen bg-gray-50">
            <div className="bg-white px-8 pt-6">
                <Breadcrumb>
                  <Breadcrumb.Item onClick={() => navigate('/customer/sandbox')} className="text-black hover:text-[#e87722] cursor-pointer">
                    <HomeOutlined />
                    <span className="ml-1">Home</span>
                  </Breadcrumb.Item>
                  <Breadcrumb.Item className="text-orange-500 font-semibold">
                    PolicyPal Assistant
                  </Breadcrumb.Item>
                </Breadcrumb>
            </div>

            {/* Main Content Area with Two Columns */}
            <div className="max-w-7xl mx-auto p-6 ">
                <Row gutter={24}>
                    {/* Chat Column (Left) */}
                    <Col xs={24} md={16}>
                        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden h-full">
                            {/* Chat Header */}
                            <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                                <div className="flex items-center gap-2">
                                    <div className="flex items-center">
                                        <PackageSearch className="text-[#e87722] mr-3 text-xl" />
                                        <Text strong className="text-lg text-gray-800">PolicyPal Assistant</Text>
                                    </div>
                                    <Tooltip title="Ask me anything about Insurance policies. I'll find the most relevant information for you.">
                                        <Info className="text-[#e87722] mr-3 hover:cursor-pointer" size={16}/>
                                    </Tooltip>
                                </div>
                            </div>

                            {/* Chat Messages */}
                            <div className="h-96 overflow-y-auto p-6" ref={chatContainerRef}>
                                <div className="space-y-6">
                                    {conversation.map((msg) => (
                                        <div 
                                            key={msg.id} 
                                            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                                        >
                                            <div className={`max-w-[70%] ${msg.sender === 'user' ? 'order-2' : 'order-1'}`}>
                                                <div className="flex items-start mb-2">
                                                    {msg.sender === 'bot' ? (
                                                        <>
                                                            <div className="w-10 h-10 bg-[#e8782244] text-[#e87722] rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                                                                <MessageOutlined className="text-white text-sm" />
                                                            </div>
                                                            <div className='rounded-lg p-4 bg-gray-50 border border-gray-200'>
                                                                <Text className="text-gray-800">{msg.text}</Text>
                                                            </div>
                                                        </>
                                                    ) : (
                                                        <>
                                                            <div className='rounded-lg p-4 bg-[#e8782244] border border-[#e87722]'>
                                                                <Text className="text-gray-800">{msg.text}</Text>
                                                            </div>
                                                            <div className="w-10 h-10 bg-[#e8782244] text-[#e87722] rounded-full flex items-center justify-center ml-3 flex-shrink-0">
                                                                <UserOutlined className="text-white text-sm" />
                                                            </div>
                                                        </>
                                                    )}
                                                </div>
                                                <Text type="secondary" className="text-xs ml-13">
                                                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                </Text>
                                            </div>
                                        </div>
                                    ))}
                                    {isStreaming && streamingText && (
                                        <div className="flex justify-start">
                                            <div className="max-w-[70%]">
                                                <div className="rounded-lg p-4 bg-gray-50 border border-gray-200">
                                                    <Text className="text-gray-800">{streamingText}</Text>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    {loading && (
                                        <div className="flex justify-start">
                                            <div className="flex items-start">
                                                <div className="w-10 h-10 bg-[#e87722] rounded-full flex items-center justify-center mr-3">
                                                    <Bot className="text-white text-sm" />
                                                </div>
                                                <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                                    <Spin size="small" className="mr-2" />
                                                    <Text type="secondary">Thinking...</Text>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    <div ref={messagesEndRef} />
                                </div>
                            </div>
                            <div className="m-2">
                                <div className="flex gap-2 overflow-x-auto">
                                    {[
                                        "Khi mua bảo hiểm y tế, cần phải thực hiện thủ tục gì?",
                                        // "Một số loại trừ phổ biến trong hợp đồng bảo hiểm sức khỏe tiêu chuẩn là gì?",
                                        "Số tiền bảo hiểm cho hợp đồng bảo hiểm nhà được tính như thế nào?",
                                        "Cần những giấy tờ gì để nộp đơn yêu cầu bảo hiểm y tế?"
                                    ].map((question) => (
                                        <Button
                                            key={question}
                                            className="!bg-white !text-[#e87722] !border-[#e87722] hover:!bg-[#e87722] hover:!text-white text-left py-3 px-4 rounded-lg transition-all duration-200 shadow-sm hover:shadow-md whitespace-normal flex-shrink-0"
                                            onClick={() => setMessageInput(question)}
                                        >
                                            <span className="text-xs leading-relaxed block">{question}</span>
                                        </Button>
                                    ))}
                                </div>
                            </div>
                            {/* Input Area */}
                            <div className="border-t border-gray-200 p-6 bg-white">
                                <div className="flex items-end gap-3">
                                    <div className="flex-1 relative" style={{marginTop:'1rem'}}>
                                        <Input
                                            value={messageInput}
                                            onChange={(e) => setMessageInput(e.target.value)}
                                            placeholder="Type your message here..."
                                            className="h-12 text-base border-gray-300 rounded-lg"
                                            onPressEnter={(e) => {
                                                if (!e.shiftKey) {
                                                    e.preventDefault();
                                                    handleSendMessage();
                                                }
                                            }}
                                        />
                                    </div>
                                    <Button
                                        type="primary"
                                        icon={<SendOutlined />}
                                        onClick={handleSendMessage}
                                        className="h-12 w-12 bg-orange-100 border-orange-200 text-[#e87722] hover:bg-orange-200 hover:border-orange-300 rounded-full"
                                        disabled={!messageInput.trim()}
                                        size="large"
                                    />
                                </div>
                            </div>
                        </div>
                    </Col>

                    {/* Knowledge Base Column (Right) */}
                    <Col xs={24} md={8}>
                        <Row>
                            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden h-full">
                                {/* Knowledge Base Header */}
                                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 rounded-t-xl">
                                    <div className="flex items-center gap-2">
                                        <FileText className="text-[#e87722] text-xl" />
                                        <span className="font-semibold text-lg text-gray-800">Document Directory</span>
                                        <Tooltip title="These are the documents currently being referenced by the assistant">
                                            <Info className="text-[#e87722] ml-1 hover:cursor-pointer" size={18}/>
                                        </Tooltip>
                                    </div>
                                </div>
                                {/* Knowledge Base Content */}
                                <div className="p-4 overflow-y-auto" style={{ maxHeight: '400px' }}>
                                    <Text type="secondary" className="block mb-4 text-sm">
                                        The assistant references these documents to provide accurate answers to your questions.
                                    </Text>
                                    <div className="flex flex-col gap-3">
                                        {activeDocuments.map((doc) => (
                                            <div
                                                key={doc.id}
                                                className="flex items-center bg-[#f9fafb] rounded-xl border border-[#f3f4f6] px-4 py-3 shadow-sm hover:shadow-md transition cursor-pointer group"
                                                onClick={() => doc.src && window.open(doc.src, '_blank')}
                                            >
                                                <div className="flex items-center justify-center w-9 h-9 rounded-md bg-[#fbbf24]/20 mr-3">
                                                    <FileText className="text-[#e87722] text-lg" />
                                                </div>
                                                <span className="font-semibold text-base text-gray-800 group-hover:text-[#e87722]">
                                                    {doc.title}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </Row>
                        <Row>
                            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 mt-4">
                                {/* Optional Features Header */}
                                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                                    <div className="flex items-center gap-2">
                                        <FileText className="text-[#e87722] mr-3 text-xl" />
                                        <Text strong className="text-lg text-gray-800">Optional Features</Text>
                                    </div>
                                </div>

                                {/* Optional Features Content */}
                                <div className="p-6">
                                    <div className="space-y-4">
                                        {[
                                            'Intelligent Knowledge Optimization',
                                            'Compliance & Audit Tracking',
                                            'Role-Based Access Control (RBAC)',
                                            'Budget Monitoring',
                                            'Interaction Quality Logging'
                                        ].map((feature) => (
                                            <div key={feature} className="flex items-center">
                                                <CheckCircleOutlined className="!text-green-500 mr-3 text-lg" />
                                                <Text className="text-gray-700 text-base">{feature}</Text>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </Row>
                    </Col>
                </Row>
            </div>
            
        </div>
        <Footer/>
        </>
    );
};

export default BaovietRAGDemo;