import React, { useState } from 'react';
import { Upload, Card, Layout, Typography, Space, message, Button, Table, Tooltip, Modal, Breadcrumb } from 'antd';
import { InboxOutlined, UploadOutlined, VideoCameraOutlined, CloseCircleOutlined, PlayCircleOutlined, HomeOutlined } from '@ant-design/icons';
import inputVideo from '../../../public/MainboxDoc/Outputfile.mp4';
import outputVideo from '../../../public/MainboxDoc/Inputfile.mp4';
import { PlaySquare, ImageIcon, Sparkles, ClipboardCheck, Database, FileText, Code2, PlayCircle, Captions, FileOutput, FileInput } from 'lucide-react';
import type { UploadChangeParam,UploadFile } from 'antd/es/upload';
// import type { UploadFile } from 'antd/es/upload';
import Footer from './Footer';
import LoginNavbar from '../layout/LoginNavbar';
import { Link } from 'react-router-dom';

const { Title, Text } = Typography;
const { Dragger } = Upload;

const PRIMARY_COLOR = '#F76B00';

type UploadedVideo = {
  key: string;
  uploadDateTime: string;
  fileName: string;
  videoOverview: string;
  inputVideo: string;
  outputVideo: string;
};

const VideoUploader = () => {
  const [fileList, setFileList] = useState<UploadFile<any>[]>([]);
  const [uploadedVideos, setUploadedVideos] = useState<UploadedVideo[]>([]);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewVideo, setPreviewVideo] = useState('');
  

  const handleFileChange = (info: UploadChangeParam) => {
    let newFileList = [...info.fileList];
    newFileList = newFileList.slice(-1); 

    newFileList = newFileList.map(file => ({
      ...file,
      status: file.status || 'done',
    }));

    setFileList(newFileList);
  };

  const handleSubmit = () => {
    if (fileList.length > 0) {
      const file = fileList[0];
      const newVideoRecord = {
        key: file.uid,
        uploadDateTime: new Date().toLocaleString(),
        fileName: file.name,
        videoOverview: "Hello, everyone. Welcome back to CNN 10. I'm Coy Wire. Hope you had an awesome weekend and you enjoyed falling back, feeling refreshed after turning back those clocks getting an extra hour of sleep. We had daylight saving time in the wee hours of yesterday morning and for the two states that don't do daylight saving Arizona and Hawaii. Sorry to bring it up. Hope you're still feeling fresh and ready to start this week off strong. All right, tomorrow is Election day in the US. So the next two episodes will be election themed special editions examining America heading to the polls today though. Let's start by checking in on the country of Spain which is recovering from what their prime minister says is the worst natural disaster to affect the country in recent history. More than 200 people have been killed. Hundreds more still missing this after storms concentrated over the two river basins and produced walls of water that overflowed river banks, catching people off guard late Tuesday evening and early on Wednesday, Cnn's Atika Schubert has more on the situation in a dystopian scene of Spain's deadliest floods in decades, dozens of cars and debris are piled on top of what was a railroad in eastern Spain with a year's worth of rainfall plummeting down in just hours. On Tuesday, hundreds of people have been killed according to authorities and the death toll is only expected to rise. The extreme weather has caused a surge of water to break bridges, damaging homes and cars along the way with the floods turning gray roads into a muddy brown. These satellite images taken less than two weeks apart show the sheer level of destruction the floods have left behind but now armed with broom sticks and shovels, locals have been coming in droves to clean up the streets. Some tell us how they turned up just to help people suffering and everything. There have been widespread concerns about official warning systems. Many residents saying they were alerted too late, the storm hit in the morning but the water didn't get to us until eight in the evening yet, nobody warned us nothing, nobody cared. At 70 years old, I had to go with these old clothes to change, but I haven't even been able to take a shower. This children's school was also affected by the tragedy. Its interior severely damaged. You can see how high the waters were more than chest high, higher than a child. And this is a school. All of this equipment we are told is brand new and it's been completely destroyed by the mud and the flooding from the river Spanish Prime Minister Pedro Sanchez has called this Spain's worst natural disaster in a century. And eu officials warned of the flood's wider implication is not really affect all of us in the wake of the destruction. The Spanish government says it has deployed more than 1000 soldiers to help the clean up and rescue efforts. But as more rainfall is expected in the coming days, meteorologists say this human made crisis is only going to get worse. Next, we get a bit of food for thought from one of the greatest athletes the world has ever seen superstar. Gymnast Simone Biles and her Olympic teammate Jordan childs. I caught up with them recently to feature them in our new CNN series visionaries by now, you likely know the story. As young girls, Simone and her sister Adria spent time in foster care before being adopted by their grandparents, Nelly and Ron Biles whom they now call mom and dad. Simone began gymnastics at six years old, bursting onto the world scene in 2013 before making her Olympic debut three years later in Rio at the age of 19. All right. Speaking of youngsters, I had to spin through the old CNN archives 2017. And Simone, you shared what you would have told your younger self. You said if I could say anything to my younger self, it stop being so stubborn because I was a very stubborn kid. Very crazy too. So, so I think that kind of halted a bit of stuff. But I think it turned out for the best with everything that's happened since seven years later. What would you tell yourself? Now? Still, I feel like there are times where we give a lot of pushback because we're so afraid of what's going to happen. So to just not be anxious and to relax a little bit, obviously, there's more that goes on behind that, but we are so grateful to be in a position where we have amazing resources to help us. Um So it's just like for me now, it's just being vulnerable and asking for help. Simone's close friend and teammate Jordan Childs is a two time Olympian in Tokyo in Paris. Now at the age of 23 she's found herself center stage like never before, including besides Simone on the gold over America tour post Paris Jordan. What would you tell your younger self my younger self? I definitely could say just to understand the word. No, I did have a lot of times where I would just say yes to everything and being able just to follow the path that you wanted to go in and not really what everybody is creating for you. Um And always just let people in, I think that's where the help comes into play because I, when I was younger, I did not want help from anybody. Um But just, you know, to really look back and be like, ok, your journey and your path is something that you should write for yourself and kind of just let it ride in the way that you want to write. And, you know, I look at my life as puzzle, just put the puzzle pieces in the right spot and just let it all create itself. So I'm happy that now where I am now, I'm able to actually say that because when I was younger, I think that was something I, you know, I was silent so I couldn't really speak how I wanted to speak. The, the vulnerability comes into play for sure. 12th trivia, what us president is featured on the dime Franklin D Roosevelt, Abraham Lincoln, George Washington or Grover Cleveland. If you said FDR, you are correct. The 32nd president of the United States has been on the front of the dime since 1946. Today's story getting a 10 out of 10. When is a dime not worth 10 cents? Apparently when it's worth half a million bucks because it's missing a single letter. Our Jeremy Roth explains. Take a look at an ultra rare dime that just sold for half a million dollars. Let me explain. Normally, the ubiquitous 10 cent piece is well a dime, a dozen, so to speak. Nothing special. But according to auction house great collections, this 1975 dime is a very rare exception. Indeed. Why? Because of this, the absence of a tiny letter s that adorns all dimes struck at the US proof mint in San Francisco. See there it is right there. Great collections says the Sless dime is infinitely rarer with this error. It's certainly more interesting or should I say Ting? In fact, it's one of only two examples known to exist and was purchased by an Ohio family in 1978 and held for almost 50 years before being consigned and garnering more than 200 bids ultimately selling for a record setting 506,000 and change. See what I did there. All right, superstars time for the best part of the show. You shout out time now and this one goes to Lowndes Academy, Lowndes Borough, Alabama. We hope you and everyone watching. Have an awesome day. Let's rise up and do it again tomorrow. I'm Coy Wire and we are CNN 10.",
        inputVideo: inputVideo, // Using imported input video
        outputVideo: outputVideo, // Using imported output video
      };
      setUploadedVideos(prev => [...prev, newVideoRecord]);
      message.success(`${file.name} video uploaded successfully.`);
      setFileList([]); // Clear file list after submission
    } else {
      message.error('Please select a video file to upload.');
    }
  };

  const handleVideoPreview = (videoUrl: string) => {
    setPreviewVideo(videoUrl);
    setPreviewVisible(true);
  };

  const uploadProps = {
    name: 'file',
    multiple: false,
    accept: 'video/*',
    fileList: fileList,
    onChange: handleFileChange,
    beforeUpload: (file: UploadFile<any>) => {
      const isVideo = file.type && file.type.startsWith('video/');
      if (!isVideo) {
        message.error('You can only upload video files!');
        return Upload.LIST_IGNORE;
      }
      return false; // Prevent auto upload
    },
    maxCount: 1,
    showUploadList: false,
  };

  const columns = [
    {
      title: 'Date & Time',
      dataIndex: 'uploadDateTime',
      key: 'uploadDateTime',
    },
    {
      title: 'File Name',
      dataIndex: 'fileName',
      key: 'fileName',
    },
   
    {
      title: 'Audio Transcript',
      dataIndex: 'videoOverview',
      key: 'videoOverview',
      render: (text:string) => {
        const truncatedText = text.length > 50 ? `${text.substring(0, 50)}...` : text;
        return (
          <Tooltip
            title={<div style={{ maxWidth: 500, maxHeight: 200, overflow: 'auto', color: '#333' }}>{text}</div>}
            overlayStyle={{ 
              maxWidth: '420px',
              backgroundColor: '#fff',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
              borderRadius: '8px'
            }}
            className='h-10'
            color="#fff"
          >
            <span>{truncatedText}</span>
          </Tooltip>
        );
      },
    }
,    
    {
      title: 'Input Video',
      dataIndex: 'inputVideo',
      key: 'inputVideo',
      render: (text:string) => (
        <PlayCircleOutlined 
          style={{ fontSize: '24px', color: PRIMARY_COLOR, cursor: 'pointer' }}
          onClick={() => handleVideoPreview(text)}
        />
      ),
    },
    {
      title: 'Audio Highlight',
      dataIndex: 'outputVideo',
      key: 'outputVideo',
      render: (text:string) => (
        <PlayCircleOutlined 
          style={{ fontSize: '24px', color: PRIMARY_COLOR, cursor: 'pointer' }}
          onClick={() => handleVideoPreview(text)}
        />
      ),
    },
  ];

  return (
    <>
      <LoginNavbar />
      <Layout className=" px-0 !bg-white">
        <div className="px-20">
          <div className="pt-5 pl-6 border-r border-blue-100 ">
            <Breadcrumb>
              <Breadcrumb.Item className="text-black">
                <Link to="/customer/sandbox" className="flex items-center">
                  <HomeOutlined />
                  <span className="ml-1">Home</span>
                </Link>
              </Breadcrumb.Item>
              <Breadcrumb.Item className="text-orange-500 font-semibold">
                Logistics
              </Breadcrumb.Item>
            </Breadcrumb>
          </div>
          <div className="flex mt-4 px-5">
            <PlaySquare className="text-[#e87722] mr-3 " size={28} />
            <Title level={3} className="text-blue-800 ">VideoInsight Studio</Title>
          </div>
          <div className='px-4'>
            <div className="grid grid-cols-4 gap-4 ">
              <Card className="shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center mb-2">
                  <PlayCircle className="text-[#e87722] mr-2" />
                  <Text strong>Video Upload</Text>
                </div>
                <Text type="secondary">
                  Drag-and-drop or browse to upload Media video files.
                </Text>
              </Card>

             
    <Card className="shadow-sm hover:shadow-md transition-shadow">
        <div className="flex items-center mb-2">
          <Captions className="text-[#e87722] mr-2" />
          <Text strong>Audio Transcript</Text>
        </div>
        <Text type="secondary">
    Automatically converts video speech to text and displays it in an interactive transcript viewer.    </Text>
      </Card>
       <Card className="shadow-sm hover:shadow-md transition-shadow">
        <div className="flex items-center mb-2">
          <FileInput className="text-[#e87722] mr-2" />
          <Text strong>Input Video</Text>
        </div>
        <Text type="secondary">
Shows your original upload and provides processed files for download.    </Text>
      </Card>
      <Card className="shadow-sm hover:shadow-md transition-shadow">
        <div className="flex items-center mb-2">
          <FileOutput className="text-[#e87722] mr-2" />
          <Text strong>Video Highlight</Text>
        </div>
        <Text type="secondary">
Summarize the video content by extracting highlights from the lengthy audio.    </Text>
      </Card>

      
    </div>
    <div className='mt-3'>
          <Card >
            <Space direction="vertical" size="large" style={{ width: '100%' }} >
              {/* <Title level={4} style={{ textAlign: 'center' }}>Video Summarization</Title> */}
              <div className='p-2 rounded-lg'>
                <Dragger {...uploadProps} disabled={fileList.length > 0}>
                  <p className="ant-upload-drag-icon">
                    <VideoCameraOutlined style={{ fontSize: '48px', color: PRIMARY_COLOR }} />
                  </p>
                  <p className="ant-upload-text">Click or drag video file to this area to upload</p>
                  <p className="ant-upload-hint">Support for a single video file upload</p>
                </Dragger>
              </div>
              {fileList.length > 0 && (
                <div style={{ textAlign: 'center', marginTop: '16px' }}>
                  <Card size="small" style={{
                    marginBottom: '16px',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    width: '100%',
                  }}>
                    <Space size="small" style={{
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      width: '100%',
                      gap: '8px',
                    }}>
                      <VideoCameraOutlined style={{ fontSize: '20px' }} />
                      <Text style={{
                        wordBreak: 'break-all',
                        textAlign: 'center',
                        flex: 1,
                        margin: 0,
                      }}>{fileList[0].name}</Text>
                      <CloseCircleOutlined 
                        onClick={() => setFileList([])}
                        className="remove-icon"
                        style={{
                          fontSize: '16px',
                          cursor: 'pointer',
                          color: PRIMARY_COLOR,
                          transition: 'color 0.3s',
                        }}
                      />
                    </Space>
                  </Card>
                  <Button
                    type="primary"
                    icon={<UploadOutlined />}
                    onClick={handleSubmit}
                    size="large"
                    style={{
                      backgroundColor: PRIMARY_COLOR,
                      borderColor: PRIMARY_COLOR,
                    }}
                  >
                    Upload Video
                  </Button>
                </div>
              )}

              {/* <Title level={4} style={{ textAlign: 'center', marginTop: '32px' }}>Video Records</Title> */}
              <Card 
                style={{
                  borderRadius: '8px',
                  boxShadow: '0 4px 8px rgba(0, 0, 0, 0.05)',
                  border: '1px solid #e0e0e0',
                  width: '100%'
                }}
                bodyStyle={{ padding: '0' }}
              >
                <Table 
                  dataSource={uploadedVideos} 
                  columns={columns} 
                  pagination={false}
                  rowKey="key"
                  style={{ width: '100%' }}
                />
              </Card>

              <Modal
                title="Video Preview"
                open={previewVisible}
                onCancel={() => setPreviewVisible(false)}
                footer={null}
                width={800}
              >
                <video
                  controls
                  style={{ width: '100%' }}
                  src={previewVideo}
                >
                  Your browser does not support the video tag.
                </video>
              </Modal>

            </Space>
          </Card>
          </div>
        </div>
      </div>
      <div className='mt-2'><Footer /></div>
    </Layout>
  </>
);
};

export default VideoUploader; 