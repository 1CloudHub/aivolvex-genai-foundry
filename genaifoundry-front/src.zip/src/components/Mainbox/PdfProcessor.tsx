import React, { useState } from 'react';
import { Breadcrumb, Card, Layout, Typography, Empty, Divider } from 'antd';
import { FileText, ClipboardCheck, Database, Code2, Clock,  Plane, Receipt, PackageSearch } from 'lucide-react';
import { CheckCircleOutlined, HomeOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

import Packing from '../../../public/MainboxDoc/PL_SAMPLE_01.pdf';
import BOL from '../../../public/MainboxDoc/BOL_SAMPLE_01.pdf';
import Invoice from '../../../public/MainboxDoc/INV_SAMPLE_04.pdf';
import AWB from '../../../public/MainboxDoc/AWB_SAMPLE_01.pdf';

import Footer from './Footer';
import LoginNavbar from '../layout/LoginNavbar';

const { Content } = Layout;
const { Text } = Typography;

const billOfLadingTypes = {
  upload: {
    name: "Packing List",
    path: Packing,
    description: "A logistics document that itemizes the contents of a shipment"
  },
  validation: {
    name: "Bill of Lading",
    path: BOL,
    description: "A transport document that serves as a contract and receipt for goods shipped"
  },
  extraction: {
    name: "Invoice",
    path: Invoice,
    description: "A commercial document that specifies the value of goods for payment and customs"
  },
  jsonOutput: {
    name: "Air Waybill",
    path: AWB,
    description: "An air transport document with shipping and delivery details"
  }
};

// Static JSON responses for each document type with exactly 15 fields each
const jsonResponses = {
  upload: {
    "Document Type": "CONTAINER PACKING LIST",
    "Document Pages": "1 of 1",
    "Exporter Name": "The Electric Shop",
    "Exporter Address": "1 Plate Street, Brisbane, QLD, 4300, Australia",
    "Inco Docs Number": "INCO-3764-CIRA-5789",
    "Bill Of Lading Number": "SHATSV173288",
    "Consignee Name": "The SwitchGear CO. LTD",
    "Consignee Address": "Xiao Dong Shan Xiamen, Fujian, 361006, China",
    "Vessel Name": "Seamax Stanford",
    "Voyage Number": "638E",
    "Port Of Loading": "Brisbane",
    "Port Of Discharge": "Shanghai",
    "Container Number": "TFCU456789",
    "SealNumber": "215365",
    "Goods Description": "Lightbulb 2 x 37 watt, Elecwire 20m, Cable wire 40m",
    "Total Packages": 245,
    "Gross Weight": "1820.00 KG",
    "Net Weight": "1730.00 KG",
    "Volume": "23.15 CBM",
    "Issue Date": "21 JUN 2017",
    "Issue Place": "Brisbane",
    "Additional Notes": "Please note fragile.",
    "filename": "packing_list.pdf",
    "uploaded Time": new Date().toLocaleTimeString(),
    "processing Time": 1.8
  },
  validation: {
    "Document Type": "BILL OF LADING",
    "Shipper Name": "GALLAGHER TRANSPORT",
    "Shipper Address": "P.O. BOX 39005, DENVER, CO 80239",
    "Consignee Name": "GALLAGHER'S INTL EMPORIUM",
    "Consignee Address": "BLANGO 1279, VALPARAISO CEP239005 BRAZIL",
    "BOL Number": "GALT ST33L3RS",
    "Forwarding Agent": "GALLAGHER TRANSPORT INTL",
    "Origin Port": "COLORADO",
    "Origin Country": "UNITED STATES OF AMERICA",
    "Loading Port": "DIRECT VESSEL/MIAMI, V.1111",
    "Discharge Port": "SAO PAULO",
    "Vessel Name": "V.1111",
    "Container Number": "CATU123456-7/40",
    "Seal Number": "N/A",
    "Goods Description": "SAID TO CONTAIN GOLDEN FISH RODS FOR PIRANHA FISHING",
    "Total Packages": "253 PCS",
    "Gross Weight": "23000 KG",
    "Net Weight": "N/A",
    "Volume": "19.75 CBM",
    "Freight Charges": "3,050.00 USD",
    "Issue Date": "Aug 26, 2008",
    "file name": "bill_of_lading.pdf",
    "uploaded Time": new Date().toLocaleTimeString(),
    "processing Time": 2.1
  },
  extraction: {
    "Document Type": "COMMERCIAL INVOICE",
    "Invoice Number": "4646164",
    "Invoice Date": "08-03-2021",
    "Due Date": "15-03-2021",
    "Seller Name": "S.K.P.S DIGITAL",
    "Seller Address": "Okhla Industrial Area, New Delhi-110020",
    "Seller GST IN": "89889898989",
    "Buyer Name": "Nazim Khan",
    "Buyer Address": "Sector-200, Noida, U.P., Uttar Pradesh",
    "Buyer GST IN": "696969696969696969",
    "Item1": "ITEM NAME 2 - 26 PCS",
    "Item2": "ITEM NAME 3 - 2 PCS",
    "Item3": "ITEM NAME 4 - 50 PCS",
    "Item4": "ITEM NAME 5 - 15 PCS",
    "Sub total": "Rs. 34,914.52",
    "Discount": "Rs. 349.15",
    "Taxable Amount": "Rs. 34,565.37",
    "SGST": "Rs. 2,073.92",
    "CGST": "Rs. 3,110.88",
    "Total Amount": "Rs. 39,750.18",
    "Payment Terms": "To be paid in full in maximum 7 days",
    "file name": "invoice.pdf",
    "uploaded Time": new Date().toLocaleTimeString(),
    "processing Time": 1.5
  },
  jsonOutput: {
    "Document Type": "AIR WAYBILL",
    "AWBNumber": "312 MAA 9413 5646",
    "Shipper Name": "HEXAGON NUTRITION (EXPORTS) PRIVATE LIMITED",
    "Shipper Address": "PLOT NO. B11, PHASE 1, MEPZ-SEZ, TAMBARAM, CHENNAI - 600045, TAMIL NADU, INDIA",
    "Consignee Name": "PT DPD INDONESIA",
    "Consignee Address": "KOMP. DUTA INDAH ICONIC, UNIT C41-42, JL.M.H.THAMRIN, KEBON NANAS, RT.004/RW.002, PANUNGGANGAN UTARA, PINANG, TANGERANG BANTEN - 15143, INDONESIA",
    "Airline": "INDIGO AIRLINES",
    "Agent": "KERRY INDEV LOGISTICS PRIVATE LIMITED",
    "Departure Airport": "CHENNAI (MAA)",
    "Destination Airport": "CGK (JAKARTA, INDONESIA)",
    "Flight Number": "6E6623",
    "Flight Date": "15-NOV-23",
    "Total Packages": "2 CARTONS",
    "Goods Description": "50 KGS FORTIMIN-ZN (MINERAL PREMIX)",
    "Gross Weight": "55.000 KGS",
    "Net Weight": "50.000 KGS",
    "Dimensions": "(2) 60X46X26 CM",
    "HS CODE": "2817.00.10",
    "Freight Type": "PREPAID",
    "Issue Date": "15-NOV-23",
    "Issue Place": "CHENNAI",
    "file name": "air_waybill.pdf",
    "uploaded Time": new Date().toLocaleTimeString(),
    "processing Time": 1.2
  }
};

const BillOfLadingProcessor = () => {
  const [activeCard, setActiveCard] = useState<keyof typeof billOfLadingTypes | null>(null);
  const [extractedData, setExtractedData] = useState<Record<string, any> | null>(null);
const [loadingProgress, setLoadingProgress] = useState(0);
const [isProcessing, setIsProcessing] = useState(false);
const navigate = useNavigate();

  // const handleCardClick = (cardKey) => {
  //   setActiveCard(cardKey);
  //   setExtractedData(jsonResponses[cardKey]);
  // };

  const handleCardClick = (key: keyof typeof billOfLadingTypes) => {
  setActiveCard(key);
  setIsProcessing(true);
  setLoadingProgress(0);
  setExtractedData(null);

  let progress = 0;
  const interval = setInterval(() => {
    progress += 10;
    setLoadingProgress(progress);
    if (progress >= 100) {
      clearInterval(interval);
      setIsProcessing(false);
      setActiveCard(key); 
      setExtractedData(jsonResponses[key]); 
    }
  }, 200);
};


const getFieldLabels = (cardKey: keyof typeof billOfLadingTypes) => {
    const commonLabels = {
      "DocumentType": "Document Type",
      "filename": "File Name",
      "uploadedTime": "Upload Time"
    };

    const specificLabels = {
      upload: {
        "ExporterName": "Exporter Name",
        "ConsigneeName": "Consignee Name",
        "VesselName": "Vessel Name",
        "VoyageNumber": "Voyage Number",
        "PortOfLoading": "Port of Loading",
        "PortOfDischarge": "Port of Discharge",
        "ContainerNumber": "Container Number",
        "SealNumber": "Seal Number",
        "GoodsDescription": "Goods Description",
        "TotalPackages": "Total Packages",
        "GrossWeight": "Gross Weight",
        "NetWeight": "Net Weight",
        "Volume": "Volume",
        "IssueDate": "Issue Date"
      },
      validation: {
        "ShipperName": "Shipper Name",
        "ConsigneeName": "Consignee Name",
        "BOLNumber": "BOL Number",
        "OriginPort": "Origin Port",
        "LoadingPort": "Loading Port",
        "DischargePort": "Discharge Port",
        "VesselName": "Vessel Name",
        "ContainerNumber": "Container Number",
        "GoodsDescription": "Goods Description",
        "TotalPackages": "Total Packages",
        "GrossWeight": "Gross Weight",
        "Volume": "Volume",
        "FreightCharges": "Freight Charges",
        "IssueDate": "Issue Date"
      },
      extraction: {
        "InvoiceNumber": "Invoice Number",
        "InvoiceDate": "Invoice Date",
        "SellerName": "Seller Name",
        "BuyerName": "Buyer Name",
        "Item1": "Item 1",
        "Item2": "Item 2",
        "Item3": "Item 3",
        "Item4": "Item 4",
        "Subtotal": "Subtotal",
        "Discount": "Discount",
        "TaxableAmount": "Taxable Amount",
        "SGST": "SGST",
        "CGST": "CGST",
        "TotalAmount": "Total Amount",
        "PaymentTerms": "Payment Terms"
      },
      jsonOutput: {
        "AWBNumber": "AWB Number",
        "ShipperName": "Shipper Name",
        "ConsigneeName": "Consignee Name",
        "Airline": "Airline",
        "DepartureAirport": "Departure Airport",
        "DestinationAirport": "Destination Airport",
        "FlightNumber": "Flight Number",
        "FlightDate": "Flight Date",
        "TotalPackages": "Total Packages",
        "GoodsDescription": "Goods Description",
        "GrossWeight": "Gross Weight",
        "NetWeight": "Net Weight",
        "Dimensions": "Dimensions",
        "HSCODE": "HS Code",
        "IssueDate": "Issue Date"
      }
    };

    return {
      ...commonLabels,
      ...(specificLabels[cardKey] || {})
    };
  };


  const getDisplayFields = (data: Record<string, any>) => {
    if (!data) return [];
    const { filename, uploadedTime, processingTime, ...displayData } = data;
    return Object.entries(displayData).slice(0, 15); // Show exactly 15 fields
  };

  return (
    <>
    <LoginNavbar />
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="flex-grow flex flex-col items-center justify-start py-10 px-2">
        <div className="w-full max-w-7xl p-0">
          <div className="mb-2">
           <Breadcrumb>
              <Breadcrumb.Item className="text-black cursor-pointer" onClick={() => navigate('/customer/sandbox')}>
    <HomeOutlined />
    <span className="ml-1">Home</span>
  </Breadcrumb.Item>
  <Breadcrumb.Item className="text-orange-500 font-semibold">
  Logistics
  </Breadcrumb.Item>
</Breadcrumb>
      </div>
          <div className="flex items-start gap-4 mt-4">
        <div className="bg-[#e87722]/10 p-2 rounded-full">
          <FileText className="text-[#e87722]" size={28} />
        </div>
        <div>
          <h2 className="mb-0 font-bold text-4xl text-black font-sans">Bill of Lading Processor</h2>
          <p className="font-sans text-gray-600 text-base">
            View logistics documents and their AI-extracted key details in a single interface
          </p>
        </div>
      </div>
          <div className='pt-8 text-xl text-black font-semibold'>Select Document Pair</div>
          <div className="mt-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 ">
          {Object.entries(billOfLadingTypes).map(([key, value]) => (
            <Card
              key={key}
              style={activeCard === key ? { border: '1px solid #e87722' } : {}}
              className="shadow-sm transition-all duration-300 cursor-pointer hover:shadow-md"
                  onClick={() => handleCardClick(key as keyof typeof billOfLadingTypes)}
            >
              <div className="flex items-center mb-2">
                <div className={`mr-2 ${activeCard === key ? 'text-[#e87722]' : 'text-[#e87722]/80'}`}>
                  {key === 'upload' ? <PackageSearch /> :
                   key === 'validation' ? <FileText /> :
                   key === 'extraction' ? <Receipt /> : <Plane />}
                </div>
                <Text strong>
                  <div className='text-lg text-black font-semibold'>
                    {value.name}
                  </div>
                </Text>
              </div>
              <Text type='secondary'>
                <div className='font-sans text-gray-600 text-sm'>
                  {value.description}
                </div>
              </Text>
            </Card>
          ))}
        </div>
        {!activeCard && (
          <div className="text-center pt-10">
            <Empty description={<Text type="secondary">Select a document option to begin the extraction process</Text>} />
          </div>
        )}
        {activeCard && isProcessing && (
          <Card className="col-span-2 h-60 flex items-center justify-center">
            <div className="w-full px-10">
              <Text className="text-sm text-gray-600 mb-2 block text-center">Processing document...</Text>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-[#e87722] h-3 rounded-full transition-all duration-300"
                  style={{ width: `${loadingProgress}%` }}
                />
              </div>
            </div>
          </Card>
        )}
        {activeCard && !isProcessing && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                <Card title={<span className="text-lg text-black font-semibold">{billOfLadingTypes[activeCard].name}</span>}>
                  <div className="bg-gray-50 p-4 rounded h-[500px] flex items-center justify-center text-gray-800 text-xs border border-gray-200">
                <iframe
                  src={`${billOfLadingTypes[activeCard].path}#toolbar=0&navpanes=0&scrollbar=0`}
                      className="w-full h-full min-h-[400px]"
                  title="Bill of Lading Viewer"
                />
              </div>
              <div className="mt-4">
                <Text type="secondary">{billOfLadingTypes[activeCard].description}</Text>
              </div>
            </Card>
            <Card title={<span className="text-lg text-black font-semibold">Extracted Information</span>}>
              {extractedData ? (
                <>
                  <div className="space-y-4 text-gray-800 text-xs border border-gray-200 p-4 rounded h-150 overflow-y-auto">
                    {getDisplayFields(extractedData).map(([fieldKey, fieldValue]) => {
                          const label = getFieldLabels(activeCard)[fieldKey as keyof ReturnType<typeof getFieldLabels>] || fieldKey;
                      return (
                        <div className="flex justify-between" key={fieldKey}>
                          <div className="flex items-center gap-2">
                            <CheckCircleOutlined style={{ color: 'green' }} />
                            <Text>{label}</Text>
                          </div>
                          <Text strong className="text-right max-w-[60%]">
                            {Array.isArray(fieldValue)
                              ? fieldValue.join(', ')
                              : fieldValue !== null && fieldValue !== undefined
                                ? fieldValue.toString()
                                : '-'}
                          </Text>
                        </div>
                      );
                    })}
                  </div>
                </>
              ) : (
                <div className="text-gray-400 p-4 text-center">No data extracted yet.</div>
              )}
            </Card>
          </div>
        )}
          </div>
        </div>
  </div>
  <div className='mt-2'><Footer /></div>
    </div>
</>
  );
};

export default BillOfLadingProcessor;