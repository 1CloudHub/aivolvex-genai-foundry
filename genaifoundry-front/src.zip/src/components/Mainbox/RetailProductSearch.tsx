import React, { useState, useEffect } from 'react';
import { Camera, Headphones, Footprints, Image as ImageIcon } from 'lucide-react';
import { Upload, Button, Card, Image, Spin, Typography, Divider, List, message, Row, Col, Breadcrumb, Tag } from 'antd';
import { UploadOutlined, SearchOutlined, ShoppingCartOutlined, StarFilled, ThunderboltFilled, HomeOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';
// import { Camera, Headphones, Image as ImageIcon, Sparkles, ChevronRight, Footprints } from 'lucide-react';
// import Navbar from './Navbar';
import Footer from './Footer';
import LoginNavbar from '../layout/LoginNavbar';

const { Title, Text } = Typography;

const RetailProductSearch = () => {
    const [selectedProductCard, setSelectedProductCard] = useState<'headphone' | 'shoe' | 'camera' | null>(null);
    const [loading, setLoading] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    type Product = {
        id: number;
        name: string;
        price: number;
        rating: number;
        image: string;
        matches: number;
        description: string;
      };
      const [searchResults, setSearchResults] = useState<Product[]>([]);
    // const [selectedProductCard, setSelectedProductCard] = useState(null);

    const productCatalogs = {
        headphone: {
            preview: "https://m.media-amazon.com/images/I/61GywIq-pwL._SX679_.jpg",
            results: [
                {
                    id: 1,
                    name: "HyperX Cloud Stinger 2 Core Gaming Headset",
                    price: 29.22,
                    rating: 4.5,
                    image: "https://m.media-amazon.com/images/I/61GywIq-pwL._SX679_.jpg",
                    matches: 100,
                    description: "40mm sound drivers with powerful bass and wide frequency response."
                },
                {
                    id: 2,
                    name: "Sennheiser HD 599 Special Edition",
                    price: 105.13,
                    rating: 4.2,
                    image: "https://m.media-amazon.com/images/I/41nCPANcDKL._SX300_SY300_QL70_FMwebp_.jpg",
                    matches: 87,
                    description: "Premium open-back headphones with outstanding natural spatial performance."
                },
                {
                    id: 3,
                    name: "Razer Blackshark V2 X Gaming Headset",
                    price: 37.02,
                    rating: 4.7,
                    image: "https://m.media-amazon.com/images/I/61DHIJl0M7L._SX679_.jpg",
                    matches: 85,
                    description: "7.1 Surround Sound with custom-tuned 50mm drivers."
                }
            ]
        },
        shoe: {
            preview: "https://m.media-amazon.com/images/I/91gtt6wsBDL._AC_SX675_.jpg",
            results: [
                {
                    id: 4,
                    name: "Skechers Women's Hands Free Slip-ins Glide- Step - Excite Sneaker",
                    price: 63.00,
                    rating: 4.8,
                    image: "https://m.media-amazon.com/images/I/61MCamA1sjL._AC_SY675_.jpg",
                    matches: 95,
                    description: "Hands Free Slip-In Technology,Breathable leather lining,Flexible outsole"
 
 
                },
                {
                    id: 5,
                    name: "Glolily Elle Slip-On Women's Comfort Sneakers",
                    price: 39.99,
                    rating: 4.6,
                    image: "https://m.media-amazon.com/images/I/51pLHsAXyhL._AC_SY675_.jpg",
                    matches: 90,
                    description: "Orthotic Lightweight & Flexible Walking Shoes with Arch Support, Comfortable Casual Fashion Shoes for Women."
                },
                {
                    id: 6,
                    name: "Feethit Womens Slip On Walking Shoes ",
                    price: 36.99,
                    rating: 4.4,
                    image: "https://m.media-amazon.com/images/I/717hkMu0x2L._AC_SX675_.jpg",
                    matches: 88,
                    description: "Non Slip Running Shoes Breathable Workout Shoes Lightweight Gym Sneakers."
                }
            ]
        },
        camera: {
            preview: "https://m.media-amazon.com/images/I/81tgYgn0YBL.__AC_SY300_SX300_QL70_FMwebp_.jpg",
            results: [
                {
                    id: 7,
                    name: "Canon EOS Rebel T7 DSLR Camera with 18-55mm Lens | Built-in Wi-Fi | 24.1 MP CMOS Sensor",
                    price: 350.00,
                    rating: 4.7,
                    image: "https://m.media-amazon.com/images/I/61BKYlNqH6L._AC_SX679_.jpg",
                    matches: 93,
                    description: " 24.1 MP CMOS Sensor | DIGIC 4+ Image Processor and Full HD Videos"
                },
                {
                    id: 8,
                    name: "NIkon COOLPIX P950 Superzoom Digital Camera ",
                    price: 479.00,
                    rating: 4.5,
                    image: "https://m.media-amazon.com/images/I/71s89wc2L5L._AC_SX679_.jpg",
                    matches: 91,
                    description: "83x Optical Zoom with Image Stabilization 16 MP 4K Ultra HD Video Wi-Fi Connectivity RAW Format and Rotating LCD Screen (Black)"
                },
                {
                    id: 9,
                    name: "Sony Alpha 7 IV Full-frame Mirrorless Interchangeable Lens Camera",
                    price: 556.95,
                    rating: 4.6,
                    image: "https://m.media-amazon.com/images/I/71BaBwNek-L._AC_SX569_.jpg",
                    matches: 89,
                    description: "33MP full-frame Exmor R back-illuminated CMOS sensor."
                }
            ]
        }
    };

    useEffect(() => {
        handleProductCardClick('headphone');
    }, []);

    const handleProductCardClick = (productType: 'headphone' | 'shoe' | 'camera') => {
        setLoading(true);
        setTimeout(() => {
            setPreviewImage(productCatalogs[productType].preview);
            setSearchResults(productCatalogs[productType].results);
            setSelectedProductCard(productType);
            setLoading(false);
            message.success(`Showing ${productType === 'headphone' ? 'headphones' : productType + 's'}`);
        }, 800);
    };

    const renderRating = (rating: number) => {
        return (
            <div className="flex items-center bg-blue-50 px-2 py-1 rounded">
                <StarFilled className="text-yellow-400 mr-1" />
                <Text className="text-sm font-medium">{rating}</Text>
            </div>
        );
    };

    const renderMatchPercentage = (percentage:number) => {
        let color = '';
        if (percentage >= 90) color = 'green';
        else if (percentage >= 80) color = 'blue';
        else color = 'orange';
        
        return (
            <Tag color={color} className="text-xs font-medium">
                {percentage}% match
            </Tag>
        );
    };

    return (
        <>
        {/* Add Login Navbar */}
        <LoginNavbar />
        {/* <Navbar/> */}
        <div className="min-h-screen bg-gray-50">
            
            <main className="flex-grow">
                <div className="max-w-6xl mx-auto px-6 py-8">
                 

                    <Breadcrumb>
  <Breadcrumb.Item className="text-black">
    <Link to="/customer/sandbox" className="flex items-center">
      <HomeOutlined />
      <span className="ml-1">Home</span>
    </Link>
  </Breadcrumb.Item>
  <Breadcrumb.Item className="text-orange-500 font-semibold">
    Product Vision Search
  </Breadcrumb.Item>
</Breadcrumb>
                    <div className="flex items-center mt-4">
                        <div className="bg-[#e8782240] p-2 rounded-lg mr-4">
                            <SearchOutlined className="text-[#e87722] text-xl" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold text-gray-800">Product Vision Search</h1>
                            <p className="text-gray-600">Find similar products using visual search technology that analyzes features and matches against similar products</p>
                        </div>
                    </div>

                    <Card className="!border-0">
                        <div className="flex items-center mb-2">
                            <Camera className="text-[#e87722] mr-2" />
                            <h2 className="text-lg font-semibold text-gray-800">Select a product sample</h2>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            {[
                                { type: 'headphone', icon: <Headphones className="text-[#e87722]" />, label: "Gaming Headset" },
                                { type: 'shoe', icon: <Footprints className="text-[#e87722]" />, label: "Shoe" },
                                { type: 'camera', icon: <Camera className="text-[#e87722]" />, label: "Digital Camera" }
                            ].map((product) => (
                                <Card
                                    key={product.type}
                                    hoverable
                                    className={`transition-all duration-200 ${selectedProductCard === product.type ? 'border-2 border-orange-500' : 'border border-gray-200'}`}
                                    onClick={() => handleProductCardClick(product.type as 'headphone' | 'shoe' | 'camera')}
                                >
                                    <div className="flex flex-col items-center text-center">
                                        <div className="bg-blue-50 rounded-full mb-3">
                                            {product.icon}
                                        </div>
                                        <h3 className="font-medium text-gray-800">{product.label}</h3>
                                        
                                    </div>
                                </Card>
                            ))}
                        </div>
                    </Card>

                    <Divider className="!my-4" />

                    <Row gutter={[24, 24]}>
                        <Col xs={24} md={12}>
                            <Card className="h-full border-0 shadow-sm">
                                <div className="flex items-center mb-4">
                                    <ImageIcon className="text-[#e87722] mr-2" />
                                    <h2 className="text-lg font-semibold text-gray-800">Uploaded Product</h2>
                                </div>
                                {loading ? (
                                    <div className="flex items-center justify-center h-64">
                                        <Spin size="large" tip="Loading image..." />
                                    </div>
                                ) : (
                                    <div className="flex flex-col h-full">
                                        <div className="flex-grow flex items-center justify-center bg-gray-50 rounded-lg p-4 mb-4">
                                            <Image
                                                src={previewImage}
                                                alt="Selected product"
                                                className="max-h-80 object-contain"
                                                preview={false}
                                            />
                                        </div>
                                        
                                    </div>
                                )}
                            </Card>
                        </Col>

                        <Col xs={24} md={12}>
                            <Card className="h-full border-0 shadow-sm">
                                <div className="flex items-center justify-between mb-4">
                                    <div className="flex items-center">
                                        <SearchOutlined className="!text-[#e87722] mr-2" />
                                        <h2 className="text-lg font-semibold text-gray-800">Matching Products</h2>
                                    </div>
                                    <Tag color="#e87722">{searchResults.length} results</Tag>
                                </div>
                                {loading ? (
                                    <div className="flex items-center justify-center h-64">
                                        <Spin size="large" tip="Finding matches..." />
                                    </div>
                                ) : (
                                    <div className="h-[350px] overflow-y-auto pr-2">
                                        <List
                                            itemLayout="vertical"
                                            dataSource={searchResults}
                                            renderItem={(product) => (
                                                <List.Item className="!py-4 !px-0">
                                                    <Card hoverable className="border border-gray-100 shadow-xs">
                                                        <div className="flex flex-col sm:flex-row gap-4">
                                                            <div className="w-full sm:w-1/3">
                                                                <div className="relative">
                                                                    <Image
                                                                        src={product.image}
                                                                        alt={product.name}
                                                                        className="rounded-lg w-full"
                                                                        preview={false}
                                                                    />
                                                                    <div className="absolute top-2 right-2">
                                                                        {renderMatchPercentage(product.matches)}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="w-full sm:w-2/3">
                                                                <h3 className="font-medium text-gray-800 mb-2">{product.name}</h3>
                                                                <p className="text-gray-600 text-sm mb-3">{product.description}</p>
                                                                <div className="flex justify-between items-center">
                                                                    <p className="text-lg font-bold text-blue-600">${product.price}</p>
                                                                    <Button>
                                                                        Add to Cart
                                                                    </Button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </Card>
                                                </List.Item>
                                            )}
                                        />
                                    </div>
                                )}
                            </Card>
                        </Col>
                    </Row>
                </div>
            </main>

            <Footer/>
        </div>
        </>
    );
};

export default RetailProductSearch;