import { memo } from "react";
import SentimentChartAgent from "./SentimentChartAgent";

const SentimentChart = () => {
  return <SentimentChartAgent/>;
};

export default memo(SentimentChart);
