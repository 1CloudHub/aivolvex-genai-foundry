import { memo } from "react";
import { Avatar } from "antd";
import { Ticket } from "lucide-react";
import { mockTranscript } from "./mockdata";

const PCATranscript = () => {
  const Transcript = mockTranscript;
  return (
    <div className="post-call-transcript h173x ">
      {Array.isArray(Transcript)
        ? Transcript.map((msg, index) => (
            <div key={index}>
              {msg.speaker === "SPEAKER_00" ? (
                <div className="d-flex justify-content-start mt-2">
                  <div>
                    <Avatar className="pca-chatbot-ai" size="large">
                      C
                    </Avatar>
                  </div>
                  <div>
                    <div className="pca-ai-message" style={{ fontSize: '14px' }}>
                      {msg.transcript}
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  <div className="d-flex justify-content-end mt-2">
                    <div className="pca-ai-message-replay" style={{ fontSize: '14px' }}>
                      {msg.transcript}
                    </div>
                    <div>
                      <Avatar className="pca-chatbot-ai-replay" size="large">
                        A
                      </Avatar>
                    </div>
                  </div>
                  {msg.Ticket_Oppportunity === "Yes" && (
                    <Ticket size={24} className="ticket-client" />
                  )}
                </>
              )}
            </div>
          ))
        : null}
    </div>
  );
};

export default memo(PCATranscript);
