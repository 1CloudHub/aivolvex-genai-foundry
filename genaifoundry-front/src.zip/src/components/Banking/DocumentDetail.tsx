import React from 'react';

const DocumentDetail: React.FC = () => {
  return (
    <div 
      className="bg-white p-8 border border-gray-200 overflow-y-auto" 
      style={{ 
        height: '1122px', 
        scrollbarWidth: 'none',
        msOverflowStyle: 'none'
      }}
    >
      <style>{`
        .bg-white.p-8.border.border-gray-200.overflow-y-auto::-webkit-scrollbar {
          display: none;
        }
      `}</style>
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-xl font-bold uppercase text-gray-800">Container Packing List</h1>
        </div>
        <div className="text-right">
          <div className="text-sm">Page</div>
          <div className="text-sm font-semibold">1 of 1</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 text-xs mb-4">
        <div className="border border-gray-300 p-2">
          <div className="font-bold">Exporter</div>
          <p>The Electric Shop</p>
          <p>1 Plate Street</p>
          <p>Brisbane, QLD, 4300</p>
          <p>Australia</p>
        </div>
        <div className="space-y-1">
          <div className="grid grid-cols-2 border border-gray-300 p-2">
            <div className="font-bold">IncoDocs Number</div>
            <div>INCO-3764-CIRA-5789</div>
          </div>
          <div className="grid grid-cols-2 border border-gray-300 p-2">
            <div className="font-bold">Bill of Lading No</div>
            <div>SHATSV173288</div>
          </div>
          <div className="grid grid-cols-2 border border-gray-300 p-2">
            <div className="font-bold">Exporter Reference</div>
            <div>DB-12657</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 text-xs mb-4">
        <div className="border border-gray-300 p-2">
          <div className="font-bold">Consignee</div>
          <p>The SwitchGear CO. LTD</p>
          <p>Xiao Dong Shan Xiamen</p>
          <p>Fujian, 361006</p>
          <p>China</p>
        </div>
        <div className="border border-gray-300 p-2">
          <div className="font-bold">Buyer (if not Consignee)</div>
        </div>
      </div>
      
      <table className="w-full text-xs border-collapse border border-gray-300 mb-4">
        <thead>
          <tr>
            <th className="border border-gray-300 p-1 text-left font-bold">Method of Dispatch</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Type of Shipment</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Country of Origin of Goods</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Final Destination</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-gray-300 p-1">Sea</td>
            <td className="border border-gray-300 p-1">FCL</td>
            <td className="border border-gray-300 p-1">Australia</td>
            <td className="border border-gray-300 p-1">China</td>
          </tr>
        </tbody>
      </table>

      <table className="w-full text-xs border-collapse border border-gray-300 mb-4">
      <thead>
          <tr>
            <th className="border border-gray-300 p-1 text-left font-bold">Vessel / Aircraft</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Voyage No.</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Packing Information</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-gray-300 p-1">Seamax Stanford</td>
            <td className="border border-gray-300 p-1">638E</td>
            <td className="border border-gray-300 p-1">Goods packed with bubble wrap.</td>
          </tr>
        </tbody>
      </table>

      <table className="w-full text-xs border-collapse border border-gray-300 mb-4">
        <thead>
          <tr>
            <th className="border border-gray-300 p-1 text-left font-bold">Port of Loading</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Date of Departure</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Port of Discharge</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Final Destination</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-gray-300 p-1">Brisbane</td>
            <td className="border border-gray-300 p-1">22 JUN 2017</td>
            <td className="border border-gray-300 p-1">Shanghai</td>
            <td className="border border-gray-300 p-1">Shanghai</td>
          </tr>
        </tbody>
      </table>

      <table className="w-full text-xs border-collapse border border-gray-300 mb-4">
        <thead>
          <tr>
            <th className="border border-gray-300 p-1 text-left font-bold">Container No.</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Seal No.</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Description of Goods</th>
            <th className="border border-gray-300 p-1 text-left font-bold">No. of Packages</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Net Weight (kg)</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Gross Weight (kg)</th>
            <th className="border border-gray-300 p-1 text-left font-bold">Cube (m³)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-gray-300 p-1">TFCU456789</td>
            <td className="border border-gray-300 p-1">215365</td>
            <td className="border border-gray-300 p-1">Lightbulb 2 x 37 watt<br/>Elecwire 20m<br/>Cable wire 40m</td>
            <td className="border border-gray-300 p-1">245</td>
            <td className="border border-gray-300 p-1">1730.00</td>
            <td className="border border-gray-300 p-1">1820.00</td>
            <td className="border border-gray-300 p-1">23.15</td>
          </tr>
        </tbody>
      </table>

      <table className="w-full text-xs border-collapse border border-gray-300">
        <tbody>
          <tr>
            <td className="p-1 border border-gray-300">No of Containers This Page: 1</td>
            <td className="p-1 border border-gray-300">Total This Page</td>
            <td className="p-1 border border-gray-300 text-right">245</td>
            <td className="p-1 border border-gray-300 text-right">1730.00 kg</td>
            <td className="p-1 border border-gray-300 text-right">1820.00 kg</td>
            <td className="p-1 border border-gray-300 text-right">23.15 m³</td>
          </tr>
          <tr>
            <td className="p-1 border border-gray-300">No of Containers This Consignment: 1</td>
            <td className="p-1 border border-gray-300">Consignment Total</td>
            <td className="p-1 border border-gray-300 text-right">245</td>
            <td className="p-1 border border-gray-300 text-right">1730.00 kg</td>
            <td className="p-1 border border-gray-300 text-right">1820.00 kg</td>
            <td className="p-1 border border-gray-300 text-right">23.15 m³</td>
          </tr>
        </tbody>
      </table>

      {/* NRIC Explicit Extraction Section (bank statement style, final polish) */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Explicit Extraction</h2>
        <hr className="border-t border-gray-200 mb-2" />
        <table className="w-full text-base border-separate border-spacing-0">
          <thead>
            <tr>
              <th className="py-2 text-left font-bold text-gray-500">Field</th>
              <th className="py-2 text-right font-bold text-gray-500">Extracted Value</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-t border-gray-200">
              <td className="py-3 text-gray-900 text-left">Identity Card Number</td>
              <td className="py-3 text-gray-900 text-right font-normal">123456789</td>
            </tr>
            <tr className="border-t border-gray-200">
              <td className="py-3 text-gray-900 text-left">Name</td>
              <td className="py-3 text-gray-900 text-right font-normal">MARIE JUMIO</td>
            </tr>
            <tr className="border-t border-gray-200">
              <td className="py-3 text-gray-900 text-left">Race</td>
              <td className="py-3 text-gray-900 text-right font-normal">CHINESE</td>
            </tr>
            <tr className="border-t border-gray-200">
              <td className="py-3 text-gray-900 text-left">Sex</td>
              <td className="py-3 text-gray-900 text-right font-normal">F</td>
            </tr>
            <tr className="border-t border-gray-200">
              <td className="py-3 text-gray-900 text-left">Date of Birth</td>
              <td className="py-3 text-gray-900 text-right font-normal">1975-01-01</td>
            </tr>
            <tr className="border-t border-gray-200">
              <td className="py-3 text-gray-900 text-left">Country of Birth</td>
              <td className="py-3 text-gray-900 text-right font-normal">SINGAPORE</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DocumentDetail; 