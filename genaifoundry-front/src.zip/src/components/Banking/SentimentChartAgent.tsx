import React from "react";
import ReactApexChart from "react-apexcharts";
import { mockSentimentChartData, mockXAxisData } from "./mockdata";

const SentimentChartAgent: React.FC = () => {
  const options = {
    series: mockSentimentChartData,
    chart: {
      height: 350,
      type: "line",
      toolbar: {
        show: false,
      },
      zoom: {
        enabled: false,
      },
    },
    colors: ["#ff6b18", "#2D3748"],
    dataLabels: {
      enabled: false,
    },
    stroke: {
      curve: "smooth",
      width: 2,
    },
    title: {
      align: "left",
    },
    grid: {
      row: {
        colors: ["#f3f3f3", "transparent"],
        opacity: 0.5,
      },
      padding: { left: 10, right: 6, top: 6, bottom: -22 },
    },
    xaxis: {
      categories: mockXAxisData,
      labels: {
        style: {
          fontSize: "9px",
        },
      },
    },
  };

  return (
    <div id="chart">
      <ReactApexChart
        options={options}
        series={options.series}
        type="line"
        height={220}
      />
    </div>
  );
};

export default SentimentChartAgent;
