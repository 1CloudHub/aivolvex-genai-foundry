import Chart from "react-apexcharts";

const Callchart = (props: any) => {
  const series = [
    props.callcountdetails.exist ? props.callcountdetails.exist : 0,
    props.callcountdetails.new ? props.callcountdetails.new : 0,
  ];
  const labels = ["Existing calls", "New calls"];
  const chartOptions = {
    series: series,
    options: {
      chart: {
        type: "donut" as const,
        height: 300,
      },
      labels: labels,
      dataLabels: {
        enabled: false,
      },
      legend: {
        show: false,
      },
      colors: ["#F3722C", "#B7ABFF"],
      plotOptions: {
        pie: {
          donut: {
            labels: {
              show: true,
              name: {
                show: true,
                offsetY: 0,
                formatter: function (val: any) {
                  return val;
                },
              },
              value: {
                show: true,
                offsetY: 10,
                fontWeight: "500",
                formatter: function (val: any) {
                  return val;
                },
              },
              total: {
                show: true,
                showAlways: true,
                label: "Total Calls",
                color: "#373d3f",
                fontWeight: "500",
                fontSize: "12px",
                formatter: function (w: any) {
                  return w.globals.seriesTotals.reduce((a: any, b: any) => {
                    return a + b;
                  }, 0);
                },
              },
            },
          },
        },
      },
    },
  };
  return (
    <div>
      <Chart
        options={chartOptions.options}
        series={chartOptions.series}
        type="donut"
        height={145}
      />
    </div>
  );
};

export default Callchart;
