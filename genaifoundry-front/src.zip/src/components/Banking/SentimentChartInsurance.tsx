import Chart from "react-apexcharts";

const SentimentChart = (sentimentdetails: any) => {
  let negative = 1;
  let positive = 1;
  let neutral = 1;
  if (sentimentdetails && sentimentdetails.sentimentdetails) {
    const {
      negative: negValue = 0,
      positive: posValue = 0,
      neutral: neuValue = 0,
    } = sentimentdetails.sentimentdetails;
    negative = negValue;
    positive = posValue;
    neutral = neuValue;
  }

  const chartOptions = {
    series: [negative, positive, neutral],
    options: {
      chart: {
        type: "donut" as const,
      },
      plotOptions: {
        pie: {
          startAngle: -90,
          endAngle: 90,
          donut: {
            size: "60%",
          },
        },
        dataLabels: {
          enabled: false,
        },
      },
      dataLabels: {
        enabled: false,
      },
      labels: ["Negative", "Positive", "Neutral"],
      legend: {
        show: false,
      },
      colors: ["#F94144", "#34D32F", "#D6D6D6"],
      states: {
        hover: {
          filter: {
            type: "darken",

            value: 0.9,
          },
        },
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 200,
            },
          },
        },
      ],
    },
  };

  return (
    <div>
      <Chart
        options={chartOptions.options}
        series={chartOptions.series}
        type="donut"
        height={150}
      />
    </div>
  );
};

export default SentimentChart;
