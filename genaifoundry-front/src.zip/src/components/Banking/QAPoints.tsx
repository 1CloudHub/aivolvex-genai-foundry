import { memo } from "react";
import { Tag } from "antd";
import { CheckCircle, XCircle } from "lucide-react";
import { mockQaCheck, mockQaCheckStatus } from "./mockdata";

const QAPoints = () => {
  const QaCheck = mockQaCheck;
  const QaCheckStatus = mockQaCheckStatus;

  if (!QaCheck) return null;

  return (
    <>
      <div className="d-flex justify-content-between">
        <div className="pca-title">QA Check</div>
        <div>
          <Tag
            color={QaCheck.toLowerCase() === "completed" ? "green" : "red"}
            className="opp-tag">
            {QaCheck}
          </Tag>
        </div>
      </div>
      <div className="pca-qa-body">
        {QaCheckStatus.map(([key, value], index) => (
          <div key={key} style={{ fontSize: '12px' }}>
            {index + 1}. {key} &nbsp;&nbsp;
            {value === "Yes" ? (
              <CheckCircle className="qa-check-tick" size={18} color="#048800" />
            ) : (
              <XCircle className="qa-check-cross" size={18} color="#f94144" />
            )}
          </div>
        ))}
      </div>
    </>
  );
};

export default memo(QAPoints);

