import { Col, Row, Tabs } from "antd";
import { memo } from "react";
import { mockPostCallRecords } from "./mockdata";
import Card from "react-bootstrap/Card";

const Insights = () => {
  const postcallrecords = mockPostCallRecords;

  return (
    postcallrecords && (
      <div className="pca-insights-scroll">
        <div>
          <Row className="pca-df mt-2">
            <Col span={24} className="pca-label-content">
              {postcallrecords.summary}
            </Col>
          </Row>
          <Row className="pca-df mt-2">
            <Col span={7} className="pca-label-title">
              Topic :
            </Col>
            <Col span={17} className="pca-label-content">
              {postcallrecords.title}
            </Col>
          </Row>
          <Row className="pca-df mt-2">
            <Col span={7} className="pca-label-title">
              Product :
            </Col>
            <Col span={17} className="pca-label-content">
              {postcallrecords.product}
            </Col>
          </Row>
          <Row className="pca-df mt-2">
            <Col span={7} className="pca-label-title">
              Resolved :
            </Col>
            <Col span={17} className="pca-label-content">
              {postcallrecords.issue_resolved}
            </Col>
          </Row>
          <Row className="pca-df mt-2">
            <Col span={7} className="pca-label-title">
              Call Back :
            </Col>
            <Col span={17} className="pca-label-content">
              {postcallrecords.callback}
            </Col>
          </Row>
        </div>
        {/* <Tabs defaultActiveKey="1" items={items} className="pca-call-summary-tab mt-2" /> */}
      </div>
    )
  );
};

export default memo(Insights);
