import Chart from "react-apexcharts";

const Total = (props: any) => {
  const days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
  const days_condition = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  console.log(props.calldetails)
  const data = days_condition.map((day) => props.calldetails?.[day] || 0);
  const chartOptions = {
    chart: {
      height: 350,
      type: "line" as const,
      colors: "#F3722C",
      toolbar: { show: false },
    },
    stroke: {
      width: [2, 4],
    },
    
    markers: {
      size: [4, 7],
    },
    xaxis: {
      categories: days,
      labels: {
        style: {
          fontSize: "12px",
        },
      },
    },
    yaxis: {
      labels: {
        style: {
          fontSize: "12px",
        },
      },
    },
    grid: {
      borderColor: "#e0e0e0",
      row: {
        colors: ["#f3f3f3", "transparent"],
        opacity: 0.5,
      },
    },
  };

  const chartSeries = [
    {
      name: "Calls",
      data: data,
      color: "#F3722C",
    },
  ];
  console.log(data);
  return (
    <div className="line-chart">
      <Chart
        options={chartOptions}
        series={chartSeries}
        type="line"
        height={140}
      />
    </div>
  );
};

export default Total;
