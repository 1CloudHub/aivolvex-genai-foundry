import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Button,
  Separator,
  Input,
  Label,  
  Dialog,
  DialogTrigger,
  DialogContent,
  
} from '../ui/index';
import { documentTypes } from '../../components/Banking/documentData';
import DocumentDetail from '../../components/Banking/DocumentDetail';
  import {
    RefreshCw,
    Home as HomeIcon,
    BarChart3,
    CheckCircle,
  TrendingUp,
  Shield,
  AlertTriangle,
  FileText,
  Calculator,
  Target,
  Award,
  Clock,
  UserCheck,
  AlertCircle,
} from 'lucide-react';
import LoginNavbar from '../layout/LoginNavbar';
import Footer from '../Banking/BankingFooter';

// import DocumentTab from './DocumentTab';

import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';

// Add API response types
interface ApiRiskFactor {
  factor: string;
  severity: 'High' | 'Medium' | 'Low';
  description: string;
  impact: string;
}
interface ApiRecommendationOption {
  option: string;
  details: string;
}
interface ApiApprovalScenario {
  scenario_name: string;
  loan_amount: number;
  tenure: number;
  emi: number;
  total_emi: number;
  dti_ratio: string;
  conditions: string[];
}
interface ApiResponse {
  calculated_metrics: {
    emi_requested_loan: number;
    total_emi_burden: number;
    dti_ratio: string;
    ltv_ratio: string;
  };
  risk_assessment: {
    risk_score: number;
    risk_level: string;
    risk_summary: string;
  };
  risk_factors: ApiRiskFactor[];
  recommendations: {
    primary_recommendation: string;
    conditions: string[];
    alternative_options: ApiRecommendationOption[];
  };
  agent_comment_influence: {
    applied_adjustment: string;
    impact_summary: string;
  };
  approval_scenarios: ApiApprovalScenario[];
}

const Risk = () => {
  // Add styles for hiding scrollbar
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .modal-scrollbar-hide::-webkit-scrollbar {
        display: none;
      }
      .modal-scrollbar-hide {
        -ms-overflow-style: none;
        scrollbar-width: none;
      }
    `;
    document.head.appendChild(style);
    return () => {
      document.head.removeChild(style);
    };
  }, []);
  const navigate = useNavigate();
  const [apiData, setApiData] = useState<ApiResponse | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [activeTab, setActiveTab] = useState<'assessment' | 'documents'>('assessment');
  const [form, setForm] = useState({
    applicant_profile: {
      name: 'Aaron Goh',
      age: '39',
      occupation: 'Self-Employed (Event Logistics Support)',
      credit_score: '1660',
    },
    financials: {
      monthly_income: '5800',
      existing_emis: '950',
      net_pay: '4850',
    },
    loan_details: {
      loan_type: 'Secured Personal Loan',
      loan_purpose: 'Short-term cash flow for upcoming even',
      requested_amount: '6000',
      tenure_months: '3',
      interest_rate: '2.5',
    },
    collateral: {
      type: 'Vehicle',
      description: '2016 Toyota Altis (full ownership, maintained)',
      market_value: '14500',
      conditionVehicle: 'Good',
      ownership_proof: 'Yes',
    },
    agent_comments: 'Known customer. Has taken one short-term loan before and repaid early. Vehicle appraised by branch staff, and event work invoice shown as partial proof of upcoming income.',
  });

  // Show metrics card by default, hide risk items
  useEffect(() => {
    setShowResults(false);
  }, []);

  const handleRecalculate = async () => {
    setIsCalculating(true);
    setShowResults(false);
    // Build request body
    const payload = {
      event_type: 'risk_sandbox',
      applicant_profile: {
        name: form.applicant_profile.name,
        age: form.applicant_profile.age ? Number(form.applicant_profile.age) : null,
        occupation: form.applicant_profile.occupation,
        credit_score: form.applicant_profile.credit_score ? Number(form.applicant_profile.credit_score) : null
      },
      financials: {
        monthly_income: form.financials.monthly_income ? Number(form.financials.monthly_income) : null,
        existing_emis: form.financials.existing_emis ? Number(form.financials.existing_emis) : null,
        net_pay: form.financials.net_pay ? Number(form.financials.net_pay) : null
      },
      loan_details: {
        loan_type: form.loan_details.loan_type,
        loan_purpose: form.loan_details.loan_purpose,
        requested_amount: form.loan_details.requested_amount ? Number(form.loan_details.requested_amount) : null,
        tenure_months: form.loan_details.tenure_months ? Number(form.loan_details.tenure_months) : null,
        interest_rate: form.loan_details.interest_rate ? Number(form.loan_details.interest_rate) : null
      },
      collateral: {
        type: form.collateral.type,
        description: form.collateral.description,
        market_value: form.collateral.market_value ? Number(form.collateral.market_value) : null,
        conditionVehicle: form.collateral.conditionVehicle,
        ownership_proof: form.collateral.ownership_proof
      },
      agent_comments: form.agent_comments || null
    };
    console.log(payload,"body_applicant_data");
    try {
      const response = await fetch(import.meta.env.VITE_API_BASE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw new Error('API error');
      const data = await response.json();
      console.log(data,"data_resposnee");
      setApiData(data);
      setShowResults(true);
    } catch (err) {
      console.error('Failed to fetch risk assessment.', err);
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Login Navbar */}
      <LoginNavbar />
      {/* Spacing below navbar */}
      <div className="flex-grow px-15 mx-auto py-3">
        <div className="container py-6">
          {/* Breadcrumb */}
          <nav className="flex text-sm text-gray-500 mb-2 -ml-1" aria-label="Breadcrumb">
            <ol className="inline-flex items-center space-x-1">
              <li>
                <button 
                  type="button" 
                  onClick={() => navigate('/customer/sandbox/bankinghome')} 
                  className="flex items-center gap-2 text-orange-600 no-underline"
                  style={{ textDecoration: 'none', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
                >
                  <HomeIcon size={16} className="relative top-[-1px]" />
                  Home
                </button>
              </li>
              <li>
                <span className="mx-2">/</span>
                <span className="text-gray-500">RiskLens</span>
              </li>
            </ol>
          </nav>
          {/* Page Title and Subtitle */}
          <div className="flex items-center gap-6 mb-8">
            <div className="rounded-full bg-[#fbeee6] p-6 flex items-center justify-center">
              <BarChart3 className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Inter, sans-serif' }}>
                RiskLens
              </h1>
              <p className="text-lg text-gray-600">
              Automated risk assessment tool for personal loans, home loans, and credit card applications.
              </p>
            </div>
          </div>
          {/* Tabs centered below title/subtitle, above cards */}
          <div className="flex justify-center my-6" >
            <Tabs value={activeTab} onValueChange={value => setActiveTab(value as 'assessment' | 'documents')}>
              
              <TabsContent value="assessment" className="mt-8">
                <div className="container-custom">
                  {/* <h2 className="text-2xl font-bold text-gray-900 mb-4">Assessment Directory</h2> */}
                  <div className="max-w-8xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      {/* Left: Applicant Overview (now a full multi-section form) */}
                      <div>
                        <Card className="flex flex-col h-[99rem] border-0 rounded-2xl overflow-hidden bg-white risk-lens-card" style={{ 
                          transition: 'all 0.3s ease'
                        }}>
                          <CardHeader className="bg-white border-b border-gray-200 pb-2">
                            <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-800">
                              <div className="p-1.5 bg-[#e87722] rounded-lg">
                                <FileText className="h-4 w-4 text-white" />
                              </div>
                              Loan Application Form
                            </CardTitle>
                          </CardHeader>
                                                      <CardContent className="space-y-6 bg-white mt-6">
                            {/* Applicant Profile */}
                            <div>
                              <h3 className="text-base font-bold mb-2 flex items-center">Applicant Profile</h3>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Full Name <span className="text-red-500">*</span></Label>
                                <Input type="text" value={form.applicant_profile.name} onChange={e => setForm(f => ({...f, applicant_profile: {...f.applicant_profile, name: e.target.value}}))} placeholder="e.g., John Doe" required />
                              </div>
                              <div className="grid grid-cols-2 gap-4 mb-3">
                                <div>
                                  <Label className="block text-sm font-medium mb-1">Age <span className="text-red-500">*</span></Label>
                                  <Input type="text" value={form.applicant_profile.age} onChange={e => setForm(f => ({...f, applicant_profile: {...f.applicant_profile, age: e.target.value}}))} placeholder="e.g., 30" required />
                                </div>
                                <div>
                                  <Label className="block text-sm font-medium mb-1">Credit Score <span className="text-gray-400">(Optional)</span></Label>
                                  <Input type="text" value={form.applicant_profile.credit_score ?? ''} onChange={e => setForm(f => ({...f, applicant_profile: {...f.applicant_profile, credit_score: e.target.value}}))} placeholder="Optional" />
                                </div>
                              </div>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Occupation <span className="text-red-500">*</span></Label>
                                <Input type="text" value={form.applicant_profile.occupation} onChange={e => setForm(f => ({...f, applicant_profile: {...f.applicant_profile, occupation: e.target.value}}))} placeholder="e.g., Food Delivery Driver" required />
                              </div>
                            </div>
                            <div className="border-t my-2"></div>
                            {/* Financial Information */}
                            <div>
                              <h3 className="text-base font-bold mb-2 flex items-center">Financial Information</h3>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Monthly Income (SGD)</Label>
                                <Input type="text" value={form.financials.monthly_income ?? ''} onChange={e => setForm(f => ({...f, financials: {...f.financials, monthly_income: e.target.value}}))} placeholder="Optional" />
                              </div>
                              <div className="grid grid-cols-1 gap-4 mb-3">
                                <div>
                                  <Label className="block text-sm font-medium mb-1">Existing EMIs (SGD)</Label>
                                  <Input type="text" value={form.financials.existing_emis ?? ''} onChange={e => setForm(f => ({...f, financials: {...f.financials, existing_emis: e.target.value}}))} placeholder="Optional" />
                                </div>
                                
                              </div>
                            </div>
                            <div className="border-t my-2"></div>
                            {/* Loan Details */}
                            <div>
                              <h3 className="text-base font-bold mb-2 flex items-center">Loan Details</h3>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Loan Type <span className="text-red-500">*</span></Label>
                                <select
                                  value={form.loan_details.loan_type}
                                  onChange={e => setForm(f => ({...f, loan_details: {...f.loan_details, loan_type: e.target.value}}))}
                                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                                  required
                                >
                                  <option value="Secured Personal Loan">Secured Personal Loan</option>
                                  <option value="Home Loan">Home Loan</option>
                                  <option value="Auto Loan">Auto Loan</option>
                                </select>
                              </div>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Loan Purpose <span className="text-red-500">*</span></Label>
                                <Input type="text" value={form.loan_details.loan_purpose} onChange={e => setForm(f => ({...f, loan_details: {...f.loan_details, loan_purpose: e.target.value}}))} placeholder="e.g., Business expansion, Medical emergency" required />
                              </div>
                              <div className="grid grid-cols-2 gap-4 mb-3">
                                <div>
                                  <Label className="block text-sm font-medium mb-1">Requested Amount (SGD) <span className="text-red-500">*</span></Label>
                                  <Input type="text" value={form.loan_details.requested_amount} onChange={e => setForm(f => ({...f, loan_details: {...f.loan_details, requested_amount: e.target.value}}))} placeholder="e.g., 10000" required />
                                </div>
                                <div>
                                  <Label className="block text-sm font-medium mb-1">Tenure (Months) <span className="text-red-500">*</span></Label>
                                  <Input type="text" value={form.loan_details.tenure_months} onChange={e => setForm(f => ({...f, loan_details: {...f.loan_details, tenure_months: e.target.value}}))} placeholder="e.g., 12" required />
                                </div>
                              </div>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Interest Rate (%) <span className="text-red-500">*</span></Label>
                                <Input type="text" value={form.loan_details.interest_rate} onChange={e => setForm(f => ({...f, loan_details: {...f.loan_details, interest_rate: e.target.value}}))} placeholder="e.g., 12.5" required />
                              </div>
                            </div>
                            <div className="border-t my-2"></div>
                            {/* Collateral Information */}
                            <div>
                              <h3 className="text-base font-bold mb-2 flex items-center">Collateral Information</h3>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Collateral Type <span className="text-red-500">*</span></Label>
                                <select
                                  value={form.collateral.type}
                                  onChange={e => setForm(f => ({...f, collateral: {...f.collateral, type: e.target.value}}))}
                                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                                  required
                                >
                                  <option value="Gold">Gold</option>
                                  <option value="Vehicle">Vehicle</option>
                                  <option value="Watch">Watch</option>
                                  <option value="Designer Bag">Designer Bag</option>
                                  <option value="Other">Other</option>
                                </select>
                              </div>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Description <span className="text-red-500">*</span></Label>
                                <Input type="text" value={form.collateral.description} onChange={e => setForm(f => ({...f, collateral: {...f.collateral, description: e.target.value}}))} placeholder="e.g., 2018 Honda motorcycle" required />
                              </div>
                              <div className="grid grid-cols-2 gap-4 mb-3">
                                <div>
                                  <Label className="block text-sm font-medium mb-1">Market Value (SGD) <span className="text-red-500">*</span></Label>
                                  <Input type="text" value={form.collateral.market_value} onChange={e => setForm(f => ({...f, collateral: {...f.collateral, market_value: e.target.value}}))} placeholder="e.g., 5000" required />
                            </div>
                                <div>
                                  <Label className="block text-sm font-medium mb-1">Condition <span className="text-red-500">*</span></Label>
                                  <select
                                    value={form.collateral.conditionVehicle}
                                    onChange={e => setForm(f => ({...f, collateral: {...f.collateral, conditionVehicle: e.target.value}}))}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                                    required
                                  >
                                    <option value="Excellent">Excellent</option>
                                    <option value="Good">Good</option>
                                    <option value="Fair">Fair</option>
                                  </select>
                                </div>
                              </div>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Ownership Proof Available <span className="text-red-500">*</span></Label>
                                <select
                                  value={form.collateral.ownership_proof}
                                  onChange={e => setForm(f => ({...f, collateral: {...f.collateral, ownership_proof: e.target.value}}))}
                                  className="w-full px-3 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                                  required
                                >
                                  <option value="Yes">Yes</option>
                                  <option value="No">No</option>
                                </select>
                              </div>
                            </div>
                            <div className="border-t my-2"></div>
                            {/* Agent Comments */}
                            <div>
                              <h3 className="text-base font-bold mb-2 flex items-center">Agent Comments</h3>
                              <div className="mb-3">
                                <Label className="block text-sm font-medium mb-1">Additional Notes</Label>
                                <textarea className="w-full border rounded-lg px-3 py-2 min-h-[120px]" value={form.agent_comments ?? ''} onChange={e => setForm(f => ({...f, agent_comments: e.target.value}))} placeholder="Any additional observations, customer behavior, verification notes, etc." />
                                </div>
                            </div>
                            <Button 
                              onClick={handleRecalculate}
                              disabled={isCalculating}
                              className="w-full rounded-lg bg-[#e87722]  text-white text-lg font-semibold py-3 hover:bg-[#e87722] border-0 shadow-none mt-4"
                            >
                              {isCalculating ? (
                                <><RefreshCw className="h-4 w-4 mr-2 animate-spin" />Calculating...</>
                              ) : (
                                'Assess Risk & Generate Report'
                              )}
                            </Button>
                            
                          </CardContent>
                        </Card>
                      </div>
                      
                      {/* Right: 2x2 grid */}
                      <div className="md:col-span-2 flex flex-col gap-8 h-full">
                        {/* Top row */}
                        <div className="flex gap-8 flex-1">
                                                  <Card className="flex-1 flex flex-col h-[48.5rem] border-0 rounded-2xl overflow-hidden bg-white risk-lens-card" style={{
                          transition: 'all 0.3s ease'
                        }}>
                            <CardHeader className="bg-white border-b border-gray-200 pb-2">
                              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-800">
                                <div className="p-1.5 bg-[#e87722] rounded-lg">
                                  <BarChart3 className="h-4 w-4 text-white" />
                                </div>
                                Risk Assessment
                              </CardTitle>
                            </CardHeader>
                            {isCalculating ? (
                              <CardContent className="p-6 space-y-4 h-full bg-white">
                                {/* Risk Score Skeleton */}
                                <div className="flex flex-col items-center w-full">
                                  <div className="h-14 w-20 bg-gray-200 rounded animate-pulse mb-2"></div>
                                  <div className="h-6 w-24 bg-gray-200 rounded-full animate-pulse mb-2"></div>
                                  <div className="h-4 w-20 bg-gray-200 rounded animate-pulse"></div>
                                </div>
                                {/* Risk Bar Skeleton */}
                                <div className="w-full flex flex-col items-center">
                                  <div className="w-full h-4 bg-gray-200 rounded-full animate-pulse mb-2"></div>
                                </div>
                                {/* Summary Skeleton */}
                                <div className="mt-2 text-center">
                                  <div className="h-4 w-32 bg-gray-200 rounded animate-pulse mx-auto mb-2"></div>
                                  <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                                </div>
                                {/* Metrics Skeleton */}
                                <div className="mb-6">
                                  <div className="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2"></div>
                                  <div className="grid grid-cols-2 gap-4">
                                    <div className="rounded-lg border border-gray-200 bg-white p-4 flex flex-col items-center">
                                      <div className="h-6 w-20 bg-gray-200 rounded animate-pulse mb-1"></div>
                                      <div className="h-3 w-16 bg-gray-200 rounded animate-pulse"></div>
                                    </div>
                                    <div className="rounded-lg border border-gray-200 bg-white p-4 flex flex-col items-center">
                                      <div className="h-6 w-20 bg-gray-200 rounded animate-pulse mb-1"></div>
                                      <div className="h-3 w-16 bg-gray-200 rounded animate-pulse"></div>
                                    </div>
                                    <div className="rounded-lg border border-gray-200 bg-white p-4 flex flex-col items-center">
                                      <div className="h-6 w-20 bg-gray-200 rounded animate-pulse mb-1"></div>
                                      <div className="h-3 w-16 bg-gray-200 rounded animate-pulse"></div>
                                    </div>
                                    <div className="rounded-lg border border-gray-200 bg-white p-4 flex flex-col items-center">
                                      <div className="h-6 w-20 bg-gray-200 rounded animate-pulse mb-1"></div>
                                      <div className="h-3 w-16 bg-gray-200 rounded animate-pulse"></div>
                                    </div>
                                  </div>
                                </div>
                              </CardContent>
                            ) : showResults && apiData ? (
                              <CardContent className="p-6 space-y-4 overflow-y-auto h-full bg-white">
                                {/* Score at the top, centered horizontally */}
                                <div className="flex flex-col items-center w-full">
                                  <span className={
                                    apiData.risk_assessment.risk_level === 'High' ? 'text-red-600' :
                                    apiData.risk_assessment.risk_level === 'Medium' ? 'text-amber-600' : 'text-green-600'
                                  } style={{ fontSize: 56, fontWeight: 700 }}>
                                    {apiData.risk_assessment.risk_score}
                                  </span>
                                  <span className={
                                    'mt-2 px-4 py-1 rounded-full text-base font-semibold ' +
                                    (apiData.risk_assessment.risk_level === 'High' ? 'bg-red-100 text-red-600' :
                                     apiData.risk_assessment.risk_level === 'Medium' ? 'bg-amber-100 text-amber-600' :
                                     'bg-green-100 text-green-600')
                                  }>
                                    {apiData.risk_assessment.risk_level} Risk
                                  </span>
                                  <span className="mt-2 text-muted-foreground text-base">Risk Score</span>
                                </div>
                                {/* Horizontal risk bar with 0/100 and labels */}
                                <div className="w-full flex flex-col items-center">
                                  <div className="flex items-center justify-between w-full text-xs text-muted-foreground mb-1">
                                    <span>0</span>
                                    <span>100</span>
                                  </div>
                                  <div className="relative w-full h-4 rounded-full bg-gray-200 flex items-center">
                                    <div
                                      className={
                                        'absolute h-4 rounded-full ' +
                                        (apiData.risk_assessment.risk_level === 'High' ? 'bg-red-400' :
                                         apiData.risk_assessment.risk_level === 'Medium' ? 'bg-amber-400' :   
                                         'bg-green-400')
                                      }
                                      style={{ width: `${apiData.risk_assessment.risk_score}%`, transition: 'width 1s' }}
                                    ></div>
                                  </div>
                                  <div className="flex justify-between w-full text-xs text-muted-foreground mt-1">
                                    <span>Low</span>
                                    <span>Medium</span>
                                    <span>High</span>
                                  </div>
                                </div>
                                {/* Summary */}
                                <div className="mt-2 text-sm text-gray-700 text-center w-full">
                                  <span className="font-semibold">Summary:</span> {apiData.risk_assessment.risk_summary}
                                </div>
                                {/* Calculated Metrics Section (new design) */}
                                {showResults && apiData && (
                                  <div className="mb-6">
                                    <Separator className="my-2" />
                                    <h3 className="font-semibold text-lg mb-2">Calculated Metrics</h3>
                                    <div className="grid grid-cols-2 gap-4">
                                      {/* Monthly EMI */}
                                      <div className="rounded-lg border border-blue-200 bg-white p-4 flex flex-col items-center">
                                        <span className="text-xl font-bold text-gray-900">SGD {apiData.calculated_metrics.emi_requested_loan?.toLocaleString()}</span>
                                        <span className="text-xs text-gray-500 mt-1 tracking-wide">MONTHLY EMI</span>
                                      </div>
                                      {/* Total EMI Burden */}
                                      <div className="rounded-lg border border-blue-200 bg-white p-4 flex flex-col items-center">
                                        <span className="text-xl font-bold text-gray-900">SGD {apiData.calculated_metrics.total_emi_burden?.toLocaleString()}</span>
                                        <span className="text-xs text-gray-500 mt-1 tracking-wide">TOTAL EMI BURDEN</span>
                                      </div>
                                      {/* DTI Ratio */}
                                      <div className="rounded-lg border border-blue-200 bg-white p-4 flex flex-col items-center">
                                        <span className={`text-xl font-bold ${parseFloat(apiData.calculated_metrics.dti_ratio) > 0.5 ? 'text-red-500' : 'text-gray-900'}`}>{apiData.calculated_metrics.dti_ratio}</span>
                                        <span className="text-xs text-gray-500 mt-1 tracking-wide">DTI RATIO</span>
                                      </div>
                                      {/* LTV Ratio */}
                                      <div className="rounded-lg border border-blue-200 bg-white p-4 flex flex-col items-center">
                                        <span className={`text-xl font-bold ${parseFloat(apiData.calculated_metrics.ltv_ratio) < 0.5 ? 'text-green-600' : parseFloat(apiData.calculated_metrics.ltv_ratio) < 0.8 ? 'text-amber-500' : 'text-red-500'}`}>{apiData.calculated_metrics.ltv_ratio}</span>
                                        <span className="text-xs text-gray-500 mt-1 tracking-wide">LTV RATIO</span>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </CardContent>
                            ) : (
                              <CardContent className="flex flex-col items-center justify-center space-y-6 h-full bg-white" style={{ minHeight: 300 }}>
                                 <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-mg text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-mg text-gray-400">to view your risk analysis!</p>
                      </div>
                    </div>
                              </CardContent>
                            )}
                          </Card>

                                                  <Card className="flex-1 flex flex-col h-[48.5rem]  border-0 rounded-2xl overflow-hidden bg-white risk-lens-card" style={{
                          transition: 'all 0.3s ease'
                        }}>
                            <CardHeader className="bg-white border-b border-gray-200 pb-2">
                              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-800">
                                <div className="p-1.5 bg-[#e87722] rounded-lg">
                                  <Target className="h-4 w-4 text-white" />
                                </div>
                                Recommendations
                              </CardTitle>
                            </CardHeader>
                            {isCalculating ? (
                              <CardContent className="flex-1 flex flex-col p-6 leading-relaxed space-y-4 h-full bg-white">
                                {/* Primary Recommendation Skeleton */}
                                <div className="mb-2">
                                  <div className="h-4 w-40 bg-gray-200 rounded animate-pulse mb-2"></div>
                                  <div className="h-6 w-24 bg-gray-200 rounded-full animate-pulse"></div>
                                </div>
                                {/* Conditions Skeleton */}
                                <div className="mb-2">
                                  <div className="h-4 w-20 bg-gray-200 rounded animate-pulse mb-2"></div>
                                  <div className="space-y-2">
                                    <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-4 w-3/4 bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-4 w-5/6 bg-gray-200 rounded animate-pulse"></div>
                                  </div>
                                </div>
                                {/* Alternative Options Skeleton */}
                                <div className="mb-2">
                                  <div className="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2"></div>
                                  <div className="space-y-2">
                                    <div className="h-8 w-full bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-8 w-full bg-gray-200 rounded animate-pulse"></div>
                                  </div>
                                </div>
                                {/* Agent Comment Influence Skeleton */}
                                <div className="rounded-xl bg-emerald-500 text-white p-5 mt-4">
                                  <div className="h-4 w-32 bg-white bg-opacity-20 rounded animate-pulse mb-2"></div>
                                  <div className="h-6 w-24 bg-white bg-opacity-20 rounded-full animate-pulse mb-2"></div>
                                  <div className="h-4 w-full bg-white bg-opacity-20 rounded animate-pulse"></div>
                                </div>
                              </CardContent>
                            ) : showResults && apiData ? (
                              <CardContent className="flex-1 flex flex-col p-6 leading-relaxed space-y-4 overflow-y-auto h-full bg-white">
                                <div className="mb-2">
                                  <span className="font-semibold">Primary Recommendation: </span>
                                  <span className="inline-block align-middle px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-orange-600 ml-2">{apiData.recommendations.primary_recommendation}</span>
                                </div>
                                <div className="mb-2">
                                  <span className="font-semibold">Conditions:</span>
                                  <ul className="list-disc pl-5 mt-1 space-y-1 text-sm">
                                    {apiData.recommendations.conditions.map((condition) => (
                                      <li key={condition}>{condition}</li>
                                    ))}
                                  </ul>
                                </div>
                                <div className="mb-2 font-semibold">Alternative Options:</div>
                                <div className="space-y-2 mb-4">
                                  {apiData.recommendations.alternative_options.map((option) => (
                                    <div key={option.option} className="p-2 rounded bg-blue-50 border border-blue-200 text-blue-900 text-sm font-semibold">
                                      {option.option}
                                    </div>
                                  ))}
                                </div>
                                {/* Agent Comment Influence Card */}
                                {apiData.agent_comment_influence && (
                                  <div className="rounded-xl bg-emerald-500 text-white p-5 mt-4">
                                    <div className="font-semibold text-base mb-2">Agent Comment Influence</div>
                                    {apiData.agent_comment_influence.applied_adjustment === 'Yes' && (
                                      <span className="inline-block bg-white text-emerald-700 font-bold text-xs px-3 py-1 rounded-full mb-2">ADJUSTMENT APPLIED</span>
                                    )}
                                    <div className="text-sm mt-1">{apiData.agent_comment_influence.impact_summary}</div>
                                  </div>
                                )}
                                {/* <Separator className="my-2" /> */}
                                
                              </CardContent>
                            ) : (
                              <CardContent className="flex flex-col items-center justify-center space-y-6 h-full" style={{ minHeight: 300 }}>
                 <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-mg text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-mg text-gray-400">to view your risk analysis!</p>
                      </div>
                    </div>
                              </CardContent>
                            )}
                          </Card>
                        </div>
                        {/* Bottom row */}
                        <div className="flex gap-8 flex-1">
                                                  <Card className="flex-1 flex flex-col h-[48.5rem]    border-0 rounded-2xl overflow-hidden bg-white risk-lens-card" style={{
                          transition: 'all 0.3s ease'
                        }}>
                            <CardHeader className="bg-white border-b border-gray-200 pb-2">
                              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-800">
                                <div className="p-1.5 bg-[#e87722] rounded-lg">
                                  <AlertTriangle className="h-4 w-4 text-white" />
                                </div>
                                Risk Factors
                              </CardTitle>
                            </CardHeader>
                            {isCalculating ? (
                              <CardContent className="flex-1 flex flex-col p-6 my-3 space-y-4 h-full bg-white">
                                {/* Risk Factors Skeleton */}
                                <div className="space-y-3">
                                  {[1, 2, 3].map((item) => (
                                    <div key={item} className="flex items-start gap-3">
                                      <div className="flex flex-col flex-1">
                                        <div className="flex items-center gap-8 mb-2">
                                          <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
                                          <div className="h-5 w-16 bg-gray-200 rounded-full animate-pulse"></div>
                                        </div>
                                        <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                <div className="border-t my-2"></div>
                                {/* Recommendations Skeleton */}
                                <div>
                                  <div className="h-4 w-32 bg-gray-200 rounded animate-pulse mb-2"></div>
                                  <div className="space-y-2">
                                    <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-4 w-3/4 bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-4 w-5/6 bg-gray-200 rounded animate-pulse"></div>
                                  </div>
                                </div>
                              </CardContent>
                            ) : showResults && apiData ? (
                              <CardContent className="flex-1 flex flex-col p-6 my-3 space-y-4 overflow-y-auto h-full bg-white">
                                {/* List each risk factor with badge and description */}
                                <div className="space-y-3">
                                  {apiData.risk_factors.map((factor) => (
                                    <div key={factor.factor} className="flex items-start gap-3">
                                      <div className="flex flex-col flex-1 ">
                                        <div className="flex items-center gap-8">
                                          <span className="font-semibold text-gray-900">{factor.factor}</span>
                                          <span className={
                                            'px-2 py-0.5 rounded-full text-xs font-semibold ' +
                                            (factor.severity === 'High' ? 'bg-red-100 text-red-600' :
                                             factor.severity === 'Medium' ? 'bg-amber-100 text-amber-600' :
                                             'bg-green-100 text-green-600')
                                          }>
                                            {factor.severity}
                                          </span>
                                        </div>
                                        <div className="text-sm text-gray-700 mt-1">{factor.description}</div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                <Separator className="my-2" />
                                {/* Recommendations section */}
                                <div>
                                  <div className="font-semibold mb-2">Recommendations</div>
                                  <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                                    {apiData.risk_factors.map((factor) => (
                                      <li key={factor.factor}>{factor.description}</li>
                                    ))}
                                  </ul>
                                </div>
                              </CardContent>
                                                        ) : (
                              <CardContent className="flex flex-col items-center justify-center space-y-6 h-full" style={{ minHeight: 300 }}>
                 <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-mg text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-mg text-gray-400">to view your risk analysis!</p>
                      </div>
                    </div>
                              </CardContent>
                            )}
                          </Card>

                                                  <Card className="flex-1 flex flex-col h-[48.5rem]   border-0 rounded-2xl overflow-hidden bg-white risk-lens-card" style={{
                          transition: 'all 0.3s ease'
                        }}>
                            <CardHeader className="bg-white border-b border-gray-200 pb-2">
                              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-800">
                                <div className="p-1.5 bg-[#e87722] rounded-lg">
                                  <Award className="h-4 w-4 text-white" />
                                </div>
                                Sample Approval Scenarios
                              </CardTitle>
                            </CardHeader>
                            {isCalculating ? (
                              <CardContent className="flex-1 flex flex-col p-6 my-3 space-y-4 h-full bg-white">
                                {/* Approval Scenarios Skeleton */}
                                <div className="space-y-4">
                                  {[1, 2, 3].map((item) => (
                                    <div key={item} className="border rounded-lg p-3 bg-gray-50">
                                      <div className="flex items-center justify-between mb-2">
                                        <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
                                        <div className="h-5 w-16 bg-gray-200 rounded-full animate-pulse"></div>
                                      </div>
                                      <div className="space-y-2">
                                        <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
                                        <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"></div>
                                        <div className="h-4 w-28 bg-gray-200 rounded animate-pulse"></div>
                                        <div className="h-4 w-20 bg-gray-200 rounded animate-pulse"></div>
                                        <div className="h-4 w-32 bg-gray-200 rounded animate-pulse"></div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </CardContent>
                            ) : showResults && apiData ? (
                              <CardContent className="flex-1 flex flex-col p-6 my-3 space-y-4 overflow-y-auto h-full bg-white">
                                {/* All scenarios in a single CardContent */}
                                <div className="space-y-4">
                                  {Array.isArray(apiData.approval_scenarios) && apiData.approval_scenarios.map((scenario, idx) => (
                                    <div key={scenario.scenario_name + idx} className="border rounded-lg p-3 bg-gray-50">
                                    <div className="flex items-center justify-between mb-1">
                                        <span className="font-semibold">{scenario.scenario_name}</span>
                                        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700">{scenario.dti_ratio} DTI</span>
                                    </div>
                                      {scenario.conditions && scenario.conditions.length > 0 && (
                                        <div className="text-sm text-gray-700 mb-1">{scenario.conditions[0]}</div>
                                      )}
                                      <div className="text-sm text-gray-700 mb-1">EMI: <span className="font-semibold">{scenario.emi}</span></div>
                                      <div className="text-sm text-gray-700 mb-1">Loan Amount: <span className="font-semibold">{scenario.loan_amount}</span></div>
                                      <div className="text-sm text-gray-700 mb-1">Tenure: <span className="font-semibold">{scenario.tenure}</span></div>
                                      {scenario.total_emi !== undefined && (
                                        <div className="text-sm text-gray-700 mb-1">Total EMI: <span className="font-semibold">{scenario.total_emi}</span></div>
                                      )}
                                      <div className="text-xs text-muted-foreground">Conditions: {scenario.conditions ? scenario.conditions.join(', ') : 'None'}</div>
                                    </div>
                                  ))}
                                </div>
                              </CardContent>
                            ) : (
                              <CardContent className="flex flex-col items-center justify-center space-y-6 h-full" style={{ minHeight: 300 }}>
                 <div className="flex-1 flex flex-col items-center justify-center p-6">
                      <div className="text-center">
                        <p className="text-mg text-gray-400 mb-1">Click <span className="font-semibold text-gray-500">'Assess Risk'</span></p>
                        <p className="text-mg text-gray-400">to view your risk analysis!</p>
                      </div>
                    </div>
                              </CardContent>
                            )}
                          </Card>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Document Directory Section (only document cards) */}
              <TabsContent value="documents" className="mt-8">
                
               
                 <div className="container-custom py-6">
                  <div className="mb-2 mt-2">
                    <span className="block text-xl font-bold text-black mb-4">Customer-provided documents:</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mx-auto items-stretch">
                    {documentTypes.slice(0, 4).map((doc) => {
                      const Icon = doc.icon;
                      let newDescription = doc.description;
                      if (doc.id === 'aadhaar_card') newDescription = 'View extracted identity details';
                      if (doc.id === 'pan_card') newDescription = 'View PAN and tax ID info';
                      if (doc.id === 'bank_statement') newDescription = 'Analyzes salary inflow, EMI deductions, and banking behavior such as balance trends and NSF charges to evaluate financial discipline and repayment capacity.';
                      if (doc.id === 'salary_slip') newDescription = 'Confirms current employment status, monthly income, and deductions to assess real take-home pay and debt-service capacity.';
                      return (
                        <div key={doc.id} className="h-full flex">
                          <Dialog>
                            <DialogTrigger asChild>
                              <div className="flex flex-col justify-between p-6 border border-gray-200 bg-white rounded-2xl min-h-[220px] min-w-[260px] max-w-[340px] h-full w-full transition-all cursor-pointer gap-2">
                                <div className="flex items-center gap-3 mb-2">
                                  <span className="text-[#e87722]"><Icon className="h-6 w-6 text-[#e87722]" /></span>
                                  <span className="font-bold text-base md:text-lg lg:text-xl text-black text-left">{doc.name}</span>
                                </div>
                                <div className="text-xs md:text-sm text-gray-600 mb-2 text-left w-full">{newDescription}</div>
                                <div className="flex items-center gap-2 mt-auto pt-2">
                                  <CheckCircle className="text-green-600 w-5 h-5" />
                                  <span className="text-green-700 font-medium">Available</span>
                                </div>
                              </div>
                            </DialogTrigger>
                            <DialogContent 
                              className="bg-white border-2 border-gray-200 rounded-xl max-w-4xl w-[90vw] max-h-[85vh] overflow-y-auto overflow-x-hidden"
                              style={{
                                scrollbarWidth: 'none',
                                msOverflowStyle: 'none',
                              }}
                            >
                              <style>{`
                                .bg-white.border-2.border-gray-200.rounded-xl.shadow-2xl::-webkit-scrollbar {
                                  display: none;
                                }
                              `}</style>
                              <DocumentDetail />
                            </DialogContent>
                          </Dialog>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mb-2 mt-16">
                    <span className="block text-xl font-bold text-black mb-4">Bank-Verified Data Sources:</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mx-auto items-stretch">
                    {documentTypes.slice(4, 6).map((doc) => {
                      const Icon = doc.icon;
                      let newDescription = doc.description;
                      if (doc.id === 'credit_report') newDescription = 'Provides a snapshot of the applicant creditworthiness using bureau-sourced data like score, repayment history, and open loans to assign a risk category.';
                      if (doc.id === 'provident_fund') newDescription = 'Shows long-term financial and employment consistency by tracking employee and employer contributions to the retirement fund.';
                      return (
                        <div key={doc.id} className="h-full flex">
                          <Dialog>
                            <DialogTrigger asChild>
                              <div className="flex flex-col justify-between p-6 border border-gray-200 bg-white rounded-2xl min-h-[220px] min-w-[260px] max-w-[340px] h-full w-full transition-all cursor-pointer gap-2">
                                <div className="flex items-center gap-3 mb-2">
                                  <span className="text-[#e87722]"><Icon className="h-6 w-6 text-[#e87722]" /></span>
                                  <span className="font-bold text-base md:text-lg lg:text-xl text-black text-left">{doc.name}</span>
                                </div>
                                <div className="text-xs md:text-sm text-gray-600 mb-2 text-left w-full">{newDescription}</div>
                                <div className="flex items-center gap-2 mt-auto pt-2">
                                  <CheckCircle className="text-green-600 w-5 h-5" />
                                  <span className="text-green-700 font-medium">Available</span>
                                </div>
                              </div>
                            </DialogTrigger>
                            <DialogContent 
                              className="bg-white border-2 border-gray-200 rounded-xl max-w-4xl w-[90vw] max-h-[85vh] overflow-y-auto overflow-x-hidden"
                              style={{
                                scrollbarWidth: 'none',
                                msOverflowStyle: 'none',
                              }}
                            >
                              <style>{`
                                .bg-white.border-2.border-gray-200.rounded-xl.shadow-2xl::-webkit-scrollbar {
                                  display: none;
                                }
                              `}</style>
                              <DocumentDetail />
                            </DialogContent>
                          </Dialog>
                        </div>
                      );
                    })}
                  </div>
                </div> 
                
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Risk;
