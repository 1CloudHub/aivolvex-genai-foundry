// Document data and types for reuse
import { FileText, LucideIcon } from 'lucide-react';

export interface DocumentType {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
}

export interface ExtractedField {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'error';
  message?: string;
}

export interface ProcessedDocument {
  id: string;
  name: string;
  type: string;
  status: 'processing' | 'completed' | 'failed';
  confidence: number;
  fields: ExtractedField[];
  uploadTime: Date;
}

export const documentTypes: DocumentType[] = [
  {
    id: 'aadhaar',
    name: 'Aadhaar Card',
    description: 'Shows government-issued identity proof containing the applicant’s full name, date of birth, gender, and permanent address. Essential for KYC compliance and validating demographic details.',
    icon: FileText
  },
  {
    id: 'pan',
    name: 'PAN Card',
    description: 'Provides proof of income tax registration, used to verify identity against credit bureau data and to assess the applicant\'s financial background.',
    icon: FileText
  },
  {
    id: 'bank_statement',
    name: 'Bank Statement',
    description: 'Last 3 months statement (PDF format)',
    icon: FileText
  },
  {
    id: 'salary_slip',
    name: 'Salary Slip',
    description: 'Upload your latest salary slip',
    icon: FileText
  },
  {
    id: 'credit_report',
    name: 'Credit Report',
    description: 'CIBIL Score & Credit Report',
    icon: FileText
  },
  {
    id: 'provident_fund',
    name: 'Provident Fund',
    description: 'Upload your PF statement',
    icon: FileText
  }
];

export const mockDocuments: Record<string, ProcessedDocument> = {
  aadhaar: {
    id: 'aadhaar-001',
    name: 'Aadhaar_Card.jpg',
    type: 'Aadhaar Card',
    status: 'completed',
    confidence: 92,
    fields: [
      { name: 'Full Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Date of Birth', value: '15/04/1985', status: 'success' },
      { name: 'Gender', value: 'Male', status: 'success' },
      { name: 'Address', value: '123 Main St, Bangalore, Karnataka - 560001', status: 'success' },
      { name: 'Aadhaar Number', value: 'XXXX XXXX 4567', status: 'success' }
    ],
    uploadTime: new Date('2023-01-01T10:10:21')
  },
  pan: {
    id: 'pan-001',
    name: 'PAN_Card.jpg',
    type: 'PAN Card',
    status: 'completed',
    confidence: 88,
    fields: [
      { name: 'Full Name', value: 'RAJ KUMAR SINGH', status: 'success' },
      { name: 'PAN Number', value: 'ABCPS1234D', status: 'success' },
      { name: 'Date of Birth', value: '10/06/2010', status: 'success' },
      { name: "Father's Name", value: 'AMARNATH SINGH', status: 'success' }
    ],
    uploadTime: new Date('2023-01-01T10:10:21')
  },
  bank_statement: {
    id: 'statement-001',
    name: 'Bank_Statement_Jan_Mar_2025.pdf',
    type: 'Bank Statement',
    status: 'completed',
    confidence: 95,
    fields: [
      { name: 'Account Holder Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Bank Name & Branch', value: 'State Bank of India, Bangalore Main Branch', status: 'success' },
      { name: 'Statement Period', value: 'Jan 2025 - Mar 2025', status: 'success' },
      { name: 'Monthly Salary Credits', value: '₹85,000', status: 'success' },
      { name: 'EMI/Loan Debits', value: '₹28,500', status: 'success' },
      { name: 'Utility/Recurring Payments', value: '₹5,000', status: 'success' },
      { name: 'Minimum Balance Trends', value: '₹25,000 - ₹72,456', status: 'success' },
      { name: 'NSF/Bounce Charges', value: '₹0', status: 'success' },
      { name: 'Cash Deposits/Transfers', value: '₹50,000', status: 'success' },
      { name: 'End-of-Month Balances', value: '₹72,456', status: 'success' }
    ],
    uploadTime: new Date('2023-01-01T10:10:21')
  },
  salary_slip: {
    id: 'salary-slip-001',
    name: 'Salary_Slip_Mar_2025.pdf',
    type: 'Salary Slip',
    status: 'completed',
    confidence: 93,
    fields: [
      { name: 'Employee Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'Designation', value: 'Senior Software Engineer', status: 'success' },
      { name: 'Gross Monthly Income', value: '₹90,000', status: 'success' },
      { name: 'Deductions', value: '₹8,000', status: 'success' },
      { name: 'Net Take-Home Pay', value: '₹82,000', status: 'success' },
      { name: 'Pay Period', value: 'Mar 2025', status: 'success' }
    ],
    uploadTime: new Date('2023-01-01T10:10:21')
  },
  credit_report: {
    id: 'credit-report-001',
    name: 'Credit_Report.pdf',
    type: 'Credit Report',
    status: 'completed',
    confidence: 85,
    fields: [
      { name: 'CIBIL Score', value: '695', status: 'success' },
      { name: 'Score Band', value: 'Fair (650–749)', status: 'success' },
      { name: 'Score Provider', value: 'TransUnion CIBIL', status: 'success' },
      { name: 'Last Updated', value: '02-Apr-2025', status: 'success' },
      { name: 'Credit History Length', value: '6 years', status: 'success' },
      { name: 'Number of Active Accounts', value: '3', status: 'success' },
      { name: 'Loan Types', value: 'Personal Loan, Credit Card, Consumer Durable Loan', status: 'success' },
      { name: 'Total Outstanding', value: '₹2,75,000', status: 'success' },
      { name: 'Recent EMI Payments', value: 'On-time', status: 'success' },
      { name: 'Overdue Payments (last 12 months)', value: '0', status: 'success' },
      { name: 'Hard Inquiries (last 6 months)', value: '2', status: 'success' },
      { name: 'Red Flags', value: 'None', status: 'success' },
      { name: 'Remarks', value: 'Satisfactory repayment behavior', status: 'success' }
    ],
    uploadTime: new Date('2025-04-02T11:53:08')
  },
  provident_fund: {
    id: 'provident-fund-001',
    name: 'PF_Statement_2025.pdf',
    type: 'Provident Fund',
    status: 'completed',
    confidence: 95,
    fields: [
      { name: 'Employee Name', value: 'Raj Kumar Singh', status: 'success' },
      { name: 'UAN Number', value: '100456789012', status: 'success' },
      { name: 'Employer Name', value: 'ABC Technologies Pvt. Ltd.', status: 'success' },
      { name: 'Employment Type', value: 'Full-Time', status: 'success' },
      { name: 'PF Account Number', value: 'KN/BNG/1234567/000001', status: 'success' },
      { name: 'Contribution Period', value: 'Jan 2021 – Mar 2025', status: 'success' },
      { name: 'Monthly Contribution', value: '₹3,600 (Employee) + ₹3,600 (Employer)', status: 'success' },
      { name: 'Total Balance', value: '₹2,88,000', status: 'success' },
      { name: 'Last Contribution Date', value: '31-Mar-2025', status: 'success' },
      { name: 'Withdrawal History', value: 'None', status: 'success' }
    ],
    uploadTime: new Date('2025-03-31T10:10:21')
  }
}; 