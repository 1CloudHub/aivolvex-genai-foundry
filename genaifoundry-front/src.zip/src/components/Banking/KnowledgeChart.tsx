import Chart from "react-apexcharts";

const Knowledgechart = (props: any) => {
  const days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
   const days_condition = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  const data = days_condition.map((day) => props.WeeklyKB?.[day] || 0);

  const chartSeries = [
    {
      name: "Usage ",
      type: "area" as const,
      data: data,
      color: "#F3722C",
    },
  ];
  const chartOptions = {
    chart: {
      height: 350,
      type: "line" as const,
      toolbar: {
        show: false,
      },
    },
    series: chartSeries,
    grid: {
      show: false,
    },
    stroke: {
      curve: "smooth" as const,
      width: 2,
    },
    fill: {
      type: "solid" as const,
      opacity: [0.35, 1],
    },
    // labels: labels,
    markers: {
      size: 0,
    },
    yaxis: {
      title: {
        text: "Usage Count",
        style: {
          color: "#000",
          fontWeight: "400",
        },
      },
      labels: {
        style: {
          colors: "#000",
        },
      },
    },
    legend: {
      labels: {
        colors: "#000",
      },
    },
    xaxis: {
      type: "category" as const,
      categories: days,
      labels: {
        style: {
          colors: "#000",
        },
      },
      tooltip: {
        enabled: false,
      },
    },
    tooltip: {
      shared: true,
      intersect: false,
      y: {
        formatter: function (y: any) {
          if (typeof y !== "undefined") {
            return y.toFixed(0);
          }
          return y;
        },
      },
    },
  };
  


  return (
    <div className="line-chart">
      <Chart
        options={chartOptions}
        series={chartSeries}
        type="line"
        height={140}
      />
    </div>
  );
};

export default Knowledgechart;
