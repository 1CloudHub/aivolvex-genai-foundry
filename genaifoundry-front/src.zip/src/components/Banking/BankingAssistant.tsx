import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Home } from 'lucide-react';
import ConversationalAssistantTool from './BankingAssistantTool';
import LoginNavbar from '../../components/layout/LoginNavbar';
import Footer from '../Banking/BankingFooter';
// import './';

const ConversationalAssistantPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <LoginNavbar />
      <div className="flex-grow container mx-auto px-4 py-4">
        <div className="mx-auto w-full max-w-10xl mt-8">
          <div className="mb-4">
            <div className="w-full">
              <nav className="flex text-sm text-gray-500 mb-2 -mt-6 -ml-5" aria-label="Breadcrumb">
                <ol className="inline-flex items-center space-x-1">
                  <li>
                    <Link to="/customer/sandbox/bankinghome" className="flex items-center text-orange-600 hover:underline">
                      <Home size={16} className="mr-1" />
                      Home
                    </Link>
                  </li>
                  <li>
                    <span className="mx-2">/</span>
                    <span className="text-gray-500">Virtual Banking Assistant</span>
                  </li>
                </ol>
              </nav>
              <div className="flex items-center mb-2">
                <div className="ub-feature-icon mr-3">
                  <MessageSquare size={30} />
                </div>
                <div>
                  <h2 className="mb-0 text-3xl font-bold">Virtual Banking Assistant</h2>
                  <p className="text-gray-500">AI-powered chatbot helping customers discover banking products, view account balances, and file service requests using advanced RAG technology</p>
                </div>
              </div>
            </div>
          </div>
          
          <ConversationalAssistantTool />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ConversationalAssistantPage;