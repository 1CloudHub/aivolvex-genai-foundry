export interface Message {
    id: string;
    sender: 'user' | 'bot';
    text: string;
    timestamp: string;
    contextSource?: string;
  }
  
  export interface Conversation {
    id: string;
    messages: Message[];
  }
  
  export interface PromptChip {
    id: string;
    text: string;
  }
  
  export interface AnalyticsData {
    topTopic: string;
    sentiment: 'positive' | 'neutral' | 'negative';
    followUpSent: boolean;
  }
  
  export const promptChips: PromptChip[] = [
    { id: 'account-balance', text: "What's my account balance?" },
    { id: 'card-details', text: "Can I see my card dues and loan details?" },
    { id: 'service-request', text: "How do I file a service request?" }
  ];
  
  export const sampleConversation: Conversation = {
    id: 'sample-conversation',
    messages: [
      {
        id: '1',
        sender: 'user',
        text: "What's my account balance?",
        timestamp: '2025-04-05T09:30:00Z'
      },
      {
        id: '2',
        sender: 'bot',
        text: "I can help you check your account balance. To access your financial summary across all your accounts (savings, current, credit card, and loan accounts), I'll need your customer ID and PIN for security verification. Could you please provide your customer ID (e.g., CUST1001) and your 4-6 digit PIN?",
        timestamp: '2025-04-05T09:30:10Z',
        contextSource: 'Account Summary Tool'
      },
      {
        id: '3',
        sender: 'user',
        text: "My customer ID is CUST1001 and PIN is 1023",
        timestamp: '2025-04-05T09:31:05Z'
      },
      {
        id: '4',
        sender: 'bot',
        text: "Thank you for providing your credentials. Here's your account summary:\n\n**eSaver Plus Account (XXXXXX4321)**\n- Balance: SGD 10,452.75\n- Status: Active\n\n**Rewards+ Card (XXXXXX9876)**\n- Outstanding Balance: SGD 1,880.10\n- Credit Limit: SGD 12,000.00\n- Payment Due Date: August 3, 2025\n\n**Personal Loan (LN-984521)**\n- Outstanding Balance: SGD 14,600.00\n- Monthly Installment: SGD 630.50\n- Remaining Tenure: 28 months\n- Interest Rate: 7.2% EIR\n\nAll accounts are in good standing. Would you like to know more about any specific account or need help with anything else?",
        timestamp: '2025-04-05T09:31:15Z',
        contextSource: 'Account Summary Response'
      }
    ]
  };
  
  export const whatsAppPreview = {
    phoneNumber: '+65 9123 4567',
    message: "Hi Rachel Tan! Here's your AnyBank SG account summary:\n\n💰 eSaver Plus: SGD 10,452.75\n💳 Rewards+ Card: SGD 1,880.10 due (Aug 3)\n🏦 Personal Loan: SGD 14,600.00 outstanding\n\nAll accounts are active and in good standing.\n\nNeed help? Reply 'HELP' or call our hotline at 1800-123-4567.\n\nThank you for banking with AnyBank SG! 🏦"
  };