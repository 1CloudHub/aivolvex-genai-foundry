// src/pages/PostCall/mockdata.ts

export const mockPostCallRecords = {
    summary: "The customer contacted the contact centre to enquire about available personal loan options. The agent provided detailed information about the 'Personal Loan Plan', including loan amounts, interest rates, and eligibility criteria. The customer expressed interest and requested a follow-up with a loan officer to proceed with application.",
    title: "Personal Loan Enquiry",
    product: "Personal Loan Plan",
    issue_resolved: "Information Provided",
    callback: "Yes – Scheduled with Loan Officer",
    customer_name: "Lim Mei Ling",
    phone_number: "+6591234567",
    account_number: "SGP-98234761",
    current_plan: "Not Enrolled",
    joined_date: "March 15 2023",
    recent_tickets: "Credit Card Enquiry (Resolved)",
    action_items: "Schedule loan officer callback and email loan brochure",
    stream_output_s3path: "",
  };
  
  export const mockQaCheck = "Completed";
  export const mockQaCheckStatus = [
    ["Professional Greeting", "Yes"],
    ["Accuracy of Information", "Yes"],
    ["Customer Verification", "No"],
    ["Empathy Displayed", "Yes"],
    ["Communication Clarity", "Yes"],
    ["Efficient Query Resolution", "Yes"],
    ["Compliance with Procedures", "Yes"],
    ["Effective Call Management", "Yes"],
    ["Appropriate Upselling Cross Selling", "Yes"],
    ["Professional Closure and Follow Up", "Yes"],
  ];
  
  export const mockCallSummaryRecords = [
    {
      opportunity_status: "positive",
      opportunity_tag: "Loan Interest Captured",
      transcript: "I'm looking for a personal loan for home improvements. Can you tell me what options are available?",
    },
    {
      opportunity_status: "negative",
      opportunity_tag: "Missed Compliance Check",
      transcript: "The agent did not perform the mandatory income verification before sharing loan details.",
    },
  ];
  
  export const mockChatMessages = [
    { type: "agent", message: "Hi, how can I help you today?" },
    { type: "ans", message: "Hello! My internet has been really slow today. Can you please help me out?" },
  ];
  
  export const mockTranscript = [
    {
      speaker: "SPEAKER_00", // Client
      transcript: "Hi, I was looking to understand your personal loan options. Can someone help me with that?",
      Opportunity_status: "positive",
      sentiment_status: "Neutral",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01", // Agent
      transcript: "Absolutely, I’d be happy to assist you. Are you looking for individual coverage or a family protection plan?",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "I’m mainly interested in something that would cover my family in case something happens to me.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01",
      transcript: "Understood. In that case, our Personal Loan would be ideal. It includes loan amounts up to SGD 50,000 and competitive interest rates.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "That sounds good. What would the monthly repayments look like?",
      Opportunity_status: "positive",
      sentiment_status: "Neutral",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01",
      transcript: "Monthly repayments start from SGD 500 per month depending on your loan amount and tenure. I can send a brochure with full details.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "Yes, please do. Also, can someone reach out to help me apply?",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_01",
      transcript: "Certainly. I’ll schedule a callback with one of our licensed advisors. Is tomorrow morning okay?",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
    {
      speaker: "SPEAKER_00",
      transcript: "Perfect. Thanks for your help.",
      Opportunity_status: "positive",
      sentiment_status: "Positive",
      Ticket_Oppportunity: "No",
    },
  ];
   
  
  export const mockKBListData = [
    { type: "agent", message: "please tell me more about the Personal Loan Plan" },
  {
    type: "ans",
    message: "The Personal Loan Plan includes the following features: - Loan Amount: Up to SGD 50,000 - Monthly Repayment: Starting from SGD 500/month - Eligibility: Singapore residents aged 21 to 65 - Benefits: Competitive interest rates, Flexible repayment terms, Quick approval process, No collateral required, Dedicated loan officer support"
  }
  ];
  
  export const mockCallHistoryData = [
    {
      title: "Tan Wei Ming",
      phone_number: "+6598765432",
      created_at: "2024-06-01T10:00:00Z",
      session_id: "session1",
    },
    {
      title: "Chen Li Hua",
      phone_number: "+6592345678",
      created_at: "2024-06-02T11:30:00Z",
      session_id: "session2",
    },
  ];
  
  export const mockSummaryDetails = [
    {
      title: "Personal Loan Enquiry Call",
      summary: "Customer called to enquire about personal loan options. Agent provided details and scheduled follow-up.",
      sentiment_status: "Positive",
      sentiment: "The customer was satisfied with the service.",
      opportunity_status: "Loan Offered",
      opportunity: "Agent offered the Personal Loan Plan.",
      qa_check: JSON.stringify({
        "Professional Greeting": "Yes",
        "Accuracy of Information": "Yes",
        "Customer Verification": "No",
        "Empathy Displayed": "Yes",
        "Communication Clarity": "Yes",
        "Efficient Query Resolution": "Yes",
        "Compliance with Procedures": "Yes",
        "Effective Call Management": "Yes",
        "Appropriate Upselling Cross Selling": "Yes",
        "Professional Closure and Follow Up": "Yes"
      })
    }
  ];
  
  export const mockSentimentChartData = [
    {
      name: "Agent",
      data: [0, 0, 3, 3, 4, 4, 4, 3, 3, 4, 4, 3], // generally calm, supportive, and professional
    },
    {
      name: "Client",
      data: [-2, 0, 2, 3, 3, 4, 4, 3, 3, 3, 2, 2], // starts neutral, gets more engaged, ends calm
    },
  ];
  
  export const mockXAxisData = [
    "00:00:01.000",
    "00:00:02.000",
    "00:00:03.000",
    "00:00:04.000",
    "00:00:05.000",
    "00:00:06.000",
    "00:00:07.000",
    "00:00:08.000",
    "00:00:09.000",
    "00:00:10.000",
    "00:00:11.000",
    "00:00:12.000",
  ]; 