import React from 'react';
// import ChatCopilot from '../components/AgentAssistChatCopilot/ChatCopilot';
import CCIDashboard from './CciDashboard'
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import { Bot } from 'lucide-react';
import LoginNavbar from '../layout/LoginNavbar';
import InsuranceFooter from './BankingFooter';

const AgentAssistChatCopilotPage: React.FC = () => (
  <div className="min-h-screen bg-gray-50 flex flex-col">
    <LoginNavbar />
    <div className="flex-grow">
      <div className="container px-0" style={{ minHeight: '100vh' }}>
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 -mb-1 -ml-6 mt-4 ms-1" aria-label="Breadcrumb">
          <ol className="inline-flex items-center space-x-1">
            <li>
              <Link to="/customer/sandbox/bankinghome" className="flex items-center gap-2 text-orange-600 no-underline">
                <Home size={16} className="relative top-[-1px]" />
                Home
              </Link>
            </li>
            <li>
              <span className="mx-2">/</span>
              <span className="text-gray-500">Contact Centre Intelligence</span>
            </li>
          </ol>
        </nav>
        {/* Header and Scenario Selector */}
        <div className="row align-items-center mb-12 -ml-4">
          <div className="col-12 col-md-7 d-flex align-items-center mb-3 mb-md-0 ms-4">
            <div className="me-3 flex-shrink-0">
              <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#fff4ed', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Bot size={30} color="#f37021" />
              </div>
            </div>
            <div>
              <h2 className="fw-bold mb-1" style={{ color: '#000' }}>Contact Centre Intelligence</h2>
              <div className="text-muted -mb-4" style={{ fontSize: 17 }}>An analytics dashboard offering deep insights into customer sentiment, agent performance, and call quality.</div>
            </div>
          </div>
          <div className="col-12 col-md-5 d-flex justify-content-md-end align-items-center">
            {/* ScenarioSelector will be rendered inside ChatCopilot, so leave space here for alignment */}
          </div>
        </div>
        {/* Main Content - Direct Cards */}
        <div className="row justify-content-center">
          <div className="col-12">
            <CCIDashboard />
          </div>
        </div>
        {/* Bottom Spacing */}
        <div className="pb-5"></div>
      </div>
    </div>
    <InsuranceFooter />
  </div>
);

export default AgentAssistChatCopilotPage; 