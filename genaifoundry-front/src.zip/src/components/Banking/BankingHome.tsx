import React, { useState } from 'react';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import {
    Mic ,
    Edit3 ,
    BarChart2 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    FileText,
    Home,
    ClipboardCheck,
    PieChart,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../layout/LoginNavbar';
import Footer from '../Banking/BankingFooter';

const GenAISandboxHome = () => {
    const { Title, Text } = Typography;
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');

const solutions = [
  {
    title: 'Virtual Banking Assistant',
    area: 'Banking',
    icon: <MessageSquare size={24} />,
    description: 'AI-powered chatbot helping customers discover products, view account balances, and file service requests using RAG technology.',
    buttonText: 'Try Now',
    tags: ['Digital Banking', 'AI Chat'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '💬',
      heading: 'Virtual Banking Assistant',
      subheading: 'AI Chatbot for Banking Services',
      points: [
        'Discover banking products (savings, credit cards, loans)',
        'View account balances and transaction history',
        'File service requests and complaints',
        'Schedule agent callback',
        'Uses RAG and tool calling for accurate responses'
      ]
    }
  },
  {
    title: 'Voicebot with RAG Support',
    area: 'Contact Center',
    icon: <Sparkles size={24} />,
    description: 'Voice-enabled AI assistant that handles customer queries by retrieving answers from banking documents and policies in real-time.',
    buttonText: 'Explore',
    tags: ['Voice Banking', 'AI Support'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🗣️',
      heading: 'Banking Voicebot with RAG',
      subheading: 'Voice AI for Banking Support',
      points: [
        'Handles customer queries via voice interface',
        'Retrieves answers from banking product documents',
        'Supports account procedures and banking policies',
        'Real-time voice interaction with customers'
      ]
    }
  },
  {
    title: 'Document Processing Assistant',
    area: 'Operations',
    icon: <FileText size={24} />,
    description: 'Extracts data from banking documents like account statements and loan applications.',
    buttonText: 'Try Now',
    tags: ['Document AI', 'KYC', 'Automation'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📄',
      heading: 'Banking Document Processor',
      subheading: 'AI Document Extraction for Banking',
      points: [
        'Extracts data from account statements and loan applications',
        'Processes KYC documents and financial reports',
        'Supports account opening and loan processing workflows',
        'Automated document verification and data extraction'
      ]
    }
  },
  {
    title: 'RiskLens',
    area: 'Risk & Compliance',
    icon: <ClipboardCheck size={24} />,
    description: 'Automated risk assessment tool for personal loans, home loans, and credit card applications.',
    buttonText: 'Explore',
    tags: ['Risk Assessment', 'Risk AI'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📋',
      heading: 'Banking Risk Assessment',
      subheading: 'AI-Powered Credit Risk Analysis',
      points: [
        'Automated credit scoring for loan applications',
        'Risk factor identification and analysis',
        'Supports personal loans, home loans, and credit cards',
        'Intelligent underwriting decision support',
        'Real-time risk evaluation and recommendations'
      ]
    }
  },
  {
    title: 'Contact Centre Intelligence',
    area: 'Contact Center',
    icon: <BarChart2 size={24} />,
    description: 'Contact Centre Intelligence dashboard for banking operations with AI-powered call analysis, agent performance tracking',
    buttonText: 'Try Now',
    tags: ['Contact Center', 'AI Analytics' ],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '📊',
      heading: 'CCI Dashboard',
      subheading: 'Contact Centre Intelligence for Banking',
      points: [
        'AI-powered call analysis and transcription',
        'Agent performance tracking and scoring',
        'Real-time sentiment analysis',
        'Issue tagging and categorization',
        'Performance dashboards and insights'
      ]
    }
  },

];

   
    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {/* Login Navbar */}
            <LoginNavbar />
            {/* Breadcrumb */}
            <div className="container mx-auto px-4 w-full max-w-6xl mt-8">
                <nav className="flex text-sm text-gray-500 mb-4" aria-label="Breadcrumb">
                    
                </nav>
            </div>
            {/* Spacing below navbar */}
            <div className="flex-grow px-15 mx-auto py-3">
                {/* Header Section - Matching the image */}
                <div className="text-center">
                    <div className="flex flex-col items-center justify-center mt-8 mb-2">
                        <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                            <span style={{ color: '#e87722' }}>GenAI</span>
                            <span style={{ color: '#181f5a' }}> Sandbox</span>
                        </h1>
                    </div>
                    <div className="mb-8">
                        <span className="text-lg text-gray-700">
                            Explore AI-powered tools designed to transform business unit operations across industries.
                        </span>
                    </div>
                </div>

                {/* Solution Cards Section - Styled to match the image with reduced height and increased width appearance */}
                <Row
                        gutter={[16, 16]}
                        justify="center"
                        className="p-4"
                        style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
                    >
                        {solutions.map((solution, index) => (
                      
                            <Col key={index} style={{ flex: "0 0 calc(20% - 16px)" }}>
    <Card
        className="relative w-full h-[340px] border-2 border-transparent rounded-lg shadow-md
            hover:shadow-lg transition-all duration-300 ease-in-out
            hover:!border-[#e87822] flex flex-col"
        bodyStyle={{ 
            height: "100%",
            display: 'flex', 
            flexDirection: 'column',
            overflow: 'hidden',
        }}
    >


        <div className="absolute top-2 right-2 z-10">
            
    
<Tooltip
  placement="topRight"
  color="white" 
  overlayInnerStyle={{
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    borderRadius: '10px',
    padding: '0', 
    maxWidth: '250px',
  }}
  title={
    <div className="p-[1px]">
  
      <div className="flex bg-[#f9fafb] rounded-md border-l-[4px] border-[#e87722] p-4">
        <div className="flex flex-col">
          <div className="font-bold text-[#181f5a] text-sm mb-1">
            {solution.tooltip.icon} {solution.tooltip.heading}
          </div>
          <div className="text-black text-xs font-semibold mb-2">
            {solution.tooltip.subheading}
          </div>
          <ul className="list-disc pl-5 space-y-1 text-xs text-gray-700">
            {solution.tooltip.points.map((point, idx) => (
              <li key={idx}>{point}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  }
>
  <Info className="text-[#e87722] hover:cursor-pointer" size={16} />
</Tooltip>


        </div>

        {/* Restructured card layout with proper flexbox organization */}
        <div className="flex flex-col h-full justify-between">
            {/* Top Section: Icon and Tags (flex-shrink-0) */}
            <div className="flex-shrink-0">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-[#e8782222] mb-2">
                    {React.cloneElement(solution.icon, {
                        size: 20,
                        className: "text-[#e87722]",
                    })}
                </div>

                <div className="mb-2 min-h-[20px] flex gap-1 flex-wrap">
                    {solution.tags?.map((tag, index) => (
                        <span key={index} className="inline-block bg-[#e8782222] text-[#e87722] text-xs font-medium px-2 py-0.5 rounded-md">
                            {tag}
                        </span>
                    ))}
                </div>
            </div>

            {/* Middle Section: Title and Description (flex-grow) */}
            <div className="flex-grow flex flex-col">
                {/* Title - removed fixed height and reduced margin */}
                <Title level={5} className="!text-lg !font-bold !mb-2 !text-gray-900">
                    {solution.title}
                </Title>

                {/* Description - removed text truncation and fixed height, using flex-grow */}
                <div className="flex-grow">
                    <Text className="text-gray-600 !text-xs leading-relaxed">
                        {solution.description}
                    </Text>
                </div>
            </div>

            {/* Bottom Section: Button (flex-shrink-0) */}
            <div className="flex-shrink-0 mt-3">
                {solution.title === "Virtual Banking Assistant" ? (
                    <button
                        onClick={() => {
                            if (solution.title === "Virtual Banking Assistant") {
                                navigate('/customer/sandbox/bankinghome/banking-assistant');
                            }
                        }}
                        className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                            hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                            !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                        style={{ height: '36px', textDecoration: 'none' }}
                    >
                        {solution.buttonText}
                    </button>
                ) : solution.title === "Voicebot with RAG Support" ? (
                    <button
                        onClick={() => navigate('/customer/sandbox/bankinghome/banking-voicebot')}
                        className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                            hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                            !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                        style={{ height: '36px', textDecoration: 'none' }}
                    >
                        {solution.buttonText}
                    </button>
                ) : solution.title === "Document Processing Assistant" ? (
                    <button
                        onClick={() => navigate('/customer/sandbox/bankinghome/bankdocument')}
                        className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                            hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                            !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                        style={{ height: '36px', textDecoration: 'none' }}
                    >
                        {solution.buttonText}
                    </button>
                ) : solution.title === "RiskLens" ? (
                    <button
                        onClick={() => navigate('/customer/sandbox/bankinghome/risklens')}
                        className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                            hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                            !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                        style={{ height: '36px', textDecoration: 'none' }}
                    >
                        {solution.buttonText}
                    </button>
                ) : solution.title === "Contact Centre Intelligence" ? (
                    <button
                        onClick={() => navigate('/customer/sandbox/bankinghome/cci-dashboard')}
                        className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                            hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                            !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                        style={{ height: '36px', textDecoration: 'none' }}
                    >
                        {solution.buttonText}
                    </button>
                             ) : solution.title === "Underwriting Decision Support Assistant" ? (
                     <button
                         onClick={() => navigate('/customer/sandbox/underwriting-decision-support')}
                         className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                             hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                             !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                         style={{ height: '36px', textDecoration: 'none' }}
                     >
                         {solution.buttonText}
                     </button>
                             ) : solution.title === "Contact Centre Intelligence" ? (
                     <button
                         onClick={() => navigate('/customer/sandbox/insurance/cci-dashboard')}
                         className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                             hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                             !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                         style={{ height: '36px', textDecoration: 'none' }}
                     >
                         {solution.buttonText}
                     </button>
                             ) : solution.title === "Quicksight Executive Dashboard + GenAI Q&A" ? (
                     <button
                         onClick={() => navigate('/customer/sandbox/bankhome/chat-copilot')}
                         className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                             hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722]
                             !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                         style={{ height: '36px', textDecoration: 'none' }}
                     >
                         {solution.buttonText}
                     </button>
                ) : (
                    <Link
                        to={`/industryusecases/${solution.redirect}`}
                        className="text-center !w-full !px-4 !py-2 !bg-[#e87722] !text-white !rounded-md !text-xs !font-medium
                            hover:!bg-[#d0691d] focus:!outline-none !focus:ring-2 !focus:ring-[#e87722] 
                            !focus:ring-opacity-50 !transition-colors !duration-200 !no-underline"
                        style={{ height: '36px', textDecoration: 'none' }}
                    >
                        {solution.buttonText}
                    </Link>
                )}
            </div>
        </div>
    </Card>
</Col>
))}
                    </Row>
                </div>
                <Footer />

            </div>

    );
};

export default GenAISandboxHome;