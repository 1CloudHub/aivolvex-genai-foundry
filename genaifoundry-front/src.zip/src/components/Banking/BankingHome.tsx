import React, { useEffect, useState } from 'react';
import { Card, Typography, Row, Col, Divider, Button, Tooltip } from 'antd';
import { useAppContext } from '../../context/AppContext';
import {
    Mic ,
    Edit3 ,
    BarChart2 ,
    MessageSquare ,
    FileSearch ,
    Sparkles,
    Divide,
    Info,
    FileText,
    Home,
    ClipboardCheck,
    PieChart,
} from 'lucide-react';
import { Outlet, redirect } from "react-router-dom";
import { useNavigate,Link } from 'react-router-dom';
import LoginNavbar from '../layout/LoginNavbar';
import Footer from '../Banking/BankingFooter';
import HomeCard from '../ui/HomeCard';

const GenAISandboxHome = () => {
    const navigate = useNavigate();
    const [currentView, setCurrentView] = useState('home');
    const { projectType } = useAppContext();

    useEffect(() => {
        console.log("🔍 Current Project Type from Context:", projectType);
    }, [projectType]);

const solutions = [
  {
    title: 'Virtual Banking Assistant',
    area: 'Banking',
    icon: <MessageSquare size={24} />,
    description: 'AI-powered chatbot helping customers discover products, view account balances, and file service requests using RAG technology.',
    buttonText: 'Try Now',
    tags: ['Digital Banking', 'AI Chat'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'Virtual Banking Assistant',
      subheading: 'AI Chatbot for Banking Services',
      points: [
        'Discover banking products (savings, credit cards, loans)',
        'View account balances and transaction history',
        'File service requests and complaints',
        'Schedule agent callback',
        'Uses RAG and tool calling for accurate responses'
      ]
    }
  },
  {
    title: 'Voicebot with RAG Support',
    area: 'Contact Center',
    icon: <Sparkles size={24} />,
    description: 'Voice-enabled AI assistant that handles customer queries by retrieving answers from banking documents and policies in real-time.',
    buttonText: 'Explore',
    tags: ['Voice Banking', 'AI Support'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '🗣️',
      heading: 'Banking Voicebot with RAG',
      subheading: 'Voice AI for Banking Support',
      points: [
        'Handles customer queries via voice interface',
        'Retrieves answers from banking product documents',
        'Supports account procedures and banking policies',
        'Real-time voice interaction with customers'
      ]
    }
  },
  {
    title: 'Document Processing Assistant',
    area: 'Operations',
    icon: <FileText size={24} />,
    description: 'Extracts data from banking documents like account statements and loan applications.',
    buttonText: 'Try Now',
    tags: ['Document AI', 'KYC', 'Automation'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'Banking Document Processor',
      subheading: 'AI Document Extraction for Banking',
      points: [
        'Extracts data from account statements and loan applications',
        'Processes KYC documents and financial reports',
        'Supports account opening and loan processing workflows',
        'Automated document verification and data extraction'
      ]
    }
  },
  {
    title: 'RiskLens',
    area: 'Risk & Compliance',
    icon: <ClipboardCheck size={24} />,
    description: 'Automated risk assessment tool for personal loans, home loans, and credit card applications.',
    buttonText: 'Explore',
    tags: ['Risk Assessment', 'Risk AI'],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'Banking Risk Assessment',
      subheading: 'AI-Powered Credit Risk Analysis',
      points: [
        'Automated credit scoring for loan applications',
        'Risk factor identification and analysis',
        'Supports personal loans, home loans, and credit cards',
        'Intelligent underwriting decision support',
        'Real-time risk evaluation and recommendations'
      ]
    }
  },
  {
    title: 'Contact Centre Intelligence',
    area: 'Contact Center',
    icon: <BarChart2 size={24} />,
    description: 'Contact Centre Intelligence dashboard for banking operations with AI-powered call analysis, agent performance tracking',
    buttonText: 'Try Now',
    tags: ['Contact Center', 'AI Analytics' ],
    redirect: '#',
    type: 'component',
    tooltip: {
      icon: '',
      heading: 'CCI Dashboard',
      subheading: 'Contact Centre Intelligence for Banking',
      points: [
        'AI-powered call analysis and transcription',
        'Agent performance tracking and scoring',
        'Real-time sentiment analysis',
        'Issue tagging and categorization',
        'Performance dashboards and insights'
      ]
    }
  },
];

// Navigation handler for Banking solutions
const handleBankingNavigation = (solution: any) => {
  switch (solution.title) {
    case "Virtual Banking Assistant":
      navigate('/customer/sandbox/bankinghome/banking-assistant');
      break;
    case "Voicebot with RAG Support":
      navigate('/customer/sandbox/bankinghome/banking-voicebot');
      break;
    case "Document Processing Assistant":
      navigate('/customer/sandbox/bankinghome/bankdocument');
      break;
    case "RiskLens":
      navigate('/customer/sandbox/bankinghome/risklens');
      break;
    case "Contact Centre Intelligence":
      navigate('/customer/sandbox/bankinghome/cci-dashboard');
      break;
    case "Underwriting Decision Support Assistant":
      navigate('/customer/sandbox/underwriting-decision-support');
      break;
    default:
      // Handle default case or external links
      break;
  }
};

return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Login Navbar */}
        <LoginNavbar />
        
        {/* Spacing below navbar */}
        <div className="flex-grow px-15 mx-auto py-3">
            {/* Header Section */}
            <div className="text-center">
                <div className="flex flex-col items-center justify-center mt-8 mb-2">
                    <h1 className="text-5xl font-bold tracking-tight mb-2" style={{ fontFamily: 'Inter, sans-serif' }}>
                        <span style={{ color: '#e87722' }}>GenAI</span>
                        <span style={{ color: '#181f5a' }}> Sandbox</span>
                    </h1>
                </div>
                <div className="mb-8">
                    <span className="text-lg text-gray-700">
                        Explore AI-powered tools designed to transform business unit operations across industries.
                    </span>
                </div>
            </div>

            {/* Solution Cards Section */}
            <Row
                gutter={[16, 16]}
                justify="center"
                className="p-4"
                style={{ scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}
            >
                {solutions.map((solution, index) => (
                    <Col key={index} style={{ flex: "0 0 calc(20% - 16px)" }}>
                        <HomeCard
                            solution={solution}
                            cardHeight="h-[340px]"
                            buttonHeight="36px"
                            onNavigate={handleBankingNavigation}
                        />
                    </Col>
                ))}
            </Row>
        </div>
        <Footer />
    </div>
);

};

export default GenAISandboxHome;