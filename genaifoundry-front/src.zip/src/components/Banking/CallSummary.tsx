import React, { memo } from "react";
import { Col, Row, Tabs, Modal } from "antd";

import { mockCallSummaryRecords } from "./mockdata";


interface CallSummaryProps {
  postcallrecords?: any;
}

const CallSummary: React.FC<CallSummaryProps> = (props) => {
  const recordslist = mockCallSummaryRecords;
  const [historyOpen, setHistoryOpen] = React.useState(false);
  const [isModalVisible, setIsModalVisible] = React.useState(false);

  const showModalTicletModal = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancelTicket = () => {
    setIsModalVisible(false);
  };
  const showModal = () => {
    setHistoryOpen(true);
  };

  const handleCancel = () => {
    setHistoryOpen(false);
  };

  return (
    <>
      <Row>
        <Col span={24} className="pca-label-title" style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>Opportunity</Col>
        <TagList
          type="positive"
          recordslist={recordslist}
          historyOpen={historyOpen}
          showModal={showModal}
          handleCancel={handleCancel}
        />
      </Row>
      <Row style={{ marginTop: 24 }}>
        <Col span={24} className="pca-label-title" style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>Issue</Col>
        <TagList
          type="negative"
          recordslist={recordslist}
          historyOpen={historyOpen}
          showModal={showModal}
          handleCancel={handleCancel}
        />
      </Row>
    </>
  );
};

const TagList = (props: any) => {
  const filteredData = props.recordslist.filter(
    (entry: any) => entry.opportunity_status === props.type
  );
  
  return (
    <>
      <div className="pca-call-summary-tag-body">
        {filteredData.map((records: any) => {
          return (
            <Row className="pca-df mt-2" key={records.opportunity_tag}>
              <Col span={24} className="pca-label-title">
                <span
                  className={
                    props.type === "negative" ? "issue-tag" : "success-tag"
                  }
                >
                 {records.opportunity_tag}
                </span>
              </Col>
              <Col span={24} className="pca-label-content">
                {records.transcript}
              </Col>
            </Row>
          );
        })}
      </div>
    </>
  );
};

export default memo(CallSummary);
