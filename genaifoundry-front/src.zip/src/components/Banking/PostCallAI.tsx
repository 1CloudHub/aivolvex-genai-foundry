import { memo } from "react";
import Card from "react-bootstrap/Card";
import { mockPostCallRecords } from "./mockdata";
import "./postcallanalysis.scss";

const PostCallAI = () => {

  const postcallrecords = mockPostCallRecords;

    const CustomerProfile = () => {
    return (
      <div className="pca-customer-profile-grid">
        <div className="pca-customer-profile-row">
          <span className="pca-label-title">Customer Name:</span>
          <span className="pca-label-content">{postcallrecords.customer_name}</span>
        </div>
        <div className="pca-customer-profile-row">
          <span className="pca-label-title">Phone Number:</span>
          <span className="pca-label-content">{postcallrecords.phone_number}</span>
        </div>
        <div className="pca-customer-profile-row">
          <span className="pca-label-title">Account Number:</span>
          <span className="pca-label-content">{postcallrecords.account_number}</span>
        </div>
        <div className="pca-customer-profile-row">
          <span className="pca-label-title">Current Plan:</span>
          <span className="pca-label-content">{postcallrecords.current_plan}</span>
        </div>
        <div className="pca-customer-profile-row">
          <span className="pca-label-title">Joined Date:</span>
          <span className="pca-label-content">{postcallrecords.joined_date}</span>
        </div>
        <div className="pca-customer-profile-row">
          <span className="pca-label-title">Recent Tickets:</span>
          <span className="pca-label-content">{postcallrecords.recent_tickets}</span>
        </div>
        <div className="pca-customer-profile-row"></div>
        <div className="pca-customer-profile-row"></div>
        <div className="pca-customer-profile-row"></div>
        <div className="pca-customer-profile-row"></div>
      </div>
    );
  };

  return (
    // <Card> ... <Card.Header> ... <Card.Body> ... </Card>
    // Now just return the content for Card.Body
    <CustomerProfile />
  );
};

export default memo(PostCallAI);
