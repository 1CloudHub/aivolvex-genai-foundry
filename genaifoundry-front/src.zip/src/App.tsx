import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { NotificationProvider } from './hooks/useNotification';
import ProtectedRoute from './components/layout/ProtectedRoute';
import InsuranceHome from './components/Insurance/InsuranceHome';
import VirtualAssistant from './components/Insurance/VirtualAssistant';
import DocumentProcessingAssistant from './components/Insurance/DocumentProcessingAssistant';
import CciDashboard from './components/Insurance/AgentAssistantCallCopilotPage';
import CciDashboardBanking from './components/Banking/AgentAssistantCallCopilotPage';
import PostCallAnalysis from './components/Insurance/PostCallAnalysisInsurance';
import PostCallAnalysisBanking from './components/Banking/PostCallAnalysisInsurance';
import VoicebotRAGSupport from './components/Insurance/VoicebotRAGSupport';
import UnderwritingDecisionSupport from './components/Insurance/UnderwritingDecisionSupport';
import BankingHome from './components/Banking/BankingHome';
import BankingAssistant from './components/Banking/BankingAssistant';
import Risk from './components/Banking/Risk';
import BankingDocumentProcessing from './components/Banking/BankDocumentProcessing';
import BankingVoiceBot from './components/Banking/BankingVoiceBot';
import RetailHome from './pages/retail/Home';
import IntelligentDocumentProcessing from './pages/retail/IntelligentDocumentProcessing';
import VisualProductSearch from './pages/retail/VisualProductSearch';
import ProductOptimizationAssistant from './pages/retail/ProductOptimizationAssistant';
import RetailAssistant from './pages/retail/RetailAssistant';
import VisualContentVirtualTryOn from './pages/retail/VisualContentVirtualTryOn';
import HealthCareHome from './pages/HealthCare/HealthCareHome';
import HealthCareAssistant from './pages/HealthCare/HealthCareAssistant';
import ClinicalNoteGeneration from './pages/HealthCare/ClinicalNoteGeneration';
import HealthCareDocumentProcessing from './pages/HealthCare/HealthCareDocumentProcessing';
import MedicalCodingAssistant from './pages/HealthCare/MedicalCodingAssistant';
import DeepResearchAssistant from './pages/HealthCare/DeepResearchAssistant';

import CustomerLogin from './pages/Customer/CustomerLogin';
import { AppProvider } from './context/AppContext'; 



function App() {

  return (
    <AppProvider>
    <AuthProvider>
      <NotificationProvider>
      
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              {/* Public Routes */}
              <Route path="/login" element={<CustomerLogin />} />
              <Route path="/customer/login" element={<CustomerLogin />} />

              {/* Protected Routes with Layout */}

            <Route path="/customer/sandbox/insurance" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <InsuranceHome />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurancehome" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <InsuranceHome />
                </ProtectedRoute>
              } />

              
            <Route path="/customer/sandbox/bankinghome" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingHome />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurance/virtual-assistant" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <VirtualAssistant />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/bankinghome/banking-assistant" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingAssistant />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/bankinghome/risklens" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <Risk />
                </ProtectedRoute>
              } />
               <Route path="/customer/sandbox/bankinghome/bankdocument" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingDocumentProcessing />
                </ProtectedRoute>
              } />
              <Route path="/customer/sandbox/bankinghome/banking-voicebot" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingVoiceBot />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/bankinghome/cci-dashboard" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <CciDashboardBanking />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurance/document-processing" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <DocumentProcessingAssistant />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurance/cci-dashboard" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <CciDashboard />
                </ProtectedRoute>
              } />

             
              <Route path="/customer/sandbox/insurance/post-call-analysis/:sessionId" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <PostCallAnalysis />
                </ProtectedRoute>
              } />
               <Route path="/customer/sandbox/bankinghome/post-call-analysis/:sessionId" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <PostCallAnalysisBanking />
                </ProtectedRoute>
              } />


              <Route path="/customer/sandbox/insurance/voicebot-rag-support" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <VoicebotRAGSupport />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/underwriting-decision-support" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <UnderwritingDecisionSupport />
                </ProtectedRoute>
              } />
                      <Route path="/customer/sandbox/retailhome" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <RetailHome />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/retailhome/retail-assistant" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <RetailAssistant />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/retailhome/document-processing" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <IntelligentDocumentProcessing />
                </ProtectedRoute>
              } />
  
              <Route path="/customer/sandbox/retailhome/visual-product-search" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <VisualProductSearch />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/retailhome/visual-content-virtual-tryon" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <VisualContentVirtualTryOn />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/retailhome/product-optimization" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <ProductOptimizationAssistant />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/healthcarehome" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <HealthCareHome />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/healthcarehome/hospital-assistant" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <HealthCareAssistant />
                </ProtectedRoute>
              } />

                      <Route path="/customer/sandbox/healthcarehome/clinical-notes" element={
            <ProtectedRoute allowedRoles={['customer']}>
              <ClinicalNoteGeneration />
            </ProtectedRoute>
          } />
        <Route path="/customer/sandbox/healthcarehome/document-processing" element={
            <ProtectedRoute allowedRoles={['customer']}>
              <HealthCareDocumentProcessing />
            </ProtectedRoute>
          } />

        <Route path="/customer/sandbox/healthcarehome/medical-coding" element={
            <ProtectedRoute allowedRoles={['customer']}>
              <MedicalCodingAssistant />
            </ProtectedRoute>
          } />

        <Route path="/customer/sandbox/healthcarehome/research-assistant" element={
            <ProtectedRoute allowedRoles={['customer']}>
              <DeepResearchAssistant />
            </ProtectedRoute>
          } />

              
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </div>
        </Router>
      </NotificationProvider>
    </AuthProvider>
    </AppProvider>
  );
}

export default App;
