import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { NotificationProvider } from './hooks/useNotification';
import Sidebar from './components/layout/Sidebar';
import TopNavbar from './components/layout/TopNavbar';
import ProtectedRoute from './components/layout/ProtectedRoute';

import InsuranceHome from './components/Insurance/InsuranceHome';
import VirtualAssistant from './components/Insurance/VirtualAssistant';
import DocumentProcessingAssistant from './components/Insurance/DocumentProcessingAssistant';
import CciDashboard from './components/Insurance/AgentAssistantCallCopilotPage';
import CciDashboardBanking from './components/Banking/AgentAssistantCallCopilotPage';
import PostCallAnalysis from './components/Insurance/PostCallAnalysisInsurance';
import PostCallAnalysisBanking from './components/Banking/PostCallAnalysisInsurance';
import VoicebotRAGSupport from './components/Insurance/VoicebotRAGSupport';
import UnderwritingDecisionSupport from './components/Insurance/UnderwritingDecisionSupport';
import BankingHome from './components/Banking/BankingHome';
import BankingAssistant from './components/Banking/BankingAssistant';
import Risk from './components/Banking/Risk';
import BankingDocumentProcessing from './components/Banking/BankDocumentProcessing';
import BankingVoiceBot from './components/Banking/BankingVoiceBot';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard/Dashboard';
import EventDashboard from './pages/Events/EventDashboard';
import EventSetup from './pages/Events/EventSetup';
import CreditApproval from './pages/Events/CreditApproval';
import CustomerRegistration from './pages/Customers/CustomerRegistration';
import AttendeeTracker from './pages/Sales/AttendeeTracker';
import AttendeeStatus from './pages/Sales/AttendeeStatus';
import EmailTrigger from './pages/Sales/EmailTrigger';
import CustomerLogin from './pages/Customer/CustomerLogin';
import SandboxPreview from './pages/Customer/SandboxPreview';
import LaunchCTA from './pages/Customer/LaunchCTA';
import CustomerReports from './pages/Reports/CustomerReports';
import PublicRegistration from './pages/Customer/PublicRegistration';


function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <AuthProvider>
      <NotificationProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              {/* Public Routes */}
              <Route path="/login" element={<CustomerLogin />} />
              <Route path="/customer/login" element={<CustomerLogin />} />
              <Route path="/register" element={<PublicRegistration />} />

              {/* Protected Routes with Layout */}
              <Route path="/*" element={
                <ProtectedRoute>
                  <div className="flex">
                    <Sidebar collapsed={sidebarCollapsed} setCollapsed={setSidebarCollapsed} />
                    <div className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
                      <TopNavbar onSidebarToggle={() => setSidebarCollapsed((prev) => !prev)} />
                      <main className="pt-28 p-8 animate-fade-in">
                        <Routes>
                          {/* Dashboard Routes */}
                          <Route path="/dashboard" element={
                            <ProtectedRoute allowedRoles={['marketing', 'devops', 'sales']}>
                              <Dashboard />
                            </ProtectedRoute>
                          } />

                          {/* Event Routes */}
                          <Route path="/events" element={
                            <ProtectedRoute allowedRoles={['marketing', 'devops', 'sales']}>
                              <EventDashboard />
                            </ProtectedRoute>
                          } />

                          <Route path="/events/new" element={
                            <ProtectedRoute allowedRoles={['marketing']}>
                              <EventSetup />
                            </ProtectedRoute>
                          } />

                          <Route path="/events/:id/credit-check" element={
                            <ProtectedRoute allowedRoles={['devops', 'sales']}>
                              <CreditApproval />
                            </ProtectedRoute>
                          } />

                          {/* Customer Routes */}
                          <Route path="/customers/new" element={
                            <ProtectedRoute allowedRoles={['marketing', 'sales']}>
                              <CustomerRegistration />
                            </ProtectedRoute>
                          } />

                          {/* Sales Routes */}
                          <Route path="/events/:id/attendees" element={
                            <ProtectedRoute allowedRoles={['sales']}>
                              <AttendeeTracker />
                            </ProtectedRoute>
                          } />

                          <Route path="/attendees/:id/status" element={
                            <ProtectedRoute allowedRoles={['sales']}>
                              <AttendeeStatus />
                            </ProtectedRoute>
                          } />

                          <Route path="/attendees/:id/email" element={
                            <ProtectedRoute allowedRoles={['sales']}>
                              <EmailTrigger />
                            </ProtectedRoute>
                          } />

                          {/* Report Routes */}
                          <Route path="/reports/customers" element={
                            <ProtectedRoute allowedRoles={['marketing', 'sales']}>
                              <CustomerReports />
                            </ProtectedRoute>
                          } />

                          {/* Default Redirect */}
                          <Route path="/" element={<Navigate to="/dashboard" replace />} />
                        </Routes>
                      </main>
                    </div>
                  </div>
                </ProtectedRoute>
              } />

              {/* Customer Routes (separate layout) */}
              <Route path="/customer/sandbox" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <SandboxPreview />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurance" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <InsuranceHome />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurancehome" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <InsuranceHome />
                </ProtectedRoute>
              } />

              
            <Route path="/customer/sandbox/bankinghome" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingHome />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurance/virtual-assistant" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <VirtualAssistant />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/bankinghome/banking-assistant" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingAssistant />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/bankinghome/risklens" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <Risk />
                </ProtectedRoute>
              } />
               <Route path="/customer/sandbox/bankinghome/bankdocument" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingDocumentProcessing />
                </ProtectedRoute>
              } />
              <Route path="/customer/sandbox/bankinghome/banking-voicebot" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <BankingVoiceBot />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/bankinghome/cci-dashboard" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <CciDashboardBanking />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurance/document-processing" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <DocumentProcessingAssistant />
                </ProtectedRoute>
              } />

            <Route path="/customer/sandbox/insurance/cci-dashboard" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <CciDashboard />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/launch" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <LaunchCTA />
                </ProtectedRoute>
              } />

             
              <Route path="/customer/sandbox/insurance/post-call-analysis/:sessionId" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <PostCallAnalysis />
                </ProtectedRoute>
              } />
               <Route path="/customer/sandbox/bankinghome/post-call-analysis/:sessionId" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <PostCallAnalysisBanking />
                </ProtectedRoute>
              } />


              <Route path="/customer/sandbox/insurance/voicebot-rag-support" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <VoicebotRAGSupport />
                </ProtectedRoute>
              } />

              <Route path="/customer/sandbox/underwriting-decision-support" element={
                <ProtectedRoute allowedRoles={['customer']}>
                  <UnderwritingDecisionSupport />
                </ProtectedRoute>
              } />

              
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </div>
        </Router>
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;
