import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Users, Download, Filter, Search, Calendar, Building, Mail, Phone, Eye, CreditCard, Upload, CheckCircle, FileSpreadsheet, XCircle, Folder, Home, Send, MailX, Server, CloudOff } from 'lucide-react';
import EmailConfirmation from '../../components/ui/EmailConfirmation';
import CustomerDetailsModal from '../../components/ui/CustomerDetailsModal';
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbSeparator,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbHome,
} from '../../components/ui/breadcrumb';
import { useAuth } from '../../context/AuthContext';
import * as XLSX from 'xlsx';
import type { Customer } from '../../CustomerTypes';
import { Pagination, Card } from 'antd';
import 'antd/dist/reset.css';
import { useNotification } from '../../hooks/useNotification';

const mockCustomers: Customer[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john@techbank.com',
    phone: '+1 (555) 123-4567',
    company: 'TechBank Corp',
    jobTitle: 'VP of Technology',
    industry: 'Banking & Finance',
    eventId: '1',
    eventName: 'GenAI for Banking Summit',
    registrationDate: '2025-01-10',
    status: 'attended',
    salesQualified: true,
    interests: ['BankAssist Suite', 'PolicyPal Assistant'],
    mailSent: true,
    acctLaunched: false,
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah@insureco.com',
    phone: '+1 (555) 234-5678',
    company: 'InsureCo',
    jobTitle: 'Digital Innovation Manager',
    industry: 'Insurance',
    eventId: '1',
    eventName: 'GenAI for Banking Summit',
    registrationDate: '2025-01-12',
    status: 'attended',
    salesQualified: false,
    interests: ['PolicyPal Assistant'],
    mailSent: false,
    acctLaunched: true,
  },
  {
    id: '3',
    name: 'Mike Chen',
    email: 'mchen@retailplus.com',
    phone: '+1 (555) 345-6789',
    company: 'RetailPlus',
    jobTitle: 'CTO',
    industry: 'Retail & E-commerce',
    eventId: '2',
    eventName: 'Insurance AI Workshop',
    registrationDate: '2025-01-08',
    status: 'registered',
    salesQualified: false,
    interests: ['Product Vision Search'],
    mailSent: false,
    acctLaunched: false,
  }
];

const mockEvents = [
  { id: '1', name: 'GenAI for Banking Summit' },
  { id: '2', name: 'Insurance AI Workshop' },
  { id: '3', name: 'Retail AI Conference' }
];

// Hardcoded Excel data for sales notification
const HARDCODED_EXCEL_ROWS = [
  ['Name', 'Company'],
  ['Abishek', '1CH'],
  ['Rcikel', 'Google'],
  ['Walter', 'AWS'],
  ['Jon Snow', 'Flex'],
  ['Jesse', 'Micro'],
  ['Ramsey', 'Oracle'],
  ['Cersei', 'RedHat'],
];

export default function CustomerReports() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [customers] = useState(mockCustomers);
  const [filteredCustomers, setFilteredCustomers] = useState(mockCustomers);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEvent, setSelectedEvent] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('');
  const [customerForEmail, setCustomerForEmail] = useState<Customer | null>(null);
  const [customerForDetails, setCustomerForDetails] = useState<Customer | null>(null);
  const [previewData, setPreviewData] = useState<any[][] | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [uploadMessage, setUploadMessage] = useState('');
  const [excelNotification, setExcelNotification] = useState(user?.role === 'sales');
  const [showExcelModal, setShowExcelModal] = useState(false);
  const [excelRows, setExcelRows] = useState<any[][]>(user?.role === 'sales' ? HARDCODED_EXCEL_ROWS : []);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [uploadedCandidates, setUploadedCandidates] = useState<string[]>([]);
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [showUploadStatusModal, setShowUploadStatusModal] = useState(false);
  const [selectedCustomerIds, setSelectedCustomerIds] = useState<string[]>([]);
  const [showEmailNotification, setShowEmailNotification] = useState(false);
  const [mailSentFilter, setMailSentFilter] = useState('');
  const [acctLaunchedFilter, setAcctLaunchedFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [lastUploadedFile, setLastUploadedFile] = useState<{ fileName: string; uploadDate: string; previewData: any[][] } | null>(null);
  const [showUploadDetailsModal, setShowUploadDetailsModal] = useState(false);
  const { showNotification } = useNotification();

  const handleRegisterCustomer = () => {
    // Always use the selected event from the filter or query param for registration
    navigate(`/customers/new${selectedEvent ? `?eventId=${selectedEvent}` : ''}`);
  };

  React.useEffect(() => {
    let filtered = customers;

    if (searchTerm) {
      filtered = filtered.filter(customer =>
        customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.company.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedEvent) {
      filtered = filtered.filter(customer => customer.eventId === selectedEvent);
    }

    if (selectedStatus) {
      filtered = filtered.filter(customer => customer.status === selectedStatus);
    }

    if (selectedIndustry) {
      filtered = filtered.filter(customer => customer.industry === selectedIndustry);
    }

    if (mailSentFilter) {
      filtered = filtered.filter(customer =>
        mailSentFilter === 'sent' ? customer.mailSent : !customer.mailSent
      );
    }
    if (acctLaunchedFilter) {
      filtered = filtered.filter(customer =>
        acctLaunchedFilter === 'launched' ? customer.acctLaunched : !customer.acctLaunched
      );
    }

    setFilteredCustomers(filtered);
    setCurrentPage(1); // Reset to first page on filter change
  }, [customers, searchTerm, selectedEvent, selectedStatus, selectedIndustry, mailSentFilter, acctLaunchedFilter]);

  const getStatusBadge = (status: string) => {
    const baseClasses = "px-3 py-1 rounded-full text-xs font-medium";
    switch (status) {
      case 'registered':
        return `${baseClasses} bg-blue-100 text-blue-800`;
      case 'attended':
        return `${baseClasses} bg-green-100 text-green-800`;
      case 'no-show':
        return `${baseClasses} bg-red-100 text-red-800`;
      default:
        return baseClasses;
    }
  };

  const exportToCSV = () => {
    let headers = ['Name', 'Email', 'Phone', 'Company', 'Job Title', 'Industry', 'Event', 'Registration Date'];
    if (user?.role === 'sales') {
      headers.push('Mail Sent', 'Acct Launched');
    }
    const csvContent = [
      headers.join(','),
      ...filteredCustomers.map(customer => {
        const baseFields = [
          customer.name,
          customer.email,
          customer.phone,
          customer.company,
          customer.jobTitle,
          customer.industry,
          customer.eventName,
          customer.registrationDate
        ];
        if (user?.role === 'sales') {
          baseFields.push(customer.mailSent ? 'Yes' : 'No');
          baseFields.push(customer.acctLaunched ? 'Yes' : 'No');
        }
        return baseFields.join(',');
      })
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'customer-report.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const exportToJSON = () => {
    const jsonContent = JSON.stringify(filteredCustomers, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'customer-report.json';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const stats = {
    total: filteredCustomers.length,
    attended: filteredCustomers.filter(c => c.status === 'attended').length,
    qualified: filteredCustomers.filter(c => c.salesQualified).length,
    registered: filteredCustomers.filter(c => c.status === 'registered').length
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name); // Store the file name

    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = new Uint8Array(evt.target?.result as ArrayBuffer);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
      setPreviewData(json.slice(0, 10)); // Preview first 10 rows
      setShowPreview(true);
      // For marketing, store last uploaded file details
      if (user?.role === 'marketing') {
        setLastUploadedFile({
          fileName: file.name,
          uploadDate: new Date().toLocaleDateString(),
          previewData: json.slice(0, 10),
        });
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  };

  const handleUploadSubmit = () => {
    setShowPreview(false);
    setUploadMessage('The Excel/CSV has been uploaded for manual verification by the sales department.');
    showNotification('success', 'Upload Successful! Customer list has been uploaded successfully.');
    setTimeout(() => setUploadMessage(''), 5000);
  };

  // SALES: Open Excel modal
  const handleExcelIconClick = () => {
    setShowExcelModal(true);
    setSelectedRows([]);
    setSelectAll(false);
  };

  // SALES: Handle row selection
  const handleRowSelect = (idx: number) => {
    setSelectedRows((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  // SALES: Handle select all
  const handleSelectAll = () => {
    if (!excelRows || excelRows.length <= 1) return;
    if (selectAll) {
      setSelectedRows([]);
      setSelectAll(false);
    } else {
      setSelectedRows(excelRows.slice(1).map((_, idx) => idx));
      setSelectAll(true);
    }
  };

  // Helper for Excel import: ensure status is valid
  const validStatuses = ['registered', 'attended', 'no-show', 'pending'] as const;
  function toCustomer(row: any): Customer {
    return {
      id: row.id || crypto.randomUUID(),
      name: row.name,
      email: row.email,
      phone: row.phone,
      company: row.company,
      jobTitle: row.jobTitle,
      industry: row.industry,
      eventId: row.eventId,
      eventName: row.eventName,
      registrationDate: row.registrationDate,
      status: validStatuses.includes(row.status) ? row.status as Customer['status'] : 'registered',
      salesQualified: !!row.salesQualified,
      interests: Array.isArray(row.interests) ? row.interests : [],
      mailSent: !!row.mailSent,
      acctLaunched: !!row.acctLaunched,
    };
  }

  // SALES: Upload selected rows to customer list
  const handleSalesUpload = () => {
    if (!excelRows || selectedRows.length === 0) return;
    const headers = excelRows[0];
    let missingFields = false;
    const newCustomers: Customer[] = [];
    for (const idx of selectedRows) {
      const row = excelRows[idx + 1];
      // Map headers to row values
      const rowObj: Record<string, any> = {};
      (headers as string[]).forEach((header: string, i: number) => {
        rowObj[header.trim().toLowerCase().replace(/\s+/g, '')] = row[i];
      });
      // Prefill eventName for sales if not present
      let eventName = rowObj['eventname'] || rowObj['event'] || '';
      if (!eventName && user?.role === 'sales') {
        eventName = 'GenAI for Banking Summit';
      }
      // Check mandatory fields
      const name = rowObj['name'] || rowObj['customername'] || rowObj['customer'] || '';
      const company = rowObj['company'] || '';
      if (!name || !company || !eventName) {
        missingFields = true;
        break;
      }
      // Build customer object
      newCustomers.push(toCustomer({
        ...rowObj,
        name,
        company,
        eventName,
      }));
    }
    if (missingFields) {
      showNotification('error', 'Mandatory fields are required: Customer Name, Company, Event Name');
      return;
    }
    setFilteredCustomers((prev) => [...prev, ...newCustomers]);
    setShowExcelModal(false);
    setUploadMessage('Selected candidates have been uploaded and are now available in the customer list.');
    showNotification('success', 'Selected candidates have been uploaded and are now available in the customer list.');
    setExcelNotification(false);
    localStorage.removeItem('uploadedExcelData');
    setTimeout(() => setUploadMessage(''), 5000);
  };

  // Checkbox logic for sales
  const isAllSelected = filteredCustomers.length > 0 && selectedCustomerIds.length === filteredCustomers.length;
  const isIndeterminate = selectedCustomerIds.length > 0 && selectedCustomerIds.length < filteredCustomers.length;

  const handleSelectCustomer = (id: string) => {
    setSelectedCustomerIds((prev) =>
      prev.includes(id) ? prev.filter((cid) => cid !== id) : [...prev, id]
    );
  };

  const handleSelectAllCustomers = () => {
    if (isAllSelected) {
      setSelectedCustomerIds([]);
    } else {
      setSelectedCustomerIds(filteredCustomers.map((c) => c.id));
    }
  };

  const filters = [
    searchTerm,
    selectedEvent,
    selectedStatus,
    selectedIndustry,
    mailSentFilter,
    acctLaunchedFilter
  ];
  const activeFilterIndex = filters.findIndex(f => f && f !== '');

  const totalPages = Math.ceil(filteredCustomers.length / pageSize);
  const paginatedCustomers = filteredCustomers.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handlePageSizeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setPageSize(Number(e.target.value));
    setCurrentPage(1);
  };

  // Show notification instead of modal for email sent
  React.useEffect(() => {
    if (showEmailNotification) {
      showNotification('success', 'Mail has been forwarded to the Customers Successfully');
      setShowEmailNotification(false);
    }
  }, [showEmailNotification, showNotification]);

  return (
    <>
      {/* Modals and overlays at root level for correct overlay and centering */}
      {showPreview && previewData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/80">
          <div className="bg-white rounded-lg shadow-lg w-[700px] h-[400px] flex flex-col pointer-events-auto">
            <div className="flex items-center justify-between border-b px-6 py-4">
              <h2 className="text-xl font-bold">User List Preview</h2>
              <button onClick={() => setShowPreview(false)} className="text-gray-400 hover:text-gray-700 text-xl">&times;</button>
            </div>
            <div className="flex-1 overflow-auto px-6 py-4">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    {previewData[0].map((header, index) => (
                      <th key={index} className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider border-b">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {previewData.slice(1).map((row, index) => (
                    <tr key={index} className="hover:bg-gray-50 transition-colors duration-200">
                      {row.map((cell, cellIndex) => (
                        <td key={cellIndex} className="px-4 py-2 whitespace-nowrap">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="border-t px-6 py-4 flex justify-end">
              <button
                onClick={handleUploadSubmit}
                className="px-5 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors duration-200 font-semibold"
              >
                Upload
              </button>
            </div>
          </div>
        </div>
      )}

      {showExcelModal && excelRows.length > 1 && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/80">
          <div className="relative pointer-events-auto">
            <div className="bg-white rounded-lg shadow-lg w-[700px] h-[400px] flex flex-col">
              <div className="flex items-center justify-between border-b px-6 py-4">
                <h2 className="text-xl font-bold">Registered Customer Data</h2>
                <button onClick={() => setShowExcelModal(false)} className="text-gray-400 hover:text-gray-700 text-xl">&times;</button>
              </div>
              <div className="flex-1 overflow-auto px-6 py-4">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th>
                        <input
                          type="checkbox"
                          checked={selectAll}
                          onChange={handleSelectAll}
                        />
                      </th>
                      {excelRows[0].map((header: any, index: number) => (
                        <th key={index} className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider border-b">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {excelRows.slice(1).map((row: any[], idx: number) => (
                      <tr key={idx} className="hover:bg-gray-50 transition-colors duration-200">
                        <td>
                          <input
                            type="checkbox"
                            checked={selectedRows.includes(idx)}
                            onChange={() => handleRowSelect(idx)}
                          />
                        </td>
                        {row.map((cell, cellIndex) => (
                          <td key={cellIndex} className="px-4 py-2 whitespace-nowrap">
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="border-t px-6 py-4 flex justify-end">
                <button
                  onClick={handleSalesUpload}
                  className="px-5 py-2 rounded-md font-semibold"
                  style={{ background: '#ec580c', color: '#fff' }}
                >
                  Upload
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showUploadDetailsModal && lastUploadedFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/80">
          <div className="relative pointer-events-auto">
            <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-xl transition-all sm:my-8 w-full max-w-lg mx-auto" style={{ minHeight: '20rem', maxHeight: '32rem', width: '32rem', overflow: 'auto', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div className="bg-white px-8 pb-6 pt-6 overflow-y-auto" style={{ maxHeight: '24rem' }}>
                <div className="flex items-center mb-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-blue-100">
                    <FileSpreadsheet className="h-6 w-6 text-blue-600" aria-hidden="true" />
                  </div>
                  <h3 className="ml-3 text-lg font-semibold leading-6 text-gray-900" id="modal-title">
                      Uploaded User's List
                    </h3>
                </div>
                <div className="overflow-x-auto rounded-lg border border-gray-200">
                  <table className="min-w-full text-sm">
                          <thead className="bg-gray-50">
                            <tr>
                              {lastUploadedFile.previewData[0].map((header, idx) => (
                          <th key={idx} className="px-5 py-3 text-left font-semibold text-gray-700 uppercase tracking-wider border-b border-gray-200 bg-gray-50">
                                  {header}
                                </th>
                              ))}
                            </tr>
                          </thead>
                    <tbody className="bg-white divide-y divide-gray-100">
                            {lastUploadedFile.previewData.slice(1).map((row, idx) => (
                              <tr key={idx} className="hover:bg-gray-50 transition-colors duration-200">
                                {row.map((cell, cellIdx) => (
                            <td key={cellIdx} className="px-5 py-3 text-left whitespace-nowrap text-gray-900">
                                    {cell}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                <div className="flex justify-end mt-6">
                <button
                  type="button"
                    className="inline-flex justify-center rounded-md bg-orange-500 px-5 py-2 text-sm font-semibold text-white shadow-sm hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-400"
                  onClick={() => setShowUploadDetailsModal(false)}
                >
                  Close
                </button>
              </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main page content below modals */}
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
        <div className="mb-2">
              <Breadcrumb>
                <BreadcrumbList className="flex items-center text-base font-semibold gap-0">
                  <BreadcrumbItem className="flex items-center">
                    <BreadcrumbLink to="/">
                      <span className="inline-flex items-center align-middle">
                        <Home className="h-4 w-4 mr-1 text-gray-700 align-middle mb-1" />
                        <span className="text-gray-700 font-semibold align-middle"></span>
                      </span>
                    </BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbSeparator>
                    <span className="mx-1 text-gray-400 text-lg font-bold">/</span>
                  </BreadcrumbSeparator>
                  <BreadcrumbItem className="flex items-center">
                    <BreadcrumbLink to="/events" className="text-gray-700 hover:text-orange-600 font-semibold">Events</BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbSeparator>
                    <span className="mx-1 text-gray-400 text-lg font-bold">/</span>
                  </BreadcrumbSeparator>
                  <BreadcrumbItem className="flex items-center">
                    <BreadcrumbPage className="text-orange-600 font-semibold">Customer Reports</BreadcrumbPage>
                  </BreadcrumbItem>
                </BreadcrumbList>
              </Breadcrumb>
            </div>
            <h1 className="text-3xl font-medium text-gray-900 mb-2">Customer Reports</h1>
          
            {/* <p className="text-gray-600 mt-2">View and analyze customer registration data</p> */}
        </div>
        <div className="flex items-center space-x-2">
          {user?.role === 'sales' && (
            <button
              onClick={handleExcelIconClick}
              className="relative p-2 rounded-full text-green-600 hover:bg-green-100 transition-colors duration-200"
              title="View Uploaded Excel"
            >
              <FileSpreadsheet className="h-6 w-6" />
              {excelRows.length > 1 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">
                  {excelRows.length - 1}
                </span>
              )}
            </button>
          )}

          {/* MARKETING: Excel icon before Export JSON */}
          {user?.role === 'marketing' && lastUploadedFile && (
            <button
              onClick={() => setShowUploadDetailsModal(true)}
              className="p-2 rounded-full text-green-600 hover:bg-green-100 transition-colors duration-200"
              title="View Uploaded Excel"
            >
              <FileSpreadsheet className="h-6 w-6" />
            </button>
          )}

          <button
            onClick={exportToCSV}
            className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
          >
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </button>

          {user?.role === 'marketing' && (
            <>
              <button
                onClick={() => document.getElementById('excel-upload-input')?.click()}
                className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 text-orange-600 rounded-lg hover:bg-orange-50 transition-colors duration-200"
              >
                <Upload className="h-4 w-4 mr-2" />
                Upload User's List
              </button>
              <input
                id="excel-upload-input"
                type="file"
                accept=".xlsx,.csv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </>
          )}

          {user?.role !== 'marketing' && (
            <button
              onClick={handleRegisterCustomer}
              className="inline-flex items-center px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors duration-200"
            >
              <Users className="h-4 w-4 mr-2" />
              Register Customer
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex flex-col w-full">
          <div className="w-full overflow-x-auto">
            <div className="flex flex-row flex-nowrap gap-4 items-center w-full min-w-[700px]">
              <span className="flex items-center gap-2">
                <Filter className="h-5 w-5 text-gray-400" />
                <div className="relative w-56">
              <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                placeholder="Search customers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
              </span>
              <span className="flex items-center gap-2">
                <Filter className="h-5 w-5 text-gray-400 md:hidden" />
            <select
              value={selectedEvent}
              onChange={(e) => setSelectedEvent(e.target.value)}
                  className="w-48 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
            >
              <option value="">All Events</option>
              {mockEvents.map((event) => (
                <option key={event.id} value={event.id}>{event.name}</option>
              ))}
            </select>
              </span>
              <span className="flex items-center gap-2">
                <Filter className="h-5 w-5 text-gray-400 md:hidden" />
            <select
              value={selectedIndustry}
              onChange={(e) => setSelectedIndustry(e.target.value)}
                  className="w-48 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
            >
              <option value="">All Industries</option>
              <option value="Banking & Finance">Banking & Finance</option>
              <option value="Insurance">Insurance</option>
              <option value="Retail & E-commerce">Retail & E-commerce</option>
              <option value="Healthcare">Healthcare</option>
            </select>
              </span>
            {user?.role === 'sales' && (
              <>
                  <span className="flex items-center gap-2">
                    <Filter className="h-5 w-5 text-gray-400 md:hidden" />
                <select
                  value={mailSentFilter}
                  onChange={(e) => setMailSentFilter(e.target.value)}
                      className="w-40 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="" disabled hidden>Mail Status</option>
                  <option value="sent">Sent</option>
                  <option value="not_sent">Not Sent</option>
                </select>
                  </span>
                  <span className="flex items-center gap-2">
                    <Filter className="h-5 w-5 text-gray-400 md:hidden" />
                <select
                  value={acctLaunchedFilter}
                  onChange={(e) => setAcctLaunchedFilter(e.target.value)}
                      className="w-40 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="" disabled hidden>Acct Status</option>
                  <option value="launched">Launched</option>
                  <option value="not_launched">Not Launched</option>
                </select>
                  </span>
              </>
            )}
            </div>
          </div>
          <div className="flex justify-end w-full mt-4">
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setSelectedEvent('');
                setSelectedStatus('');
                setSelectedIndustry('');
                setMailSentFilter('');
                setAcctLaunchedFilter('');
              }}
              disabled={activeFilterIndex === -1}
              className={`px-3 py-2 text-sm rounded-md border transition ${activeFilterIndex === -1 ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-orange-500 text-white hover:bg-orange-600'}`}
              style={{ width: '8rem', height: '2.6rem' }}
            >
              Clear Filter
            </button>
          </div>
        </div>
      </div>

      {/* Customer Table */}
      <Card bordered={false} style={{ boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900">
            Customer List 
          </h2>
          {user?.role === 'sales' && (
            <button
              onClick={() => setShowEmailNotification(true)}
              disabled={selectedCustomerIds.length === 0}
              className={`inline-flex items-center px-4 py-2 rounded-lg font-semibold shadow transition-colors duration-200
                ${selectedCustomerIds.length === 0
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  : 'bg-orange-500 text-white hover:bg-orange-600'}
              `}
            >
              <Mail className="h-5 w-5 mr-2" />
              Send Email
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                {user?.role === 'sales' && (
                  <th className="pl-4">
                    <input
                      type="checkbox"
                      checked={isAllSelected}
                      ref={el => { if (el) el.indeterminate = isIndeterminate; }}
                      onChange={handleSelectAllCustomers}
                    />
                  </th>
                )}
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Event
                </th>
                {user?.role === 'sales' && (
                  <>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mail Sent</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acct Launched</th>
                  </>
                )}
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
                {paginatedCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={user?.role === 'sales' ? 7 : 5} className="py-16 text-center text-gray-500">
                      <span className="flex flex-col items-center justify-center gap-2">
                        <Folder className="mx-auto h-10 w-10 text-gray-300" />
                        <span className="text-lg font-semibold">No data available</span>

                      </span>
                    </td>
                  </tr>
                ) : (
                  paginatedCustomers.map((customer) => (
                <tr key={customer.id} className="hover:bg-gray-50 transition-colors duration-200">
                  {user?.role === 'sales' && (
                    <td className="pl-4">
                      <input
                        type="checkbox"
                        checked={selectedCustomerIds.includes(customer.id)}
                        onChange={() => handleSelectCustomer(customer.id)}
                      />
                    </td>
                  )}
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                      <div className="text-sm text-gray-500">{customer.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{customer.company}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{customer.eventName}</div>
                  </td>
                  {user?.role === 'sales' && (
                    <>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {customer.mailSent ? (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full border border-green-200 bg-green-50 text-green-700 font-semibold">
                            <Send className="h-4 w-4 text-green-400" />
                            Sent
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full border border-red-200 bg-red-50 text-red-600 font-semibold">
                            <MailX className="h-4 w-4 text-red-300" />
                            Pending
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {customer.acctLaunched ? (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full border border-blue-200 bg-blue-50 text-blue-700 font-semibold">
                            <Server className="h-4 w-4 text-blue-400" />
                            Launched
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full border border-gray-300 bg-gray-100 text-gray-600 font-semibold">
                            <CloudOff className="h-4 w-4 text-gray-300" />
                            Pending
                          </span>
                        )}
                      </td>
                    </>
                  )}
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex items-center space-x-4">
                    <button
                      onClick={() => setCustomerForDetails(customer)}
                      className="flex items-center text-orange-600 hover:text-orange-800 font-semibold transition-colors duration-200"
                      title="View Details"
                    >
                      <Eye className="h-5 w-5 mr-1" />
                      View
                    </button>
                    {user?.role !== 'marketing' && (
                      <button
                        onClick={() => setCustomerForEmail(customer)}
                        className="flex items-center text-blue-600 hover:text-blue-800 font-semibold transition-colors duration-200"
                        title="Preview Launch Email"
                      >
                        <Mail className="h-5 w-5 mr-1" />
                        Email
                      </button>
                    )}
                  </td>
                </tr>
                  ))
                )}
            </tbody>
          </table>
        </div>
        <div className="custom-pagination-bar flex items-center justify-between mt-4">
          <div className="flex items-center gap-3">
            <span className="font-semibold" style={{fontSize: '14px'}}>Rows per page</span>
            <select
              className="rounded-lg border border-gray-200 px-4 py-2 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
              value={pageSize}
              onChange={handlePageSizeChange}
            >
              {[5, 10, 20, 50].map(size => (
                <option key={size} value={size}>{size}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-semibold" style={{fontSize: '14px'}}>Page {currentPage} of {totalPages}</span>
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
            >{'<<'}</button>
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(currentPage - 1)}
              disabled={currentPage === 1}
            >{'<'}</button>
            <input
              type="number"
              min={1}
              max={totalPages}
              value={currentPage}
              onChange={e => {
                let val = Number(e.target.value);
                if (val < 1) val = 1;
                if (val > totalPages) val = totalPages;
                setCurrentPage(val);
              }}
              className="w-12 text-center border border-gray-200 rounded-lg px-2 py-1 mx-1 shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-400"
            />
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >{'>'}</button>
            <button
              className="rounded-md px-2 py-1 text-gray-500 hover:bg-gray-100 disabled:opacity-50"
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages}
            >{'>>'}</button>
          </div>
        </div>
      </Card>

      {customerForEmail && (
        <EmailConfirmation
          customerData={{
            name: customerForEmail.name,
            email: customerForEmail.email,
            company: customerForEmail.company,
            eventName: customerForEmail.eventName,
            eventDate: customerForEmail.registrationDate
          }}
          onClose={() => setCustomerForEmail(null)}
        />
      )}

      {customerForDetails && (
        <CustomerDetailsModal
          customer={customerForDetails}
          onClose={() => setCustomerForDetails(null)}
        />
      )}
            </div>
    </>
  );
}