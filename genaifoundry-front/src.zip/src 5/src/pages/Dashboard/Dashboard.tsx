import React from 'react';
import { useAuth } from '../../context/AuthContext';
import MarketingDashboard from './MarketingDashboard';
import DevOpsDashboard from './DevOpsDashboard';
import SalesDashboard from './SalesDashboard';

export default function Dashboard() {
  const { user } = useAuth();

  if (!user) return null;

  switch (user.role) {
    case 'marketing':
      return <MarketingDashboard />;
    case 'devops':
      return <DevOpsDashboard />;
    case 'sales':
      return <SalesDashboard />;
    default:
      return (
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
          <p className="text-gray-600 mt-2">Welcome to your dashboard</p>
        </div>
      );
  }
}