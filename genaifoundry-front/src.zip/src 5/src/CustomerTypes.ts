export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  jobTitle: string;
  industry: string;
  eventId: string;
  eventName: string;
  registrationDate: string;
  status: 'registered' | 'attended' | 'no-show' | 'pending';
  salesQualified: boolean;
  interests: string[];
  mailSent?: boolean;
  acctLaunched?: boolean;
} 